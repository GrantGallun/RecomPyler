"""Probe live alias changes against an explicit unchanged compiler source tree."""
import hashlib
import json
import os
from pathlib import Path
import sys

here = Path(__file__).resolve().parent
repo = Path(sys.argv[1]).resolve()
label = sys.argv[2]
os.environ["RECOMPYLER_CACHE"] = str(here / (label + "-cache"))
os.environ["NUMBA_CACHE_DIR"] = str(here / (label + "-numba"))
sys.path[:0] = [str(repo / "src"), str(here.parent / "wave8-header-fix" / "tests")]
from recompyler import heap
from test_heap_header_indices import State, len_then_append

heap._cached_module = lambda source: None
rows = []
for native in (False, True):
    heap.NATIVE = native
    region = heap.lift_region(len_then_append)
    warm_state, warm_alias = State([10.0]), [10.0]
    warm_result = region(warm_state, warm_alias)
    state = State([10.0])
    alias = state.values
    actual = region(state, alias)
    program = region.latest
    field_kind = program.fields[program.family(State)]["values"]
    argument_kind = program.entry.vars["alias"]
    rows.append({"native_loader": native, "warm_result": warm_result, "actual_result": actual,
                 "actual_state": vars(state), "actual_alias": alias,
                 "same_list": state.values is alias,
                 "counts": [region.compiled_calls, region.fallback_calls],
                 "field_kind_mutated": heap._find(field_kind.cell).mutated,
                 "argument_kind_mutated": heap._find(argument_kind.cell).mutated})
report = {"compiler": str(repo), "heap_sha256": hashlib.sha256(Path(heap.__file__).read_bytes()).hexdigest(),
          "rows": rows, "note": "Read-only frozen source. Warm call has distinct lists, next call aliases field and argument. Native values are correct; writeback is skipped by first-loaded field kind."}
(here / (label + ".json")).write_text(json.dumps(report, indent=2), encoding="utf-8")
print(json.dumps(report, indent=2))
