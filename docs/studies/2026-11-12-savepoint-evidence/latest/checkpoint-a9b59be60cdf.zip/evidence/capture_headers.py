"""Retain exact JIT predicate bodies and distinguish shared-read evidence."""
import hashlib
import json
from pathlib import Path
import re
import sys

here = Path(__file__).resolve().parent
repo = here.parent / "wave8-header-fix"
sys.path[:0] = [str(repo / "src"), str(repo / "tests")]
from recompyler import heap
from test_heap_header_indices import len_one_first, truth_item

out = here / sys.argv[1]
out.mkdir(exist_ok=False)
heap._cached_module = lambda source: None
rows = []
for function, args in [(len_one_first, ([2.5],)), (truth_item, ([1.5, 2.5], -1))]:
    region = heap.lift_region(function)
    assert region(*args) == 2.5 and region.compiled_calls == 1, region.problem
    body = region.latest.run
    signature = body.signatures[0]
    symbol = body.overloads[signature].fndesc.llvm_func_name
    llvm = body.inspect_llvm(signature)
    native = next(block.split("\n}", 1)[0] for block in llvm.split("define ")[1:]
                  if "@" + symbol + "(" in block.splitlines()[0])
    for suffix, value in [("source.py", region.latest.source), ("ll", llvm),
                          ("native.ll", "define " + native + "\n}\n"), ("asm", body.inspect_asm(signature))]:
        (out / (function.__name__ + "." + suffix)).write_text(value, encoding="utf-8")
    rows.append({"function": function.__name__, "symbol": symbol, "signature": str(signature),
                 "digest": region.latest.digest,
                 "arena_shape_uses": [line for line in native.splitlines()[1:]
                                      if re.search(r"%arg\.[FI]\.(?:2|5\.0)(?:\.\d+)?\b", line)],
                 "i64_load_lines": len(re.findall(r"\bload i64\b", native)),
                 "item_error_stores": len(re.findall(r"\bstore i8 1\b", native)),
                 "dynamic_signed_comparison": bool(re.search(
                     r"icmp s[lg][te] i64 %arg\.v_index(?:\.\d+)?\b", native))})
report = {"kind": "actual-jit-fixtures-not-workload-aot", "fixtures": rows,
          "inputs": {name: hashlib.sha256((repo / name).read_bytes()).hexdigest() for name in (
              "src/recompyler/heap.py", "src/recompyler/lift.py", "src/recompyler/_region_seed.py",
              "src/recompyler/_heap.c", "src/recompyler/_heap.cp314-win_amd64.pyd",
              "tests/test_heap_header_indices.py")},
          "files_sha256": {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir()}}
(out / "report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
print(json.dumps([{key: row[key] for key in ("function", "i64_load_lines", "item_error_stores",
                                            "dynamic_signed_comparison")}
                  | {"arena_shape_uses": len(row["arena_shape_uses"])} for row in rows]))
