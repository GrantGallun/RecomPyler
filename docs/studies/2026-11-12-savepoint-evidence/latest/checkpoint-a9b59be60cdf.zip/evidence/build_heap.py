"""Build only the task-owned _heap extension and retain source/command/output."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

here = Path(__file__).resolve().parent
repo = here.parent / "wave8-header-fix"
out = here / "native-heap-build"
out.mkdir(exist_ok=False)
for name in ("temp", "lib", "tmp"):
    (out / name).mkdir()
source = repo / "src/recompyler/_heap.c"
binary = repo / "src/recompyler/_heap.cp314-win_amd64.pyd"
monitor = repo / "src/recompyler/_monitor.cp314-win_amd64.pyd"
before_source = hashlib.sha256(source.read_bytes()).hexdigest()
before_monitor = hashlib.sha256(monitor.read_bytes()).hexdigest()
before_binary = hashlib.sha256(binary.read_bytes()).hexdigest()
code = ("from setuptools import setup, Extension; "
        "setup(ext_modules=[Extension('recompyler._heap', ['src/recompyler/_heap.c'])], "
        f"script_args={['build_ext', '--inplace', '--build-temp', str(out / 'temp'), '--build-lib', str(out / 'lib')]!r})")
command = [sys.executable, "-c", code]
env = dict(os.environ, TMP=str(out / "tmp"), TEMP=str(out / "tmp"))
done = subprocess.run(command, cwd=repo, env=env, capture_output=True, timeout=180)
(out / "stdout.bin").write_bytes(done.stdout)
(out / "stderr.bin").write_bytes(done.stderr)
assert done.returncode == 0, done.stderr.decode(errors="replace")
assert before_source == hashlib.sha256(source.read_bytes()).hexdigest()
assert before_monitor == hashlib.sha256(monitor.read_bytes()).hexdigest()
probe_code = "import json; from recompyler import _heap; print(json.dumps({'file':_heap.__file__,'version':_heap.LOAD_CONTRACTS_VERSION}))"
probe = subprocess.run([sys.executable, "-c", probe_code], cwd=repo,
                       env=dict(env, PYTHONPATH=str(repo / "src")), capture_output=True, timeout=30)
(out / "probe.stdout.bin").write_bytes(probe.stdout)
(out / "probe.stderr.bin").write_bytes(probe.stderr)
assert probe.returncode == 0, probe.stderr.decode(errors="replace")
feature = json.loads(probe.stdout.splitlines()[-1])
assert Path(feature["file"]).resolve() == binary.resolve() and feature["version"] == 1
report = {"command": command, "cwd": str(repo), "environment": {"TMP": env["TMP"], "TEMP": env["TEMP"]},
          "source_sha256": before_source, "old_binary_sha256": before_binary,
          "binary_sha256": hashlib.sha256(binary.read_bytes()).hexdigest(),
          "monitor_sha256_unchanged": before_monitor, "capability": feature,
          "exit_code": done.returncode, "source_unchanged_during_build": True,
          "stdout_sha256": hashlib.sha256(done.stdout).hexdigest(),
          "stderr_sha256": hashlib.sha256(done.stderr).hexdigest()}
(out / "report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
print(done.stdout.decode(errors="replace"))
print(json.dumps(report, indent=2))
