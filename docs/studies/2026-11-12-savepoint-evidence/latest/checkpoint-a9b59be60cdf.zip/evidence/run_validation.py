"""Run one approved validation command with exact inputs and byte output retained."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

here = Path(__file__).resolve().parent
repo = here.parent / "wave8-header-fix"
label, *args = sys.argv[1:]
out = here / label
out.mkdir(exist_ok=False)
files = [p for directory in (repo / "src", repo / "tests") for p in directory.rglob("*")
         if p.is_file() and p.suffix in (".py", ".c", ".h", ".pyd")]
before = {str(p.relative_to(repo)): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
command = [sys.executable, "-m", "pytest", *args]
manifest = {"command": command, "cwd": str(repo), "python": sys.version,
            "environment_override": {"PYTHONPATH": str(repo / "src")}, "inputs_sha256": before}
(out / "inputs.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
start = time.perf_counter()
done = subprocess.run(command, cwd=repo, env=dict(os.environ, PYTHONPATH=str(repo / "src")),
                      capture_output=True, timeout=900)
seconds = time.perf_counter() - start
(out / "stdout.bin").write_bytes(done.stdout)
(out / "stderr.bin").write_bytes(done.stderr)
after = {str(p.relative_to(repo)): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
result = {"exit_code": done.returncode, "wall_seconds_including_test_startup": seconds,
          "inputs_unchanged": before == after,
          "stdout_sha256": hashlib.sha256(done.stdout).hexdigest(),
          "stderr_sha256": hashlib.sha256(done.stderr).hexdigest()}
(out / "result.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
print(done.stdout.decode("utf-8", errors="replace"))
if done.stderr:
    print(done.stderr.decode("utf-8", errors="replace"), file=sys.stderr)
assert result["inputs_unchanged"], "validation inputs changed while tests ran"
raise SystemExit(done.returncode)
