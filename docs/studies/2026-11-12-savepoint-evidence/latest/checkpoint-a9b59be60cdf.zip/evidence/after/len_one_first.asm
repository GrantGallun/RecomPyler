	.file	"<string>"
	.section	.rodata.cst8,"aM",@progbits,8
	.p2align	3, 0x0
.LCPI0_0:
	.quad	0xbff0000000000000
	.section	.ltext,"axl",@progbits
	.globl	_ZN26recompyler_generated_heap016f0_len_one_firstB3v11B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedEx
	.p2align	4
	.type	_ZN26recompyler_generated_heap016f0_len_one_firstB3v11B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedEx,@function
_ZN26recompyler_generated_heap016f0_len_one_firstB3v11B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedEx:
	movq	248(%rsp), %rax
	movq	112(%rsp), %rdx
	cmpq	$1, (%rdx,%rax,8)
	jne	.LBB0_1
	movq	56(%rsp), %r8
	movq	16(%rdx,%rax,8), %rax
	vmovsd	(%r8,%rax,8), %xmm0
	xorl	%eax, %eax
	vmovsd	%xmm0, (%rcx)
	retq
.LBB0_1:
	movabsq	$.LCPI0_0, %rax
	vmovsd	(%rax), %xmm0
	xorl	%eax, %eax
	vmovsd	%xmm0, (%rcx)
	retq
.Lfunc_end0:
	.size	_ZN26recompyler_generated_heap016f0_len_one_firstB3v11B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedEx, .Lfunc_end0-_ZN26recompyler_generated_heap016f0_len_one_firstB3v11B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedEx

	.globl	_ZN7cpython26recompyler_generated_heap016f0_len_one_firstB3v11B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedEx
	.p2align	4
	.type	_ZN7cpython26recompyler_generated_heap016f0_len_one_firstB3v11B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedEx,@function
_ZN7cpython26recompyler_generated_heap016f0_len_one_firstB3v11B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedEx:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%r13
	.cfi_def_cfa_offset 32
	pushq	%r12
	.cfi_def_cfa_offset 40
	pushq	%rsi
	.cfi_def_cfa_offset 48
	pushq	%rdi
	.cfi_def_cfa_offset 56
	pushq	%rbp
	.cfi_def_cfa_offset 64
	pushq	%rbx
	.cfi_def_cfa_offset 72
	subq	$584, %rsp
	vmovaps	%xmm6, 560(%rsp)
	.cfi_def_cfa_offset 656
	.cfi_offset %rbx, -72
	.cfi_offset %rbp, -64
	.cfi_offset %rdi, -56
	.cfi_offset %rsi, -48
	.cfi_offset %r12, -40
	.cfi_offset %r13, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	.cfi_offset %xmm6, -96
	movq	%rdx, %rcx
	leaq	272(%rsp), %r8
	leaq	280(%rsp), %rdx
	leaq	264(%rsp), %rax
	movl	$5, %r9d
	movq	%r8, 56(%rsp)
	movq	%rdx, 48(%rsp)
	leaq	288(%rsp), %r8
	leaq	296(%rsp), %rdx
	movq	%rax, 64(%rsp)
	movabsq	$PyArg_UnpackTuple, %rax
	movq	%r8, 40(%rsp)
	movq	%rdx, 32(%rsp)
	movabsq	$.const.f0_len_one_first, %rdx
	movl	$5, %r8d
	callq	*%rax
	testl	%eax, %eax
	je	.LBB1_1
	movabsq	$_ZN08NumbaEnv26recompyler_generated_heap016f0_len_one_firstB3v11B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedEx, %rax
	cmpq	$0, (%rax)
	je	.LBB1_4
	movq	296(%rsp), %rcx
	movabsq	$NRT_adapt_ndarray_from_python, %r14
	leaq	368(%rsp), %rdx
	vxorps	%xmm0, %xmm0, %xmm0
	vmovups	%ymm0, 368(%rsp)
	vmovups	%ymm0, 392(%rsp)
	vzeroupper
	callq	*%r14
	testl	%eax, %eax
	jne	.LBB1_8
	cmpq	$8, 392(%rsp)
	jne	.LBB1_8
	movq	288(%rsp), %rcx
	movq	368(%rsp), %rsi
	movq	400(%rsp), %r13
	leaq	304(%rsp), %rdx
	vxorps	%xmm0, %xmm0, %xmm0
	vmovups	%ymm0, 304(%rsp)
	vmovups	%ymm0, 328(%rsp)
	vzeroupper
	callq	*%r14
	testl	%eax, %eax
	jne	.LBB1_11
	cmpq	$8, 328(%rsp)
	jne	.LBB1_11
	movq	280(%rsp), %rcx
	movq	304(%rsp), %rdi
	movq	336(%rsp), %rbp
	leaq	496(%rsp), %rdx
	vxorps	%xmm0, %xmm0, %xmm0
	vmovups	%ymm0, 496(%rsp)
	vmovups	%ymm0, 520(%rsp)
	vzeroupper
	callq	*%r14
	testl	%eax, %eax
	jne	.LBB1_14
	cmpq	$8, 520(%rsp)
	jne	.LBB1_14
	movq	272(%rsp), %rcx
	movq	496(%rsp), %rbx
	leaq	432(%rsp), %rdx
	vxorps	%xmm0, %xmm0, %xmm0
	vmovups	%ymm0, 432(%rsp)
	vmovups	%ymm0, 456(%rsp)
	vzeroupper
	callq	*%r14
	testl	%eax, %eax
	jne	.LBB1_19
	cmpq	$1, 456(%rsp)
	jne	.LBB1_19
	movq	264(%rsp), %rcx
	movq	432(%rsp), %r14
	movabsq	$PyNumber_Long, %rax
	callq	*%rax
	testq	%rax, %rax
	je	.LBB1_21
	movq	%rax, %r12
	movabsq	$PyLong_AsLongLong, %rax
	movq	%r12, %rcx
	callq	*%rax
	movq	%rax, %r15
	movabsq	$Py_DecRef, %rax
	movq	%r12, %rcx
	callq	*%rax
	movabsq	$PyErr_Occurred, %rax
	callq	*%rax
	testq	%rax, %rax
	jne	.LBB1_22
.LBB1_26:
	movabsq	$_ZN26recompyler_generated_heap016f0_len_one_firstB3v11B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedEx, %rax
	leaq	256(%rsp), %rcx
	movq	%r15, 240(%rsp)
	movq	%rbp, 104(%rsp)
	movq	%r13, 48(%rsp)
	callq	*%rax
	vmovsd	256(%rsp), %xmm6
	movabsq	$NRT_decref, %r15
	movq	%rsi, %rcx
	callq	*%r15
	movq	%rdi, %rcx
	callq	*%r15
	movq	%rbx, %rcx
	callq	*%r15
	movq	%r14, %rcx
	callq	*%r15
	movabsq	$PyFloat_FromDouble, %rax
	vmovaps	%xmm6, %xmm0
	callq	*%rax
.LBB1_2:
	vmovaps	560(%rsp), %xmm6
	addq	$584, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	retq
.LBB1_4:
	movabsq	$PyExc_RuntimeError, %rcx
	movabsq	$".const.missing Environment: _ZN08NumbaEnv26recompyler_generated_heap016f0_len_one_firstB3v11B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedEx", %rdx
	jmp	.LBB1_5
.LBB1_8:
	movabsq	$PyExc_TypeError, %rcx
	movabsq	$".const.can't unbox array from PyObject into native value.  The object maybe of a different type", %rdx
.LBB1_5:
	movabsq	$PyErr_SetString, %rax
	callq	*%rax
	jmp	.LBB1_1
.LBB1_11:
	movabsq	$PyExc_TypeError, %rcx
	movabsq	$".const.can't unbox array from PyObject into native value.  The object maybe of a different type", %rdx
	movabsq	$PyErr_SetString, %rax
	callq	*%rax
	jmp	.LBB1_16
.LBB1_14:
	movabsq	$PyExc_TypeError, %rcx
	movabsq	$".const.can't unbox array from PyObject into native value.  The object maybe of a different type", %rdx
	movabsq	$PyErr_SetString, %rax
	callq	*%rax
	jmp	.LBB1_15
.LBB1_19:
	movabsq	$PyExc_TypeError, %rcx
	movabsq	$".const.can't unbox array from PyObject into native value.  The object maybe of a different type", %rdx
	movabsq	$PyErr_SetString, %rax
	callq	*%rax
	jmp	.LBB1_23
.LBB1_21:
	xorl	%r15d, %r15d
	movabsq	$PyErr_Occurred, %rax
	callq	*%rax
	testq	%rax, %rax
	je	.LBB1_26
.LBB1_22:
	movabsq	$NRT_decref, %rax
	movq	%r14, %rcx
	callq	*%rax
.LBB1_23:
	movabsq	$NRT_decref, %rax
	movq	%rbx, %rcx
	callq	*%rax
.LBB1_15:
	movabsq	$NRT_decref, %rax
	movq	%rdi, %rcx
	callq	*%rax
.LBB1_16:
	movabsq	$NRT_decref, %rax
	movq	%rsi, %rcx
	callq	*%rax
.LBB1_1:
	xorl	%eax, %eax
	jmp	.LBB1_2
.Lfunc_end1:
	.size	_ZN7cpython26recompyler_generated_heap016f0_len_one_firstB3v11B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedEx, .Lfunc_end1-_ZN7cpython26recompyler_generated_heap016f0_len_one_firstB3v11B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedEx
	.cfi_endproc

	.globl	cfunc._ZN26recompyler_generated_heap016f0_len_one_firstB3v11B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedEx
	.p2align	4
	.type	cfunc._ZN26recompyler_generated_heap016f0_len_one_firstB3v11B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedEx,@function
cfunc._ZN26recompyler_generated_heap016f0_len_one_firstB3v11B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedEx:
	subq	$264, %rsp
	movq	304(%rsp), %rax
	movq	360(%rsp), %rcx
	movq	496(%rsp), %rdx
	movq	%rcx, 104(%rsp)
	movq	%rax, 48(%rsp)
	movabsq	$_ZN26recompyler_generated_heap016f0_len_one_firstB3v11B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedEx, %rax
	leaq	256(%rsp), %rcx
	movq	%rdx, 240(%rsp)
	callq	*%rax
	vmovsd	256(%rsp), %xmm0
	addq	$264, %rsp
	retq
.Lfunc_end2:
	.size	cfunc._ZN26recompyler_generated_heap016f0_len_one_firstB3v11B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedEx, .Lfunc_end2-cfunc._ZN26recompyler_generated_heap016f0_len_one_firstB3v11B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedEx

	.weak	NRT_decref
	.p2align	4
	.type	NRT_decref,@function
NRT_decref:
	.cfi_startproc
	testq	%rcx, %rcx
	je	.LBB3_2
	#MEMBARRIER
	lock		decq	(%rcx)
	je	.LBB3_3
.LBB3_2:
	retq
.LBB3_3:
	movabsq	$NRT_MemInfo_call_dtor, %rax
	#MEMBARRIER
	rex64 jmpq	*%rax
.Lfunc_end3:
	.size	NRT_decref, .Lfunc_end3-NRT_decref
	.cfi_endproc

	.type	.const.f0_len_one_first,@object
	.section	.lrodata,"al",@progbits
	.p2align	4, 0x0
.const.f0_len_one_first:
	.asciz	"f0_len_one_first"
	.size	.const.f0_len_one_first, 17

	.type	_ZN08NumbaEnv26recompyler_generated_heap016f0_len_one_firstB3v11B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedEx,@object
	.comm	_ZN08NumbaEnv26recompyler_generated_heap016f0_len_one_firstB3v11B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedEx,8,8
	.type	".const.missing Environment: _ZN08NumbaEnv26recompyler_generated_heap016f0_len_one_firstB3v11B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedEx",@object
	.p2align	4, 0x0
".const.missing Environment: _ZN08NumbaEnv26recompyler_generated_heap016f0_len_one_firstB3v11B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedEx":
	.asciz	"missing Environment: _ZN08NumbaEnv26recompyler_generated_heap016f0_len_one_firstB3v11B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedEx"
	.size	".const.missing Environment: _ZN08NumbaEnv26recompyler_generated_heap016f0_len_one_firstB3v11B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedEx", 259

	.type	".const.can't unbox array from PyObject into native value.  The object maybe of a different type",@object
	.p2align	4, 0x0
".const.can't unbox array from PyObject into native value.  The object maybe of a different type":
	.asciz	"can't unbox array from PyObject into native value.  The object maybe of a different type"
	.size	".const.can't unbox array from PyObject into native value.  The object maybe of a different type", 89

	.section	".note.GNU-stack","",@progbits
