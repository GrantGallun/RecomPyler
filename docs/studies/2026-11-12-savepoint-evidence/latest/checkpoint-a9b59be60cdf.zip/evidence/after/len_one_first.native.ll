define noundef i32 @_ZN26recompyler_generated_heap016f0_len_one_firstB3v11B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedEx(ptr noalias writeonly captures(none) initializes((0, 8)) %retptr, ptr noalias readnone captures(none) %excinfo, ptr readnone captures(none) %arg.F.0, ptr readnone captures(none) %arg.F.1, i64 %arg.F.2, i64 %arg.F.3, ptr readonly captures(none) %arg.F.4, i64 %arg.F.5.0, i64 %arg.F.6.0, ptr readnone captures(none) %arg.I.0, ptr readnone captures(none) %arg.I.1, i64 %arg.I.2, i64 %arg.I.3, ptr readonly captures(none) %arg.I.4, i64 %arg.I.5.0, i64 %arg.I.6.0, ptr readnone captures(none) %arg.top.0, ptr readnone captures(none) %arg.top.1, i64 %arg.top.2, i64 %arg.top.3, ptr readnone captures(none) %arg.top.4, i64 %arg.top.5.0, i64 %arg.top.6.0, ptr readnone captures(none) %arg.st.0, ptr readnone captures(none) %arg.st.1, i64 %arg.st.2, i64 %arg.st.3, ptr readnone captures(none) %arg.st.4, i64 %arg.st.5.0, i64 %arg.st.6.0, i64 %arg.v_values) local_unnamed_addr #0 {
B0:
  %.89 = getelementptr i64, ptr %arg.I.4, i64 %arg.v_values
  %.90 = load i64, ptr %.89, align 8
  %.91 = icmp eq i64 %.90, 1
  br i1 %.91, label %B218, label %common.ret

common.ret:                                       ; preds = %B0, %B218
  %storemerge = phi double [ %.323, %B218 ], [ -1.000000e+00, %B0 ]
  store double %storemerge, ptr %retptr, align 8
  ret i32 0

B218:                                             ; preds = %B0
  %sunkaddr = mul i64 %arg.v_values, 8
  %sunkaddr1 = getelementptr i8, ptr %arg.I.4, i64 %sunkaddr
  %sunkaddr2 = getelementptr i8, ptr %sunkaddr1, i64 16
  %.287 = load i64, ptr %sunkaddr2, align 8
  %.322 = getelementptr double, ptr %arg.F.4, i64 %.287
  %.323 = load double, ptr %.322, align 8
  br label %common.ret
}
