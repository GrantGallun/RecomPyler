define noundef i32 @_ZN26recompyler_generated_heap113f0_truth_itemB3v12B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedExx(ptr noalias writeonly captures(none) initializes((0, 8)) %retptr, ptr noalias readnone captures(none) %excinfo, ptr readnone captures(none) %arg.F.0, ptr readnone captures(none) %arg.F.1, i64 %arg.F.2, i64 %arg.F.3, ptr readonly captures(none) %arg.F.4, i64 %arg.F.5.0, i64 %arg.F.6.0, ptr readnone captures(none) %arg.I.0, ptr readnone captures(none) %arg.I.1, i64 %arg.I.2, i64 %arg.I.3, ptr readonly captures(none) %arg.I.4, i64 %arg.I.5.0, i64 %arg.I.6.0, ptr readnone captures(none) %arg.top.0, ptr readnone captures(none) %arg.top.1, i64 %arg.top.2, i64 %arg.top.3, ptr writeonly captures(none) %arg.top.4, i64 %arg.top.5.0, i64 %arg.top.6.0, ptr readnone captures(none) %arg.st.0, ptr readnone captures(none) %arg.st.1, i64 %arg.st.2, i64 %arg.st.3, ptr writeonly captures(none) %arg.st.4, i64 %arg.st.5.0, i64 %arg.st.6.0, i64 %arg.v_values, i64 %arg.v_index) local_unnamed_addr #0 {
B0:
  %.92 = getelementptr i64, ptr %arg.I.4, i64 %arg.v_values
  %.93 = load i64, ptr %.92, align 8
  %.94.not = icmp eq i64 %.93, 0
  br i1 %.94.not, label %common.ret, label %B82

B82:                                              ; preds = %B0
  %.138 = icmp slt i64 %arg.v_index, 0
  br i1 %.138, label %B176, label %B188

B176:                                             ; preds = %B82
  %.142 = add nsw i64 %.93, %arg.v_index
  %.151 = icmp slt i64 %.142, 0
  br i1 %.151, label %B202, label %B188

B188:                                             ; preds = %B82, %B176
  %t3.2.0243 = phi i64 [ %.142, %B176 ], [ %arg.v_index, %B82 ]
  %.155.not = icmp slt i64 %t3.2.0243, %.93
  br i1 %.155.not, label %B226, label %B202

common.ret:                                       ; preds = %B0, %B226, %B202
  %.sink = phi double [ 0.000000e+00, %B202 ], [ %.339, %B226 ], [ -1.000000e+00, %B0 ]
  store double %.sink, ptr %retptr, align 8
  ret i32 0

B202:                                             ; preds = %B188, %B176
  store i8 1, ptr %arg.st.4, align 1
  %.254 = getelementptr i8, ptr %arg.top.4, i64 24
  store i64 3, ptr %.254, align 8
  br label %common.ret

B226:                                             ; preds = %B188
  %sunkaddr = mul i64 %arg.v_values, 8
  %sunkaddr1 = getelementptr i8, ptr %arg.I.4, i64 %sunkaddr
  %sunkaddr2 = getelementptr i8, ptr %sunkaddr1, i64 16
  %.303 = load i64, ptr %sunkaddr2, align 8
  %0 = getelementptr double, ptr %arg.F.4, i64 %.303
  %.338 = getelementptr double, ptr %0, i64 %t3.2.0243
  %.339 = load double, ptr %.338, align 8
  br label %common.ret
}
