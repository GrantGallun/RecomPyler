# Inherited live-alias writeback finding

The new two-line header annotation passes both actual native fixtures and all 16 JIT semantic cases. A separate fresh AOT case fails its caller-state assertion: native code returns the correct `(2, 99.0)` after append, but the original shared list remains `[10.0]`; the object's counter updates to 1.

The artifact/section from the failing run is preserved in `aot-first-failure/`; `header-green/` retains exact command, all inputs and raw output. No GREEN or complete claim is made for that 19-case run.

## Baseline reproduction

`repro_alias_writeback.py ../wave8-runtime-fix baseline-411-alias` was run with bytecode writes disabled against the untouched measured 411 compiler. Both Python/native loaders reproduce the same behavior on cached JIT code after a warm call with distinct lists, followed by a call sharing a list through an object field and a separate argument. Compiler heap SHA256 is the frozen `81e6a9a153a3da3adec8914dbf8e73b734da0d27149314cf2bbccd42aee2e106`. `baseline-411-alias.json` records two successful compiled calls, zero fallback, correct native result and stale caller list.

The field's list cell is marked `mutated=False`; the alias argument's separate list cell is `mutated=True`. Both `_Loader.list` and native `load_list` return the existing handle when the same live object has already been loaded. Their retained list record keeps the first encountered kind. `_Unloader.write_back` skips a list whenever that retained kind's cell is not marked mutated. This loses the second alias contract's mutation information.

This failure predates the new header casts and concerns dynamic alias patterns between type contracts. Native state observes the write correctly, so it is separate from commoning a header read across an actual append/pop. The existing JIT semantic test starts with the shared alias and passes; the fresh AOT test trained with distinct lists and exposes the reuse case.

## Scope boundary

Do not silently change training inputs to hide the failure or claim the failing AOT case passed. A remedy needs independent review of first-seen alias contracts under both loaders, including metadata/writeback and possibly compatibility validation for a second kind. Known-handle short-circuiting also appears to bypass validation of a second alias's different type layout; that broader risk is a static concern here, not an additional executed reproduction. Blanket writeback or changing handle identity is not established safe by this finding.

No loader, unloader, seed, native extension or other product code has been edited as part of this diagnosis. The new header worker's only product diff remains the authorized two lines. Root has been notified for an explicit scope decision.

## Resolution after explicit scope authorization

The paragraph above records the initial diagnosis stage. Root subsequently authorized the separately reviewed cached-contract safety repair, including concrete object/dict/set/ndarray failures. Commit `0a8b1768324af2092bd973baabae1409a1c01521` rejects unsupported repeated contracts before native entry; it does not merge mutation flags or write back unchecked data. Captured same-contract aliases and cycles retain native execution. Header commit `a9b59be60cdf568c8f6b63442e7efa88fd16fdd2` then reapplies only the two proved header casts.

The original failing unseen-alias AOT control remains: a valid distinct-input AOT warm call is followed by the shared live alias, which now takes safe Python fallback with no additional entry into the old native export and correct state. The final 572-test suite passed on unchanged frozen inputs. See `VALIDATION.md` and the checkpoint receipt. Old 411 source, binary and evidence remain unchanged.
