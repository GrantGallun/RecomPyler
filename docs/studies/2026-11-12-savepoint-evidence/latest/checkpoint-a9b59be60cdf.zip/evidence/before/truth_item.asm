	.file	"<string>"
	.section	.rodata.cst8,"aM",@progbits,8
	.p2align	3, 0x0
.LCPI0_0:
	.quad	0xbff0000000000000
	.section	.ltext,"axl",@progbits
	.globl	_ZN26recompyler_generated_heap113f0_truth_itemB3v12B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedExx
	.p2align	4
	.type	_ZN26recompyler_generated_heap113f0_truth_itemB3v12B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedExx,@function
_ZN26recompyler_generated_heap113f0_truth_itemB3v12B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedExx:
	movq	248(%rsp), %rax
	movq	%rax, %rdx
	sarq	$63, %rdx
	shlq	$3, %rax
	andq	120(%rsp), %rdx
	addq	112(%rsp), %rax
	cmpq	$0, (%rax,%rdx,8)
	je	.LBB0_1
	movq	256(%rsp), %rdx
	movq	(%rax), %r8
	testq	%rdx, %rdx
	jns	.LBB0_4
	addq	%r8, %rdx
	js	.LBB0_5
.LBB0_4:
	cmpq	%r8, %rdx
	jge	.LBB0_5
	movq	56(%rsp), %r8
	movq	16(%rax), %rax
	leaq	(%r8,%rax,8), %rax
	vmovsd	(%rax,%rdx,8), %xmm0
	xorl	%eax, %eax
	vmovsd	%xmm0, (%rcx)
	retq
.LBB0_1:
	movabsq	$.LCPI0_0, %rax
	vmovsd	(%rax), %xmm0
	xorl	%eax, %eax
	vmovsd	%xmm0, (%rcx)
	retq
.LBB0_5:
	movq	224(%rsp), %rax
	movq	168(%rsp), %rdx
	vxorps	%xmm0, %xmm0, %xmm0
	movb	$1, (%rax)
	movq	$3, 24(%rdx)
	xorl	%eax, %eax
	vmovsd	%xmm0, (%rcx)
	retq
.Lfunc_end0:
	.size	_ZN26recompyler_generated_heap113f0_truth_itemB3v12B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedExx, .Lfunc_end0-_ZN26recompyler_generated_heap113f0_truth_itemB3v12B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedExx

	.globl	_ZN7cpython26recompyler_generated_heap113f0_truth_itemB3v12B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedExx
	.p2align	4
	.type	_ZN7cpython26recompyler_generated_heap113f0_truth_itemB3v12B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedExx,@function
_ZN7cpython26recompyler_generated_heap113f0_truth_itemB3v12B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedExx:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%r13
	.cfi_def_cfa_offset 32
	pushq	%r12
	.cfi_def_cfa_offset 40
	pushq	%rsi
	.cfi_def_cfa_offset 48
	pushq	%rdi
	.cfi_def_cfa_offset 56
	pushq	%rbp
	.cfi_def_cfa_offset 64
	pushq	%rbx
	.cfi_def_cfa_offset 72
	subq	$648, %rsp
	vmovaps	%xmm6, 624(%rsp)
	.cfi_def_cfa_offset 720
	.cfi_offset %rbx, -72
	.cfi_offset %rbp, -64
	.cfi_offset %rdi, -56
	.cfi_offset %rsi, -48
	.cfi_offset %r12, -40
	.cfi_offset %r13, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	.cfi_offset %xmm6, -96
	movq	%rdx, %rcx
	leaq	328(%rsp), %rdx
	leaq	336(%rsp), %r8
	leaq	320(%rsp), %rax
	movl	$6, %r9d
	movq	%rdx, 64(%rsp)
	leaq	344(%rsp), %rdx
	movq	%r8, 56(%rsp)
	leaq	352(%rsp), %r8
	movq	%rax, 72(%rsp)
	movabsq	$PyArg_UnpackTuple, %rax
	movq	%rdx, 48(%rsp)
	leaq	360(%rsp), %rdx
	movq	%r8, 40(%rsp)
	movl	$6, %r8d
	movq	%rdx, 32(%rsp)
	movabsq	$.const.f0_truth_item, %rdx
	callq	*%rax
	movq	$0, 288(%rsp)
	testl	%eax, %eax
	je	.LBB1_1
	movabsq	$_ZN08NumbaEnv26recompyler_generated_heap113f0_truth_itemB3v12B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedExx, %rax
	cmpq	$0, (%rax)
	je	.LBB1_4
	movq	360(%rsp), %rcx
	movabsq	$NRT_adapt_ndarray_from_python, %rbx
	leaq	560(%rsp), %rdx
	vxorps	%xmm0, %xmm0, %xmm0
	vmovups	%ymm0, 560(%rsp)
	vmovups	%ymm0, 584(%rsp)
	vzeroupper
	callq	*%rbx
	testl	%eax, %eax
	jne	.LBB1_8
	cmpq	$8, 584(%rsp)
	jne	.LBB1_8
	movq	352(%rsp), %rcx
	movq	560(%rsp), %r14
	movq	592(%rsp), %rdi
	leaq	368(%rsp), %rdx
	vxorps	%xmm0, %xmm0, %xmm0
	vmovups	%ymm0, 368(%rsp)
	vmovups	%ymm0, 392(%rsp)
	vzeroupper
	callq	*%rbx
	testl	%eax, %eax
	jne	.LBB1_11
	cmpq	$8, 392(%rsp)
	jne	.LBB1_11
	movq	344(%rsp), %rcx
	movq	368(%rsp), %rsi
	movq	400(%rsp), %r12
	movq	408(%rsp), %r13
	leaq	496(%rsp), %rdx
	vxorps	%xmm0, %xmm0, %xmm0
	vmovups	%ymm0, 496(%rsp)
	vmovups	%ymm0, 520(%rsp)
	vzeroupper
	callq	*%rbx
	testl	%eax, %eax
	jne	.LBB1_14
	cmpq	$8, 520(%rsp)
	jne	.LBB1_14
	movq	336(%rsp), %rcx
	movq	496(%rsp), %r15
	movq	528(%rsp), %rbp
	leaq	432(%rsp), %rdx
	vxorps	%xmm0, %xmm0, %xmm0
	vmovups	%ymm0, 432(%rsp)
	vmovups	%ymm0, 456(%rsp)
	vzeroupper
	callq	*%rbx
	testl	%eax, %eax
	jne	.LBB1_19
	cmpq	$1, 456(%rsp)
	jne	.LBB1_19
	movq	432(%rsp), %rax
	movq	328(%rsp), %rcx
	movq	464(%rsp), %rbx
	movq	%r13, 296(%rsp)
	movabsq	$PyNumber_Long, %r13
	movq	%r12, 304(%rsp)
	movq	%r15, 272(%rsp)
	movq	%rdi, 312(%rsp)
	movq	%rsi, 280(%rsp)
	movq	%rax, 264(%rsp)
	callq	*%r13
	movabsq	$PyLong_AsLongLong, %rdi
	movabsq	$Py_DecRef, %rsi
	movq	%r14, 256(%rsp)
	testq	%rax, %rax
	je	.LBB1_21
	movq	%rax, %rcx
	movq	%rax, %r12
	callq	*%rdi
	movq	%r12, %rcx
	movq	%rax, %r15
	callq	*%rsi
	movabsq	$PyErr_Occurred, %r14
	callq	*%r14
	testq	%rax, %rax
	jne	.LBB1_22
.LBB1_26:
	movq	320(%rsp), %rcx
	callq	*%r13
	testq	%rax, %rax
	je	.LBB1_27
	movq	%rax, %rcx
	movq	%rax, %r13
	callq	*%rdi
	movq	%r13, %rcx
	movq	%rax, %r12
	callq	*%rsi
	callq	*%r14
	testq	%rax, %rax
	jne	.LBB1_22
.LBB1_30:
	movq	296(%rsp), %rax
	movq	312(%rsp), %rcx
	movq	304(%rsp), %r10
	movq	%r12, 248(%rsp)
	movq	%r15, 240(%rsp)
	movq	%rbx, 216(%rsp)
	movq	%rbp, 160(%rsp)
	movq	%rax, 112(%rsp)
	movq	%rcx, 48(%rsp)
	movabsq	$_ZN26recompyler_generated_heap113f0_truth_itemB3v12B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedExx, %rax
	leaq	288(%rsp), %rcx
	movq	%r10, 104(%rsp)
	callq	*%rax
	vmovsd	288(%rsp), %xmm6
	movq	256(%rsp), %rcx
	movabsq	$NRT_decref, %rsi
	callq	*%rsi
	movq	280(%rsp), %rcx
	callq	*%rsi
	movq	272(%rsp), %rcx
	callq	*%rsi
	movq	264(%rsp), %rcx
	callq	*%rsi
	movabsq	$PyFloat_FromDouble, %rax
	vmovaps	%xmm6, %xmm0
	callq	*%rax
.LBB1_2:
	vmovaps	624(%rsp), %xmm6
	addq	$648, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	retq
.LBB1_4:
	movabsq	$PyExc_RuntimeError, %rcx
	movabsq	$".const.missing Environment: _ZN08NumbaEnv26recompyler_generated_heap113f0_truth_itemB3v12B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedExx", %rdx
	jmp	.LBB1_5
.LBB1_8:
	movabsq	$PyExc_TypeError, %rcx
	movabsq	$".const.can't unbox array from PyObject into native value.  The object maybe of a different type", %rdx
.LBB1_5:
	movabsq	$PyErr_SetString, %rax
	callq	*%rax
	jmp	.LBB1_1
.LBB1_11:
	movabsq	$PyExc_TypeError, %rcx
	movabsq	$".const.can't unbox array from PyObject into native value.  The object maybe of a different type", %rdx
	movabsq	$PyErr_SetString, %rax
	callq	*%rax
	jmp	.LBB1_16
.LBB1_14:
	movabsq	$PyExc_TypeError, %rcx
	movabsq	$".const.can't unbox array from PyObject into native value.  The object maybe of a different type", %rdx
	movabsq	$PyErr_SetString, %rax
	callq	*%rax
	jmp	.LBB1_15
.LBB1_19:
	movabsq	$PyExc_TypeError, %rcx
	movabsq	$".const.can't unbox array from PyObject into native value.  The object maybe of a different type", %rdx
	movabsq	$PyErr_SetString, %rax
	callq	*%rax
	jmp	.LBB1_23
.LBB1_21:
	xorl	%r15d, %r15d
	movabsq	$PyErr_Occurred, %r14
	callq	*%r14
	testq	%rax, %rax
	je	.LBB1_26
	jmp	.LBB1_22
.LBB1_27:
	xorl	%r12d, %r12d
	callq	*%r14
	testq	%rax, %rax
	je	.LBB1_30
.LBB1_22:
	movq	264(%rsp), %rcx
	movabsq	$NRT_decref, %rax
	callq	*%rax
	movq	256(%rsp), %r14
	movq	280(%rsp), %rsi
	movq	272(%rsp), %r15
.LBB1_23:
	movabsq	$NRT_decref, %rax
	movq	%r15, %rcx
	callq	*%rax
.LBB1_15:
	movabsq	$NRT_decref, %rax
	movq	%rsi, %rcx
	callq	*%rax
.LBB1_16:
	movabsq	$NRT_decref, %rax
	movq	%r14, %rcx
	callq	*%rax
.LBB1_1:
	xorl	%eax, %eax
	jmp	.LBB1_2
.Lfunc_end1:
	.size	_ZN7cpython26recompyler_generated_heap113f0_truth_itemB3v12B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedExx, .Lfunc_end1-_ZN7cpython26recompyler_generated_heap113f0_truth_itemB3v12B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedExx
	.cfi_endproc

	.globl	cfunc._ZN26recompyler_generated_heap113f0_truth_itemB3v12B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedExx
	.p2align	4
	.type	cfunc._ZN26recompyler_generated_heap113f0_truth_itemB3v12B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedExx,@function
cfunc._ZN26recompyler_generated_heap113f0_truth_itemB3v12B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedExx:
	subq	$264, %rsp
	vmovaps	496(%rsp), %xmm1
	vmovups	360(%rsp), %xmm0
	movq	304(%rsp), %rax
	movq	416(%rsp), %rcx
	movq	472(%rsp), %rdx
	vmovups	%xmm1, 240(%rsp)
	movq	%rcx, 160(%rsp)
	movq	%rdx, 216(%rsp)
	vmovups	%xmm0, 104(%rsp)
	movq	%rax, 48(%rsp)
	movabsq	$_ZN26recompyler_generated_heap113f0_truth_itemB3v12B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedExx, %rax
	leaq	256(%rsp), %rcx
	callq	*%rax
	vmovsd	256(%rsp), %xmm0
	addq	$264, %rsp
	retq
.Lfunc_end2:
	.size	cfunc._ZN26recompyler_generated_heap113f0_truth_itemB3v12B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedExx, .Lfunc_end2-cfunc._ZN26recompyler_generated_heap113f0_truth_itemB3v12B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedExx

	.weak	NRT_decref
	.p2align	4
	.type	NRT_decref,@function
NRT_decref:
	.cfi_startproc
	testq	%rcx, %rcx
	je	.LBB3_2
	#MEMBARRIER
	lock		decq	(%rcx)
	je	.LBB3_3
.LBB3_2:
	retq
.LBB3_3:
	movabsq	$NRT_MemInfo_call_dtor, %rax
	#MEMBARRIER
	rex64 jmpq	*%rax
.Lfunc_end3:
	.size	NRT_decref, .Lfunc_end3-NRT_decref
	.cfi_endproc

	.type	.const.f0_truth_item,@object
	.section	.lrodata,"al",@progbits
.const.f0_truth_item:
	.asciz	"f0_truth_item"
	.size	.const.f0_truth_item, 14

	.type	_ZN08NumbaEnv26recompyler_generated_heap113f0_truth_itemB3v12B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedExx,@object
	.comm	_ZN08NumbaEnv26recompyler_generated_heap113f0_truth_itemB3v12B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedExx,8,8
	.type	".const.missing Environment: _ZN08NumbaEnv26recompyler_generated_heap113f0_truth_itemB3v12B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedExx",@object
	.p2align	4, 0x0
".const.missing Environment: _ZN08NumbaEnv26recompyler_generated_heap113f0_truth_itemB3v12B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedExx":
	.asciz	"missing Environment: _ZN08NumbaEnv26recompyler_generated_heap113f0_truth_itemB3v12B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedExx"
	.size	".const.missing Environment: _ZN08NumbaEnv26recompyler_generated_heap113f0_truth_itemB3v12B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedExx", 257

	.type	".const.can't unbox array from PyObject into native value.  The object maybe of a different type",@object
	.p2align	4, 0x0
".const.can't unbox array from PyObject into native value.  The object maybe of a different type":
	.asciz	"can't unbox array from PyObject into native value.  The object maybe of a different type"
	.size	".const.can't unbox array from PyObject into native value.  The object maybe of a different type", 89

	.section	".note.GNU-stack","",@progbits
