define noundef i32 @_ZN26recompyler_generated_heap113f0_truth_itemB3v12B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedExx(ptr noalias writeonly captures(none) initializes((0, 8)) %retptr, ptr noalias readnone captures(none) %excinfo, ptr readnone captures(none) %arg.F.0, ptr readnone captures(none) %arg.F.1, i64 %arg.F.2, i64 %arg.F.3, ptr readonly captures(none) %arg.F.4, i64 %arg.F.5.0, i64 %arg.F.6.0, ptr readnone captures(none) %arg.I.0, ptr readnone captures(none) %arg.I.1, i64 %arg.I.2, i64 %arg.I.3, ptr readonly captures(none) %arg.I.4, i64 %arg.I.5.0, i64 %arg.I.6.0, ptr readnone captures(none) %arg.top.0, ptr readnone captures(none) %arg.top.1, i64 %arg.top.2, i64 %arg.top.3, ptr writeonly captures(none) %arg.top.4, i64 %arg.top.5.0, i64 %arg.top.6.0, ptr readnone captures(none) %arg.st.0, ptr readnone captures(none) %arg.st.1, i64 %arg.st.2, i64 %arg.st.3, ptr writeonly captures(none) %arg.st.4, i64 %arg.st.5.0, i64 %arg.st.6.0, i64 %arg.v_values, i64 %arg.v_index) local_unnamed_addr #0 {
B0:
  %.80 = icmp slt i64 %arg.v_values, 0
  %.81 = select i1 %.80, i64 %arg.I.5.0, i64 0
  %0 = getelementptr i64, ptr %arg.I.4, i64 %arg.v_values
  %.95 = getelementptr i64, ptr %0, i64 %.81
  %.96 = load i64, ptr %.95, align 8
  %.97.not = icmp eq i64 %.96, 0
  br i1 %.97.not, label %common.ret, label %B40

B40:                                              ; preds = %B0
  %.126 = load i64, ptr %0, align 8
  %.141 = icmp slt i64 %arg.v_index, 0
  br i1 %.141, label %B134, label %B146

B134:                                             ; preds = %B40
  %.145 = add nsw i64 %.126, %arg.v_index
  %.154 = icmp slt i64 %.145, 0
  br i1 %.154, label %B160, label %B146

B146:                                             ; preds = %B40, %B134
  %t3.2.0243 = phi i64 [ %.145, %B134 ], [ %arg.v_index, %B40 ]
  %.158.not = icmp slt i64 %t3.2.0243, %.126
  br i1 %.158.not, label %B184, label %B160

common.ret:                                       ; preds = %B0, %B184, %B160
  %.sink = phi double [ 0.000000e+00, %B160 ], [ %.342, %B184 ], [ -1.000000e+00, %B0 ]
  store double %.sink, ptr %retptr, align 8
  ret i32 0

B160:                                             ; preds = %B146, %B134
  store i8 1, ptr %arg.st.4, align 1
  %.257 = getelementptr i8, ptr %arg.top.4, i64 24
  store i64 3, ptr %.257, align 8
  br label %common.ret

B184:                                             ; preds = %B146
  %.305 = getelementptr i8, ptr %0, i64 16
  %.306 = load i64, ptr %.305, align 8
  %1 = getelementptr double, ptr %arg.F.4, i64 %.306
  %.341 = getelementptr double, ptr %1, i64 %t3.2.0243
  %.342 = load double, ptr %.341, align 8
  br label %common.ret
}
