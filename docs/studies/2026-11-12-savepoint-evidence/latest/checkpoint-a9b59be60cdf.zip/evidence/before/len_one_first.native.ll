define noundef i32 @_ZN26recompyler_generated_heap016f0_len_one_firstB3v11B44c8tJTIeFIjxB2IKSgI4CrvQCk0Z4yRYcWsBAK4JIagIAE5ArrayIdLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIxLi1E1C7mutable7alignedE5ArrayIhLi1E1C7mutable7alignedEx(ptr noalias writeonly captures(none) initializes((0, 8)) %retptr, ptr noalias readnone captures(none) %excinfo, ptr readnone captures(none) %arg.F.0, ptr readnone captures(none) %arg.F.1, i64 %arg.F.2, i64 %arg.F.3, ptr readonly captures(none) %arg.F.4, i64 %arg.F.5.0, i64 %arg.F.6.0, ptr readnone captures(none) %arg.I.0, ptr readnone captures(none) %arg.I.1, i64 %arg.I.2, i64 %arg.I.3, ptr readonly captures(none) %arg.I.4, i64 %arg.I.5.0, i64 %arg.I.6.0, ptr readnone captures(none) %arg.top.0, ptr readnone captures(none) %arg.top.1, i64 %arg.top.2, i64 %arg.top.3, ptr writeonly captures(none) %arg.top.4, i64 %arg.top.5.0, i64 %arg.top.6.0, ptr readnone captures(none) %arg.st.0, ptr readnone captures(none) %arg.st.1, i64 %arg.st.2, i64 %arg.st.3, ptr writeonly captures(none) %arg.st.4, i64 %arg.st.5.0, i64 %arg.st.6.0, i64 %arg.v_values) local_unnamed_addr #0 {
B0:
  %.77 = icmp slt i64 %arg.v_values, 0
  %.78 = select i1 %.77, i64 %arg.I.5.0, i64 0
  %0 = getelementptr i64, ptr %arg.I.4, i64 %arg.v_values
  %.92 = getelementptr i64, ptr %0, i64 %.78
  %.93 = load i64, ptr %.92, align 8
  %.94 = icmp eq i64 %.93, 1
  br i1 %.94, label %B138, label %common.ret

B138:                                             ; preds = %B0
  %.123 = load i64, ptr %0, align 8
  %.142 = icmp slt i64 %.123, 1
  br i1 %.142, label %B152, label %B176

common.ret:                                       ; preds = %B0, %B176, %B152
  %.sink = phi double [ 0.000000e+00, %B152 ], [ %.326, %B176 ], [ -1.000000e+00, %B0 ]
  store double %.sink, ptr %retptr, align 8
  ret i32 0

B152:                                             ; preds = %B138
  store i8 1, ptr %arg.st.4, align 1
  %.241 = getelementptr i8, ptr %arg.top.4, i64 24
  store i64 3, ptr %.241, align 8
  br label %common.ret

B176:                                             ; preds = %B138
  %.289 = getelementptr i8, ptr %0, i64 16
  %.290 = load i64, ptr %.289, align 8
  %.325 = getelementptr double, ptr %arg.F.4, i64 %.290
  %.326 = load double, ptr %.325, align 8
  br label %common.ret
}
