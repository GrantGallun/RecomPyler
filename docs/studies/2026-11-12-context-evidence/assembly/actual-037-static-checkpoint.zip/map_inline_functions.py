"""PE unwind-function and direct-call inventory from static evidence only.

No compiled artifact is imported/executed. Functions are identified by unwind
entries plus source-bound machine-call chains, never nearest printed PyInit.
Leaf functions may have no unwind entry; report unmatched edges explicitly.
"""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import struct

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'inline-actual-artifacts'
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('case')
args = parser.parse_args()
meta = json.loads((OUT / (args.case + '-provenance.json')).read_text())
raw = Path(meta['artifact']).read_bytes()
assert hashlib.sha256(raw).hexdigest() == meta['artifact_sha256']
assembly = OUT / (args.case + '.asm')
assert hashlib.sha256(assembly.read_bytes()).hexdigest() == meta['assembly_sha256']
base = int(meta['preferred_image_base'], 16)
functions = []
for section in meta['sections']:
    if section['name'] != '.pdata':
        continue
    for offset in range(section['offset'], section['offset'] + section['rawsize'] - 11, 12):
        start, end, unwind = struct.unpack_from('<III', raw, offset)
        if start == end == unwind == 0:
            continue
        if start >= end:
            raise ValueError('Invalid PE unwind interval')
        functions.append({'start': base + start, 'end': base + end,
                          'unwind_info': hex(base + unwind)})
functions.sort(key=lambda f: f['start'])
rows = []
for line in assembly.read_text().splitlines():
    match = re.match(r'\s*([0-9a-f]+):\s+(\w+)\s*(.*)', line)
    if match:
        rows.append((int(match[1], 16), match[2], match[3], line))
for function in functions:
    selected = [r for r in rows if function['start'] <= r[0] < function['end']]
    function['instructions_excluding_outside_unwind_padding'] = len(selected)
    function['frame_reservations'] = [r[3].strip() for r in selected
                                     if r[1] == 'subq' and ', %rsp' in r[2]]
    function['stack_operand_lines'] = sum('%rsp' in r[2] for r in selected)
    function['direct_calls'] = []
    function['self_calls'] = []
    for r in selected:
        match = re.match(r'0x([0-9a-f]+)\b', r[2]) if r[1] == 'callq' else None
        if not match:
            continue
        target = int(match[1], 16)
        edge = {'instruction': hex(r[0]), 'target': hex(target), 'assembly': r[3].strip(),
                'following_instructions': [q[3].strip() for q in selected
                                           if r[0] < q[0]][:5]}
        function['direct_calls'].append(edge)
        if target == function['start']:
            function['self_calls'].append(hex(r[0]))
    function['mnemonic_counts'] = dict(Counter(r[1] for r in selected))
    function['start'] = hex(function['start'])
    function['end_exclusive'] = hex(function.pop('end'))
result = {'case': args.case, 'artifact_sha256': meta['artifact_sha256'],
          'wrapper': meta['method']['function_address'], 'functions': functions,
          'self_recursive_functions': [f['start'] for f in functions if f['self_calls']],
          'limitation': 'Unwind intervals can exclude padding; bounded comparative counts use separately reviewed source/call-target ranges. No cycle/dynamic-frequency inference.',
          'artifact_imported_or_executed': False}
(OUT / (args.case + '-functions.json')).write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'case': args.case, 'functions': len(functions),
                  'self_recursive_functions': result['self_recursive_functions']}))
