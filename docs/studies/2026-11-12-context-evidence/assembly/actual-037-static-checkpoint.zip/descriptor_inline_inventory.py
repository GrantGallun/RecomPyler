"""Statically bound descriptor reads in selected037 bodies, including inline work."""
from collections import Counter
import json
from pathlib import Path
import re

OUT = Path(__file__).resolve().parent / 'inline-actual-artifacts'
BOUNDS = {
    'barnes-force': ('barnes-final', [('r8', 0x180002b60, 0x180003100)]),
    'barnes-advance-including-inline-helpers': ('barnes-final', [('r8', 0x1800025f0, 0x180002b60)]),
    'raytrace-render-including-inline-helpers': ('raytrace-final', [
        ('r8', 0x180001ae9, 0x180001afc), ('r14', 0x1800019e0, 0x180002e80)]),
    'raytrace-scc-entry-fields': ('raytrace-final', [('r8', 0x180002fe5, 0x180002ff8)]),
}
fields = {0: 'F', 8: 'I', 16: 'top', 24: 'status', 32: 'arena_length'}
result = {}
for label, (case, intervals) in BOUNDS.items():
    selected = []
    for line in (OUT / (case+'.asm')).read_text().splitlines():
        match = re.match(r'\s*([0-9a-f]+):\s+(\w+)\s*(.*)', line)
        if not match:
            continue
        address = int(match[1], 16)
        for register, start, end in intervals:
            if not start <= address < end:
                continue
            operand = re.search(r'(?:(0x[0-9a-f]+))?\(%'+register+r'\)', match[3])
            if operand:
                offset = int(operand[1], 16) if operand[1] else 0
                if offset in fields:
                    assert match[2] in ('movq', 'cmpq'), line
                    selected.append({'instruction': hex(address), 'field': fields[offset],
                                     'mnemonic': match[2], 'assembly': line.strip()})
    result[label] = {'descriptor_read_instruction_lines': len(selected),
                     'fields': dict(Counter(r['field'] for r in selected)),
                     'instructions': selected,
                     'basis': 'Reviewed context-base dataflow. Count includes memory-operand compares, not dynamic loads/cycles; inline helper instructions included in containing body.'}
result['limitations'] = ['SCC entry-field range is explicit; source and full-body context-register review found no helper descriptor re-reads. Unrelated uses of r8 after its repurposing are not descriptor loads.',
                         'Descriptor read counts are static instructions; loop nesting and branches determine execution frequency.',
                         'F and I remain overlapping pointees; immutable descriptor source does not authorize payload alias metadata.']
(OUT/'descriptor-inventory.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({k: v['descriptor_read_instruction_lines'] for k,v in result.items() if isinstance(v,dict)}))
