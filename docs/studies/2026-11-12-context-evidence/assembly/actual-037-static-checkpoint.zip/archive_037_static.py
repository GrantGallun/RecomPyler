"""Freeze the read-only refined037 static analysis; no product/native execution."""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
sha = lambda data: hashlib.sha256(data).hexdigest()
paths = [ROOT / name for name in ('ACTUAL-037-REPORT.md', 'collect_inline.py',
         'static_method.py', 'map_inline_functions.py', 'summarize_inline.py',
         'verify_inline.py', 'descriptor_inline_inventory.py',
         'INLINE-FOLLOWUP-PRODUCT-REVIEW.md', 'archive_037_static.py')]
paths += sorted((ROOT / 'inline-actual-artifacts').glob('*'))
assert all(path.is_file() for path in paths)
records = {path.relative_to(ROOT).as_posix(): {'sha256': sha(path.read_bytes()),
            'bytes': path.stat().st_size} for path in paths}
manifest = {'mode': 'readonly selected native static analysis checkpoint',
            'study_manifest_sha256': sha((ROOT.parent/'wave9-native/results-inline/manifest.json').read_bytes()),
            'candidate_commit': json.loads((ROOT.parent/'wave9-native/results-inline/manifest.json').read_text())['sources']['final']['git_head'],
            'members': records, 'member_count_excluding_manifest': len(records),
            'artifact_imported_or_executed_by_reviewer': False}
archive = ROOT / 'actual-037-static-checkpoint.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as output:
    for path in paths:
        output.writestr(path.relative_to(ROOT).as_posix(), path.read_bytes())
    output.writestr('archive-manifest.json', json.dumps(manifest, indent=2)+'\n')
with zipfile.ZipFile(archive) as source:
    for name, record in records.items():
        assert sha(source.read(name)) == record['sha256'], name
receipt = {'archive': str(archive), 'archive_sha256': sha(archive.read_bytes()),
           'bytes': archive.stat().st_size, 'members': len(records)+1,
           'member_bytes_verified': True, 'manifest': manifest}
(ROOT/'actual-037-static-checkpoint-receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k!='manifest'}))
