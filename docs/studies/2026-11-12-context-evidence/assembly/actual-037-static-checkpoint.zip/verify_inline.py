"""Cross-check static maps, immutable inputs and retained state; execute no artifacts."""
import ast
import hashlib
import json
import statistics
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'inline-actual-artifacts'
STUDY = ROOT.parent / 'wave9-native/results-inline'
read = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
manifest = read(STUDY/'manifest.json')
assert manifest['sources']['current']['git_head'] == 'a9b59be60cdf568c8f6b63442e7efa88fd16fdd2'
assert manifest['sources']['final']['git_head'].startswith('0373788')
for variant, identity in manifest['sources'].items():
    for relative, expected in identity['src_sha256'].items():
        assert sha(Path(identity['path'])/'src'/relative) == expected, (variant, relative)
result = {'mode': 'read-only metadata/state/static evidence verification',
          'manifest_sha256': sha(STUDY/'manifest.json'),
          'source_hashes_match_frozen_manifest': True, 'cases': {}}
for workload, short in (('barnes_hut', 'barnes'), ('raytrace', 'raytrace')):
    folder = STUDY/'programs'/workload
    plain = read(folder/'plain-state.json')
    expected = 100 if workload == 'barnes_hut' else 1
    case = {}
    for variant in ('current', 'final'):
        meta = read(OUT/f'{short}-{variant}-provenance.json')
        mapping = read(folder/f'{variant}-aot-map.json')
        assert len(mapping) == 1
        mapping = mapping[0]
        assert mapping['selected_digest'] == meta['digest']
        assert mapping['selected_export'] == meta['export']
        assert mapping['artifact_sha256'] == meta['artifact_sha256']
        assert mapping['wrapper_preferred_address'] == meta['method']['function_address']
        assert sha(Path(meta['artifact'])) == meta['artifact_sha256']
        for item in ('plan', 'audit', 'frozen'):
            assert sha(Path(meta[item])) == meta[item+'_sha256']
        assert sha(OUT/f'{short}-{variant}.asm') == meta['assembly_sha256']
        assert meta['actual_aot_calls'] == expected
        state = read(folder/f'{variant}-state.json')
        keys = ('initial','final','checkpoints') if workload == 'barnes_hut' else ('final','observed')
        for key in keys:
            assert state[key] == plain[key], (workload,variant,key)
        case[variant] = {'artifact_sha256':meta['artifact_sha256'], 'selected_digest':meta['digest'],
                         'static_map_equals_runtime_map':True, 'exact_state_matches_plain':True,
                         'actual_aot_calls':expected}
    driver = ROOT.parent/'wave5-study/results/drivers'/f'{workload}.py'
    tree = ast.parse(driver.read_bytes())
    aug = [node.lineno for node in ast.walk(tree)
           if isinstance(node,ast.AugAssign) and isinstance(node.target,ast.Subscript)]
    assert not aug
    case['driver_sha256'] = sha(driver)
    case['subscript_augassign_sites'] = aug
    result['cases'][workload] = case
summary = read(STUDY/'SUMMARY.json')
result['fresh_measurements'] = {}
result['raw_timing_verification'] = {}
timing_aot = 0
for name, rows in summary['programs'].items():
    folder = STUDY/'programs'/name
    raw_verified = {}
    for variant in ('plain', 'c', 'current', 'final'):
        records = [read(folder/f'{variant}-{index}.json') for index in range(5)]
        assert all(r['status']=='ok' and r['exit_code']==0 for r in records)
        times = []
        for index in range(5):
            lines = (folder/f'{variant}-{index}.stdout').read_text().splitlines()
            values = [float(parts[1]) for line in lines if len(parts:=line.split())==2 and parts[0]=='seconds']
            assert len(values)==1, (name, variant, index)
            times.append(values[0])
        walls = [r['wall_s'] for r in records]
        assert rows[variant]['kernel_samples_s']==times
        assert rows[variant]['median_best_kernel_s']==statistics.median(times)
        assert rows[variant]['process_wall_samples_s']==walls
        assert rows[variant]['median_process_wall_s']==statistics.median(walls)
        calls = 0
        if variant in ('current','final'):
            expected = 500 if name=='barnes_hut' else 5
            for index in range(5):
                counts=read(folder/f'{variant}-{index}.counts.json')
                assert sum(f.get('aot_calls',0) for f in counts['functions'])==expected
                assert not any(f.get('jit_calls',0) or f.get('fallback_calls',0) for f in counts['functions'])
                assert not counts.get('not_found') and not counts.get('batches')
                calls += expected
            timing_aot += calls
        raw_verified[variant]={'processes':5,'raw_stdout_medians_recomputed':True,
                                'raw_process_wall_medians_recomputed':True,'aot_calls':calls}
    binary=Path(manifest['programs'][name]['binary'])
    assert sha(binary)==manifest['programs'][name]['binary_sha256']
    raw_verified['c_binary_sha256']=sha(binary)
    result['raw_timing_verification'][name]=raw_verified
    current, final, c = (rows[k] for k in ('current','final','c'))
    a,b,cv = (r['median_best_kernel_s'] for r in (current,final,c))
    result['fresh_measurements'][name] = {
        'current_ms':a*1000, 'final_ms':b*1000, 'c_ms':cv*1000,
        'final_time_change_percent':100*(b/a-1), 'current_over_c':a/cv, 'final_over_c':b/cv,
        'current_range_ms':[min(current['kernel_samples_s'])*1000,max(current['kernel_samples_s'])*1000],
        'final_range_ms':[min(final['kernel_samples_s'])*1000,max(final['kernel_samples_s'])*1000],
        'current_wall_ms':current['median_process_wall_s']*1000,
        'final_wall_ms':final['median_process_wall_s']*1000,
    }
result['summary_sha256'] = sha(STUDY/'SUMMARY.json')
assert timing_aot==5050
result['timing_aot_verified']=timing_aot
(OUT/'verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result['fresh_measurements'],indent=2))
