
D:\Code\Datathon\recompyler-codex-20261111\wave9-native\results-inline\cache\barnes_hut\current\recompyler\rcaotr_37d5bbedabb5b3cb6ca652c3.cp314-win_amd64.pyd:	file format coff-x86-64

Disassembly of section .text:

0000000180001000 <.text>:
180001000:     	movl	$0x1, %eax
180001005:     	lock
180001006:     	xaddq	%rax, (%rcx)
18000100a:     	incq	%rax
18000100d:     	retq
18000100e:     	nop
180001010:     	movq	$-0x1, %rax
180001017:     	lock
180001018:     	xaddq	%rax, (%rcx)
18000101c:     	decq	%rax
18000101f:     	retq
180001020:     	movq	%rdx, %rax
180001023:     	xorl	%edx, %edx
180001025:     	lock
180001026:     	cmpxchgq	%r8, (%rcx)
18000102a:     	sete	%dl
18000102d:     	movq	%rax, (%r9)
180001030:     	movl	%edx, %eax
180001032:     	retq
180001033:     	nopw	%cs:(%rax,%rax)
18000103d:     	nopl	(%rax)
180001040:     	movq	0x18(%rcx), %rax
180001044:     	retq
180001045:     	nopw	%cs:(%rax,%rax)
18000104f:     	nop
180001050:     	testq	%rcx, %rcx
180001053:     	je	0x180001059 <.text+0x59>
180001055:     	lock
180001056:     	incq	(%rcx)
180001059:     	retq
18000105a:     	nopw	(%rax,%rax)
180001060:     	testq	%rcx, %rcx
180001063:     	je	0x18000106b <.text+0x6b>
180001065:     	lock
180001066:     	decq	(%rcx)
180001069:     	je	0x18000106c <.text+0x6c>
18000106b:     	retq
18000106c:     	jmp	0x1800088b0 <numba_list_iter_next+0x160>
180001071:     	nopw	%cs:(%rax,%rax)
18000107b:     	nopl	(%rax,%rax)
180001080:     	leaq	0x93f9(%rip), %rax      # 0x18000a480
180001087:     	movq	%rax, (%rdx)
18000108a:     	movl	$0x1, %eax
18000108f:     	retq
180001090:     	pushq	%r14
180001092:     	pushq	%rsi
180001093:     	pushq	%rdi
180001094:     	pushq	%rbx
180001095:     	subq	$0x78, %rsp
180001099:     	movq	%rcx, %rsi
18000109c:     	movq	0x108(%rsp), %rax
1800010a4:     	movq	0xf0(%rsp), %rcx
1800010ac:     	movq	0xd8(%rsp), %r10
1800010b4:     	movq	0xc0(%rsp), %r11
1800010bc:     	movq	0x100(%rsp), %rdi
1800010c4:     	movq	0xe8(%rsp), %rbx
1800010cc:     	movq	$0x0, 0x68(%rsp)
1800010d5:     	movq	0xd0(%rsp), %r14
1800010dd:     	xorq	%r9, %r14
1800010e0:     	xorq	$0x4, %rbx
1800010e4:     	orq	%r14, %rbx
1800010e7:     	xorq	$0x1, %rdi
1800010eb:     	xorq	$0x8, %r11
1800010ef:     	orq	%rdi, %r11
1800010f2:     	orq	%rbx, %r11
1800010f5:     	xorq	$0x8, %r10
1800010f9:     	xorq	$0x8, %rcx
1800010fd:     	orq	%r10, %rcx
180001100:     	orq	%r11, %rcx
180001103:     	xorq	$0x1, %rax
180001107:     	orq	%rcx, %rax
18000110a:     	jne	0x1800011aa <.text+0x1aa>
180001110:     	movq	%rdx, %rdi
180001113:     	movq	0x130(%rsp), %rcx
18000111b:     	movq	0x128(%rsp), %rdx
180001123:     	movsd	0x120(%rsp), %xmm0
18000112c:     	movsd	0x118(%rsp), %xmm1
180001135:     	movq	0x110(%rsp), %r10
18000113d:     	movq	0xf8(%rsp), %r11
180001145:     	movq	0xe0(%rsp), %rbx
18000114d:     	movq	0xc8(%rsp), %rax
180001155:     	movq	$0x0, 0x70(%rsp)
18000115e:     	movq	%rcx, 0x58(%rsp)
180001163:     	movq	%rdx, 0x50(%rsp)
180001168:     	movsd	%xmm0, 0x48(%rsp)
18000116e:     	movsd	%xmm1, 0x40(%rsp)
180001174:     	movq	%r10, 0x38(%rsp)
180001179:     	movq	%r9, 0x30(%rsp)
18000117e:     	movq	%r11, 0x28(%rsp)
180001183:     	movq	%rbx, 0x20(%rsp)
180001188:     	leaq	0x70(%rsp), %rcx
18000118d:     	leaq	0x68(%rsp), %rdx
180001192:     	movq	%rax, %r9
180001195:     	callq	0x1800025d0 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x60>
18000119a:     	testl	%eax, %eax
18000119c:     	jne	0x1800011c3 <.text+0x1c3>
18000119e:     	movq	0x70(%rsp), %rax
1800011a3:     	movq	%rax, (%rsi)
1800011a6:     	xorl	%eax, %eax
1800011a8:     	jmp	0x1800011b9 <.text+0x1b9>
1800011aa:     	leaq	0x939f(%rip), %rax      # 0x18000a550
1800011b1:     	movq	%rax, (%rdx)
1800011b4:     	movl	$0x1, %eax
1800011b9:     	addq	$0x78, %rsp
1800011bd:     	popq	%rbx
1800011be:     	popq	%rdi
1800011bf:     	popq	%rsi
1800011c0:     	popq	%r14
1800011c2:     	retq
1800011c3:     	movq	0x68(%rsp), %rcx
1800011c8:     	movq	%rcx, (%rdi)
1800011cb:     	jmp	0x1800011b9 <.text+0x1b9>
1800011cd:     	nopl	(%rax)
1800011d0:     	pushq	%r15
1800011d2:     	pushq	%r14
1800011d4:     	pushq	%r13
1800011d6:     	pushq	%r12
1800011d8:     	pushq	%rsi
1800011d9:     	pushq	%rdi
1800011da:     	pushq	%rbp
1800011db:     	pushq	%rbx
1800011dc:     	subq	$0x278, %rsp            # imm = 0x278
1800011e3:     	movaps	%xmm7, 0x260(%rsp)
1800011eb:     	movaps	%xmm6, 0x250(%rsp)
1800011f3:     	movq	%rdx, %rcx
1800011f6:     	leaq	0x108(%rsp), %rax
1800011fe:     	movq	%rax, 0x60(%rsp)
180001203:     	leaq	0x110(%rsp), %rax
18000120b:     	movq	%rax, 0x58(%rsp)
180001210:     	leaq	0x118(%rsp), %rax
180001218:     	movq	%rax, 0x50(%rsp)
18000121d:     	leaq	0x120(%rsp), %rax
180001225:     	movq	%rax, 0x48(%rsp)
18000122a:     	leaq	0x128(%rsp), %rax
180001232:     	movq	%rax, 0x40(%rsp)
180001237:     	leaq	0x130(%rsp), %rax
18000123f:     	movq	%rax, 0x38(%rsp)
180001244:     	leaq	0x138(%rsp), %rax
18000124c:     	movq	%rax, 0x30(%rsp)
180001251:     	leaq	0x140(%rsp), %rax
180001259:     	movq	%rax, 0x28(%rsp)
18000125e:     	leaq	0x148(%rsp), %rax
180001266:     	movq	%rax, 0x20(%rsp)
18000126b:     	leaq	0x930e(%rip), %rdx      # 0x18000a580
180001272:     	movl	$0x9, %r8d
180001278:     	movl	$0x9, %r9d
18000127e:     	callq	0x180008a61 <numba_list_iter_next+0x311>
180001283:     	testl	%eax, %eax
180001285:     	movq	$0x0, 0xb8(%rsp)
180001291:     	je	0x18000183b <.text+0x83b>
180001297:     	cmpq	$0x0, 0x10a59(%rip)     # 0x180011cf8
18000129f:     	je	0x180001773 <.text+0x773>
1800012a5:     	movq	0x148(%rsp), %rcx
1800012ad:     	xorps	%xmm0, %xmm0
1800012b0:     	movaps	%xmm0, 0x210(%rsp)
1800012b8:     	movaps	%xmm0, 0x220(%rsp)
1800012c0:     	movaps	%xmm0, 0x230(%rsp)
1800012c8:     	movq	$0x0, 0x240(%rsp)
1800012d4:     	leaq	0x210(%rsp), %rdx
1800012dc:     	callq	0x180007720 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x51b0>
1800012e1:     	testl	%eax, %eax
1800012e3:     	jne	0x18000178b <.text+0x78b>
1800012e9:     	cmpq	$0x8, 0x228(%rsp)
1800012f2:     	jne	0x18000178b <.text+0x78b>
1800012f8:     	movq	0x210(%rsp), %rdi
180001300:     	movq	0x230(%rsp), %r14
180001308:     	movq	0x238(%rsp), %r12
180001310:     	movq	0x240(%rsp), %rbx
180001318:     	movq	0x140(%rsp), %rcx
180001320:     	xorps	%xmm0, %xmm0
180001323:     	movaps	%xmm0, 0x1d0(%rsp)
18000132b:     	movaps	%xmm0, 0x1e0(%rsp)
180001333:     	movaps	%xmm0, 0x1f0(%rsp)
18000133b:     	movq	$0x0, 0x200(%rsp)
180001347:     	leaq	0x1d0(%rsp), %rdx
18000134f:     	callq	0x180007720 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x51b0>
180001354:     	testl	%eax, %eax
180001356:     	jne	0x1800017a3 <.text+0x7a3>
18000135c:     	cmpq	$0x8, 0x1e8(%rsp)
180001365:     	jne	0x1800017a3 <.text+0x7a3>
18000136b:     	movq	0x1d0(%rsp), %r15
180001373:     	movq	0x1f0(%rsp), %rbp
18000137b:     	movq	0x1f8(%rsp), %rsi
180001383:     	movq	0x200(%rsp), %r13
18000138b:     	movq	0x138(%rsp), %rcx
180001393:     	xorps	%xmm0, %xmm0
180001396:     	movaps	%xmm0, 0x190(%rsp)
18000139e:     	movaps	%xmm0, 0x1a0(%rsp)
1800013a6:     	movaps	%xmm0, 0x1b0(%rsp)
1800013ae:     	movq	$0x0, 0x1c0(%rsp)
1800013ba:     	leaq	0x190(%rsp), %rdx
1800013c2:     	callq	0x180007720 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x51b0>
1800013c7:     	testl	%eax, %eax
1800013c9:     	jne	0x1800017b8 <.text+0x7b8>
1800013cf:     	cmpq	$0x8, 0x1a8(%rsp)
1800013d8:     	jne	0x1800017b8 <.text+0x7b8>
1800013de:     	movq	%r13, 0x100(%rsp)
1800013e6:     	movq	0x190(%rsp), %r13
1800013ee:     	movq	0x1b0(%rsp), %rax
1800013f6:     	movq	%rax, 0xf8(%rsp)
1800013fe:     	movq	0x1b8(%rsp), %rax
180001406:     	movq	%rax, 0xf0(%rsp)
18000140e:     	movq	0x1c0(%rsp), %rax
180001416:     	movq	%rax, 0xe8(%rsp)
18000141e:     	movq	0x130(%rsp), %rcx
180001426:     	xorps	%xmm0, %xmm0
180001429:     	movaps	%xmm0, 0x150(%rsp)
180001431:     	movaps	%xmm0, 0x160(%rsp)
180001439:     	movaps	%xmm0, 0x170(%rsp)
180001441:     	movq	$0x0, 0x180(%rsp)
18000144d:     	leaq	0x150(%rsp), %rdx
180001455:     	callq	0x180007720 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x51b0>
18000145a:     	testl	%eax, %eax
18000145c:     	jne	0x1800017cd <.text+0x7cd>
180001462:     	cmpq	$0x1, 0x168(%rsp)
18000146b:     	jne	0x1800017cd <.text+0x7cd>
180001471:     	movq	%rsi, 0xd8(%rsp)
180001479:     	movq	0x150(%rsp), %rax
180001481:     	movq	%rax, 0xa8(%rsp)
180001489:     	movq	0x170(%rsp), %rax
180001491:     	movq	%rax, 0xd0(%rsp)
180001499:     	movq	0x178(%rsp), %rax
1800014a1:     	movq	%rax, 0xc8(%rsp)
1800014a9:     	movq	0x180(%rsp), %rax
1800014b1:     	movq	%rax, 0xc0(%rsp)
1800014b9:     	movq	0x128(%rsp), %rcx
1800014c1:     	callq	0x180008a67 <numba_list_iter_next+0x317>
1800014c6:     	testq	%rax, %rax
1800014c9:     	movq	%r13, 0xb0(%rsp)
1800014d1:     	movq	%rbp, 0xe0(%rsp)
1800014d9:     	je	0x1800017e2 <.text+0x7e2>
1800014df:     	movq	%rax, %rsi
1800014e2:     	movq	%rax, %rcx
1800014e5:     	callq	0x180008a6d <numba_list_iter_next+0x31d>
1800014ea:     	movq	%rax, 0xa0(%rsp)
1800014f2:     	movq	%rsi, %rcx
1800014f5:     	callq	0x180008a73 <numba_list_iter_next+0x323>
1800014fa:     	callq	0x180008a79 <numba_list_iter_next+0x329>
1800014ff:     	testq	%rax, %rax
180001502:     	jne	0x18000180e <.text+0x80e>
180001508:     	movq	0x120(%rsp), %rcx
180001510:     	callq	0x180008a7f <numba_list_iter_next+0x32f>
180001515:     	movq	%rax, %rsi
180001518:     	movq	%rax, %rcx
18000151b:     	callq	0x180008a85 <numba_list_iter_next+0x335>
180001520:     	movaps	%xmm0, %xmm6
180001523:     	movq	%rsi, %rcx
180001526:     	callq	0x180008a73 <numba_list_iter_next+0x323>
18000152b:     	callq	0x180008a79 <numba_list_iter_next+0x329>
180001530:     	testq	%rax, %rax
180001533:     	jne	0x18000180e <.text+0x80e>
180001539:     	movq	0x118(%rsp), %rcx
180001541:     	callq	0x180008a7f <numba_list_iter_next+0x32f>
180001546:     	movq	%rax, %rsi
180001549:     	movq	%rax, %rcx
18000154c:     	callq	0x180008a85 <numba_list_iter_next+0x335>
180001551:     	movaps	%xmm0, %xmm7
180001554:     	movq	%rsi, %rcx
180001557:     	callq	0x180008a73 <numba_list_iter_next+0x323>
18000155c:     	callq	0x180008a79 <numba_list_iter_next+0x329>
180001561:     	testq	%rax, %rax
180001564:     	jne	0x18000180e <.text+0x80e>
18000156a:     	movq	0x110(%rsp), %rcx
180001572:     	callq	0x180008a67 <numba_list_iter_next+0x317>
180001577:     	testq	%rax, %rax
18000157a:     	je	0x1800017fe <.text+0x7fe>
180001580:     	movq	%rax, %rsi
180001583:     	movq	%rax, %rcx
180001586:     	callq	0x180008a6d <numba_list_iter_next+0x31d>
18000158b:     	movq	%rax, %rbp
18000158e:     	movq	%rsi, %rcx
180001591:     	callq	0x180008a73 <numba_list_iter_next+0x323>
180001596:     	callq	0x180008a79 <numba_list_iter_next+0x329>
18000159b:     	testq	%rax, %rax
18000159e:     	jne	0x18000180e <.text+0x80e>
1800015a4:     	movq	%rbx, %r13
1800015a7:     	movq	%r12, %rbx
1800015aa:     	movq	%r14, %r12
1800015ad:     	movq	%r15, %r14
1800015b0:     	movq	%rdi, %r15
1800015b3:     	movq	0x108(%rsp), %rcx
1800015bb:     	callq	0x180008a67 <numba_list_iter_next+0x317>
1800015c0:     	testq	%rax, %rax
1800015c3:     	je	0x180001842 <.text+0x842>
1800015c9:     	movq	%rax, %rdi
1800015cc:     	movq	%rax, %rcx
1800015cf:     	callq	0x180008a6d <numba_list_iter_next+0x31d>
1800015d4:     	movq	%rax, %rsi
1800015d7:     	movq	%rdi, %rcx
1800015da:     	callq	0x180008a73 <numba_list_iter_next+0x323>
1800015df:     	callq	0x180008a79 <numba_list_iter_next+0x329>
1800015e4:     	testq	%rax, %rax
1800015e7:     	movq	%r15, %rdi
1800015ea:     	movq	%r14, %r15
1800015ed:     	jne	0x18000180e <.text+0x80e>
1800015f3:     	movq	%rsi, 0x90(%rsp)
1800015fb:     	movq	%rbp, 0x88(%rsp)
180001603:     	movsd	%xmm7, 0x80(%rsp)
18000160c:     	movsd	%xmm6, 0x78(%rsp)
180001612:     	movq	0xa0(%rsp), %rax
18000161a:     	movq	%rax, 0x70(%rsp)
18000161f:     	movq	0xc0(%rsp), %rax
180001627:     	movq	%rax, 0x68(%rsp)
18000162c:     	movq	0xc8(%rsp), %rax
180001634:     	movq	%rax, 0x60(%rsp)
180001639:     	movq	0xd0(%rsp), %rax
180001641:     	movq	%rax, 0x58(%rsp)
180001646:     	movq	0xe8(%rsp), %rax
18000164e:     	movq	%rax, 0x50(%rsp)
180001653:     	movq	0xf0(%rsp), %rax
18000165b:     	movq	%rax, 0x48(%rsp)
180001660:     	movq	0xf8(%rsp), %rax
180001668:     	movq	%rax, 0x40(%rsp)
18000166d:     	movq	0x100(%rsp), %rax
180001675:     	movq	%rax, 0x38(%rsp)
18000167a:     	movq	0xd8(%rsp), %rax
180001682:     	movq	%rax, 0x30(%rsp)
180001687:     	movq	0xe0(%rsp), %rax
18000168f:     	movq	%rax, 0x28(%rsp)
180001694:     	movq	%r13, 0x20(%rsp)
180001699:     	leaq	0x248(%rsp), %rcx
1800016a1:     	leaq	0xb8(%rsp), %rdx
1800016a9:     	movq	%r12, %r8
1800016ac:     	movq	%rbx, %r9
1800016af:     	callq	0x180001090 <.text+0x90>
1800016b4:     	movl	%eax, %ebp
1800016b6:     	movq	0xb8(%rsp), %rbx
1800016be:     	movq	%rdi, %rcx
1800016c1:     	callq	0x180001060 <.text+0x60>
1800016c6:     	movq	%r15, %rcx
1800016c9:     	callq	0x180001060 <.text+0x60>
1800016ce:     	movq	0xb0(%rsp), %rcx
1800016d6:     	callq	0x180001060 <.text+0x60>
1800016db:     	movq	0xa8(%rsp), %rcx
1800016e3:     	callq	0x180001060 <.text+0x60>
1800016e8:     	testl	%ebp, %ebp
1800016ea:     	jne	0x180001722 <.text+0x722>
1800016ec:     	movq	0x8bdd(%rip), %rsi      # 0x18000a2d0
1800016f3:     	movq	%rsi, %rcx
1800016f6:     	callq	0x180008a8b <numba_list_iter_next+0x33b>
1800016fb:     	movq	%rsi, %rax
1800016fe:     	movaps	0x250(%rsp), %xmm6
180001706:     	movaps	0x260(%rsp), %xmm7
18000170e:     	addq	$0x278, %rsp            # imm = 0x278
180001715:     	popq	%rbx
180001716:     	popq	%rbp
180001717:     	popq	%rdi
180001718:     	popq	%rsi
180001719:     	popq	%r12
18000171b:     	popq	%r13
18000171d:     	popq	%r14
18000171f:     	popq	%r15
180001721:     	retq
180001722:     	jle	0x180001849 <.text+0x849>
180001728:     	callq	0x180008a91 <numba_list_iter_next+0x341>
18000172d:     	movl	0x8(%rbx), %edx
180001730:     	movq	(%rbx), %rcx
180001733:     	cmpl	$0x0, 0x20(%rbx)
180001737:     	jle	0x180001868 <.text+0x868>
18000173d:     	movslq	%edx, %rdx
180001740:     	callq	0x180008a97 <numba_list_iter_next+0x347>
180001745:     	movq	%rax, %rsi
180001748:     	movq	0x10(%rbx), %rcx
18000174c:     	callq	*0x18(%rbx)
18000174f:     	testq	%rax, %rax
180001752:     	je	0x180001891 <.text+0x891>
180001758:     	movq	%rsi, %rcx
18000175b:     	movq	%rax, %rdx
18000175e:     	callq	0x180006f30 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x49c0>
180001763:     	movq	%rax, %rsi
180001766:     	movq	%rbx, %rcx
180001769:     	callq	0x1800089c0 <numba_list_iter_next+0x270>
18000176e:     	jmp	0x180001874 <.text+0x874>
180001773:     	movq	0x8b36(%rip), %rcx      # 0x18000a2b0
18000177a:     	leaq	0x8e1f(%rip), %rdx      # 0x18000a5a0
180001781:     	callq	0x180008a9d <numba_list_iter_next+0x34d>
180001786:     	jmp	0x18000183b <.text+0x83b>
18000178b:     	movq	0x8b0e(%rip), %rcx      # 0x18000a2a0
180001792:     	leaq	0x8f07(%rip), %rdx      # 0x18000a6a0
180001799:     	callq	0x180008a9d <numba_list_iter_next+0x34d>
18000179e:     	jmp	0x18000183b <.text+0x83b>
1800017a3:     	movq	0x8af6(%rip), %rcx      # 0x18000a2a0
1800017aa:     	leaq	0x8eef(%rip), %rdx      # 0x18000a6a0
1800017b1:     	callq	0x180008a9d <numba_list_iter_next+0x34d>
1800017b6:     	jmp	0x180001833 <.text+0x833>
1800017b8:     	movq	0x8ae1(%rip), %rcx      # 0x18000a2a0
1800017bf:     	leaq	0x8eda(%rip), %rdx      # 0x18000a6a0
1800017c6:     	callq	0x180008a9d <numba_list_iter_next+0x34d>
1800017cb:     	jmp	0x18000182b <.text+0x82b>
1800017cd:     	movq	0x8acc(%rip), %rcx      # 0x18000a2a0
1800017d4:     	leaq	0x8ec5(%rip), %rdx      # 0x18000a6a0
1800017db:     	callq	0x180008a9d <numba_list_iter_next+0x34d>
1800017e0:     	jmp	0x180001823 <.text+0x823>
1800017e2:     	movq	$0x0, 0xa0(%rsp)
1800017ee:     	callq	0x180008a79 <numba_list_iter_next+0x329>
1800017f3:     	testq	%rax, %rax
1800017f6:     	je	0x180001508 <.text+0x508>
1800017fc:     	jmp	0x18000180e <.text+0x80e>
1800017fe:     	xorl	%ebp, %ebp
180001800:     	callq	0x180008a79 <numba_list_iter_next+0x329>
180001805:     	testq	%rax, %rax
180001808:     	je	0x1800015a4 <.text+0x5a4>
18000180e:     	movq	0xa8(%rsp), %rcx
180001816:     	callq	0x180001060 <.text+0x60>
18000181b:     	movq	0xb0(%rsp), %r13
180001823:     	movq	%r13, %rcx
180001826:     	callq	0x180001060 <.text+0x60>
18000182b:     	movq	%r15, %rcx
18000182e:     	callq	0x180001060 <.text+0x60>
180001833:     	movq	%rdi, %rcx
180001836:     	callq	0x180001060 <.text+0x60>
18000183b:     	xorl	%esi, %esi
18000183d:     	jmp	0x1800016fb <.text+0x6fb>
180001842:     	xorl	%esi, %esi
180001844:     	jmp	0x1800015df <.text+0x5df>
180001849:     	cmpl	$-0x3, %ebp
18000184c:     	je	0x180001883 <.text+0x883>
18000184e:     	cmpl	$-0x1, %ebp
180001851:     	je	0x18000183b <.text+0x83b>
180001853:     	movq	0x8a3e(%rip), %rcx      # 0x18000a298
18000185a:     	leaq	0x8edf(%rip), %rdx      # 0x18000a740
180001861:     	callq	0x180008a9d <numba_list_iter_next+0x34d>
180001866:     	jmp	0x18000183b <.text+0x83b>
180001868:     	movq	0x10(%rbx), %r8
18000186c:     	callq	0x180006e50 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x48e0>
180001871:     	movq	%rax, %rsi
180001874:     	testq	%rsi, %rsi
180001877:     	je	0x18000183b <.text+0x83b>
180001879:     	movq	%rsi, %rcx
18000187c:     	callq	0x1800069f0 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4480>
180001881:     	jmp	0x18000183b <.text+0x83b>
180001883:     	movq	0x8a06(%rip), %rcx      # 0x18000a290
18000188a:     	callq	0x180008aa3 <numba_list_iter_next+0x353>
18000188f:     	jmp	0x18000183b <.text+0x83b>
180001891:     	movq	0x8a18(%rip), %rcx      # 0x18000a2b0
180001898:     	leaq	0x8e61(%rip), %rdx      # 0x18000a700
18000189f:     	callq	0x180008a9d <numba_list_iter_next+0x34d>
1800018a4:     	jmp	0x18000183b <.text+0x83b>
1800018a6:     	nopw	%cs:(%rax,%rax)
1800018b0:     	pushq	%r15
1800018b2:     	pushq	%r14
1800018b4:     	pushq	%r13
1800018b6:     	pushq	%r12
1800018b8:     	pushq	%rsi
1800018b9:     	pushq	%rdi
1800018ba:     	pushq	%rbp
1800018bb:     	pushq	%rbx
1800018bc:     	subq	$0xb8, %rsp
1800018c3:     	movq	0x120(%rsp), %r8
1800018cb:     	movq	0x128(%rsp), %r9
1800018d3:     	movq	0x130(%rsp), %rax
1800018db:     	movq	0x158(%rsp), %rcx
1800018e3:     	movq	0x160(%rsp), %rdx
1800018eb:     	movq	0x168(%rsp), %r10
1800018f3:     	movq	0x190(%rsp), %r11
1800018fb:     	movq	0x198(%rsp), %rsi
180001903:     	movq	0x1a0(%rsp), %rdi
18000190b:     	movq	0x1c8(%rsp), %rbx
180001913:     	movq	0x1d0(%rsp), %r14
18000191b:     	movq	0x1d8(%rsp), %r15
180001923:     	movq	0x1e0(%rsp), %r12
18000192b:     	movsd	0x1e8(%rsp), %xmm0
180001934:     	movsd	0x1f0(%rsp), %xmm1
18000193d:     	movq	0x1f8(%rsp), %r13
180001945:     	movq	0x200(%rsp), %rbp
18000194d:     	movq	$0x0, 0xb0(%rsp)
180001959:     	movq	$0x0, 0xa8(%rsp)
180001965:     	movq	%rbp, 0x90(%rsp)
18000196d:     	movq	%r13, 0x88(%rsp)
180001975:     	movsd	%xmm1, 0x80(%rsp)
18000197e:     	movsd	%xmm0, 0x78(%rsp)
180001984:     	movq	%r12, 0x70(%rsp)
180001989:     	movq	%r15, 0x68(%rsp)
18000198e:     	movq	%r14, 0x60(%rsp)
180001993:     	movq	%rbx, 0x58(%rsp)
180001998:     	movq	%rdi, 0x50(%rsp)
18000199d:     	movq	%rsi, 0x48(%rsp)
1800019a2:     	movq	%r11, 0x40(%rsp)
1800019a7:     	movq	%r10, 0x38(%rsp)
1800019ac:     	movq	%rdx, 0x30(%rsp)
1800019b1:     	movq	%rcx, 0x28(%rsp)
1800019b6:     	movq	%rax, 0x20(%rsp)
1800019bb:     	leaq	0xb0(%rsp), %rcx
1800019c3:     	leaq	0xa8(%rsp), %rdx
1800019cb:     	callq	0x180001090 <.text+0x90>
1800019d0:     	movl	%eax, %edx
1800019d2:     	movq	0xa8(%rsp), %rsi
1800019da:     	movq	0xb0(%rsp), %rax
1800019e2:     	movl	$0x0, 0xa4(%rsp)
1800019ed:     	testl	%edx, %edx
1800019ef:     	jne	0x180001a05 <.text+0xa05>
1800019f1:     	addq	$0xb8, %rsp
1800019f8:     	popq	%rbx
1800019f9:     	popq	%rbp
1800019fa:     	popq	%rdi
1800019fb:     	popq	%rsi
1800019fc:     	popq	%r12
1800019fe:     	popq	%r13
180001a00:     	popq	%r14
180001a02:     	popq	%r15
180001a04:     	retq
180001a05:     	movq	%rax, %rbx
180001a08:     	leaq	0xa4(%rsp), %rcx
180001a10:     	movl	%edx, %edi
180001a12:     	callq	0x1800069c0 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4450>
180001a17:     	testl	%edi, %edi
180001a19:     	jle	0x180001a5f <.text+0xa5f>
180001a1b:     	callq	0x180008a91 <numba_list_iter_next+0x341>
180001a20:     	movl	0x8(%rsi), %edx
180001a23:     	movq	(%rsi), %rcx
180001a26:     	cmpl	$0x0, 0x20(%rsi)
180001a2a:     	jle	0x180001a80 <.text+0xa80>
180001a2c:     	movslq	%edx, %rdx
180001a2f:     	callq	0x180008a97 <numba_list_iter_next+0x347>
180001a34:     	movq	%rax, %rdi
180001a37:     	movq	0x10(%rsi), %rcx
180001a3b:     	callq	*0x18(%rsi)
180001a3e:     	testq	%rax, %rax
180001a41:     	je	0x180001adb <.text+0xadb>
180001a47:     	movq	%rdi, %rcx
180001a4a:     	movq	%rax, %rdx
180001a4d:     	callq	0x180006f30 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x49c0>
180001a52:     	movq	%rax, %rdi
180001a55:     	movq	%rsi, %rcx
180001a58:     	callq	0x1800089c0 <numba_list_iter_next+0x270>
180001a5d:     	jmp	0x180001a8c <.text+0xa8c>
180001a5f:     	movl	%edi, %eax
180001a61:     	cmpl	$-0x3, %edi
180001a64:     	je	0x180001acd <.text+0xacd>
180001a66:     	cmpl	$-0x1, %eax
180001a69:     	je	0x180001a99 <.text+0xa99>
180001a6b:     	movq	0x8826(%rip), %rcx      # 0x18000a298
180001a72:     	leaq	0x8d37(%rip), %rdx      # 0x18000a7b0
180001a79:     	callq	0x180008a9d <numba_list_iter_next+0x34d>
180001a7e:     	jmp	0x180001a99 <.text+0xa99>
180001a80:     	movq	0x10(%rsi), %r8
180001a84:     	callq	0x180006e50 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x48e0>
180001a89:     	movq	%rax, %rdi
180001a8c:     	testq	%rdi, %rdi
180001a8f:     	je	0x180001a99 <.text+0xa99>
180001a91:     	movq	%rdi, %rcx
180001a94:     	callq	0x1800069f0 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4480>
180001a99:     	leaq	0x8d40(%rip), %rcx      # 0x18000a7e0
180001aa0:     	callq	0x180008aa9 <numba_list_iter_next+0x359>
180001aa5:     	movq	%rax, %rsi
180001aa8:     	movq	%rax, %rcx
180001aab:     	callq	0x180008aaf <numba_list_iter_next+0x35f>
180001ab0:     	movq	%rsi, %rcx
180001ab3:     	callq	0x180008a73 <numba_list_iter_next+0x323>
180001ab8:     	leaq	0xa4(%rsp), %rcx
180001ac0:     	callq	0x1800069e0 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4470>
180001ac5:     	movq	%rbx, %rax
180001ac8:     	jmp	0x1800019f1 <.text+0x9f1>
180001acd:     	movq	0x87bc(%rip), %rcx      # 0x18000a290
180001ad4:     	callq	0x180008aa3 <numba_list_iter_next+0x353>
180001ad9:     	jmp	0x180001a99 <.text+0xa99>
180001adb:     	movq	0x87ce(%rip), %rcx      # 0x18000a2b0
180001ae2:     	leaq	0x8c87(%rip), %rdx      # 0x18000a770
180001ae9:     	callq	0x180008a9d <numba_list_iter_next+0x34d>
180001aee:     	xorl	%eax, %eax
180001af0:     	jmp	0x1800019f1 <.text+0x9f1>
180001af5:     	nopw	%cs:(%rax,%rax)
180001aff:     	nop
180001b00:     	pushq	%r14
180001b02:     	pushq	%rsi
180001b03:     	pushq	%rdi
180001b04:     	pushq	%rbx
180001b05:     	subq	$0x78, %rsp
180001b09:     	movq	%rcx, %rsi
180001b0c:     	movq	0x108(%rsp), %rax
180001b14:     	movq	0xf0(%rsp), %rcx
180001b1c:     	movq	0xd8(%rsp), %r10
180001b24:     	movq	0xc0(%rsp), %r11
180001b2c:     	movq	0x100(%rsp), %rdi
180001b34:     	movq	0xe8(%rsp), %rbx
180001b3c:     	movq	$0x0, 0x68(%rsp)
180001b45:     	movq	0xd0(%rsp), %r14
180001b4d:     	xorq	%r9, %r14
180001b50:     	xorq	$0x4, %rbx
180001b54:     	orq	%r14, %rbx
180001b57:     	xorq	$0x1, %rdi
180001b5b:     	xorq	$0x8, %r11
180001b5f:     	orq	%rdi, %r11
180001b62:     	orq	%rbx, %r11
180001b65:     	xorq	$0x8, %r10
180001b69:     	xorq	$0x8, %rcx
180001b6d:     	orq	%r10, %rcx
180001b70:     	orq	%r11, %rcx
180001b73:     	xorq	$0x1, %rax
180001b77:     	orq	%rcx, %rax
180001b7a:     	jne	0x180001c1a <.text+0xc1a>
180001b80:     	movq	%rdx, %rdi
180001b83:     	movq	0x130(%rsp), %rcx
180001b8b:     	movq	0x128(%rsp), %rdx
180001b93:     	movsd	0x120(%rsp), %xmm0
180001b9c:     	movsd	0x118(%rsp), %xmm1
180001ba5:     	movq	0x110(%rsp), %r10
180001bad:     	movq	0xf8(%rsp), %r11
180001bb5:     	movq	0xe0(%rsp), %rbx
180001bbd:     	movq	0xc8(%rsp), %rax
180001bc5:     	movq	$0x0, 0x70(%rsp)
180001bce:     	movq	%rcx, 0x58(%rsp)
180001bd3:     	movq	%rdx, 0x50(%rsp)
180001bd8:     	movsd	%xmm0, 0x48(%rsp)
180001bde:     	movsd	%xmm1, 0x40(%rsp)
180001be4:     	movq	%r10, 0x38(%rsp)
180001be9:     	movq	%r9, 0x30(%rsp)
180001bee:     	movq	%r11, 0x28(%rsp)
180001bf3:     	movq	%rbx, 0x20(%rsp)
180001bf8:     	leaq	0x70(%rsp), %rcx
180001bfd:     	leaq	0x68(%rsp), %rdx
180001c02:     	movq	%rax, %r9
180001c05:     	callq	0x1800045c0 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2050>
180001c0a:     	testl	%eax, %eax
180001c0c:     	jne	0x180001c33 <.text+0xc33>
180001c0e:     	movq	0x70(%rsp), %rax
180001c13:     	movq	%rax, (%rsi)
180001c16:     	xorl	%eax, %eax
180001c18:     	jmp	0x180001c29 <.text+0xc29>
180001c1a:     	leaq	0x8c7f(%rip), %rax      # 0x18000a8a0
180001c21:     	movq	%rax, (%rdx)
180001c24:     	movl	$0x1, %eax
180001c29:     	addq	$0x78, %rsp
180001c2d:     	popq	%rbx
180001c2e:     	popq	%rdi
180001c2f:     	popq	%rsi
180001c30:     	popq	%r14
180001c32:     	retq
180001c33:     	movq	0x68(%rsp), %rcx
180001c38:     	movq	%rcx, (%rdi)
180001c3b:     	jmp	0x180001c29 <.text+0xc29>
180001c3d:     	nopl	(%rax)
180001c40:     	pushq	%r15
180001c42:     	pushq	%r14
180001c44:     	pushq	%r13
180001c46:     	pushq	%r12
180001c48:     	pushq	%rsi
180001c49:     	pushq	%rdi
180001c4a:     	pushq	%rbp
180001c4b:     	pushq	%rbx
180001c4c:     	subq	$0x278, %rsp            # imm = 0x278
180001c53:     	movaps	%xmm7, 0x260(%rsp)
180001c5b:     	movaps	%xmm6, 0x250(%rsp)
180001c63:     	movq	%rdx, %rcx
180001c66:     	leaq	0x108(%rsp), %rax
180001c6e:     	movq	%rax, 0x60(%rsp)
180001c73:     	leaq	0x110(%rsp), %rax
180001c7b:     	movq	%rax, 0x58(%rsp)
180001c80:     	leaq	0x118(%rsp), %rax
180001c88:     	movq	%rax, 0x50(%rsp)
180001c8d:     	leaq	0x120(%rsp), %rax
180001c95:     	movq	%rax, 0x48(%rsp)
180001c9a:     	leaq	0x128(%rsp), %rax
180001ca2:     	movq	%rax, 0x40(%rsp)
180001ca7:     	leaq	0x130(%rsp), %rax
180001caf:     	movq	%rax, 0x38(%rsp)
180001cb4:     	leaq	0x138(%rsp), %rax
180001cbc:     	movq	%rax, 0x30(%rsp)
180001cc1:     	leaq	0x140(%rsp), %rax
180001cc9:     	movq	%rax, 0x28(%rsp)
180001cce:     	leaq	0x148(%rsp), %rax
180001cd6:     	movq	%rax, 0x20(%rsp)
180001cdb:     	leaq	0x8bee(%rip), %rdx      # 0x18000a8d0
180001ce2:     	movl	$0x9, %r8d
180001ce8:     	movl	$0x9, %r9d
180001cee:     	callq	0x180008a61 <numba_list_iter_next+0x311>
180001cf3:     	testl	%eax, %eax
180001cf5:     	movq	$0x0, 0xb8(%rsp)
180001d01:     	je	0x1800022ab <.text+0x12ab>
180001d07:     	cmpq	$0x0, 0xffe1(%rip)      # 0x180011cf0
180001d0f:     	je	0x1800021e3 <.text+0x11e3>
180001d15:     	movq	0x148(%rsp), %rcx
180001d1d:     	xorps	%xmm0, %xmm0
180001d20:     	movaps	%xmm0, 0x210(%rsp)
180001d28:     	movaps	%xmm0, 0x220(%rsp)
180001d30:     	movaps	%xmm0, 0x230(%rsp)
180001d38:     	movq	$0x0, 0x240(%rsp)
180001d44:     	leaq	0x210(%rsp), %rdx
180001d4c:     	callq	0x180007720 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x51b0>
180001d51:     	testl	%eax, %eax
180001d53:     	jne	0x1800021fb <.text+0x11fb>
180001d59:     	cmpq	$0x8, 0x228(%rsp)
180001d62:     	jne	0x1800021fb <.text+0x11fb>
180001d68:     	movq	0x210(%rsp), %rdi
180001d70:     	movq	0x230(%rsp), %r14
180001d78:     	movq	0x238(%rsp), %r12
180001d80:     	movq	0x240(%rsp), %rbx
180001d88:     	movq	0x140(%rsp), %rcx
180001d90:     	xorps	%xmm0, %xmm0
180001d93:     	movaps	%xmm0, 0x1d0(%rsp)
180001d9b:     	movaps	%xmm0, 0x1e0(%rsp)
180001da3:     	movaps	%xmm0, 0x1f0(%rsp)
180001dab:     	movq	$0x0, 0x200(%rsp)
180001db7:     	leaq	0x1d0(%rsp), %rdx
180001dbf:     	callq	0x180007720 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x51b0>
180001dc4:     	testl	%eax, %eax
180001dc6:     	jne	0x180002213 <.text+0x1213>
180001dcc:     	cmpq	$0x8, 0x1e8(%rsp)
180001dd5:     	jne	0x180002213 <.text+0x1213>
180001ddb:     	movq	0x1d0(%rsp), %r15
180001de3:     	movq	0x1f0(%rsp), %rbp
180001deb:     	movq	0x1f8(%rsp), %rsi
180001df3:     	movq	0x200(%rsp), %r13
180001dfb:     	movq	0x138(%rsp), %rcx
180001e03:     	xorps	%xmm0, %xmm0
180001e06:     	movaps	%xmm0, 0x190(%rsp)
180001e0e:     	movaps	%xmm0, 0x1a0(%rsp)
180001e16:     	movaps	%xmm0, 0x1b0(%rsp)
180001e1e:     	movq	$0x0, 0x1c0(%rsp)
180001e2a:     	leaq	0x190(%rsp), %rdx
180001e32:     	callq	0x180007720 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x51b0>
180001e37:     	testl	%eax, %eax
180001e39:     	jne	0x180002228 <.text+0x1228>
180001e3f:     	cmpq	$0x8, 0x1a8(%rsp)
180001e48:     	jne	0x180002228 <.text+0x1228>
180001e4e:     	movq	%r13, 0x100(%rsp)
180001e56:     	movq	0x190(%rsp), %r13
180001e5e:     	movq	0x1b0(%rsp), %rax
180001e66:     	movq	%rax, 0xf8(%rsp)
180001e6e:     	movq	0x1b8(%rsp), %rax
180001e76:     	movq	%rax, 0xf0(%rsp)
180001e7e:     	movq	0x1c0(%rsp), %rax
180001e86:     	movq	%rax, 0xe8(%rsp)
180001e8e:     	movq	0x130(%rsp), %rcx
180001e96:     	xorps	%xmm0, %xmm0
180001e99:     	movaps	%xmm0, 0x150(%rsp)
180001ea1:     	movaps	%xmm0, 0x160(%rsp)
180001ea9:     	movaps	%xmm0, 0x170(%rsp)
180001eb1:     	movq	$0x0, 0x180(%rsp)
180001ebd:     	leaq	0x150(%rsp), %rdx
180001ec5:     	callq	0x180007720 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x51b0>
180001eca:     	testl	%eax, %eax
180001ecc:     	jne	0x18000223d <.text+0x123d>
180001ed2:     	cmpq	$0x1, 0x168(%rsp)
180001edb:     	jne	0x18000223d <.text+0x123d>
180001ee1:     	movq	%rsi, 0xd8(%rsp)
180001ee9:     	movq	0x150(%rsp), %rax
180001ef1:     	movq	%rax, 0xa8(%rsp)
180001ef9:     	movq	0x170(%rsp), %rax
180001f01:     	movq	%rax, 0xd0(%rsp)
180001f09:     	movq	0x178(%rsp), %rax
180001f11:     	movq	%rax, 0xc8(%rsp)
180001f19:     	movq	0x180(%rsp), %rax
180001f21:     	movq	%rax, 0xc0(%rsp)
180001f29:     	movq	0x128(%rsp), %rcx
180001f31:     	callq	0x180008a67 <numba_list_iter_next+0x317>
180001f36:     	testq	%rax, %rax
180001f39:     	movq	%r13, 0xb0(%rsp)
180001f41:     	movq	%rbp, 0xe0(%rsp)
180001f49:     	je	0x180002252 <.text+0x1252>
180001f4f:     	movq	%rax, %rsi
180001f52:     	movq	%rax, %rcx
180001f55:     	callq	0x180008a6d <numba_list_iter_next+0x31d>
180001f5a:     	movq	%rax, 0xa0(%rsp)
180001f62:     	movq	%rsi, %rcx
180001f65:     	callq	0x180008a73 <numba_list_iter_next+0x323>
180001f6a:     	callq	0x180008a79 <numba_list_iter_next+0x329>
180001f6f:     	testq	%rax, %rax
180001f72:     	jne	0x18000227e <.text+0x127e>
180001f78:     	movq	0x120(%rsp), %rcx
180001f80:     	callq	0x180008a7f <numba_list_iter_next+0x32f>
180001f85:     	movq	%rax, %rsi
180001f88:     	movq	%rax, %rcx
180001f8b:     	callq	0x180008a85 <numba_list_iter_next+0x335>
180001f90:     	movaps	%xmm0, %xmm6
180001f93:     	movq	%rsi, %rcx
180001f96:     	callq	0x180008a73 <numba_list_iter_next+0x323>
180001f9b:     	callq	0x180008a79 <numba_list_iter_next+0x329>
180001fa0:     	testq	%rax, %rax
180001fa3:     	jne	0x18000227e <.text+0x127e>
180001fa9:     	movq	0x118(%rsp), %rcx
180001fb1:     	callq	0x180008a7f <numba_list_iter_next+0x32f>
180001fb6:     	movq	%rax, %rsi
180001fb9:     	movq	%rax, %rcx
180001fbc:     	callq	0x180008a85 <numba_list_iter_next+0x335>
180001fc1:     	movaps	%xmm0, %xmm7
180001fc4:     	movq	%rsi, %rcx
180001fc7:     	callq	0x180008a73 <numba_list_iter_next+0x323>
180001fcc:     	callq	0x180008a79 <numba_list_iter_next+0x329>
180001fd1:     	testq	%rax, %rax
180001fd4:     	jne	0x18000227e <.text+0x127e>
180001fda:     	movq	0x110(%rsp), %rcx
180001fe2:     	callq	0x180008a67 <numba_list_iter_next+0x317>
180001fe7:     	testq	%rax, %rax
180001fea:     	je	0x18000226e <.text+0x126e>
180001ff0:     	movq	%rax, %rsi
180001ff3:     	movq	%rax, %rcx
180001ff6:     	callq	0x180008a6d <numba_list_iter_next+0x31d>
180001ffb:     	movq	%rax, %rbp
180001ffe:     	movq	%rsi, %rcx
180002001:     	callq	0x180008a73 <numba_list_iter_next+0x323>
180002006:     	callq	0x180008a79 <numba_list_iter_next+0x329>
18000200b:     	testq	%rax, %rax
18000200e:     	jne	0x18000227e <.text+0x127e>
180002014:     	movq	%rbx, %r13
180002017:     	movq	%r12, %rbx
18000201a:     	movq	%r14, %r12
18000201d:     	movq	%r15, %r14
180002020:     	movq	%rdi, %r15
180002023:     	movq	0x108(%rsp), %rcx
18000202b:     	callq	0x180008a67 <numba_list_iter_next+0x317>
180002030:     	testq	%rax, %rax
180002033:     	je	0x1800022b2 <.text+0x12b2>
180002039:     	movq	%rax, %rdi
18000203c:     	movq	%rax, %rcx
18000203f:     	callq	0x180008a6d <numba_list_iter_next+0x31d>
180002044:     	movq	%rax, %rsi
180002047:     	movq	%rdi, %rcx
18000204a:     	callq	0x180008a73 <numba_list_iter_next+0x323>
18000204f:     	callq	0x180008a79 <numba_list_iter_next+0x329>
180002054:     	testq	%rax, %rax
180002057:     	movq	%r15, %rdi
18000205a:     	movq	%r14, %r15
18000205d:     	jne	0x18000227e <.text+0x127e>
180002063:     	movq	%rsi, 0x90(%rsp)
18000206b:     	movq	%rbp, 0x88(%rsp)
180002073:     	movsd	%xmm7, 0x80(%rsp)
18000207c:     	movsd	%xmm6, 0x78(%rsp)
180002082:     	movq	0xa0(%rsp), %rax
18000208a:     	movq	%rax, 0x70(%rsp)
18000208f:     	movq	0xc0(%rsp), %rax
180002097:     	movq	%rax, 0x68(%rsp)
18000209c:     	movq	0xc8(%rsp), %rax
1800020a4:     	movq	%rax, 0x60(%rsp)
1800020a9:     	movq	0xd0(%rsp), %rax
1800020b1:     	movq	%rax, 0x58(%rsp)
1800020b6:     	movq	0xe8(%rsp), %rax
1800020be:     	movq	%rax, 0x50(%rsp)
1800020c3:     	movq	0xf0(%rsp), %rax
1800020cb:     	movq	%rax, 0x48(%rsp)
1800020d0:     	movq	0xf8(%rsp), %rax
1800020d8:     	movq	%rax, 0x40(%rsp)
1800020dd:     	movq	0x100(%rsp), %rax
1800020e5:     	movq	%rax, 0x38(%rsp)
1800020ea:     	movq	0xd8(%rsp), %rax
1800020f2:     	movq	%rax, 0x30(%rsp)
1800020f7:     	movq	0xe0(%rsp), %rax
1800020ff:     	movq	%rax, 0x28(%rsp)
180002104:     	movq	%r13, 0x20(%rsp)
180002109:     	leaq	0x248(%rsp), %rcx
180002111:     	leaq	0xb8(%rsp), %rdx
180002119:     	movq	%r12, %r8
18000211c:     	movq	%rbx, %r9
18000211f:     	callq	0x180001b00 <.text+0xb00>
180002124:     	movl	%eax, %ebp
180002126:     	movq	0xb8(%rsp), %rbx
18000212e:     	movq	%rdi, %rcx
180002131:     	callq	0x180001060 <.text+0x60>
180002136:     	movq	%r15, %rcx
180002139:     	callq	0x180001060 <.text+0x60>
18000213e:     	movq	0xb0(%rsp), %rcx
180002146:     	callq	0x180001060 <.text+0x60>
18000214b:     	movq	0xa8(%rsp), %rcx
180002153:     	callq	0x180001060 <.text+0x60>
180002158:     	testl	%ebp, %ebp
18000215a:     	jne	0x180002192 <.text+0x1192>
18000215c:     	movq	0x816d(%rip), %rsi      # 0x18000a2d0
180002163:     	movq	%rsi, %rcx
180002166:     	callq	0x180008a8b <numba_list_iter_next+0x33b>
18000216b:     	movq	%rsi, %rax
18000216e:     	movaps	0x250(%rsp), %xmm6
180002176:     	movaps	0x260(%rsp), %xmm7
18000217e:     	addq	$0x278, %rsp            # imm = 0x278
180002185:     	popq	%rbx
180002186:     	popq	%rbp
180002187:     	popq	%rdi
180002188:     	popq	%rsi
180002189:     	popq	%r12
18000218b:     	popq	%r13
18000218d:     	popq	%r14
18000218f:     	popq	%r15
180002191:     	retq
180002192:     	jle	0x1800022b9 <.text+0x12b9>
180002198:     	callq	0x180008a91 <numba_list_iter_next+0x341>
18000219d:     	movl	0x8(%rbx), %edx
1800021a0:     	movq	(%rbx), %rcx
1800021a3:     	cmpl	$0x0, 0x20(%rbx)
1800021a7:     	jle	0x1800022d8 <.text+0x12d8>
1800021ad:     	movslq	%edx, %rdx
1800021b0:     	callq	0x180008a97 <numba_list_iter_next+0x347>
1800021b5:     	movq	%rax, %rsi
1800021b8:     	movq	0x10(%rbx), %rcx
1800021bc:     	callq	*0x18(%rbx)
1800021bf:     	testq	%rax, %rax
1800021c2:     	je	0x180002301 <.text+0x1301>
1800021c8:     	movq	%rsi, %rcx
1800021cb:     	movq	%rax, %rdx
1800021ce:     	callq	0x180006f30 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x49c0>
1800021d3:     	movq	%rax, %rsi
1800021d6:     	movq	%rbx, %rcx
1800021d9:     	callq	0x1800089c0 <numba_list_iter_next+0x270>
1800021de:     	jmp	0x1800022e4 <.text+0x12e4>
1800021e3:     	movq	0x80c6(%rip), %rcx      # 0x18000a2b0
1800021ea:     	leaq	0x86ff(%rip), %rdx      # 0x18000a8f0
1800021f1:     	callq	0x180008a9d <numba_list_iter_next+0x34d>
1800021f6:     	jmp	0x1800022ab <.text+0x12ab>
1800021fb:     	movq	0x809e(%rip), %rcx      # 0x18000a2a0
180002202:     	leaq	0x87e7(%rip), %rdx      # 0x18000a9f0
180002209:     	callq	0x180008a9d <numba_list_iter_next+0x34d>
18000220e:     	jmp	0x1800022ab <.text+0x12ab>
180002213:     	movq	0x8086(%rip), %rcx      # 0x18000a2a0
18000221a:     	leaq	0x87cf(%rip), %rdx      # 0x18000a9f0
180002221:     	callq	0x180008a9d <numba_list_iter_next+0x34d>
180002226:     	jmp	0x1800022a3 <.text+0x12a3>
180002228:     	movq	0x8071(%rip), %rcx      # 0x18000a2a0
18000222f:     	leaq	0x87ba(%rip), %rdx      # 0x18000a9f0
180002236:     	callq	0x180008a9d <numba_list_iter_next+0x34d>
18000223b:     	jmp	0x18000229b <.text+0x129b>
18000223d:     	movq	0x805c(%rip), %rcx      # 0x18000a2a0
180002244:     	leaq	0x87a5(%rip), %rdx      # 0x18000a9f0
18000224b:     	callq	0x180008a9d <numba_list_iter_next+0x34d>
180002250:     	jmp	0x180002293 <.text+0x1293>
180002252:     	movq	$0x0, 0xa0(%rsp)
18000225e:     	callq	0x180008a79 <numba_list_iter_next+0x329>
180002263:     	testq	%rax, %rax
180002266:     	je	0x180001f78 <.text+0xf78>
18000226c:     	jmp	0x18000227e <.text+0x127e>
18000226e:     	xorl	%ebp, %ebp
180002270:     	callq	0x180008a79 <numba_list_iter_next+0x329>
180002275:     	testq	%rax, %rax
180002278:     	je	0x180002014 <.text+0x1014>
18000227e:     	movq	0xa8(%rsp), %rcx
180002286:     	callq	0x180001060 <.text+0x60>
18000228b:     	movq	0xb0(%rsp), %r13
180002293:     	movq	%r13, %rcx
180002296:     	callq	0x180001060 <.text+0x60>
18000229b:     	movq	%r15, %rcx
18000229e:     	callq	0x180001060 <.text+0x60>
1800022a3:     	movq	%rdi, %rcx
1800022a6:     	callq	0x180001060 <.text+0x60>
1800022ab:     	xorl	%esi, %esi
1800022ad:     	jmp	0x18000216b <.text+0x116b>
1800022b2:     	xorl	%esi, %esi
1800022b4:     	jmp	0x18000204f <.text+0x104f>
1800022b9:     	cmpl	$-0x3, %ebp
1800022bc:     	je	0x1800022f3 <.text+0x12f3>
1800022be:     	cmpl	$-0x1, %ebp
1800022c1:     	je	0x1800022ab <.text+0x12ab>
1800022c3:     	movq	0x7fce(%rip), %rcx      # 0x18000a298
1800022ca:     	leaq	0x87bf(%rip), %rdx      # 0x18000aa90
1800022d1:     	callq	0x180008a9d <numba_list_iter_next+0x34d>
1800022d6:     	jmp	0x1800022ab <.text+0x12ab>
1800022d8:     	movq	0x10(%rbx), %r8
1800022dc:     	callq	0x180006e50 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x48e0>
1800022e1:     	movq	%rax, %rsi
1800022e4:     	testq	%rsi, %rsi
1800022e7:     	je	0x1800022ab <.text+0x12ab>
1800022e9:     	movq	%rsi, %rcx
1800022ec:     	callq	0x1800069f0 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4480>
1800022f1:     	jmp	0x1800022ab <.text+0x12ab>
1800022f3:     	movq	0x7f96(%rip), %rcx      # 0x18000a290
1800022fa:     	callq	0x180008aa3 <numba_list_iter_next+0x353>
1800022ff:     	jmp	0x1800022ab <.text+0x12ab>
180002301:     	movq	0x7fa8(%rip), %rcx      # 0x18000a2b0
180002308:     	leaq	0x8741(%rip), %rdx      # 0x18000aa50
18000230f:     	callq	0x180008a9d <numba_list_iter_next+0x34d>
180002314:     	jmp	0x1800022ab <.text+0x12ab>
180002316:     	nopw	%cs:(%rax,%rax)
180002320:     	pushq	%r15
180002322:     	pushq	%r14
180002324:     	pushq	%r13
180002326:     	pushq	%r12
180002328:     	pushq	%rsi
180002329:     	pushq	%rdi
18000232a:     	pushq	%rbp
18000232b:     	pushq	%rbx
18000232c:     	subq	$0xb8, %rsp
180002333:     	movq	0x120(%rsp), %r8
18000233b:     	movq	0x128(%rsp), %r9
180002343:     	movq	0x130(%rsp), %rax
18000234b:     	movq	0x158(%rsp), %rcx
180002353:     	movq	0x160(%rsp), %rdx
18000235b:     	movq	0x168(%rsp), %r10
180002363:     	movq	0x190(%rsp), %r11
18000236b:     	movq	0x198(%rsp), %rsi
180002373:     	movq	0x1a0(%rsp), %rdi
18000237b:     	movq	0x1c8(%rsp), %rbx
180002383:     	movq	0x1d0(%rsp), %r14
18000238b:     	movq	0x1d8(%rsp), %r15
180002393:     	movq	0x1e0(%rsp), %r12
18000239b:     	movsd	0x1e8(%rsp), %xmm0
1800023a4:     	movsd	0x1f0(%rsp), %xmm1
1800023ad:     	movq	0x1f8(%rsp), %r13
1800023b5:     	movq	0x200(%rsp), %rbp
1800023bd:     	movq	$0x0, 0xb0(%rsp)
1800023c9:     	movq	$0x0, 0xa8(%rsp)
1800023d5:     	movq	%rbp, 0x90(%rsp)
1800023dd:     	movq	%r13, 0x88(%rsp)
1800023e5:     	movsd	%xmm1, 0x80(%rsp)
1800023ee:     	movsd	%xmm0, 0x78(%rsp)
1800023f4:     	movq	%r12, 0x70(%rsp)
1800023f9:     	movq	%r15, 0x68(%rsp)
1800023fe:     	movq	%r14, 0x60(%rsp)
180002403:     	movq	%rbx, 0x58(%rsp)
180002408:     	movq	%rdi, 0x50(%rsp)
18000240d:     	movq	%rsi, 0x48(%rsp)
180002412:     	movq	%r11, 0x40(%rsp)
180002417:     	movq	%r10, 0x38(%rsp)
18000241c:     	movq	%rdx, 0x30(%rsp)
180002421:     	movq	%rcx, 0x28(%rsp)
180002426:     	movq	%rax, 0x20(%rsp)
18000242b:     	leaq	0xb0(%rsp), %rcx
180002433:     	leaq	0xa8(%rsp), %rdx
18000243b:     	callq	0x180001b00 <.text+0xb00>
180002440:     	movl	%eax, %edx
180002442:     	movq	0xa8(%rsp), %rsi
18000244a:     	movq	0xb0(%rsp), %rax
180002452:     	movl	$0x0, 0xa4(%rsp)
18000245d:     	testl	%edx, %edx
18000245f:     	jne	0x180002475 <.text+0x1475>
180002461:     	addq	$0xb8, %rsp
180002468:     	popq	%rbx
180002469:     	popq	%rbp
18000246a:     	popq	%rdi
18000246b:     	popq	%rsi
18000246c:     	popq	%r12
18000246e:     	popq	%r13
180002470:     	popq	%r14
180002472:     	popq	%r15
180002474:     	retq
180002475:     	movq	%rax, %rbx
180002478:     	leaq	0xa4(%rsp), %rcx
180002480:     	movl	%edx, %edi
180002482:     	callq	0x1800069c0 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4450>
180002487:     	testl	%edi, %edi
180002489:     	jle	0x1800024cf <.text+0x14cf>
18000248b:     	callq	0x180008a91 <numba_list_iter_next+0x341>
180002490:     	movl	0x8(%rsi), %edx
180002493:     	movq	(%rsi), %rcx
180002496:     	cmpl	$0x0, 0x20(%rsi)
18000249a:     	jle	0x1800024f0 <.text+0x14f0>
18000249c:     	movslq	%edx, %rdx
18000249f:     	callq	0x180008a97 <numba_list_iter_next+0x347>
1800024a4:     	movq	%rax, %rdi
1800024a7:     	movq	0x10(%rsi), %rcx
1800024ab:     	callq	*0x18(%rsi)
1800024ae:     	testq	%rax, %rax
1800024b1:     	je	0x18000254b <.text+0x154b>
1800024b7:     	movq	%rdi, %rcx
1800024ba:     	movq	%rax, %rdx
1800024bd:     	callq	0x180006f30 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x49c0>
1800024c2:     	movq	%rax, %rdi
1800024c5:     	movq	%rsi, %rcx
1800024c8:     	callq	0x1800089c0 <numba_list_iter_next+0x270>
1800024cd:     	jmp	0x1800024fc <.text+0x14fc>
1800024cf:     	movl	%edi, %eax
1800024d1:     	cmpl	$-0x3, %edi
1800024d4:     	je	0x18000253d <.text+0x153d>
1800024d6:     	cmpl	$-0x1, %eax
1800024d9:     	je	0x180002509 <.text+0x1509>
1800024db:     	movq	0x7db6(%rip), %rcx      # 0x18000a298
1800024e2:     	leaq	0x8617(%rip), %rdx      # 0x18000ab00
1800024e9:     	callq	0x180008a9d <numba_list_iter_next+0x34d>
1800024ee:     	jmp	0x180002509 <.text+0x1509>
1800024f0:     	movq	0x10(%rsi), %r8
1800024f4:     	callq	0x180006e50 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x48e0>
1800024f9:     	movq	%rax, %rdi
1800024fc:     	testq	%rdi, %rdi
1800024ff:     	je	0x180002509 <.text+0x1509>
180002501:     	movq	%rdi, %rcx
180002504:     	callq	0x1800069f0 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4480>
180002509:     	leaq	0x8620(%rip), %rcx      # 0x18000ab30
180002510:     	callq	0x180008aa9 <numba_list_iter_next+0x359>
180002515:     	movq	%rax, %rsi
180002518:     	movq	%rax, %rcx
18000251b:     	callq	0x180008aaf <numba_list_iter_next+0x35f>
180002520:     	movq	%rsi, %rcx
180002523:     	callq	0x180008a73 <numba_list_iter_next+0x323>
180002528:     	leaq	0xa4(%rsp), %rcx
180002530:     	callq	0x1800069e0 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4470>
180002535:     	movq	%rbx, %rax
180002538:     	jmp	0x180002461 <.text+0x1461>
18000253d:     	movq	0x7d4c(%rip), %rcx      # 0x18000a290
180002544:     	callq	0x180008aa3 <numba_list_iter_next+0x353>
180002549:     	jmp	0x180002509 <.text+0x1509>
18000254b:     	movq	0x7d5e(%rip), %rcx      # 0x18000a2b0
180002552:     	leaq	0x8567(%rip), %rdx      # 0x18000aac0
180002559:     	callq	0x180008a9d <numba_list_iter_next+0x34d>
18000255e:     	xorl	%eax, %eax
180002560:     	jmp	0x180002461 <.text+0x1461>
180002565:     	nopw	%cs:(%rax,%rax)
18000256f:     	nop

0000000180002570 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3>:
180002570:     	pushq	%rsi
180002571:     	subq	$0x20, %rsp
180002575:     	leaq	0xeae4(%rip), %rcx      # 0x180011060
18000257c:     	movl	$0x3f5, %edx            # imm = 0x3F5
180002581:     	callq	0x180008ab5 <numba_list_iter_next+0x365>
180002586:     	testq	%rax, %rax
180002589:     	je	0x1800025bb <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4b>
18000258b:     	leaq	0xea6e(%rip), %rdx      # 0x180011000
180002592:     	leaq	0x8607(%rip), %r8       # 0x18000aba0
180002599:     	leaq	0x87c0(%rip), %r9       # 0x18000ad60
1800025a0:     	movq	%rax, %rcx
1800025a3:     	movq	%rax, %rsi
1800025a6:     	callq	0x180007990 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5420>
1800025ab:     	movl	%eax, %ecx
1800025ad:     	xorl	%eax, %eax
1800025af:     	testl	%ecx, %ecx
1800025b1:     	cmoveq	%rsi, %rax
1800025b5:     	addq	$0x20, %rsp
1800025b9:     	popq	%rsi
1800025ba:     	retq
1800025bb:     	xorl	%eax, %eax
1800025bd:     	addq	$0x20, %rsp
1800025c1:     	popq	%rsi
1800025c2:     	retq
1800025c3:     	nopw	%cs:(%rax,%rax)
1800025cd:     	nopl	(%rax)
1800025d0:     	pushq	%r15
1800025d2:     	pushq	%r14
1800025d4:     	pushq	%r13
1800025d6:     	pushq	%r12
1800025d8:     	pushq	%rsi
1800025d9:     	pushq	%rdi
1800025da:     	pushq	%rbp
1800025db:     	pushq	%rbx
1800025dc:     	subq	$0xf8, %rsp
1800025e3:     	movapd	%xmm8, 0xe0(%rsp)
1800025ed:     	movaps	%xmm7, 0xd0(%rsp)
1800025f5:     	movapd	%xmm6, 0xc0(%rsp)
1800025fe:     	movq	0x190(%rsp), %r11
180002606:     	movq	0x168(%rsp), %r15
18000260e:     	movq	0x160(%rsp), %r13
180002616:     	movabsq	$-0x20000000000001, %rax # imm = 0xFFDFFFFFFFFFFFFF
180002620:     	movabsq	$-0x40000000000001, %r10 # imm = 0xFFBFFFFFFFFFFFFF
18000262a:     	movq	$0x0, 0x90(%rsp)
180002636:     	movq	$0x0, 0xa0(%rsp)
180002642:     	leaq	(%r11,%rax), %rsi
180002646:     	cmpq	%r10, %rsi
180002649:     	jb	0x18000265b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xeb>
18000264b:     	movq	0x198(%rsp), %rsi
180002653:     	addq	%rsi, %rax
180002656:     	cmpq	%r10, %rax
180002659:     	jae	0x18000269d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x12d>
18000265b:     	movb	$0x1, (%r15)
18000265f:     	movq	$0x4, 0x18(%r13)
180002667:     	xorl	%eax, %eax
180002669:     	movq	$0x0, (%rcx)
180002670:     	movaps	0xc0(%rsp), %xmm6
180002678:     	movaps	0xd0(%rsp), %xmm7
180002680:     	movaps	0xe0(%rsp), %xmm8
180002689:     	addq	$0xf8, %rsp
180002690:     	popq	%rbx
180002691:     	popq	%rbp
180002692:     	popq	%rdi
180002693:     	popq	%rsi
180002694:     	popq	%r12
180002696:     	popq	%r13
180002698:     	popq	%r14
18000269a:     	popq	%r15
18000269c:     	retq
18000269d:     	movq	0x170(%rsp), %r12
1800026a5:     	movq	(%r13), %r10
1800026a9:     	leaq	0x4(%r10), %rax
1800026ad:     	cmpq	%r12, %rax
1800026b0:     	jle	0x1800026b8 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x148>
1800026b2:     	movb	$0x2, (%r15)
1800026b6:     	jmp	0x180002667 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xf7>
1800026b8:     	movq	%rax, (%r13)
1800026bc:     	xorl	%eax, %eax
1800026be:     	cmpb	$0x0, (%r15)
1800026c2:     	jne	0x180002669 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xf9>
1800026c4:     	cvtsi2sd	%r11, %xmm0
1800026c9:     	movsd	0x7cdf(%rip), %xmm1     # 0x18000a3b0
1800026d1:     	mulsd	%xmm1, %xmm0
1800026d5:     	cvtsi2sd	%rsi, %xmm2
1800026da:     	mulsd	%xmm1, %xmm2
1800026de:     	movsd	%xmm0, 0x10(%r8,%r10,8)
1800026e5:     	movsd	%xmm2, 0x18(%r8,%r10,8)
1800026ec:     	movsd	%xmm0, 0x8(%r8,%r10,8)
1800026f3:     	movsd	%xmm2, (%r8,%r10,8)
1800026f9:     	cmpb	$0x0, (%r15)
1800026fd:     	jne	0x180002669 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xf9>
180002703:     	movq	(%r13), %rbx
180002707:     	leaq	0xb(%rbx), %r11
18000270b:     	cmpq	%r12, %r11
18000270e:     	jle	0x180002719 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x1a9>
180002710:     	movb	$0x2, (%r15)
180002714:     	jmp	0x180002669 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xf9>
180002719:     	movq	%r11, (%r13)
18000271d:     	cmpb	$0x0, (%r15)
180002721:     	jne	0x180002669 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xf9>
180002727:     	movq	%r10, (%r9,%rbx,8)
18000272b:     	movq	$0x4, 0x8(%r9,%rbx,8)
180002734:     	movq	(%r13), %r10
180002738:     	cmpq	%r12, %r10
18000273b:     	movq	%r10, %r11
18000273e:     	jle	0x18000274b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x1db>
180002740:     	movb	$0x2, (%r15)
180002744:     	movq	(%r13), %r10
180002748:     	xorl	%r11d, %r11d
18000274b:     	leaq	0x3(%r10), %rsi
18000274f:     	cmpq	%r12, %rsi
180002752:     	jg	0x180002710 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x1a0>
180002754:     	movq	%rsi, (%r13)
180002758:     	cmpb	$0x0, (%r15)
18000275c:     	jne	0x180002669 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xf9>
180002762:     	movq	%r10, %rax
180002765:     	sarq	$0x3f, %rax
180002769:     	andq	%r12, %rax
18000276c:     	leaq	(%r9,%r10,8), %rsi
180002770:     	movq	$0x0, (%rsi,%rax,8)
180002778:     	xorl	%eax, %eax
18000277a:     	cmpq	$-0x1, %r10
18000277e:     	movl	$0x0, %edi
180002783:     	cmovlq	%r12, %rdi
180002787:     	movq	$0x0, 0x8(%rsi,%rdi,8)
180002790:     	cmpq	$-0x2, %r10
180002794:     	movl	$0x0, %edi
180002799:     	cmovlq	%r12, %rdi
18000279d:     	movq	%r11, 0x10(%rsi,%rdi,8)
1800027a2:     	cmpb	$0x0, (%r15)
1800027a6:     	jne	0x180002669 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xf9>
1800027ac:     	leaq	(%r9,%rbx,8), %r11
1800027b0:     	movq	%r10, 0x30(%r11)
1800027b4:     	movq	$0x0, 0x18(%r11)
1800027bc:     	movq	(%r13), %r10
1800027c0:     	leaq	0x4(%r10), %rsi
1800027c4:     	cmpq	%r12, %rsi
1800027c7:     	jg	0x180002710 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x1a0>
1800027cd:     	movq	%rdx, 0x88(%rsp)
1800027d5:     	movq	%rsi, (%r13)
1800027d9:     	cmpb	$0x0, (%r15)
1800027dd:     	jne	0x180002669 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xf9>
1800027e3:     	movq	%rcx, 0x60(%rsp)
1800027e8:     	movq	$0x0, (%r8,%r10,8)
1800027f0:     	movq	$0x1, 0x8(%r9,%r10,8)
1800027f9:     	movq	%r8, 0x68(%rsp)
1800027fe:     	movq	$0x0, 0x10(%r8,%r10,8)
180002807:     	movq	$0x1, 0x18(%r9,%r10,8)
180002810:     	cmpb	$0x0, (%r15)
180002814:     	jne	0x180002c17 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x6a7>
18000281a:     	movq	%r9, %rdi
18000281d:     	movq	%r10, 0x10(%r11)
180002821:     	movq	0x68(%rsp), %rcx
180002826:     	movq	$0x0, 0x48(%rcx,%rbx,8)
18000282f:     	movq	$0x1, 0x50(%r11)
180002837:     	movq	$-0x1, 0x20(%r11)
18000283f:     	movq	$-0x1, 0x28(%r11)
180002847:     	movq	$-0x1, 0x38(%r11)
18000284f:     	movq	$-0x1, 0x40(%r11)
180002857:     	cmpb	$0x0, (%r15)
18000285b:     	jne	0x180002c17 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x6a7>
180002861:     	movq	0x178(%rsp), %rcx
180002869:     	movq	%rcx, %rax
18000286c:     	sarq	$0x3f, %rax
180002870:     	andq	%r12, %rax
180002873:     	leaq	(%rdi,%rcx,8), %rbp
180002877:     	movq	%rax, 0x78(%rsp)
18000287c:     	cmpq	$0x0, (%rbp,%rax,8)
180002882:     	jle	0x18000294a <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3da>
180002888:     	leaq	(,%r12,8), %rsi
180002890:     	xorl	%r14d, %r14d
180002893:     	cmpq	$-0x2, 0x178(%rsp)
18000289c:     	movq	0x8(%r13), %rax
1800028a0:     	cmovgeq	%r14, %rsi
1800028a4:     	shlq	$0x3, 0x78(%rsp)
1800028aa:     	movq	0x10(%rbp,%rsi), %rcx
1800028af:     	addq	%r14, %rcx
1800028b2:     	leaq	(%rdi,%rcx,8), %rdx
1800028b6:     	sarq	$0x3f, %rcx
1800028ba:     	andq	%r12, %rcx
1800028bd:     	movq	(%rdx,%rcx,8), %rcx
1800028c1:     	leaq	0x1(%rax), %rdx
1800028c5:     	movq	%rdx, 0x8(%r13)
1800028c9:     	cmpq	0x10(%r13), %rax
1800028cd:     	jge	0x180002ade <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x56e>
1800028d3:     	movq	%rcx, 0x48(%rsp)
1800028d8:     	movq	%rbx, 0x40(%rsp)
1800028dd:     	movq	%r12, 0x30(%rsp)
1800028e2:     	movq	%r15, 0x28(%rsp)
1800028e7:     	movq	%r13, 0x20(%rsp)
1800028ec:     	movq	$-0x1, 0x50(%rsp)
1800028f5:     	movq	$0x0, 0x38(%rsp)
1800028fe:     	leaq	0x77(%rsp), %rcx
180002903:     	leaq	0xb0(%rsp), %rdx
18000290b:     	movq	0x68(%rsp), %r8
180002910:     	movq	%rdi, %r9
180002913:     	callq	0x180003250 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xce0>
180002918:     	testl	%eax, %eax
18000291a:     	jne	0x180002ad1 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x561>
180002920:     	cmpb	$0x0, (%r15)
180002924:     	jne	0x180002c15 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x6a5>
18000292a:     	incq	%r14
18000292d:     	movq	0x8(%r13), %rax
180002931:     	decq	%rax
180002934:     	movq	%rax, 0x8(%r13)
180002938:     	movq	0x78(%rsp), %rcx
18000293d:     	cmpq	(%rbp,%rcx), %r14
180002942:     	jl	0x1800028aa <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x33a>
180002948:     	jmp	0x180002950 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3e0>
18000294a:     	shlq	$0x3, 0x78(%rsp)
180002950:     	movsd	0x188(%rsp), %xmm6
180002959:     	movsd	0x180(%rsp), %xmm7
180002962:     	leaq	(,%r12,8), %rax
18000296a:     	xorl	%r14d, %r14d
18000296d:     	cmpq	$-0x2, 0x178(%rsp)
180002976:     	cmovgeq	%r14, %rax
18000297a:     	movq	%rax, 0x80(%rsp)
180002982:     	xorpd	%xmm8, %xmm8
180002987:     	jmp	0x1800029a2 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x432>
180002989:     	movb	$0x1, (%r15)
18000298d:     	movq	$0x4c4b43, 0x18(%r13)   # imm = 0x4C4B43
180002995:     	incq	%r14
180002998:     	cmpb	$0x0, (%r15)
18000299c:     	jne	0x180002c17 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x6a7>
1800029a2:     	movq	0x78(%rsp), %rax
1800029a7:     	cmpq	(%rbp,%rax), %r14
1800029ac:     	jge	0x180002aef <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x57f>
1800029b2:     	movq	0x80(%rsp), %rax
1800029ba:     	movq	0x10(%rbp,%rax), %rax
1800029bf:     	addq	%r14, %rax
1800029c2:     	leaq	(%rdi,%rax,8), %rcx
1800029c6:     	sarq	$0x3f, %rax
1800029ca:     	andq	%r12, %rax
1800029cd:     	movq	(%rcx,%rax,8), %rsi
1800029d1:     	movq	0x8(%r13), %rax
1800029d5:     	leaq	0x1(%rax), %rcx
1800029d9:     	movq	%rcx, 0x8(%r13)
1800029dd:     	cmpq	0x10(%r13), %rax
1800029e1:     	jge	0x180002c09 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x699>
1800029e7:     	movsd	%xmm7, 0x48(%rsp)
1800029ed:     	movq	%rsi, 0x40(%rsp)
1800029f2:     	movq	%rbx, 0x38(%rsp)
1800029f7:     	movq	%r12, 0x30(%rsp)
1800029fc:     	movq	%r15, 0x28(%rsp)
180002a01:     	movq	%r13, 0x20(%rsp)
180002a06:     	leaq	0x90(%rsp), %rcx
180002a0e:     	leaq	0xb8(%rsp), %rdx
180002a16:     	movq	0x68(%rsp), %r8
180002a1b:     	movq	%rdi, %r9
180002a1e:     	callq	0x180002c30 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x6c0>
180002a23:     	testl	%eax, %eax
180002a25:     	jne	0x180002ad1 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x561>
180002a2b:     	xorl	%eax, %eax
180002a2d:     	cmpb	$0x0, (%r15)
180002a31:     	jne	0x180002c17 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x6a7>
180002a37:     	movsd	0x90(%rsp), %xmm1
180002a40:     	movsd	0xa0(%rsp), %xmm0
180002a49:     	decq	0x8(%r13)
180002a4d:     	movq	0x68(%rsp), %rcx
180002a52:     	movsd	0x8(%rcx,%rsi,8), %xmm2
180002a58:     	ucomisd	%xmm8, %xmm2
180002a5d:     	jne	0x180002a65 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4f5>
180002a5f:     	jnp	0x180002989 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x419>
180002a65:     	movq	(%rdi,%rsi,8), %rdx
180002a69:     	divsd	%xmm2, %xmm1
180002a6d:     	movq	0x68(%rsp), %r8
180002a72:     	addsd	(%r8,%rdx,8), %xmm1
180002a78:     	movsd	%xmm1, (%r8,%rdx,8)
180002a7e:     	movq	$0x0, 0x8(%rdi,%rdx,8)
180002a87:     	movsd	0x8(%r8,%rsi,8), %xmm1
180002a8e:     	ucomisd	%xmm8, %xmm1
180002a93:     	jne	0x180002aa8 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x538>
180002a95:     	jp	0x180002aa8 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x538>
180002a97:     	movb	$0x1, (%r15)
180002a9b:     	movq	$0x4c4b44, 0x18(%r13)   # imm = 0x4C4B44
180002aa3:     	jmp	0x180002995 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x425>
180002aa8:     	movq	(%rdi,%rsi,8), %rdx
180002aac:     	divsd	%xmm1, %xmm0
180002ab0:     	movq	0x68(%rsp), %r8
180002ab5:     	addsd	0x10(%r8,%rdx,8), %xmm0
180002abc:     	movsd	%xmm0, 0x10(%r8,%rdx,8)
180002ac3:     	movq	$0x0, 0x18(%rdi,%rdx,8)
180002acc:     	jmp	0x180002995 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x425>
180002ad1:     	movq	0x88(%rsp), %rcx
180002ad9:     	jmp	0x180002669 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xf9>
180002ade:     	movb	$0x1, (%r15)
180002ae2:     	movq	$0x9, 0x18(%r13)
180002aea:     	jmp	0x180002c15 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x6a5>
180002aef:     	xorl	%eax, %eax
180002af1:     	xorl	%ecx, %ecx
180002af3:     	movq	0x78(%rsp), %rdx
180002af8:     	cmpq	(%rbp,%rdx), %rcx
180002afd:     	jge	0x180002c17 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x6a7>
180002b03:     	movq	0x80(%rsp), %rdx
180002b0b:     	movq	0x10(%rbp,%rdx), %r8
180002b10:     	addq	%rcx, %r8
180002b13:     	leaq	(%rdi,%r8,8), %r9
180002b17:     	sarq	$0x3f, %r8
180002b1b:     	andq	%r12, %r8
180002b1e:     	movq	(%r9,%r8,8), %r8
180002b22:     	incq	%rcx
180002b25:     	movq	(%rdi,%r8,8), %r10
180002b29:     	movq	0x18(%rdi,%r8,8), %r11
180002b2e:     	movq	0x68(%rsp), %r9
180002b33:     	movsd	(%r9,%r10,8), %xmm0
180002b39:     	mulsd	%xmm6, %xmm0
180002b3d:     	addsd	(%r9,%r11,8), %xmm0
180002b43:     	movsd	%xmm0, (%r9,%r11,8)
180002b49:     	movq	$0x0, 0x8(%rdi,%r11,8)
180002b52:     	movq	(%rdi,%r8,8), %r10
180002b56:     	movq	0x18(%rdi,%r8,8), %r11
180002b5b:     	movsd	0x10(%r9,%r10,8), %xmm0
180002b62:     	mulsd	%xmm6, %xmm0
180002b66:     	addsd	0x10(%r9,%r11,8), %xmm0
180002b6d:     	movsd	%xmm0, 0x10(%r9,%r11,8)
180002b74:     	movq	$0x0, 0x18(%rdi,%r11,8)
180002b7d:     	movq	0x10(%rdi,%r8,8), %r10
180002b82:     	movq	0x18(%rdi,%r8,8), %r11
180002b87:     	movsd	(%r9,%r11,8), %xmm0
180002b8d:     	mulsd	%xmm6, %xmm0
180002b91:     	addsd	(%r9,%r10,8), %xmm0
180002b97:     	movsd	%xmm0, (%r9,%r10,8)
180002b9d:     	movq	$0x0, 0x8(%rdi,%r10,8)
180002ba6:     	movq	0x10(%rdi,%r8,8), %r10
180002bab:     	movq	0x18(%rdi,%r8,8), %r11
180002bb0:     	movsd	0x10(%r9,%r11,8), %xmm0
180002bb7:     	mulsd	%xmm6, %xmm0
180002bbb:     	addsd	0x10(%r9,%r10,8), %xmm0
180002bc2:     	movsd	%xmm0, 0x10(%r9,%r10,8)
180002bc9:     	movq	$0x0, 0x18(%rdi,%r10,8)
180002bd2:     	movq	(%rdi,%r8,8), %r10
180002bd6:     	movq	$0x0, (%r9,%r10,8)
180002bde:     	movq	$0x1, 0x8(%rdi,%r10,8)
180002be7:     	movq	(%rdi,%r8,8), %r8
180002beb:     	movq	$0x0, 0x10(%r9,%r8,8)
180002bf4:     	movq	$0x1, 0x18(%rdi,%r8,8)
180002bfd:     	cmpb	$0x0, (%r15)
180002c01:     	je	0x180002af3 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x583>
180002c07:     	jmp	0x180002c17 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x6a7>
180002c09:     	movb	$0x1, (%r15)
180002c0d:     	movq	$0xd, 0x18(%r13)
180002c15:     	xorl	%eax, %eax
180002c17:     	movq	0x60(%rsp), %rcx
180002c1c:     	jmp	0x180002669 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xf9>
180002c21:     	nopw	%cs:(%rax,%rax)
180002c2b:     	nopl	(%rax,%rax)
180002c30:     	pushq	%r15
180002c32:     	pushq	%r14
180002c34:     	pushq	%r13
180002c36:     	pushq	%r12
180002c38:     	pushq	%rsi
180002c39:     	pushq	%rdi
180002c3a:     	pushq	%rbp
180002c3b:     	pushq	%rbx
180002c3c:     	subq	$0x118, %rsp            # imm = 0x118
180002c43:     	movapd	%xmm8, 0x100(%rsp)
180002c4d:     	movapd	%xmm7, 0xf0(%rsp)
180002c56:     	movapd	%xmm6, 0xe0(%rsp)
180002c5f:     	movq	0x198(%rsp), %r14
180002c67:     	movq	$0x0, 0x60(%rsp)
180002c70:     	movb	$0x0, 0x68(%rsp)
180002c75:     	movq	$0x0, 0x70(%rsp)
180002c7e:     	movsd	0x48(%r8,%r14,8), %xmm0
180002c85:     	xorpd	%xmm1, %xmm1
180002c89:     	ucomisd	%xmm1, %xmm0
180002c8d:     	jne	0x180002ca6 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x736>
180002c8f:     	jp	0x180002ca6 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x736>
180002c91:     	movb	$0x1, 0x18(%rcx)
180002c95:     	movq	$0x0, 0x10(%rcx)
180002c9d:     	movb	$0x1, 0x8(%rcx)
180002ca1:     	jmp	0x180002e88 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x918>
180002ca6:     	movq	0x1a0(%rsp), %rbx
180002cae:     	movq	0x30(%r9,%r14,8), %rax
180002cb3:     	cmpq	$0x1, (%r9,%rax,8)
180002cb8:     	jne	0x180002cc5 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x755>
180002cba:     	movq	0x10(%r9,%rax,8), %rax
180002cbf:     	cmpq	%rbx, (%r9,%rax,8)
180002cc3:     	je	0x180002c91 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x721>
180002cc5:     	movq	0x188(%rsp), %rdi
180002ccd:     	movq	0x180(%rsp), %rsi
180002cd5:     	movq	0x10(%r9,%r14,8), %r10
180002cda:     	movsd	(%r8,%r10,8), %xmm1
180002ce0:     	cmpq	$0x0, 0x8(%r9,%r10,8)
180002ce6:     	setne	%r11b
180002cea:     	movq	0x10(%r9,%rbx,8), %rdx
180002cef:     	cmpq	$0x0, 0x8(%r9,%rdx,8)
180002cf5:     	setne	%al
180002cf8:     	subsd	(%r8,%rdx,8), %xmm1
180002cfe:     	andb	%r11b, %al
180002d01:     	cmpb	$0x1, %al
180002d03:     	jne	0x180002d27 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x7b7>
180002d05:     	movapd	0x76b3(%rip), %xmm2     # 0x18000a3c0
180002d0d:     	andpd	%xmm1, %xmm2
180002d11:     	ucomisd	0x76b7(%rip), %xmm2     # 0x18000a3d0
180002d19:     	jae	0x180002dce <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x85e>
180002d1f:     	xorpd	%xmm2, %xmm2
180002d23:     	addsd	%xmm2, %xmm1
180002d27:     	movsd	0x10(%r8,%r10,8), %xmm2
180002d2e:     	cmpq	$0x0, 0x18(%r9,%r10,8)
180002d34:     	subsd	0x10(%r8,%rdx,8), %xmm2
180002d3b:     	je	0x180002da5 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x835>
180002d3d:     	cmpq	$0x0, 0x18(%r9,%rdx,8)
180002d43:     	je	0x180002da5 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x835>
180002d45:     	movapd	0x7673(%rip), %xmm3     # 0x18000a3c0
180002d4d:     	andpd	%xmm2, %xmm3
180002d51:     	ucomisd	0x7677(%rip), %xmm3     # 0x18000a3d0
180002d59:     	jae	0x180002e12 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x8a2>
180002d5f:     	movapd	%xmm1, %xmm3
180002d63:     	mulsd	%xmm1, %xmm3
180002d67:     	ucomisd	0x7661(%rip), %xmm3     # 0x18000a3d0
180002d6f:     	setae	%dl
180002d72:     	testb	%dl, %al
180002d74:     	jne	0x180002dbe <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x84e>
180002d76:     	xorpd	%xmm4, %xmm4
180002d7a:     	addsd	%xmm4, %xmm2
180002d7e:     	movapd	%xmm2, %xmm4
180002d82:     	mulsd	%xmm2, %xmm4
180002d86:     	ucomisd	0x7642(%rip), %xmm4     # 0x18000a3d0
180002d8e:     	jae	0x180002dbe <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x84e>
180002d90:     	addsd	%xmm4, %xmm3
180002d94:     	ucomisd	0x7634(%rip), %xmm3     # 0x18000a3d0
180002d9c:     	setae	%dl
180002d9f:     	testb	%dl, %al
180002da1:     	jne	0x180002dbe <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x84e>
180002da3:     	jmp	0x180002dea <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x87a>
180002da5:     	movapd	%xmm1, %xmm3
180002da9:     	mulsd	%xmm1, %xmm3
180002dad:     	ucomisd	0x761b(%rip), %xmm3     # 0x18000a3d0
180002db5:     	setae	%dl
180002db8:     	andb	%dl, %al
180002dba:     	cmpb	$0x1, %al
180002dbc:     	jne	0x180002dde <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x86e>
180002dbe:     	movb	$0x1, (%rdi)
180002dc1:     	movq	$0x3d090c, 0x18(%rsi)   # imm = 0x3D090C
180002dc9:     	jmp	0x180002e70 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x900>
180002dce:     	movb	$0x1, (%rdi)
180002dd1:     	movq	$0x3d090a, 0x18(%rsi)   # imm = 0x3D090A
180002dd9:     	jmp	0x180002e70 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x900>
180002dde:     	movapd	%xmm2, %xmm4
180002de2:     	mulsd	%xmm2, %xmm4
180002de6:     	addsd	%xmm4, %xmm3
180002dea:     	xorps	%xmm4, %xmm4
180002ded:     	sqrtsd	%xmm3, %xmm4
180002df1:     	cmpq	$0x0, 0x18(%r9,%r14,8)
180002df7:     	je	0x180002e45 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x8d5>
180002df9:     	xorpd	%xmm5, %xmm5
180002dfd:     	ucomisd	%xmm5, %xmm3
180002e01:     	jne	0x180002e1f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x8af>
180002e03:     	jp	0x180002e1f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x8af>
180002e05:     	movb	$0x1, (%rdi)
180002e08:     	movq	$0x3d090f, 0x18(%rsi)   # imm = 0x3D090F
180002e10:     	jmp	0x180002e70 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x900>
180002e12:     	movb	$0x1, (%rdi)
180002e15:     	movq	$0x3d090b, 0x18(%rsi)   # imm = 0x3D090B
180002e1d:     	jmp	0x180002e70 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x900>
180002e1f:     	movsd	0x1a8(%rsp), %xmm6
180002e28:     	movq	(%r9,%r14,8), %rax
180002e2c:     	movsd	0x8(%r8,%rax,8), %xmm3
180002e33:     	addsd	%xmm3, %xmm3
180002e37:     	divsd	%xmm4, %xmm3
180002e3b:     	ucomisd	%xmm3, %xmm6
180002e3f:     	jbe	0x180002ef8 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x988>
180002e45:     	movsd	0x758b(%rip), %xmm3     # 0x18000a3d8
180002e4d:     	maxsd	%xmm4, %xmm3
180002e51:     	movapd	%xmm3, %xmm4
180002e55:     	mulsd	%xmm3, %xmm4
180002e59:     	xorpd	%xmm5, %xmm5
180002e5d:     	ucomisd	%xmm5, %xmm4
180002e61:     	jne	0x180002ebe <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x94e>
180002e63:     	jp	0x180002ebe <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x94e>
180002e65:     	movb	$0x1, (%rdi)
180002e68:     	movq	$0x3d0915, 0x18(%rsi)   # imm = 0x3D0915
180002e70:     	movq	$0x0, 0x18(%rcx)
180002e78:     	movq	$0x0, 0x10(%rcx)
180002e80:     	movq	$0x0, 0x8(%rcx)
180002e88:     	movq	$0x0, (%rcx)
180002e8f:     	xorl	%eax, %eax
180002e91:     	movaps	0xe0(%rsp), %xmm6
180002e99:     	movaps	0xf0(%rsp), %xmm7
180002ea1:     	movaps	0x100(%rsp), %xmm8
180002eaa:     	addq	$0x118, %rsp            # imm = 0x118
180002eb1:     	popq	%rbx
180002eb2:     	popq	%rbp
180002eb3:     	popq	%rdi
180002eb4:     	popq	%rsi
180002eb5:     	popq	%r12
180002eb7:     	popq	%r13
180002eb9:     	popq	%r14
180002ebb:     	popq	%r15
180002ebd:     	retq
180002ebe:     	movsd	0x8(%r8,%rbx,8), %xmm5
180002ec5:     	mulsd	0x7513(%rip), %xmm5     # 0x18000a3e0
180002ecd:     	mulsd	%xmm5, %xmm0
180002ed1:     	divsd	%xmm4, %xmm0
180002ed5:     	mulsd	%xmm0, %xmm1
180002ed9:     	divsd	%xmm3, %xmm1
180002edd:     	mulsd	%xmm0, %xmm2
180002ee1:     	divsd	%xmm3, %xmm2
180002ee5:     	movsd	%xmm2, 0x10(%rcx)
180002eea:     	movsd	%xmm1, (%rcx)
180002eee:     	movb	$0x0, 0x18(%rcx)
180002ef2:     	movb	$0x0, 0x8(%rcx)
180002ef6:     	jmp	0x180002e8f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x91f>
180002ef8:     	movq	0x190(%rsp), %r15
180002f00:     	movq	0x20(%r9,%r14,8), %rax
180002f05:     	testq	%rax, %rax
180002f08:     	js	0x180002faf <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xa3f>
180002f0e:     	movq	0x8(%rsi), %rdx
180002f12:     	leaq	0x1(%rdx), %r10
180002f16:     	movq	%r10, 0x8(%rsi)
180002f1a:     	cmpq	0x10(%rsi), %rdx
180002f1e:     	jge	0x180003100 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xb90>
180002f24:     	movq	%rcx, %r13
180002f27:     	movsd	%xmm6, 0x48(%rsp)
180002f2d:     	movq	%rbx, 0x40(%rsp)
180002f32:     	movq	%rax, 0x38(%rsp)
180002f37:     	movq	%r15, 0x30(%rsp)
180002f3c:     	movq	%rdi, 0x28(%rsp)
180002f41:     	movq	%rsi, 0x20(%rsp)
180002f46:     	leaq	0xc0(%rsp), %rcx
180002f4e:     	movq	%r15, %r12
180002f51:     	movq	%r8, %r15
180002f54:     	movq	%r9, %rbp
180002f57:     	callq	0x180002c30 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x6c0>
180002f5c:     	cmpb	$0x0, (%rdi)
180002f5f:     	jne	0x1800030db <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xb6b>
180002f65:     	cmpb	$0x0, 0xd8(%rsp)
180002f6d:     	movq	%r12, %rax
180002f70:     	setne	%r12b
180002f74:     	cmpb	$0x0, 0xc8(%rsp)
180002f7c:     	setne	%r11b
180002f80:     	xorpd	%xmm8, %xmm8
180002f85:     	movsd	0xc0(%rsp), %xmm7
180002f8e:     	addsd	%xmm8, %xmm7
180002f93:     	addsd	0xd0(%rsp), %xmm8
180002f9d:     	decq	0x8(%rsi)
180002fa1:     	movq	%r13, %rcx
180002fa4:     	movq	%r15, %r8
180002fa7:     	movq	%rbp, %r9
180002faa:     	movq	%rax, %r15
180002fad:     	jmp	0x180002fbe <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xa4e>
180002faf:     	movb	$0x1, %r11b
180002fb2:     	xorpd	%xmm7, %xmm7
180002fb6:     	xorpd	%xmm8, %xmm8
180002fbb:     	movb	$0x1, %r12b
180002fbe:     	movq	0x28(%r9,%r14,8), %rax
180002fc3:     	testq	%rax, %rax
180002fc6:     	js	0x180003075 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xb05>
180002fcc:     	movq	0x8(%rsi), %rdx
180002fd0:     	leaq	0x1(%rdx), %r10
180002fd4:     	movq	%r10, 0x8(%rsi)
180002fd8:     	cmpq	0x10(%rsi), %rdx
180002fdc:     	jge	0x180003110 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xba0>
180002fe2:     	movb	%r12b, 0x5f(%rsp)
180002fe7:     	movl	%r11d, %r12d
180002fea:     	movq	%rcx, %r13
180002fed:     	movsd	%xmm6, 0x48(%rsp)
180002ff3:     	movq	%rbx, 0x40(%rsp)
180002ff8:     	movq	%rax, 0x38(%rsp)
180002ffd:     	movq	%r15, 0x30(%rsp)
180003002:     	movq	%rdi, 0x28(%rsp)
180003007:     	movq	%rsi, 0x20(%rsp)
18000300c:     	leaq	0xa0(%rsp), %rcx
180003014:     	movq	%r8, %rbp
180003017:     	movq	%r9, %r15
18000301a:     	callq	0x180002c30 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x6c0>
18000301f:     	cmpb	$0x0, (%rdi)
180003022:     	jne	0x1800030db <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xb6b>
180003028:     	cmpb	$0x0, 0xb8(%rsp)
180003030:     	setne	%al
180003033:     	cmpb	$0x0, 0xa8(%rsp)
18000303b:     	setne	%cl
18000303e:     	addsd	0xa0(%rsp), %xmm7
180003047:     	addsd	0xb0(%rsp), %xmm8
180003051:     	decq	0x8(%rsi)
180003055:     	movl	%r12d, %r11d
180003058:     	andb	%cl, %r11b
18000305b:     	movzbl	0x5f(%rsp), %r12d
180003061:     	andb	%al, %r12b
180003064:     	movq	%r13, %rcx
180003067:     	movq	%rbp, %r8
18000306a:     	movq	%r15, %r9
18000306d:     	movq	0x190(%rsp), %r15
180003075:     	movq	0x38(%r9,%r14,8), %rax
18000307a:     	testq	%rax, %rax
18000307d:     	js	0x18000317d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xc0d>
180003083:     	movq	0x8(%rsi), %rdx
180003087:     	leaq	0x1(%rdx), %r10
18000308b:     	movq	%r10, 0x8(%rsi)
18000308f:     	cmpq	0x10(%rsi), %rdx
180003093:     	jge	0x180003120 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xbb0>
180003099:     	movb	%r12b, 0x5f(%rsp)
18000309e:     	movl	%r11d, %r12d
1800030a1:     	movq	%rcx, %r13
1800030a4:     	movsd	%xmm6, 0x48(%rsp)
1800030aa:     	movq	%rbx, 0x40(%rsp)
1800030af:     	movq	%rax, 0x38(%rsp)
1800030b4:     	movq	%r15, 0x30(%rsp)
1800030b9:     	movq	%rdi, 0x28(%rsp)
1800030be:     	movq	%rsi, 0x20(%rsp)
1800030c3:     	leaq	0x80(%rsp), %rcx
1800030cb:     	movq	%r8, %rbp
1800030ce:     	movq	%r9, %r15
1800030d1:     	callq	0x180002c30 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x6c0>
1800030d6:     	cmpb	$0x0, (%rdi)
1800030d9:     	je	0x180003130 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xbc0>
1800030db:     	movq	$0x0, 0x18(%r13)
1800030e3:     	movq	$0x0, 0x10(%r13)
1800030eb:     	movq	$0x0, 0x8(%r13)
1800030f3:     	movq	$0x0, (%r13)
1800030fb:     	jmp	0x180002e8f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x91f>
180003100:     	movb	$0x1, (%rdi)
180003103:     	movq	$0x3d0921, 0x18(%rsi)   # imm = 0x3D0921
18000310b:     	jmp	0x180002e70 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x900>
180003110:     	movb	$0x1, (%rdi)
180003113:     	movq	$0x3d0926, 0x18(%rsi)   # imm = 0x3D0926
18000311b:     	jmp	0x180002e70 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x900>
180003120:     	movb	$0x1, (%rdi)
180003123:     	movq	$0x3d092b, 0x18(%rsi)   # imm = 0x3D092B
18000312b:     	jmp	0x180002e70 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x900>
180003130:     	cmpb	$0x0, 0x98(%rsp)
180003138:     	setne	%al
18000313b:     	cmpb	$0x0, 0x88(%rsp)
180003143:     	setne	%cl
180003146:     	addsd	0x80(%rsp), %xmm7
18000314f:     	addsd	0x90(%rsp), %xmm8
180003159:     	decq	0x8(%rsi)
18000315d:     	movl	%r12d, %r11d
180003160:     	andb	%cl, %r11b
180003163:     	movzbl	0x5f(%rsp), %r12d
180003169:     	andb	%al, %r12b
18000316c:     	movq	%r13, %rcx
18000316f:     	movq	%rbp, %r8
180003172:     	movq	%r15, %r9
180003175:     	movq	0x190(%rsp), %r15
18000317d:     	movq	0x40(%r9,%r14,8), %rax
180003182:     	testq	%rax, %rax
180003185:     	js	0x180003232 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xcc2>
18000318b:     	movq	0x8(%rsi), %rdx
18000318f:     	leaq	0x1(%rdx), %r10
180003193:     	movq	%r10, 0x8(%rsi)
180003197:     	cmpq	0x10(%rsi), %rdx
18000319b:     	jge	0x1800031f5 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xc85>
18000319d:     	movl	%r11d, %ebp
1800031a0:     	movq	%rcx, %r14
1800031a3:     	movsd	%xmm6, 0x48(%rsp)
1800031a9:     	movq	%rbx, 0x40(%rsp)
1800031ae:     	movq	%rax, 0x38(%rsp)
1800031b3:     	movq	%r15, 0x30(%rsp)
1800031b8:     	movq	%rdi, 0x28(%rsp)
1800031bd:     	movq	%rsi, 0x20(%rsp)
1800031c2:     	leaq	0x60(%rsp), %rcx
1800031c7:     	callq	0x180002c30 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x6c0>
1800031cc:     	cmpb	$0x0, (%rdi)
1800031cf:     	je	0x180003205 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xc95>
1800031d1:     	movq	$0x0, 0x18(%r14)
1800031d9:     	movq	$0x0, 0x10(%r14)
1800031e1:     	movq	$0x0, 0x8(%r14)
1800031e9:     	movq	$0x0, (%r14)
1800031f0:     	jmp	0x180002e8f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x91f>
1800031f5:     	movb	$0x1, (%rdi)
1800031f8:     	movq	$0x3d0930, 0x18(%rsi)   # imm = 0x3D0930
180003200:     	jmp	0x180002e70 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x900>
180003205:     	cmpb	$0x0, 0x78(%rsp)
18000320a:     	setne	%al
18000320d:     	cmpb	$0x0, 0x68(%rsp)
180003212:     	setne	%cl
180003215:     	addsd	0x60(%rsp), %xmm7
18000321b:     	addsd	0x70(%rsp), %xmm8
180003222:     	decq	0x8(%rsi)
180003226:     	movl	%ebp, %r11d
180003229:     	andb	%cl, %r11b
18000322c:     	andb	%al, %r12b
18000322f:     	movq	%r14, %rcx
180003232:     	movb	%r12b, 0x18(%rcx)
180003236:     	movsd	%xmm8, 0x10(%rcx)
18000323c:     	movb	%r11b, 0x8(%rcx)
180003240:     	movsd	%xmm7, (%rcx)
180003244:     	jmp	0x180002e8f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x91f>
180003249:     	nopl	(%rax)
180003250:     	pushq	%r15
180003252:     	pushq	%r14
180003254:     	pushq	%r13
180003256:     	pushq	%r12
180003258:     	pushq	%rsi
180003259:     	pushq	%rdi
18000325a:     	pushq	%rbp
18000325b:     	pushq	%rbx
18000325c:     	subq	$0x108, %rsp            # imm = 0x108
180003263:     	movq	0x188(%rsp), %rax
18000326b:     	movq	0x180(%rsp), %rbx
180003273:     	movq	0x178(%rsp), %r13
18000327b:     	movq	0x170(%rsp), %rbp
180003283:     	movb	$0x0, 0x6f(%rsp)
180003288:     	movb	$0x0, 0x6a(%rsp)
18000328d:     	movb	$0x0, 0x69(%rsp)
180003292:     	movb	$0x0, 0x68(%rsp)
180003297:     	movb	$0x0, 0x67(%rsp)
18000329c:     	movb	$0x0, 0x6e(%rsp)
1800032a1:     	movb	$0x0, 0x6d(%rsp)
1800032a6:     	movb	$0x0, 0x6c(%rsp)
1800032ab:     	movb	$0x0, 0x6b(%rsp)
1800032b0:     	testq	%rax, %rax
1800032b3:     	je	0x1800032da <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xd6a>
1800032b5:     	cmpq	$0x1, %rax
1800032b9:     	jne	0x1800037ab <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x123b>
1800032bf:     	movq	(%rbp), %rdx
1800032c3:     	leaq	0x4(%rdx), %rax
1800032c7:     	cmpq	%rbx, %rax
1800032ca:     	jle	0x180003466 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xef6>
1800032d0:     	movb	$0x2, (%r13)
1800032d5:     	jmp	0x1800037ab <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x123b>
1800032da:     	movq	0x198(%rsp), %r14
1800032e2:     	movq	0x190(%rsp), %r15
1800032ea:     	movq	(%r9,%r15,8), %rax
1800032ee:     	movq	0x10(%r9,%r14,8), %rdx
1800032f3:     	movsd	(%r8,%rdx,8), %xmm0
1800032f9:     	movsd	0x8(%r8,%rax,8), %xmm2
180003300:     	movsd	0x10(%r8,%rax,8), %xmm1
180003307:     	movapd	%xmm1, %xmm3
18000330b:     	subsd	%xmm2, %xmm3
18000330f:     	xorl	%r12d, %r12d
180003312:     	ucomisd	%xmm3, %xmm0
180003316:     	jb	0x1800037ae <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x123e>
18000331c:     	addsd	%xmm2, %xmm1
180003320:     	ucomisd	%xmm0, %xmm1
180003324:     	jbe	0x1800037ae <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x123e>
18000332a:     	movsd	0x10(%r8,%rdx,8), %xmm0
180003331:     	movsd	(%r8,%rax,8), %xmm2
180003337:     	movsd	0x18(%r8,%rax,8), %xmm1
18000333e:     	movapd	%xmm1, %xmm3
180003342:     	subsd	%xmm2, %xmm3
180003346:     	ucomisd	%xmm3, %xmm0
18000334a:     	jb	0x1800037ab <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x123b>
180003350:     	addsd	%xmm2, %xmm1
180003354:     	xorl	%r12d, %r12d
180003357:     	ucomisd	%xmm0, %xmm1
18000335b:     	jbe	0x1800037ae <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x123e>
180003361:     	cmpb	$0x0, (%r13)
180003366:     	jne	0x1800037ae <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x123e>
18000336c:     	movq	0x18(%r9,%r15,8), %rdx
180003371:     	movq	0x30(%r9,%r15,8), %rax
180003376:     	movq	(%r9,%rax,8), %r10
18000337a:     	cmpq	0x8(%r9,%r15,8), %r10
18000337f:     	jge	0x180003655 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x10e5>
180003385:     	testq	%rdx, %rdx
180003388:     	jne	0x18000365a <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x10ea>
18000338e:     	leaq	(%r9,%rax,8), %rsi
180003392:     	movq	%rax, %r10
180003395:     	sarq	$0x3f, %r10
180003399:     	andq	%rbx, %r10
18000339c:     	movq	(%rsi,%r10,8), %r12
1800033a0:     	xorl	%r11d, %r11d
1800033a3:     	cmpq	$-0x1, %rax
1800033a7:     	cmovlq	%rbx, %r11
1800033ab:     	cmpq	0x8(%rsi,%r11,8), %r12
1800033b0:     	jne	0x180003b47 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x15d7>
1800033b6:     	movq	%rsi, 0xd0(%rsp)
1800033be:     	leaq	(%r12,%r12), %rdx
1800033c2:     	testq	%r12, %r12
1800033c5:     	movl	$0x4, %edi
1800033ca:     	cmovneq	%rdx, %rdi
1800033ce:     	movq	(%rbp), %rsi
1800033d2:     	movq	%rsi, 0x78(%rsp)
1800033d7:     	leaq	(%rsi,%rdi), %rdx
1800033db:     	cmpq	%rbx, %rdx
1800033de:     	jg	0x1800032d0 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xd60>
1800033e4:     	movq	%rdx, (%rbp)
1800033e8:     	cmpb	$0x0, (%r13)
1800033ed:     	jne	0x1800037ab <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x123b>
1800033f3:     	movq	%rdi, 0xb8(%rsp)
1800033fb:     	movq	%r11, 0xc0(%rsp)
180003403:     	movq	%r10, 0xc8(%rsp)
18000340b:     	xorl	%edx, %edx
18000340d:     	cmpq	$-0x2, %rax
180003411:     	cmovlq	%rbx, %rdx
180003415:     	movq	%rdx, 0x98(%rsp)
18000341d:     	movq	%r12, 0xa0(%rsp)
180003425:     	testq	%r12, %r12
180003428:     	jle	0x180003b08 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x1598>
18000342e:     	leaq	(%r9,%rax,8), %rdx
180003432:     	movq	0x98(%rsp), %r10
18000343a:     	movq	0x10(%rdx,%r10,8), %rdi
18000343f:     	movq	0xa0(%rsp), %rdx
180003447:     	movl	%edx, %esi
180003449:     	andl	$0x7, %esi
18000344c:     	cmpq	$0x7, %rdx
180003450:     	ja	0x180003837 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x12c7>
180003456:     	leaq	(,%rbx,8), %r11
18000345e:     	xorl	%r12d, %r12d
180003461:     	jmp	0x180003aca <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x155a>
180003466:     	movq	0x1a0(%rsp), %r15
18000346e:     	movq	(%r9,%r15,8), %r10
180003472:     	movsd	0x10(%r8,%r10,8), %xmm2
180003479:     	movsd	0x18(%r8,%r10,8), %xmm1
180003480:     	movsd	0x6f28(%rip), %xmm0     # 0x18000a3b0
180003488:     	movsd	0x8(%r8,%r10,8), %xmm3
18000348f:     	mulsd	%xmm0, %xmm3
180003493:     	mulsd	(%r8,%r10,8), %xmm0
180003499:     	movq	%rax, (%rbp)
18000349d:     	cmpb	$0x0, (%r13)
1800034a2:     	jne	0x1800037ab <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x123b>
1800034a8:     	movapd	%xmm2, %xmm4
1800034ac:     	addsd	%xmm3, %xmm4
1800034b0:     	movapd	%xmm1, %xmm5
1800034b4:     	subsd	%xmm0, %xmm5
1800034b8:     	movsd	%xmm4, 0x10(%r8,%rdx,8)
1800034bf:     	movsd	%xmm5, 0x18(%r8,%rdx,8)
1800034c6:     	movsd	%xmm3, 0x8(%r8,%rdx,8)
1800034cd:     	movsd	%xmm0, (%r8,%rdx,8)
1800034d3:     	cmpb	$0x0, (%r13)
1800034d8:     	jne	0x1800037ab <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x123b>
1800034de:     	movq	(%rbp), %rax
1800034e2:     	leaq	0xb(%rax), %r11
1800034e6:     	cmpq	%rbx, %r11
1800034e9:     	jg	0x1800032d0 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xd60>
1800034ef:     	movq	0x8(%r9,%r15,8), %r10
1800034f4:     	movq	%r11, (%rbp)
1800034f8:     	cmpb	$0x0, (%r13)
1800034fd:     	jne	0x1800037ab <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x123b>
180003503:     	movq	%rdx, (%r9,%rax,8)
180003507:     	movq	%r10, 0x8(%r9,%rax,8)
18000350c:     	movq	(%rbp), %rdx
180003510:     	cmpq	%rbx, %rdx
180003513:     	movq	%rdx, %r10
180003516:     	jle	0x180003524 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xfb4>
180003518:     	movb	$0x2, (%r13)
18000351d:     	movq	(%rbp), %rdx
180003521:     	xorl	%r10d, %r10d
180003524:     	leaq	0x3(%rdx), %r11
180003528:     	cmpq	%rbx, %r11
18000352b:     	jg	0x1800032d0 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xd60>
180003531:     	movq	%r11, (%rbp)
180003535:     	cmpb	$0x0, (%r13)
18000353a:     	jne	0x1800037ab <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x123b>
180003540:     	movq	%rdx, %r11
180003543:     	sarq	$0x3f, %r11
180003547:     	andq	%rbx, %r11
18000354a:     	leaq	(%r9,%rdx,8), %rsi
18000354e:     	movq	$0x0, (%rsi,%r11,8)
180003556:     	xorl	%r12d, %r12d
180003559:     	cmpq	$-0x1, %rdx
18000355d:     	movl	$0x0, %r11d
180003563:     	cmovlq	%rbx, %r11
180003567:     	movq	$0x0, 0x8(%rsi,%r11,8)
180003570:     	cmpq	$-0x2, %rdx
180003574:     	movl	$0x0, %r11d
18000357a:     	cmovlq	%rbx, %r11
18000357e:     	movq	%r10, 0x10(%rsi,%r11,8)
180003583:     	cmpb	$0x0, (%r13)
180003588:     	jne	0x1800037ae <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x123e>
18000358e:     	leaq	(%r9,%rax,8), %r10
180003592:     	movq	%rdx, 0x30(%r10)
180003596:     	movq	$0x0, 0x18(%r10)
18000359e:     	movq	(%rbp), %rdx
1800035a2:     	leaq	0x4(%rdx), %r11
1800035a6:     	cmpq	%rbx, %r11
1800035a9:     	jg	0x1800032d0 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xd60>
1800035af:     	movq	%r11, (%rbp)
1800035b3:     	cmpb	$0x0, (%r13)
1800035b8:     	jne	0x1800037ab <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x123b>
1800035be:     	movq	%rcx, %r14
1800035c1:     	movq	$0x0, (%r8,%rdx,8)
1800035c9:     	movq	$0x1, 0x8(%r9,%rdx,8)
1800035d2:     	movq	$0x0, 0x10(%r8,%rdx,8)
1800035db:     	movq	$0x1, 0x18(%r9,%rdx,8)
1800035e4:     	cmpb	$0x0, (%r13)
1800035e9:     	jne	0x180003d8d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x181d>
1800035ef:     	movq	%r8, %rdi
1800035f2:     	movq	%r9, %rsi
1800035f5:     	movq	%rdx, 0x10(%r10)
1800035f9:     	movq	$0x0, 0x48(%r8,%rax,8)
180003602:     	movq	$0x1, 0x50(%r10)
18000360a:     	movq	$-0x1, 0x20(%r10)
180003612:     	movq	$-0x1, 0x28(%r10)
18000361a:     	movq	$-0x1, 0x38(%r10)
180003622:     	movq	$-0x1, 0x40(%r10)
18000362a:     	cmpb	$0x0, (%r13)
18000362f:     	jne	0x180003d8d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x181d>
180003635:     	movq	%rax, 0x20(%rsi,%r15,8)
18000363a:     	movq	(%rbp), %rcx
18000363e:     	leaq	0x4(%rcx), %rax
180003642:     	cmpq	%rbx, %rax
180003645:     	jle	0x180003d60 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x17f0>
18000364b:     	movb	$0x2, (%r13)
180003650:     	jmp	0x180003d8d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x181d>
180003655:     	testq	%rdx, %rdx
180003658:     	je	0x1800036d5 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x1165>
18000365a:     	movq	0x20(%r9,%r15,8), %rax
18000365f:     	testq	%rax, %rax
180003662:     	js	0x18000379e <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x122e>
180003668:     	movq	0x8(%rbp), %rdx
18000366c:     	leaq	0x1(%rdx), %r10
180003670:     	movq	%r10, 0x8(%rbp)
180003674:     	cmpq	0x10(%rbp), %rdx
180003678:     	jge	0x18000379e <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x122e>
18000367e:     	movq	%rcx, %rdi
180003681:     	movb	$0x0, 0x6a(%rsp)
180003686:     	movq	%r14, 0x48(%rsp)
18000368b:     	movq	%rax, 0x40(%rsp)
180003690:     	movq	%rbx, 0x30(%rsp)
180003695:     	movq	%r13, 0x28(%rsp)
18000369a:     	movq	%rbp, 0x20(%rsp)
18000369f:     	movq	$-0x1, 0x50(%rsp)
1800036a8:     	movq	$0x0, 0x38(%rsp)
1800036b1:     	leaq	0x6a(%rsp), %rcx
1800036b6:     	movq	%r8, 0x70(%rsp)
1800036bb:     	movq	%r9, %rsi
1800036be:     	callq	0x180003250 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xce0>
1800036c3:     	cmpb	$0x0, (%r13)
1800036c8:     	je	0x180003747 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x11d7>
1800036ca:     	xorl	%r12d, %r12d
1800036cd:     	movq	%rdi, %rcx
1800036d0:     	jmp	0x1800037ae <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x123e>
1800036d5:     	movq	0x8(%rbp), %rax
1800036d9:     	leaq	0x1(%rax), %rdx
1800036dd:     	movq	%rdx, 0x8(%rbp)
1800036e1:     	cmpq	0x10(%rbp), %rax
1800036e5:     	jge	0x180003738 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x11c8>
1800036e7:     	movq	%rcx, %rsi
1800036ea:     	movq	%r15, 0x50(%rsp)
1800036ef:     	movq	%rbx, 0x30(%rsp)
1800036f4:     	movq	%r13, 0x28(%rsp)
1800036f9:     	movq	%rbp, 0x20(%rsp)
1800036fe:     	movq	$-0x1, 0x48(%rsp)
180003707:     	movq	$-0x1, 0x40(%rsp)
180003710:     	movq	$0x1, 0x38(%rsp)
180003719:     	leaq	0x6f(%rsp), %rcx
18000371e:     	movq	%r8, %rdi
180003721:     	movq	%r9, %r12
180003724:     	callq	0x180003250 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xce0>
180003729:     	cmpb	$0x0, (%r13)
18000372e:     	je	0x180003783 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x1213>
180003730:     	xorl	%r12d, %r12d
180003733:     	movq	%rsi, %rcx
180003736:     	jmp	0x1800037ae <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x123e>
180003738:     	movb	$0x1, (%r13)
18000373d:     	movq	$0x2dc6cb, 0x18(%rbp)   # imm = 0x2DC6CB
180003745:     	jmp	0x1800037ab <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x123b>
180003747:     	movq	0x8(%rbp), %rdx
18000374b:     	leaq	-0x1(%rdx), %rax
18000374f:     	cmpb	$0x0, 0x6a(%rsp)
180003754:     	movq	%rax, 0x8(%rbp)
180003758:     	movb	$0x1, %r12b
18000375b:     	movq	%rdi, %rcx
18000375e:     	jne	0x1800037ae <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x123e>
180003760:     	movq	0x28(%rsi,%r15,8), %rax
180003765:     	testq	%rax, %rax
180003768:     	js	0x180003774 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x1204>
18000376a:     	movq	%rdx, 0x8(%rbp)
18000376e:     	cmpq	0x10(%rbp), %rdx
180003772:     	jle	0x1800037cb <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x125b>
180003774:     	movb	$0x1, (%r13)
180003779:     	movq	$0x2dc6ce, 0x18(%rbp)   # imm = 0x2DC6CE
180003781:     	jmp	0x1800037ab <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x123b>
180003783:     	decq	0x8(%rbp)
180003787:     	movq	%rsi, %rcx
18000378a:     	movq	%r12, %r9
18000378d:     	movq	%rdi, %r8
180003790:     	movq	0x20(%r9,%r15,8), %rax
180003795:     	testq	%rax, %rax
180003798:     	jns	0x180003668 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x10f8>
18000379e:     	movb	$0x1, (%r13)
1800037a3:     	movq	$0x2dc6cd, 0x18(%rbp)   # imm = 0x2DC6CD
1800037ab:     	xorl	%r12d, %r12d
1800037ae:     	andb	$0x1, %r12b
1800037b2:     	movb	%r12b, (%rcx)
1800037b5:     	xorl	%eax, %eax
1800037b7:     	addq	$0x108, %rsp            # imm = 0x108
1800037be:     	popq	%rbx
1800037bf:     	popq	%rbp
1800037c0:     	popq	%rdi
1800037c1:     	popq	%rsi
1800037c2:     	popq	%r12
1800037c4:     	popq	%r13
1800037c6:     	popq	%r14
1800037c8:     	popq	%r15
1800037ca:     	retq
1800037cb:     	movq	%rsi, %r9
1800037ce:     	movb	$0x0, 0x69(%rsp)
1800037d3:     	movq	%r14, 0x48(%rsp)
1800037d8:     	movq	%rax, 0x40(%rsp)
1800037dd:     	movq	%rbx, 0x30(%rsp)
1800037e2:     	movq	%r13, 0x28(%rsp)
1800037e7:     	movq	%rbp, 0x20(%rsp)
1800037ec:     	movq	$-0x1, 0x50(%rsp)
1800037f5:     	movq	$0x0, 0x38(%rsp)
1800037fe:     	leaq	0x69(%rsp), %rcx
180003803:     	movq	0x70(%rsp), %r8
180003808:     	callq	0x180003250 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xce0>
18000380d:     	cmpb	$0x0, (%r13)
180003812:     	jne	0x1800036ca <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x115a>
180003818:     	movq	0x8(%rbp), %rcx
18000381c:     	leaq	-0x1(%rcx), %rax
180003820:     	cmpb	$0x0, 0x69(%rsp)
180003825:     	movq	%rax, 0x8(%rbp)
180003829:     	je	0x180003ca7 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x1737>
18000382f:     	movq	%rdi, %rcx
180003832:     	jmp	0x1800037ae <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x123e>
180003837:     	movq	%rax, 0xa8(%rsp)
18000383f:     	movq	%rsi, 0xb0(%rsp)
180003847:     	movabsq	$0x7ffffffffffffff8, %r12 # imm = 0x7FFFFFFFFFFFFFF8
180003851:     	andq	%rdx, %r12
180003854:     	movq	0x78(%rsp), %rax
180003859:     	leaq	(%r9,%rax,8), %rax
18000385d:     	movq	%rax, 0xe0(%rsp)
180003865:     	leaq	(,%rbx,8), %r11
18000386d:     	xorl	%esi, %esi
18000386f:     	movq	%r12, 0xe8(%rsp)
180003877:     	movq	%rdi, 0xd8(%rsp)
18000387f:     	leaq	(%rdi,%rsi), %r12
180003883:     	movq	%r12, %rdx
180003886:     	sarq	$0x3f, %rdx
18000388a:     	andq	%r11, %rdx
18000388d:     	leaq	(%r9,%rdi,8), %rdi
180003891:     	addq	%rdi, %rdx
180003894:     	movq	%rdi, 0x70(%rsp)
180003899:     	movq	(%rdx,%rsi,8), %r11
18000389d:     	movq	0x78(%rsp), %rax
1800038a2:     	leaq	(%rax,%rsi), %r10
1800038a6:     	movq	%r10, %rdx
1800038a9:     	sarq	$0x3f, %rdx
1800038ad:     	leaq	(,%rbx,8), %rax
1800038b5:     	andq	%rax, %rdx
1800038b8:     	movq	0xe0(%rsp), %rax
1800038c0:     	addq	%rax, %rdx
1800038c3:     	movq	%r11, (%rdx,%rsi,8)
1800038c7:     	movq	%r12, %rdx
1800038ca:     	incq	%rdx
1800038cd:     	movl	$0x8, %edx
1800038d2:     	leaq	0x8(,%rbx,8), %r11
1800038da:     	movq	%r11, 0x80(%rsp)
1800038e2:     	cmovsq	%r11, %rdx
1800038e6:     	addq	%rdi, %rdx
1800038e9:     	movq	(%rdx,%rsi,8), %rdx
1800038ed:     	movq	%r10, %r11
1800038f0:     	incq	%r11
1800038f3:     	movl	$0x8, %r11d
1800038f9:     	cmovsq	0x80(%rsp), %r11
180003902:     	addq	%rax, %r11
180003905:     	movq	%rdx, (%r11,%rsi,8)
180003909:     	movq	%r12, %rdx
18000390c:     	addq	$0x2, %rdx
180003910:     	movl	$0x10, %edx
180003915:     	leaq	0x10(,%rbx,8), %r11
18000391d:     	movq	%r11, 0x90(%rsp)
180003925:     	cmovsq	%r11, %rdx
180003929:     	addq	%rdi, %rdx
18000392c:     	movq	(%rdx,%rsi,8), %rdx
180003930:     	movq	%r10, %r11
180003933:     	addq	$0x2, %r11
180003937:     	movl	$0x10, %r11d
18000393d:     	cmovsq	0x90(%rsp), %r11
180003946:     	addq	%rax, %r11
180003949:     	movq	%rdx, (%r11,%rsi,8)
18000394d:     	movq	%r12, %rdx
180003950:     	addq	$0x3, %rdx
180003954:     	movl	$0x18, %edx
180003959:     	leaq	0x18(,%rbx,8), %r11
180003961:     	movq	%r11, 0x88(%rsp)
180003969:     	cmovsq	%r11, %rdx
18000396d:     	addq	%rdi, %rdx
180003970:     	movq	(%rdx,%rsi,8), %rdx
180003974:     	movq	%r10, %r11
180003977:     	addq	$0x3, %r11
18000397b:     	movl	$0x18, %r11d
180003981:     	cmovsq	0x88(%rsp), %r11
18000398a:     	addq	%rax, %r11
18000398d:     	movq	%rdx, (%r11,%rsi,8)
180003991:     	movq	%r12, %rdx
180003994:     	addq	$0x4, %rdx
180003998:     	movl	$0x20, %edx
18000399d:     	leaq	0x20(,%rbx,8), %r11
1800039a5:     	movq	%r11, 0x100(%rsp)
1800039ad:     	cmovsq	%r11, %rdx
1800039b1:     	addq	%rdi, %rdx
1800039b4:     	movq	(%rdx,%rsi,8), %rdx
1800039b8:     	movq	%r10, %r11
1800039bb:     	addq	$0x4, %r11
1800039bf:     	movl	$0x20, %r11d
1800039c5:     	cmovsq	0x100(%rsp), %r11
1800039ce:     	addq	%rax, %r11
1800039d1:     	movq	%rdx, (%r11,%rsi,8)
1800039d5:     	movq	%r12, %rdx
1800039d8:     	addq	$0x5, %rdx
1800039dc:     	movl	$0x28, %edx
1800039e1:     	leaq	0x28(,%rbx,8), %r11
1800039e9:     	movq	%r11, 0xf8(%rsp)
1800039f1:     	cmovsq	%r11, %rdx
1800039f5:     	addq	%rdi, %rdx
1800039f8:     	movq	(%rdx,%rsi,8), %rdx
1800039fc:     	movq	%r10, %r11
1800039ff:     	addq	$0x5, %r11
180003a03:     	movl	$0x28, %r11d
180003a09:     	cmovsq	0xf8(%rsp), %r11
180003a12:     	addq	%rax, %r11
180003a15:     	movq	%rdx, (%r11,%rsi,8)
180003a19:     	movq	%r12, %rdx
180003a1c:     	addq	$0x6, %rdx
180003a20:     	movl	$0x30, %edx
180003a25:     	leaq	0x30(,%rbx,8), %r11
180003a2d:     	movq	%r11, 0xf0(%rsp)
180003a35:     	cmovsq	%r11, %rdx
180003a39:     	addq	%rdi, %rdx
180003a3c:     	movq	(%rdx,%rsi,8), %rdx
180003a40:     	movq	%r10, %r11
180003a43:     	addq	$0x6, %r11
180003a47:     	movl	$0x30, %r11d
180003a4d:     	cmovsq	0xf0(%rsp), %r11
180003a56:     	addq	%rax, %r11
180003a59:     	movq	%rdx, (%r11,%rsi,8)
180003a5d:     	leaq	(,%rbx,8), %r11
180003a65:     	addq	$0x7, %r12
180003a69:     	movq	0xe8(%rsp), %r12
180003a71:     	movl	$0x38, %edx
180003a76:     	leaq	0x38(,%rbx,8), %rdi
180003a7e:     	cmovsq	%rdi, %rdx
180003a82:     	addq	0x70(%rsp), %rdx
180003a87:     	movq	(%rdx,%rsi,8), %rdx
180003a8b:     	addq	$0x7, %r10
180003a8f:     	movl	$0x38, %r10d
180003a95:     	cmovsq	%rdi, %r10
180003a99:     	movq	0xd8(%rsp), %rdi
180003aa1:     	addq	%rax, %r10
180003aa4:     	movq	%rdx, (%r10,%rsi,8)
180003aa8:     	addq	$0x8, %rsi
180003aac:     	cmpq	%rsi, %r12
180003aaf:     	jne	0x18000387f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x130f>
180003ab5:     	movq	0xb0(%rsp), %rsi
180003abd:     	testq	%rsi, %rsi
180003ac0:     	movq	0xa8(%rsp), %rax
180003ac8:     	je	0x180003b08 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x1598>
180003aca:     	movq	0x78(%rsp), %rdx
180003acf:     	addq	%r12, %rdx
180003ad2:     	addq	%r12, %rdi
180003ad5:     	movq	%rdi, %r10
180003ad8:     	sarq	$0x3f, %r10
180003adc:     	andq	%r11, %r10
180003adf:     	addq	%r9, %r10
180003ae2:     	movq	(%r10,%rdi,8), %r10
180003ae6:     	movq	%r11, %r12
180003ae9:     	movq	%rdx, %r11
180003aec:     	sarq	$0x3f, %r11
180003af0:     	andq	%r12, %r11
180003af3:     	addq	%r9, %r11
180003af6:     	movq	%r10, (%r11,%rdx,8)
180003afa:     	movq	%r12, %r11
180003afd:     	incq	%rdx
180003b00:     	incq	%rdi
180003b03:     	decq	%rsi
180003b06:     	jne	0x180003ad5 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x1565>
180003b08:     	movq	0xc0(%rsp), %rdx
180003b10:     	movq	0xb8(%rsp), %r10
180003b18:     	movq	0xd0(%rsp), %rsi
180003b20:     	movq	%r10, 0x8(%rsi,%rdx,8)
180003b25:     	movq	0x78(%rsp), %rdx
180003b2a:     	movq	0x98(%rsp), %r10
180003b32:     	movq	%rdx, 0x10(%rsi,%r10,8)
180003b37:     	movq	0xc8(%rsp), %r10
180003b3f:     	movq	0xa0(%rsp), %r12
180003b47:     	leaq	0x1(%r12), %rdx
180003b4c:     	movq	%rdx, (%rsi,%r10,8)
180003b50:     	cmpb	$0x0, (%r13)
180003b55:     	jne	0x1800037ab <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x123b>
180003b5b:     	xorl	%edx, %edx
180003b5d:     	cmpq	$-0x2, %rax
180003b61:     	cmovlq	%rbx, %rdx
180003b65:     	addq	0x10(%rsi,%rdx,8), %r12
180003b6a:     	movq	%r12, %rax
180003b6d:     	sarq	$0x3f, %rax
180003b71:     	andq	%rbx, %rax
180003b74:     	leaq	(%r9,%r12,8), %rdx
180003b78:     	movq	%r14, (%rdx,%rax,8)
180003b7c:     	movsd	0x48(%r8,%r15,8), %xmm2
180003b83:     	movsd	0x8(%r8,%r14,8), %xmm1
180003b8a:     	movapd	%xmm2, %xmm0
180003b8e:     	addsd	%xmm1, %xmm0
180003b92:     	xorpd	%xmm3, %xmm3
180003b96:     	ucomisd	%xmm3, %xmm0
180003b9a:     	jbe	0x180003c6b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x16fb>
180003ba0:     	movq	0x10(%r9,%r15,8), %rax
180003ba5:     	cmpq	$0x0, 0x8(%r9,%rax,8)
180003bab:     	mulsd	(%r8,%rax,8), %xmm2
180003bb1:     	je	0x180003bdd <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x166d>
180003bb3:     	cmpq	$0x0, 0x50(%r9,%r15,8)
180003bb9:     	je	0x180003bdd <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x166d>
180003bbb:     	movapd	0x67fd(%rip), %xmm3     # 0x18000a3c0
180003bc3:     	andpd	%xmm2, %xmm3
180003bc7:     	ucomisd	0x6801(%rip), %xmm3     # 0x18000a3d0
180003bcf:     	jae	0x180003c89 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x1719>
180003bd5:     	xorpd	%xmm3, %xmm3
180003bd9:     	addsd	%xmm3, %xmm2
180003bdd:     	movq	0x10(%r9,%r14,8), %rdx
180003be2:     	mulsd	(%r8,%rdx,8), %xmm1
180003be8:     	addsd	%xmm2, %xmm1
180003bec:     	divsd	%xmm0, %xmm1
180003bf0:     	movsd	%xmm1, (%r8,%rax,8)
180003bf6:     	movq	$0x0, 0x8(%r9,%rax,8)
180003bff:     	movq	0x10(%r9,%r15,8), %rax
180003c04:     	movsd	0x10(%r8,%rax,8), %xmm1
180003c0b:     	cmpq	$0x0, 0x18(%r9,%rax,8)
180003c11:     	mulsd	0x48(%r8,%r15,8), %xmm1
180003c18:     	je	0x180003c40 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x16d0>
180003c1a:     	cmpq	$0x0, 0x50(%r9,%r15,8)
180003c20:     	je	0x180003c40 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x16d0>
180003c22:     	movapd	0x6796(%rip), %xmm2     # 0x18000a3c0
180003c2a:     	andpd	%xmm1, %xmm2
180003c2e:     	ucomisd	0x679a(%rip), %xmm2     # 0x18000a3d0
180003c36:     	jae	0x180003c98 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x1728>
180003c38:     	xorpd	%xmm2, %xmm2
180003c3c:     	addsd	%xmm2, %xmm1
180003c40:     	movq	0x10(%r9,%r14,8), %rdx
180003c45:     	movsd	0x10(%r8,%rdx,8), %xmm2
180003c4c:     	mulsd	0x8(%r8,%r14,8), %xmm2
180003c53:     	addsd	%xmm1, %xmm2
180003c57:     	divsd	%xmm0, %xmm2
180003c5b:     	movsd	%xmm2, 0x10(%r8,%rax,8)
180003c62:     	movq	$0x0, 0x18(%r9,%rax,8)
180003c6b:     	movsd	%xmm0, 0x48(%r8,%r15,8)
180003c72:     	movq	$0x0, 0x50(%r9,%r15,8)
180003c7b:     	cmpb	$0x0, (%r13)
180003c80:     	sete	%r12b
180003c84:     	jmp	0x1800037ae <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x123e>
180003c89:     	movb	$0x1, (%r13)
180003c8e:     	movq	$0x895447, 0x18(%rbp)   # imm = 0x895447
180003c96:     	jmp	0x180003c7b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x170b>
180003c98:     	movb	$0x1, (%r13)
180003c9d:     	movq	$0x895449, 0x18(%rbp)   # imm = 0x895449
180003ca5:     	jmp	0x180003c7b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x170b>
180003ca7:     	movq	0x38(%rsi,%r15,8), %rax
180003cac:     	testq	%rax, %rax
180003caf:     	js	0x180003cbb <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x174b>
180003cb1:     	movq	%rcx, 0x8(%rbp)
180003cb5:     	cmpq	0x10(%rbp), %rcx
180003cb9:     	jle	0x180003cd3 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x1763>
180003cbb:     	movb	$0x1, (%r13)
180003cc0:     	movq	$0x2dc6cf, 0x18(%rbp)   # imm = 0x2DC6CF
180003cc8:     	xorl	%r12d, %r12d
180003ccb:     	movq	%rdi, %rcx
180003cce:     	jmp	0x1800037ae <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x123e>
180003cd3:     	movb	$0x0, 0x68(%rsp)
180003cd8:     	movq	%r14, 0x48(%rsp)
180003cdd:     	movq	%rax, 0x40(%rsp)
180003ce2:     	movq	%rbx, 0x30(%rsp)
180003ce7:     	movq	%r13, 0x28(%rsp)
180003cec:     	movq	%rbp, 0x20(%rsp)
180003cf1:     	movq	$-0x1, 0x50(%rsp)
180003cfa:     	movq	$0x0, 0x38(%rsp)
180003d03:     	leaq	0x68(%rsp), %rcx
180003d08:     	movq	0x70(%rsp), %r8
180003d0d:     	movq	%rsi, %r9
180003d10:     	callq	0x180003250 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xce0>
180003d15:     	cmpb	$0x0, (%r13)
180003d1a:     	jne	0x1800036ca <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x115a>
180003d20:     	movq	0x8(%rbp), %rax
180003d24:     	leaq	-0x1(%rax), %rcx
180003d28:     	cmpb	$0x0, 0x68(%rsp)
180003d2d:     	movq	%rcx, 0x8(%rbp)
180003d31:     	movq	%rdi, %rcx
180003d34:     	jne	0x1800037ae <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x123e>
180003d3a:     	movq	0x40(%rsi,%r15,8), %rcx
180003d3f:     	testq	%rcx, %rcx
180003d42:     	js	0x180003d4e <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x17de>
180003d44:     	movq	%rax, 0x8(%rbp)
180003d48:     	cmpq	0x10(%rbp), %rax
180003d4c:     	jle	0x180003d98 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x1828>
180003d4e:     	movb	$0x1, (%r13)
180003d53:     	movq	$0x2dc6d0, 0x18(%rbp)   # imm = 0x2DC6D0
180003d5b:     	jmp	0x1800036ca <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x115a>
180003d60:     	movq	%rax, (%rbp)
180003d64:     	cmpb	$0x0, (%r13)
180003d69:     	jne	0x180003d8d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x181d>
180003d6b:     	subsd	%xmm3, %xmm2
180003d6f:     	movsd	%xmm2, 0x10(%rdi,%rcx,8)
180003d75:     	movsd	%xmm5, 0x18(%rdi,%rcx,8)
180003d7b:     	movsd	%xmm3, 0x8(%rdi,%rcx,8)
180003d81:     	movsd	%xmm0, (%rdi,%rcx,8)
180003d86:     	cmpb	$0x0, (%r13)
180003d8b:     	je	0x180003df4 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x1884>
180003d8d:     	xorl	%r12d, %r12d
180003d90:     	movq	%r14, %rcx
180003d93:     	jmp	0x1800037ae <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x123e>
180003d98:     	movb	$0x0, 0x67(%rsp)
180003d9d:     	movq	%r14, 0x48(%rsp)
180003da2:     	movq	%rcx, 0x40(%rsp)
180003da7:     	movq	%rbx, 0x30(%rsp)
180003dac:     	movq	%r13, 0x28(%rsp)
180003db1:     	movq	%rbp, 0x20(%rsp)
180003db6:     	movq	$-0x1, 0x50(%rsp)
180003dbf:     	movq	$0x0, 0x38(%rsp)
180003dc8:     	leaq	0x67(%rsp), %rcx
180003dcd:     	movq	0x70(%rsp), %r8
180003dd2:     	movq	%rsi, %r9
180003dd5:     	callq	0x180003250 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xce0>
180003dda:     	cmpb	$0x0, (%r13)
180003ddf:     	jne	0x1800036ca <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x115a>
180003de5:     	movzbl	0x67(%rsp), %r12d
180003deb:     	decq	0x8(%rbp)
180003def:     	jmp	0x18000382f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x12bf>
180003df4:     	movq	(%rbp), %rax
180003df8:     	leaq	0xb(%rax), %r8
180003dfc:     	cmpq	%rbx, %r8
180003dff:     	jg	0x18000364b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x10db>
180003e05:     	movq	0x8(%rsi,%r15,8), %rdx
180003e0a:     	movq	%r8, (%rbp)
180003e0e:     	cmpb	$0x0, (%r13)
180003e13:     	jne	0x180003d8d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x181d>
180003e19:     	movq	%rcx, (%rsi,%rax,8)
180003e1d:     	movq	%rdx, 0x8(%rsi,%rax,8)
180003e22:     	movq	(%rbp), %rdx
180003e26:     	cmpq	%rbx, %rdx
180003e29:     	movq	%rdx, %rcx
180003e2c:     	jle	0x180003e39 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x18c9>
180003e2e:     	movb	$0x2, (%r13)
180003e33:     	movq	(%rbp), %rdx
180003e37:     	xorl	%ecx, %ecx
180003e39:     	leaq	0x3(%rdx), %r8
180003e3d:     	cmpq	%rbx, %r8
180003e40:     	jg	0x18000364b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x10db>
180003e46:     	movq	%r8, (%rbp)
180003e4a:     	cmpb	$0x0, (%r13)
180003e4f:     	jne	0x180003d8d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x181d>
180003e55:     	movq	%rdx, %r9
180003e58:     	sarq	$0x3f, %r9
180003e5c:     	andq	%rbx, %r9
180003e5f:     	leaq	(%rsi,%rdx,8), %r10
180003e63:     	movq	$0x0, (%r10,%r9,8)
180003e6b:     	xorl	%r12d, %r12d
180003e6e:     	cmpq	$-0x1, %rdx
180003e72:     	movl	$0x0, %r9d
180003e78:     	cmovlq	%rbx, %r9
180003e7c:     	movq	$0x0, 0x8(%r10,%r9,8)
180003e85:     	cmpq	$-0x2, %rdx
180003e89:     	movl	$0x0, %r9d
180003e8f:     	cmovlq	%rbx, %r9
180003e93:     	movq	%rcx, 0x10(%r10,%r9,8)
180003e98:     	cmpb	$0x0, (%r13)
180003e9d:     	movq	%r14, %rcx
180003ea0:     	jne	0x1800037ae <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x123e>
180003ea6:     	leaq	(%rsi,%rax,8), %rcx
180003eaa:     	movq	%rdx, 0x30(%rcx)
180003eae:     	movq	$0x0, 0x18(%rcx)
180003eb6:     	movq	(%rbp), %rdx
180003eba:     	leaq	0x4(%rdx), %r8
180003ebe:     	cmpq	%rbx, %r8
180003ec1:     	jg	0x18000364b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x10db>
180003ec7:     	movq	%r8, (%rbp)
180003ecb:     	cmpb	$0x0, (%r13)
180003ed0:     	jne	0x180003d8d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x181d>
180003ed6:     	movq	$0x0, (%rdi,%rdx,8)
180003ede:     	movq	$0x1, 0x8(%rsi,%rdx,8)
180003ee7:     	movq	$0x0, 0x10(%rdi,%rdx,8)
180003ef0:     	movq	$0x1, 0x18(%rsi,%rdx,8)
180003ef9:     	cmpb	$0x0, (%r13)
180003efe:     	jne	0x180003d8d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x181d>
180003f04:     	movq	%rdx, 0x10(%rcx)
180003f08:     	movq	$0x0, 0x48(%rdi,%rax,8)
180003f11:     	movq	$0x1, 0x50(%rcx)
180003f19:     	movq	$-0x1, 0x20(%rcx)
180003f21:     	movq	$-0x1, 0x28(%rcx)
180003f29:     	movq	$-0x1, 0x38(%rcx)
180003f31:     	movq	$-0x1, 0x40(%rcx)
180003f39:     	cmpb	$0x0, (%r13)
180003f3e:     	jne	0x180003d8d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x181d>
180003f44:     	movq	%rax, 0x28(%rsi,%r15,8)
180003f49:     	movq	(%rbp), %rcx
180003f4d:     	leaq	0x4(%rcx), %rax
180003f51:     	cmpq	%rbx, %rax
180003f54:     	jg	0x18000364b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x10db>
180003f5a:     	movq	%rax, (%rbp)
180003f5e:     	cmpb	$0x0, (%r13)
180003f63:     	jne	0x180003d8d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x181d>
180003f69:     	addsd	%xmm0, %xmm1
180003f6d:     	movsd	%xmm4, 0x10(%rdi,%rcx,8)
180003f73:     	movsd	%xmm1, 0x18(%rdi,%rcx,8)
180003f79:     	movsd	%xmm3, 0x8(%rdi,%rcx,8)
180003f7f:     	movsd	%xmm0, (%rdi,%rcx,8)
180003f84:     	cmpb	$0x0, (%r13)
180003f89:     	jne	0x180003d8d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x181d>
180003f8f:     	movq	(%rbp), %rax
180003f93:     	leaq	0xb(%rax), %r8
180003f97:     	cmpq	%rbx, %r8
180003f9a:     	jg	0x18000364b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x10db>
180003fa0:     	movq	0x8(%rsi,%r15,8), %rdx
180003fa5:     	movq	%r8, (%rbp)
180003fa9:     	cmpb	$0x0, (%r13)
180003fae:     	jne	0x180003d8d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x181d>
180003fb4:     	movq	%rcx, (%rsi,%rax,8)
180003fb8:     	movq	%rdx, 0x8(%rsi,%rax,8)
180003fbd:     	movq	(%rbp), %rdx
180003fc1:     	cmpq	%rbx, %rdx
180003fc4:     	movq	%rdx, %rcx
180003fc7:     	jle	0x180003fd4 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x1a64>
180003fc9:     	movb	$0x2, (%r13)
180003fce:     	movq	(%rbp), %rdx
180003fd2:     	xorl	%ecx, %ecx
180003fd4:     	leaq	0x3(%rdx), %r8
180003fd8:     	cmpq	%rbx, %r8
180003fdb:     	jg	0x18000364b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x10db>
180003fe1:     	movq	%r8, (%rbp)
180003fe5:     	cmpb	$0x0, (%r13)
180003fea:     	jne	0x180003d8d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x181d>
180003ff0:     	movq	%rdx, %r9
180003ff3:     	sarq	$0x3f, %r9
180003ff7:     	andq	%rbx, %r9
180003ffa:     	leaq	(%rsi,%rdx,8), %r10
180003ffe:     	movq	$0x0, (%r10,%r9,8)
180004006:     	xorl	%r12d, %r12d
180004009:     	cmpq	$-0x1, %rdx
18000400d:     	movl	$0x0, %r9d
180004013:     	cmovlq	%rbx, %r9
180004017:     	movq	$0x0, 0x8(%r10,%r9,8)
180004020:     	cmpq	$-0x2, %rdx
180004024:     	movl	$0x0, %r9d
18000402a:     	cmovlq	%rbx, %r9
18000402e:     	movq	%rcx, 0x10(%r10,%r9,8)
180004033:     	cmpb	$0x0, (%r13)
180004038:     	movq	%r14, %rcx
18000403b:     	jne	0x1800037ae <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x123e>
180004041:     	leaq	(%rsi,%rax,8), %rcx
180004045:     	movq	%rdx, 0x30(%rcx)
180004049:     	movq	$0x0, 0x18(%rcx)
180004051:     	movq	(%rbp), %rdx
180004055:     	leaq	0x4(%rdx), %r8
180004059:     	cmpq	%rbx, %r8
18000405c:     	jg	0x18000364b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x10db>
180004062:     	movq	%r8, (%rbp)
180004066:     	cmpb	$0x0, (%r13)
18000406b:     	jne	0x180003d8d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x181d>
180004071:     	movq	$0x0, (%rdi,%rdx,8)
180004079:     	movq	$0x1, 0x8(%rsi,%rdx,8)
180004082:     	movq	$0x0, 0x10(%rdi,%rdx,8)
18000408b:     	movq	$0x1, 0x18(%rsi,%rdx,8)
180004094:     	cmpb	$0x0, (%r13)
180004099:     	jne	0x180003d8d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x181d>
18000409f:     	movq	%rdx, 0x10(%rcx)
1800040a3:     	movq	$0x0, 0x48(%rdi,%rax,8)
1800040ac:     	movq	$0x1, 0x50(%rcx)
1800040b4:     	movq	$-0x1, 0x20(%rcx)
1800040bc:     	movq	$-0x1, 0x28(%rcx)
1800040c4:     	movq	$-0x1, 0x38(%rcx)
1800040cc:     	movq	$-0x1, 0x40(%rcx)
1800040d4:     	cmpb	$0x0, (%r13)
1800040d9:     	jne	0x180003d8d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x181d>
1800040df:     	movq	%rax, 0x38(%rsi,%r15,8)
1800040e4:     	movq	(%rbp), %rcx
1800040e8:     	leaq	0x4(%rcx), %rax
1800040ec:     	cmpq	%rbx, %rax
1800040ef:     	jg	0x18000364b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x10db>
1800040f5:     	movq	%rax, (%rbp)
1800040f9:     	cmpb	$0x0, (%r13)
1800040fe:     	jne	0x180003d8d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x181d>
180004104:     	movsd	%xmm2, 0x10(%rdi,%rcx,8)
18000410a:     	movsd	%xmm1, 0x18(%rdi,%rcx,8)
180004110:     	movsd	%xmm3, 0x8(%rdi,%rcx,8)
180004116:     	movsd	%xmm0, (%rdi,%rcx,8)
18000411b:     	cmpb	$0x0, (%r13)
180004120:     	jne	0x180003d8d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x181d>
180004126:     	movq	(%rbp), %rax
18000412a:     	leaq	0xb(%rax), %r8
18000412e:     	cmpq	%rbx, %r8
180004131:     	jg	0x18000364b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x10db>
180004137:     	movq	0x8(%rsi,%r15,8), %rdx
18000413c:     	movq	%r8, (%rbp)
180004140:     	cmpb	$0x0, (%r13)
180004145:     	jne	0x180003d8d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x181d>
18000414b:     	movq	%rcx, (%rsi,%rax,8)
18000414f:     	movq	%rdx, 0x8(%rsi,%rax,8)
180004154:     	movq	(%rbp), %rdx
180004158:     	cmpq	%rbx, %rdx
18000415b:     	movq	%rdx, %rcx
18000415e:     	jle	0x18000416b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x1bfb>
180004160:     	movb	$0x2, (%r13)
180004165:     	movq	(%rbp), %rdx
180004169:     	xorl	%ecx, %ecx
18000416b:     	leaq	0x3(%rdx), %r8
18000416f:     	cmpq	%rbx, %r8
180004172:     	jg	0x18000364b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x10db>
180004178:     	movq	%r8, (%rbp)
18000417c:     	cmpb	$0x0, (%r13)
180004181:     	jne	0x180003d8d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x181d>
180004187:     	movq	%rdx, %r9
18000418a:     	sarq	$0x3f, %r9
18000418e:     	andq	%rbx, %r9
180004191:     	leaq	(%rsi,%rdx,8), %r10
180004195:     	movq	$0x0, (%r10,%r9,8)
18000419d:     	xorl	%r12d, %r12d
1800041a0:     	cmpq	$-0x1, %rdx
1800041a4:     	movl	$0x0, %r9d
1800041aa:     	cmovlq	%rbx, %r9
1800041ae:     	movq	$0x0, 0x8(%r10,%r9,8)
1800041b7:     	cmpq	$-0x2, %rdx
1800041bb:     	movl	$0x0, %r9d
1800041c1:     	cmovlq	%rbx, %r9
1800041c5:     	movq	%rcx, 0x10(%r10,%r9,8)
1800041ca:     	cmpb	$0x0, (%r13)
1800041cf:     	movq	%r14, %rcx
1800041d2:     	jne	0x1800037ae <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x123e>
1800041d8:     	leaq	(%rsi,%rax,8), %rcx
1800041dc:     	movq	%rdx, 0x30(%rcx)
1800041e0:     	movq	$0x0, 0x18(%rcx)
1800041e8:     	movq	(%rbp), %rdx
1800041ec:     	leaq	0x4(%rdx), %r8
1800041f0:     	cmpq	%rbx, %r8
1800041f3:     	jg	0x18000364b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x10db>
1800041f9:     	movq	%r8, (%rbp)
1800041fd:     	cmpb	$0x0, (%r13)
180004202:     	jne	0x180003d8d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x181d>
180004208:     	movq	$0x0, (%rdi,%rdx,8)
180004210:     	movq	$0x1, 0x8(%rsi,%rdx,8)
180004219:     	movq	$0x0, 0x10(%rdi,%rdx,8)
180004222:     	movq	$0x1, 0x18(%rsi,%rdx,8)
18000422b:     	cmpb	$0x0, (%r13)
180004230:     	jne	0x180003d8d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x181d>
180004236:     	movq	%rdx, 0x10(%rcx)
18000423a:     	movq	$0x0, 0x48(%rdi,%rax,8)
180004243:     	movq	$0x1, 0x50(%rcx)
18000424b:     	movq	$-0x1, 0x20(%rcx)
180004253:     	movq	$-0x1, 0x28(%rcx)
18000425b:     	movq	$-0x1, 0x38(%rcx)
180004263:     	movq	$-0x1, 0x40(%rcx)
18000426b:     	cmpb	$0x0, (%r13)
180004270:     	jne	0x180003d8d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x181d>
180004276:     	movq	%rax, 0x40(%rsi,%r15,8)
18000427b:     	movq	$0x1, 0x18(%rsi,%r15,8)
180004284:     	movq	0x30(%rsi,%r15,8), %rax
180004289:     	movq	%rax, %rdx
18000428c:     	sarq	$0x3f, %rdx
180004290:     	andq	%rbx, %rdx
180004293:     	leaq	(%rsi,%rax,8), %rcx
180004297:     	movq	%rdx, 0x90(%rsp)
18000429f:     	movq	%rcx, 0x80(%rsp)
1800042a7:     	cmpq	$0x0, (%rcx,%rdx,8)
1800042ac:     	jle	0x1800044e2 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x1f72>
1800042b2:     	leaq	(,%rbx,8), %rcx
1800042ba:     	xorl	%r12d, %r12d
1800042bd:     	cmpq	$-0x2, %rax
1800042c1:     	cmovgeq	%r12, %rcx
1800042c5:     	movq	%rcx, 0x88(%rsp)
1800042cd:     	movq	0x20(%rsi,%r15,8), %rax
1800042d2:     	testq	%rax, %rax
1800042d5:     	js	0x180004569 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x1ff9>
1800042db:     	movq	0x80(%rsp), %rcx
1800042e3:     	movq	0x88(%rsp), %rdx
1800042eb:     	movq	0x10(%rcx,%rdx), %rcx
1800042f0:     	addq	%r12, %rcx
1800042f3:     	leaq	(%rsi,%rcx,8), %rdx
1800042f7:     	sarq	$0x3f, %rcx
1800042fb:     	andq	%rbx, %rcx
1800042fe:     	movq	(%rdx,%rcx,8), %rcx
180004302:     	movq	%rcx, 0x70(%rsp)
180004307:     	movq	0x8(%rbp), %rcx
18000430b:     	leaq	0x1(%rcx), %rdx
18000430f:     	movq	%rdx, 0x8(%rbp)
180004313:     	cmpq	0x10(%rbp), %rcx
180004317:     	jge	0x180004569 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x1ff9>
18000431d:     	movq	0x70(%rsp), %rcx
180004322:     	movq	%rcx, 0x48(%rsp)
180004327:     	movq	%rax, 0x40(%rsp)
18000432c:     	movq	%rbx, 0x30(%rsp)
180004331:     	movq	%r13, 0x28(%rsp)
180004336:     	movq	%rbp, 0x20(%rsp)
18000433b:     	movq	$-0x1, 0x50(%rsp)
180004344:     	movq	$0x0, 0x38(%rsp)
18000434d:     	leaq	0x6e(%rsp), %rcx
180004352:     	movq	%rdi, %r8
180004355:     	movq	%rsi, %r9
180004358:     	callq	0x180003250 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xce0>
18000435d:     	cmpb	$0x0, (%r13)
180004362:     	jne	0x180003d8d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x181d>
180004368:     	movq	0x8(%rbp), %rcx
18000436c:     	leaq	-0x1(%rcx), %rax
180004370:     	movq	%rax, 0x8(%rbp)
180004374:     	movq	0x28(%rsi,%r15,8), %rax
180004379:     	testq	%rax, %rax
18000437c:     	js	0x18000457b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x200b>
180004382:     	movq	%rcx, 0x8(%rbp)
180004386:     	cmpq	0x10(%rbp), %rcx
18000438a:     	jg	0x18000457b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x200b>
180004390:     	movq	0x70(%rsp), %rcx
180004395:     	movq	%rcx, 0x48(%rsp)
18000439a:     	movq	%rax, 0x40(%rsp)
18000439f:     	movq	%rbx, 0x30(%rsp)
1800043a4:     	movq	%r13, 0x28(%rsp)
1800043a9:     	movq	%rbp, 0x20(%rsp)
1800043ae:     	movq	$-0x1, 0x50(%rsp)
1800043b7:     	movq	$0x0, 0x38(%rsp)
1800043c0:     	leaq	0x6d(%rsp), %rcx
1800043c5:     	movq	%rdi, %r8
1800043c8:     	movq	%rsi, %r9
1800043cb:     	callq	0x180003250 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xce0>
1800043d0:     	cmpb	$0x0, (%r13)
1800043d5:     	jne	0x180003d8d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x181d>
1800043db:     	movq	0x8(%rbp), %rcx
1800043df:     	leaq	-0x1(%rcx), %rax
1800043e3:     	movq	%rax, 0x8(%rbp)
1800043e7:     	movq	0x38(%rsi,%r15,8), %rax
1800043ec:     	testq	%rax, %rax
1800043ef:     	js	0x18000458d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x201d>
1800043f5:     	movq	%rcx, 0x8(%rbp)
1800043f9:     	cmpq	0x10(%rbp), %rcx
1800043fd:     	jg	0x18000458d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x201d>
180004403:     	movq	0x70(%rsp), %rcx
180004408:     	movq	%rcx, 0x48(%rsp)
18000440d:     	movq	%rax, 0x40(%rsp)
180004412:     	movq	%rbx, 0x30(%rsp)
180004417:     	movq	%r13, 0x28(%rsp)
18000441c:     	movq	%rbp, 0x20(%rsp)
180004421:     	movq	$-0x1, 0x50(%rsp)
18000442a:     	movq	$0x0, 0x38(%rsp)
180004433:     	leaq	0x6c(%rsp), %rcx
180004438:     	movq	%rdi, %r8
18000443b:     	movq	%rsi, %r9
18000443e:     	callq	0x180003250 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xce0>
180004443:     	cmpb	$0x0, (%r13)
180004448:     	jne	0x180003d8d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x181d>
18000444e:     	movq	0x8(%rbp), %rcx
180004452:     	leaq	-0x1(%rcx), %rax
180004456:     	movq	%rax, 0x8(%rbp)
18000445a:     	movq	0x40(%rsi,%r15,8), %rax
18000445f:     	testq	%rax, %rax
180004462:     	js	0x18000459f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x202f>
180004468:     	movq	%rcx, 0x8(%rbp)
18000446c:     	cmpq	0x10(%rbp), %rcx
180004470:     	jg	0x18000459f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x202f>
180004476:     	movq	0x70(%rsp), %rcx
18000447b:     	movq	%rcx, 0x48(%rsp)
180004480:     	movq	%rax, 0x40(%rsp)
180004485:     	movq	%rbx, 0x30(%rsp)
18000448a:     	movq	%r13, 0x28(%rsp)
18000448f:     	movq	%rbp, 0x20(%rsp)
180004494:     	movq	$-0x1, 0x50(%rsp)
18000449d:     	movq	$0x0, 0x38(%rsp)
1800044a6:     	leaq	0x6b(%rsp), %rcx
1800044ab:     	movq	%rdi, %r8
1800044ae:     	movq	%rsi, %r9
1800044b1:     	callq	0x180003250 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xce0>
1800044b6:     	cmpb	$0x0, (%r13)
1800044bb:     	jne	0x180003d8d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x181d>
1800044c1:     	incq	%r12
1800044c4:     	decq	0x8(%rbp)
1800044c8:     	movq	0x90(%rsp), %rax
1800044d0:     	movq	0x80(%rsp), %rcx
1800044d8:     	cmpq	(%rcx,%rax,8), %r12
1800044dc:     	jl	0x1800042cd <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x1d5d>
1800044e2:     	movq	(%rbp), %rax
1800044e6:     	cmpq	%rbx, %rax
1800044e9:     	movq	%rax, %rcx
1800044ec:     	jle	0x1800044f9 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x1f89>
1800044ee:     	movb	$0x2, (%r13)
1800044f3:     	movq	(%rbp), %rax
1800044f7:     	xorl	%ecx, %ecx
1800044f9:     	leaq	0x3(%rax), %rdx
1800044fd:     	cmpq	%rbx, %rdx
180004500:     	jg	0x18000364b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x10db>
180004506:     	movq	%rdx, (%rbp)
18000450a:     	cmpb	$0x0, (%r13)
18000450f:     	jne	0x180003d8d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x181d>
180004515:     	movq	%rax, %rdx
180004518:     	sarq	$0x3f, %rdx
18000451c:     	andq	%rbx, %rdx
18000451f:     	leaq	(%rsi,%rax,8), %r8
180004523:     	movq	$0x0, (%r8,%rdx,8)
18000452b:     	xorl	%r12d, %r12d
18000452e:     	cmpq	$-0x1, %rax
180004532:     	movl	$0x0, %edx
180004537:     	cmovlq	%rbx, %rdx
18000453b:     	movq	$0x0, 0x8(%r8,%rdx,8)
180004544:     	cmpq	$-0x2, %rax
180004548:     	cmovgeq	%r12, %rbx
18000454c:     	movq	%rcx, 0x10(%r8,%rbx,8)
180004551:     	cmpb	$0x0, (%r13)
180004556:     	movq	%r14, %rcx
180004559:     	jne	0x1800037ae <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x123e>
18000455f:     	movq	%rax, 0x30(%rsi,%r15,8)
180004564:     	jmp	0x1800037ab <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x123b>
180004569:     	movb	$0x1, (%r13)
18000456e:     	movq	$0x989697, 0x18(%rbp)   # imm = 0x989697
180004576:     	jmp	0x180003d8d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x181d>
18000457b:     	movb	$0x1, (%r13)
180004580:     	movq	$0x989698, 0x18(%rbp)   # imm = 0x989698
180004588:     	jmp	0x180003d8d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x181d>
18000458d:     	movb	$0x1, (%r13)
180004592:     	movq	$0x989699, 0x18(%rbp)   # imm = 0x989699
18000459a:     	jmp	0x180003d8d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x181d>
18000459f:     	movb	$0x1, (%r13)
1800045a4:     	movq	$0x98969a, 0x18(%rbp)   # imm = 0x98969A
1800045ac:     	jmp	0x180003d8d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x181d>
1800045b1:     	nopw	%cs:(%rax,%rax)
1800045bb:     	nopl	(%rax,%rax)
1800045c0:     	pushq	%r15
1800045c2:     	pushq	%r14
1800045c4:     	pushq	%r13
1800045c6:     	pushq	%r12
1800045c8:     	pushq	%rsi
1800045c9:     	pushq	%rdi
1800045ca:     	pushq	%rbp
1800045cb:     	pushq	%rbx
1800045cc:     	subq	$0xe8, %rsp
1800045d3:     	movapd	%xmm7, 0xd0(%rsp)
1800045dc:     	movaps	%xmm6, 0xc0(%rsp)
1800045e4:     	movq	0x180(%rsp), %r10
1800045ec:     	movq	0x158(%rsp), %r12
1800045f4:     	movq	0x150(%rsp), %r15
1800045fc:     	movabsq	$-0x20000000000001, %rax # imm = 0xFFDFFFFFFFFFFFFF
180004606:     	movabsq	$-0x40000000000001, %rsi # imm = 0xFFBFFFFFFFFFFFFF
180004610:     	movq	$0x0, 0xa0(%rsp)
18000461c:     	movb	$0x0, 0xa8(%rsp)
180004624:     	movq	$0x0, 0xb0(%rsp)
180004630:     	movb	$0x0, 0xb8(%rsp)
180004638:     	movq	$0x0, 0x98(%rsp)
180004644:     	movb	$0x0, 0x67(%rsp)
180004649:     	movq	$0x0, 0x90(%rsp)
180004655:     	leaq	(%r10,%rax), %r11
180004659:     	cmpq	%rsi, %r11
18000465c:     	jb	0x18000466e <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x20fe>
18000465e:     	movq	0x188(%rsp), %r11
180004666:     	addq	%r11, %rax
180004669:     	cmpq	%rsi, %rax
18000466c:     	jae	0x1800046a8 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2138>
18000466e:     	movb	$0x1, (%r12)
180004673:     	movq	$0x4, 0x18(%r15)
18000467b:     	movq	$0x0, (%rcx)
180004682:     	xorl	%eax, %eax
180004684:     	movaps	0xc0(%rsp), %xmm6
18000468c:     	movaps	0xd0(%rsp), %xmm7
180004694:     	addq	$0xe8, %rsp
18000469b:     	popq	%rbx
18000469c:     	popq	%rbp
18000469d:     	popq	%rdi
18000469e:     	popq	%rsi
18000469f:     	popq	%r12
1800046a1:     	popq	%r13
1800046a3:     	popq	%r14
1800046a5:     	popq	%r15
1800046a7:     	retq
1800046a8:     	movq	0x160(%rsp), %r13
1800046b0:     	movq	(%r15), %rax
1800046b3:     	leaq	0x4(%rax), %rsi
1800046b7:     	cmpq	%r13, %rsi
1800046ba:     	jle	0x1800046c3 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2153>
1800046bc:     	movb	$0x2, (%r12)
1800046c1:     	jmp	0x18000467b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x210b>
1800046c3:     	movq	%rsi, (%r15)
1800046c6:     	cmpb	$0x0, (%r12)
1800046cb:     	jne	0x18000467b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x210b>
1800046cd:     	testq	%rax, %rax
1800046d0:     	js	0x180004714 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x21a4>
1800046d2:     	cvtsi2sd	%r11, %xmm0
1800046d7:     	movsd	0x5cd1(%rip), %xmm1     # 0x18000a3b0
1800046df:     	mulsd	%xmm1, %xmm0
1800046e3:     	cvtsi2sd	%r10, %xmm2
1800046e8:     	mulsd	%xmm1, %xmm2
1800046ec:     	movsd	%xmm2, 0x10(%r8,%rax,8)
1800046f3:     	movsd	%xmm0, 0x18(%r8,%rax,8)
1800046fa:     	movsd	%xmm2, 0x8(%r8,%rax,8)
180004701:     	movsd	%xmm0, (%r8,%rax,8)
180004707:     	cmpb	$0x0, (%r12)
18000470c:     	jne	0x18000467b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x210b>
180004712:     	jmp	0x18000472c <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x21bc>
180004714:     	movb	$0x1, (%r12)
180004719:     	movq	$0xf4242, 0x18(%r15)    # imm = 0xF4242
180004721:     	cmpb	$0x0, (%r12)
180004726:     	jne	0x18000467b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x210b>
18000472c:     	movq	(%r15), %rbp
18000472f:     	leaq	0xb(%rbp), %r10
180004733:     	cmpq	%r13, %r10
180004736:     	jg	0x1800046bc <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x214c>
180004738:     	movq	%r10, (%r15)
18000473b:     	cmpb	$0x0, (%r12)
180004740:     	jne	0x18000467b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x210b>
180004746:     	movq	%rax, (%r9,%rbp,8)
18000474a:     	movq	$0x4, 0x8(%r9,%rbp,8)
180004753:     	movq	(%r15), %r10
180004756:     	cmpq	%r13, %r10
180004759:     	movq	%r10, %rax
18000475c:     	jle	0x180004768 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x21f8>
18000475e:     	movb	$0x2, (%r12)
180004763:     	movq	(%r15), %r10
180004766:     	xorl	%eax, %eax
180004768:     	leaq	0x3(%r10), %r11
18000476c:     	cmpq	%r13, %r11
18000476f:     	jg	0x1800046bc <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x214c>
180004775:     	movq	%r11, (%r15)
180004778:     	cmpb	$0x0, (%r12)
18000477d:     	jne	0x18000467b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x210b>
180004783:     	movq	%r10, %r11
180004786:     	sarq	$0x3f, %r11
18000478a:     	andq	%r13, %r11
18000478d:     	leaq	(%r9,%r10,8), %rsi
180004791:     	movq	$0x0, (%rsi,%r11,8)
180004799:     	xorl	%r11d, %r11d
18000479c:     	cmpq	$-0x1, %r10
1800047a0:     	movl	$0x0, %edi
1800047a5:     	cmovlq	%r13, %rdi
1800047a9:     	movq	$0x0, 0x8(%rsi,%rdi,8)
1800047b2:     	cmpq	$-0x2, %r10
1800047b6:     	cmovlq	%r13, %r11
1800047ba:     	movq	%rax, 0x10(%rsi,%r11,8)
1800047bf:     	cmpb	$0x0, (%r12)
1800047c4:     	jne	0x18000467b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x210b>
1800047ca:     	leaq	(%r9,%rbp,8), %rax
1800047ce:     	movq	%r10, 0x30(%rax)
1800047d2:     	movq	$0x0, 0x18(%rax)
1800047da:     	movq	(%r15), %r10
1800047dd:     	leaq	0x4(%r10), %r11
1800047e1:     	cmpq	%r13, %r11
1800047e4:     	jg	0x1800046bc <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x214c>
1800047ea:     	movq	%r11, (%r15)
1800047ed:     	cmpb	$0x0, (%r12)
1800047f2:     	jne	0x18000467b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x210b>
1800047f8:     	movq	%rdx, 0x88(%rsp)
180004800:     	movq	%r8, %rdi
180004803:     	movq	%r9, %rsi
180004806:     	movq	%rcx, 0x68(%rsp)
18000480b:     	testq	%r10, %r10
18000480e:     	js	0x180004835 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x22c5>
180004810:     	movq	$0x0, (%rdi,%r10,8)
180004818:     	leaq	(%rsi,%r10,8), %rcx
18000481c:     	movq	$0x1, 0x8(%rsi,%r10,8)
180004825:     	movq	$0x0, 0x10(%rdi,%r10,8)
18000482e:     	movl	$0x1, %edx
180004833:     	jmp	0x180004842 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x22d2>
180004835:     	movb	$0x1, (%r12)
18000483a:     	movl	$0x6acfc2, %edx         # imm = 0x6ACFC2
18000483f:     	movq	%r15, %rcx
180004842:     	movq	%rdx, 0x18(%rcx)
180004846:     	cmpb	$0x0, (%r12)
18000484b:     	movq	0x68(%rsp), %rcx
180004850:     	jne	0x18000467b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x210b>
180004856:     	movq	%r10, 0x10(%rax)
18000485a:     	movq	$0x0, 0x48(%rdi,%rbp,8)
180004863:     	movq	$0x1, 0x50(%rax)
18000486b:     	movq	$-0x1, 0x20(%rax)
180004873:     	movq	$-0x1, 0x28(%rax)
18000487b:     	movq	$-0x1, 0x38(%rax)
180004883:     	movq	$-0x1, 0x40(%rax)
18000488b:     	cmpb	$0x0, (%r12)
180004890:     	jne	0x18000467b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x210b>
180004896:     	movq	0x168(%rsp), %rax
18000489e:     	movq	%rax, %rcx
1800048a1:     	sarq	$0x3f, %rcx
1800048a5:     	andq	%r13, %rcx
1800048a8:     	leaq	(%rsi,%rax,8), %rdx
1800048ac:     	xorl	%r8d, %r8d
1800048af:     	cmpq	$-0x2, %rax
1800048b3:     	cmovlq	%r13, %r8
1800048b7:     	movq	%r8, 0x80(%rsp)
1800048bf:     	movq	%rcx, 0x78(%rsp)
1800048c4:     	movq	%rdx, 0x70(%rsp)
1800048c9:     	cmpq	$0x0, (%rdx,%rcx,8)
1800048ce:     	jle	0x1800049a5 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2435>
1800048d4:     	testq	%rbp, %rbp
1800048d7:     	js	0x180004b14 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x25a4>
1800048dd:     	movq	0x8(%r15), %rax
1800048e1:     	shlq	$0x3, 0x80(%rsp)
1800048ea:     	shlq	$0x3, 0x78(%rsp)
1800048f0:     	xorl	%ebx, %ebx
1800048f2:     	leaq	0x67(%rsp), %r14
1800048f7:     	movq	0x70(%rsp), %rcx
1800048fc:     	movq	0x80(%rsp), %rdx
180004904:     	movq	0x10(%rcx,%rdx), %rcx
180004909:     	addq	%rbx, %rcx
18000490c:     	leaq	(%rsi,%rcx,8), %rdx
180004910:     	sarq	$0x3f, %rcx
180004914:     	andq	%r13, %rcx
180004917:     	movq	(%rdx,%rcx,8), %rcx
18000491b:     	leaq	0x1(%rax), %rdx
18000491f:     	movq	%rdx, 0x8(%r15)
180004923:     	cmpq	0x10(%r15), %rax
180004927:     	jge	0x180004b14 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x25a4>
18000492d:     	movq	%rcx, 0x48(%rsp)
180004932:     	movq	%rbp, 0x40(%rsp)
180004937:     	movq	%r13, 0x30(%rsp)
18000493c:     	movq	%r12, 0x28(%rsp)
180004941:     	movq	%r15, 0x20(%rsp)
180004946:     	movq	$-0x1, 0x50(%rsp)
18000494f:     	movq	$0x0, 0x38(%rsp)
180004958:     	movq	%r14, %rcx
18000495b:     	leaq	0x90(%rsp), %rdx
180004963:     	movq	%rdi, %r8
180004966:     	movq	%rsi, %r9
180004969:     	callq	0x180005390 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2e20>
18000496e:     	testl	%eax, %eax
180004970:     	jne	0x180004cf5 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2785>
180004976:     	cmpb	$0x0, (%r12)
18000497b:     	jne	0x180004b21 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x25b1>
180004981:     	incq	%rbx
180004984:     	movq	0x8(%r15), %rax
180004988:     	decq	%rax
18000498b:     	movq	%rax, 0x8(%r15)
18000498f:     	movq	0x78(%rsp), %rcx
180004994:     	movq	0x70(%rsp), %rdx
180004999:     	cmpq	(%rdx,%rcx), %rbx
18000499d:     	jl	0x1800048f7 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2387>
1800049a3:     	jmp	0x1800049bd <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x244d>
1800049a5:     	shlq	$0x3, 0x78(%rsp)
1800049ab:     	shlq	$0x3, 0x80(%rsp)
1800049b4:     	testq	%rbp, %rbp
1800049b7:     	js	0x180004b32 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x25c2>
1800049bd:     	movsd	0x170(%rsp), %xmm6
1800049c6:     	xorl	%ebx, %ebx
1800049c8:     	xorpd	%xmm7, %xmm7
1800049cc:     	movq	0x78(%rsp), %rax
1800049d1:     	movq	0x70(%rsp), %rcx
1800049d6:     	cmpq	(%rcx,%rax), %rbx
1800049da:     	jge	0x180004b32 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x25c2>
1800049e0:     	movq	0x70(%rsp), %rax
1800049e5:     	movq	0x80(%rsp), %rcx
1800049ed:     	movq	0x10(%rax,%rcx), %rax
1800049f2:     	addq	%rbx, %rax
1800049f5:     	leaq	(%rsi,%rax,8), %rcx
1800049f9:     	sarq	$0x3f, %rax
1800049fd:     	andq	%r13, %rax
180004a00:     	movq	(%rcx,%rax,8), %r14
180004a04:     	movq	0x8(%r15), %rax
180004a08:     	leaq	0x1(%rax), %rcx
180004a0c:     	movq	%rcx, 0x8(%r15)
180004a10:     	cmpq	0x10(%r15), %rax
180004a14:     	jge	0x180004d1f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x27af>
180004a1a:     	movsd	%xmm6, 0x48(%rsp)
180004a20:     	movq	%r14, 0x40(%rsp)
180004a25:     	movq	%rbp, 0x38(%rsp)
180004a2a:     	movq	%r13, 0x30(%rsp)
180004a2f:     	movq	%r12, 0x28(%rsp)
180004a34:     	movq	%r15, 0x20(%rsp)
180004a39:     	leaq	0xa0(%rsp), %rcx
180004a41:     	leaq	0x98(%rsp), %rdx
180004a49:     	movq	%rdi, %r8
180004a4c:     	movq	%rsi, %r9
180004a4f:     	callq	0x180004d60 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x27f0>
180004a54:     	testl	%eax, %eax
180004a56:     	jne	0x180004d43 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x27d3>
180004a5c:     	cmpb	$0x0, (%r12)
180004a61:     	jne	0x180004b21 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x25b1>
180004a67:     	movsd	0xa0(%rsp), %xmm1
180004a70:     	movsd	0xb0(%rsp), %xmm0
180004a79:     	decq	0x8(%r15)
180004a7d:     	testq	%r14, %r14
180004a80:     	js	0x180004d31 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x27c1>
180004a86:     	movq	(%rsi,%r14,8), %rax
180004a8a:     	testq	%rax, %rax
180004a8d:     	js	0x180004a9e <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x252e>
180004a8f:     	movsd	0x8(%rdi,%r14,8), %xmm2
180004a96:     	ucomisd	%xmm7, %xmm2
180004a9a:     	jne	0x180004abb <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x254b>
180004a9c:     	jp	0x180004abb <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x254b>
180004a9e:     	movb	$0x1, (%r12)
180004aa3:     	movq	$0x4c4b43, 0x18(%r15)   # imm = 0x4C4B43
180004aab:     	incq	%rbx
180004aae:     	cmpb	$0x0, (%r12)
180004ab3:     	je	0x1800049cc <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x245c>
180004ab9:     	jmp	0x180004b21 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x25b1>
180004abb:     	divsd	%xmm2, %xmm1
180004abf:     	addsd	(%rdi,%rax,8), %xmm1
180004ac4:     	movsd	%xmm1, (%rdi,%rax,8)
180004ac9:     	movq	$0x0, 0x8(%rsi,%rax,8)
180004ad2:     	movq	(%rsi,%r14,8), %rax
180004ad6:     	testq	%rax, %rax
180004ad9:     	js	0x180004aea <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x257a>
180004adb:     	movsd	0x8(%rdi,%r14,8), %xmm1
180004ae2:     	ucomisd	%xmm7, %xmm1
180004ae6:     	jne	0x180004af9 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2589>
180004ae8:     	jp	0x180004af9 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2589>
180004aea:     	movb	$0x1, (%r12)
180004aef:     	movq	$0x4c4b44, 0x18(%r15)   # imm = 0x4C4B44
180004af7:     	jmp	0x180004aab <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x253b>
180004af9:     	divsd	%xmm1, %xmm0
180004afd:     	addsd	0x10(%rdi,%rax,8), %xmm0
180004b03:     	movsd	%xmm0, 0x10(%rdi,%rax,8)
180004b09:     	movq	$0x0, 0x18(%rsi,%rax,8)
180004b12:     	jmp	0x180004aab <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x253b>
180004b14:     	movb	$0x1, (%r12)
180004b19:     	movq	$0x9, 0x18(%r15)
180004b21:     	movq	0x68(%rsp), %rax
180004b26:     	movq	$0x0, (%rax)
180004b2d:     	jmp	0x180004682 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2112>
180004b32:     	movsd	0x178(%rsp), %xmm0
180004b3b:     	xorl	%eax, %eax
180004b3d:     	movq	0x78(%rsp), %rcx
180004b42:     	movq	0x70(%rsp), %rdx
180004b47:     	cmpq	(%rdx,%rcx), %rax
180004b4b:     	jge	0x180004b21 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x25b1>
180004b4d:     	movq	0x70(%rsp), %rcx
180004b52:     	movq	0x80(%rsp), %rdx
180004b5a:     	movq	0x10(%rcx,%rdx), %rcx
180004b5f:     	addq	%rax, %rcx
180004b62:     	leaq	(%rsi,%rcx,8), %rdx
180004b66:     	sarq	$0x3f, %rcx
180004b6a:     	andq	%r13, %rcx
180004b6d:     	movq	(%rdx,%rcx,8), %rcx
180004b71:     	testq	%rcx, %rcx
180004b74:     	js	0x180004d0d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x279d>
180004b7a:     	movq	0x18(%rsi,%rcx,8), %rdx
180004b7f:     	testq	%rdx, %rdx
180004b82:     	js	0x180004c95 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2725>
180004b88:     	movq	(%rsi,%rcx,8), %r8
180004b8c:     	testq	%r8, %r8
180004b8f:     	js	0x180004c95 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2725>
180004b95:     	movsd	(%rdi,%r8,8), %xmm1
180004b9b:     	mulsd	%xmm0, %xmm1
180004b9f:     	addsd	(%rdi,%rdx,8), %xmm1
180004ba4:     	movsd	%xmm1, (%rdi,%rdx,8)
180004ba9:     	movq	$0x0, 0x8(%rsi,%rdx,8)
180004bb2:     	movq	0x18(%rsi,%rcx,8), %rdx
180004bb7:     	testq	%rdx, %rdx
180004bba:     	js	0x180004ca1 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2731>
180004bc0:     	movq	(%rsi,%rcx,8), %r8
180004bc4:     	testq	%r8, %r8
180004bc7:     	js	0x180004ca1 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2731>
180004bcd:     	movsd	0x10(%rdi,%r8,8), %xmm1
180004bd4:     	mulsd	%xmm0, %xmm1
180004bd8:     	addsd	0x10(%rdi,%rdx,8), %xmm1
180004bde:     	movsd	%xmm1, 0x10(%rdi,%rdx,8)
180004be4:     	movq	$0x0, 0x18(%rsi,%rdx,8)
180004bed:     	movq	0x10(%rsi,%rcx,8), %rdx
180004bf2:     	testq	%rdx, %rdx
180004bf5:     	js	0x180004cad <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x273d>
180004bfb:     	movq	0x18(%rsi,%rcx,8), %r8
180004c00:     	testq	%r8, %r8
180004c03:     	js	0x180004cad <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x273d>
180004c09:     	movsd	(%rdi,%r8,8), %xmm1
180004c0f:     	mulsd	%xmm0, %xmm1
180004c13:     	addsd	(%rdi,%rdx,8), %xmm1
180004c18:     	movsd	%xmm1, (%rdi,%rdx,8)
180004c1d:     	movq	$0x0, 0x8(%rsi,%rdx,8)
180004c26:     	movq	0x10(%rsi,%rcx,8), %rdx
180004c2b:     	testq	%rdx, %rdx
180004c2e:     	js	0x180004cb9 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2749>
180004c34:     	movq	0x18(%rsi,%rcx,8), %r8
180004c39:     	testq	%r8, %r8
180004c3c:     	js	0x180004cb9 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2749>
180004c3e:     	movsd	0x10(%rdi,%r8,8), %xmm1
180004c45:     	mulsd	%xmm0, %xmm1
180004c49:     	addsd	0x10(%rdi,%rdx,8), %xmm1
180004c4f:     	movsd	%xmm1, 0x10(%rdi,%rdx,8)
180004c55:     	movq	$0x0, 0x18(%rsi,%rdx,8)
180004c5e:     	movq	(%rsi,%rcx,8), %rdx
180004c62:     	testq	%rdx, %rdx
180004c65:     	js	0x180004cdd <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x276d>
180004c67:     	movq	$0x0, (%rdi,%rdx,8)
180004c6f:     	movq	$0x1, 0x8(%rsi,%rdx,8)
180004c78:     	movq	(%rsi,%rcx,8), %rcx
180004c7c:     	testq	%rcx, %rcx
180004c7f:     	js	0x180004ce9 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2779>
180004c81:     	movq	$0x0, 0x10(%rdi,%rcx,8)
180004c8a:     	leaq	(%rsi,%rcx,8), %rdx
180004c8e:     	movl	$0x1, %ecx
180004c93:     	jmp	0x180004cc6 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2756>
180004c95:     	movb	$0x1, (%r12)
180004c9a:     	movl	$0x5b8d83, %ecx         # imm = 0x5B8D83
180004c9f:     	jmp	0x180004cc3 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2753>
180004ca1:     	movb	$0x1, (%r12)
180004ca6:     	movl	$0x5b8d84, %ecx         # imm = 0x5B8D84
180004cab:     	jmp	0x180004cc3 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2753>
180004cad:     	movb	$0x1, (%r12)
180004cb2:     	movl	$0x5b8d87, %ecx         # imm = 0x5B8D87
180004cb7:     	jmp	0x180004cc3 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2753>
180004cb9:     	movb	$0x1, (%r12)
180004cbe:     	movl	$0x5b8d88, %ecx         # imm = 0x5B8D88
180004cc3:     	movq	%r15, %rdx
180004cc6:     	movq	%rcx, 0x18(%rdx)
180004cca:     	incq	%rax
180004ccd:     	cmpb	$0x0, (%r12)
180004cd2:     	je	0x180004b3d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x25cd>
180004cd8:     	jmp	0x180004b21 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x25b1>
180004cdd:     	movb	$0x1, (%r12)
180004ce2:     	movl	$0x5b8d8b, %ecx         # imm = 0x5B8D8B
180004ce7:     	jmp	0x180004cc3 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2753>
180004ce9:     	movb	$0x1, (%r12)
180004cee:     	movl	$0x5b8d8c, %ecx         # imm = 0x5B8D8C
180004cf3:     	jmp	0x180004cc3 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2753>
180004cf5:     	movq	0x90(%rsp), %rdx
180004cfd:     	movq	0x88(%rsp), %rcx
180004d05:     	movq	%rdx, (%rcx)
180004d08:     	jmp	0x180004684 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2114>
180004d0d:     	movb	$0x1, (%r12)
180004d12:     	movq	$0x12, 0x18(%r15)
180004d1a:     	jmp	0x180004b21 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x25b1>
180004d1f:     	movb	$0x1, (%r12)
180004d24:     	movq	$0xd, 0x18(%r15)
180004d2c:     	jmp	0x180004b21 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x25b1>
180004d31:     	movb	$0x1, (%r12)
180004d36:     	movq	$0xe, 0x18(%r15)
180004d3e:     	jmp	0x180004b21 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x25b1>
180004d43:     	movq	0x88(%rsp), %rcx
180004d4b:     	movq	$0x0, (%rcx)
180004d52:     	jmp	0x180004684 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2114>
180004d57:     	nopw	(%rax,%rax)
180004d60:     	pushq	%r15
180004d62:     	pushq	%r14
180004d64:     	pushq	%r13
180004d66:     	pushq	%r12
180004d68:     	pushq	%rsi
180004d69:     	pushq	%rdi
180004d6a:     	pushq	%rbp
180004d6b:     	pushq	%rbx
180004d6c:     	subq	$0x118, %rsp            # imm = 0x118
180004d73:     	movapd	%xmm8, 0x100(%rsp)
180004d7d:     	movapd	%xmm7, 0xf0(%rsp)
180004d86:     	movapd	%xmm6, 0xe0(%rsp)
180004d8f:     	movq	0x198(%rsp), %r15
180004d97:     	movq	$0x0, 0x60(%rsp)
180004da0:     	movb	$0x0, 0x68(%rsp)
180004da5:     	movq	$0x0, 0x70(%rsp)
180004dae:     	movsd	0x48(%r8,%r15,8), %xmm0
180004db5:     	xorpd	%xmm1, %xmm1
180004db9:     	ucomisd	%xmm1, %xmm0
180004dbd:     	jne	0x180004dd6 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2866>
180004dbf:     	jp	0x180004dd6 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2866>
180004dc1:     	movb	$0x1, 0x18(%rcx)
180004dc5:     	movq	$0x0, 0x10(%rcx)
180004dcd:     	movb	$0x1, 0x8(%rcx)
180004dd1:     	jmp	0x180004f26 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x29b6>
180004dd6:     	movq	0x1a0(%rsp), %r14
180004dde:     	movq	0x30(%r9,%r15,8), %rax
180004de3:     	cmpq	$0x1, (%r9,%rax,8)
180004de8:     	jne	0x180004df5 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2885>
180004dea:     	movq	0x10(%r9,%rax,8), %rax
180004def:     	cmpq	%r14, (%r9,%rax,8)
180004df3:     	je	0x180004dc1 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2851>
180004df5:     	movq	0x188(%rsp), %rbx
180004dfd:     	movq	0x180(%rsp), %rdi
180004e05:     	movq	0x10(%r9,%r15,8), %rdx
180004e0a:     	testq	%rdx, %rdx
180004e0d:     	js	0x180004f03 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2993>
180004e13:     	testq	%r14, %r14
180004e16:     	js	0x180004f03 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2993>
180004e1c:     	movq	0x10(%r9,%r14,8), %r10
180004e21:     	testq	%r10, %r10
180004e24:     	js	0x180004f03 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2993>
180004e2a:     	movsd	(%r8,%rdx,8), %xmm1
180004e30:     	cmpq	$0x0, 0x8(%r9,%rdx,8)
180004e36:     	setne	%r11b
180004e3a:     	cmpq	$0x0, 0x8(%r9,%r10,8)
180004e40:     	setne	%al
180004e43:     	subsd	(%r8,%r10,8), %xmm1
180004e49:     	andb	%r11b, %al
180004e4c:     	cmpb	$0x1, %al
180004e4e:     	jne	0x180004e72 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2902>
180004e50:     	movapd	0x5568(%rip), %xmm2     # 0x18000a3c0
180004e58:     	andpd	%xmm1, %xmm2
180004e5c:     	ucomisd	0x556c(%rip), %xmm2     # 0x18000a3d0
180004e64:     	jae	0x180004f03 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2993>
180004e6a:     	xorpd	%xmm2, %xmm2
180004e6e:     	addsd	%xmm2, %xmm1
180004e72:     	movsd	0x10(%r8,%rdx,8), %xmm2
180004e79:     	cmpq	$0x0, 0x18(%r9,%rdx,8)
180004e7f:     	subsd	0x10(%r8,%r10,8), %xmm2
180004e86:     	je	0x180004f5c <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x29ec>
180004e8c:     	cmpq	$0x0, 0x18(%r9,%r10,8)
180004e92:     	je	0x180004f5c <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x29ec>
180004e98:     	movapd	0x5520(%rip), %xmm3     # 0x18000a3c0
180004ea0:     	andpd	%xmm2, %xmm3
180004ea4:     	ucomisd	0x5524(%rip), %xmm3     # 0x18000a3d0
180004eac:     	jae	0x180004fc2 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2a52>
180004eb2:     	movapd	%xmm1, %xmm3
180004eb6:     	mulsd	%xmm1, %xmm3
180004eba:     	ucomisd	0x550e(%rip), %xmm3     # 0x18000a3d0
180004ec2:     	setae	%dl
180004ec5:     	testb	%dl, %al
180004ec7:     	jne	0x180004f75 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2a05>
180004ecd:     	xorpd	%xmm4, %xmm4
180004ed1:     	addsd	%xmm4, %xmm2
180004ed5:     	movapd	%xmm2, %xmm4
180004ed9:     	mulsd	%xmm2, %xmm4
180004edd:     	ucomisd	0x54eb(%rip), %xmm4     # 0x18000a3d0
180004ee5:     	jae	0x180004f75 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2a05>
180004eeb:     	addsd	%xmm4, %xmm3
180004eef:     	ucomisd	0x54d9(%rip), %xmm3     # 0x18000a3d0
180004ef7:     	setae	%dl
180004efa:     	testb	%dl, %al
180004efc:     	jne	0x180004f75 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2a05>
180004efe:     	jmp	0x180004f8e <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2a1e>
180004f03:     	movb	$0x1, (%rbx)
180004f06:     	movq	$0x3d090a, 0x18(%rdi)   # imm = 0x3D090A
180004f0e:     	movq	$0x0, 0x18(%rcx)
180004f16:     	movq	$0x0, 0x10(%rcx)
180004f1e:     	movq	$0x0, 0x8(%rcx)
180004f26:     	movq	$0x0, (%rcx)
180004f2d:     	xorl	%eax, %eax
180004f2f:     	movaps	0xe0(%rsp), %xmm6
180004f37:     	movaps	0xf0(%rsp), %xmm7
180004f3f:     	movaps	0x100(%rsp), %xmm8
180004f48:     	addq	$0x118, %rsp            # imm = 0x118
180004f4f:     	popq	%rbx
180004f50:     	popq	%rbp
180004f51:     	popq	%rdi
180004f52:     	popq	%rsi
180004f53:     	popq	%r12
180004f55:     	popq	%r13
180004f57:     	popq	%r14
180004f59:     	popq	%r15
180004f5b:     	retq
180004f5c:     	movapd	%xmm1, %xmm3
180004f60:     	mulsd	%xmm1, %xmm3
180004f64:     	ucomisd	0x5464(%rip), %xmm3     # 0x18000a3d0
180004f6c:     	setae	%dl
180004f6f:     	andb	%dl, %al
180004f71:     	cmpb	$0x1, %al
180004f73:     	jne	0x180004f82 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2a12>
180004f75:     	movb	$0x1, (%rbx)
180004f78:     	movq	$0x3d090c, 0x18(%rdi)   # imm = 0x3D090C
180004f80:     	jmp	0x180004f0e <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x299e>
180004f82:     	movapd	%xmm2, %xmm4
180004f86:     	mulsd	%xmm2, %xmm4
180004f8a:     	addsd	%xmm4, %xmm3
180004f8e:     	xorps	%xmm4, %xmm4
180004f91:     	sqrtsd	%xmm3, %xmm4
180004f95:     	cmpq	$0x0, 0x18(%r9,%r15,8)
180004f9b:     	je	0x180004ff0 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2a80>
180004f9d:     	movq	(%r9,%r15,8), %rax
180004fa1:     	testq	%rax, %rax
180004fa4:     	js	0x180004fb2 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2a42>
180004fa6:     	xorpd	%xmm5, %xmm5
180004faa:     	ucomisd	%xmm5, %xmm3
180004fae:     	jne	0x180004fd2 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2a62>
180004fb0:     	jp	0x180004fd2 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2a62>
180004fb2:     	movb	$0x1, (%rbx)
180004fb5:     	movq	$0x3d090f, 0x18(%rdi)   # imm = 0x3D090F
180004fbd:     	jmp	0x180004f0e <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x299e>
180004fc2:     	movb	$0x1, (%rbx)
180004fc5:     	movq	$0x3d090b, 0x18(%rdi)   # imm = 0x3D090B
180004fcd:     	jmp	0x180004f0e <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x299e>
180004fd2:     	movsd	0x1a8(%rsp), %xmm6
180004fdb:     	movsd	0x8(%r8,%rax,8), %xmm3
180004fe2:     	addsd	%xmm3, %xmm3
180004fe6:     	divsd	%xmm4, %xmm3
180004fea:     	ucomisd	%xmm3, %xmm6
180004fee:     	jbe	0x18000505d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2aed>
180004ff0:     	movsd	0x53e0(%rip), %xmm3     # 0x18000a3d8
180004ff8:     	maxsd	%xmm4, %xmm3
180004ffc:     	movapd	%xmm3, %xmm4
180005000:     	mulsd	%xmm3, %xmm4
180005004:     	xorpd	%xmm5, %xmm5
180005008:     	ucomisd	%xmm5, %xmm4
18000500c:     	jne	0x180005020 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2ab0>
18000500e:     	jp	0x180005020 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2ab0>
180005010:     	movb	$0x1, (%rbx)
180005013:     	movq	$0x3d0915, 0x18(%rdi)   # imm = 0x3D0915
18000501b:     	jmp	0x180004f0e <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x299e>
180005020:     	movsd	0x8(%r8,%r14,8), %xmm5
180005027:     	mulsd	0x53b1(%rip), %xmm5     # 0x18000a3e0
18000502f:     	mulsd	%xmm5, %xmm0
180005033:     	divsd	%xmm4, %xmm0
180005037:     	mulsd	%xmm0, %xmm1
18000503b:     	divsd	%xmm3, %xmm1
18000503f:     	mulsd	%xmm0, %xmm2
180005043:     	divsd	%xmm3, %xmm2
180005047:     	movsd	%xmm2, 0x10(%rcx)
18000504c:     	movsd	%xmm1, (%rcx)
180005050:     	movb	$0x0, 0x18(%rcx)
180005054:     	movb	$0x0, 0x8(%rcx)
180005058:     	jmp	0x180004f2d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x29bd>
18000505d:     	movq	0x190(%rsp), %r12
180005065:     	movq	0x20(%r9,%r15,8), %rax
18000506a:     	testq	%rax, %rax
18000506d:     	js	0x180005113 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2ba3>
180005073:     	movq	0x8(%rdi), %rdx
180005077:     	leaq	0x1(%rdx), %r10
18000507b:     	movq	%r10, 0x8(%rdi)
18000507f:     	cmpq	0x10(%rdi), %rdx
180005083:     	jge	0x18000527b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2d0b>
180005089:     	movq	%rcx, %rsi
18000508c:     	movsd	%xmm6, 0x48(%rsp)
180005092:     	movq	%r14, 0x40(%rsp)
180005097:     	movq	%rax, 0x38(%rsp)
18000509c:     	movq	%r12, 0x30(%rsp)
1800050a1:     	movq	%rbx, 0x28(%rsp)
1800050a6:     	movq	%rdi, 0x20(%rsp)
1800050ab:     	leaq	0xc0(%rsp), %rcx
1800050b3:     	movq	%r8, %r12
1800050b6:     	movq	%r9, %rbp
1800050b9:     	callq	0x180004d60 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x27f0>
1800050be:     	cmpb	$0x0, (%rbx)
1800050c1:     	jne	0x18000535d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2ded>
1800050c7:     	cmpb	$0x0, 0xd8(%rsp)
1800050cf:     	setne	%r13b
1800050d3:     	cmpb	$0x0, 0xc8(%rsp)
1800050db:     	setne	%r11b
1800050df:     	xorpd	%xmm8, %xmm8
1800050e4:     	movsd	0xc0(%rsp), %xmm7
1800050ed:     	addsd	%xmm8, %xmm7
1800050f2:     	addsd	0xd0(%rsp), %xmm8
1800050fc:     	decq	0x8(%rdi)
180005100:     	movq	%rsi, %rcx
180005103:     	movq	%r12, %r8
180005106:     	movq	%rbp, %r9
180005109:     	movq	0x190(%rsp), %r12
180005111:     	jmp	0x180005122 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2bb2>
180005113:     	movb	$0x1, %r11b
180005116:     	xorpd	%xmm7, %xmm7
18000511a:     	xorpd	%xmm8, %xmm8
18000511f:     	movb	$0x1, %r13b
180005122:     	movq	0x28(%r9,%r15,8), %rax
180005127:     	testq	%rax, %rax
18000512a:     	js	0x1800051d9 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2c69>
180005130:     	movq	0x8(%rdi), %rdx
180005134:     	leaq	0x1(%rdx), %r10
180005138:     	movq	%r10, 0x8(%rdi)
18000513c:     	cmpq	0x10(%rdi), %rdx
180005140:     	jge	0x18000528b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2d1b>
180005146:     	movb	%r13b, 0x58(%rsp)
18000514b:     	movl	%r11d, %r13d
18000514e:     	movq	%rcx, %rsi
180005151:     	movsd	%xmm6, 0x48(%rsp)
180005157:     	movq	%r14, 0x40(%rsp)
18000515c:     	movq	%rax, 0x38(%rsp)
180005161:     	movq	%r12, 0x30(%rsp)
180005166:     	movq	%rbx, 0x28(%rsp)
18000516b:     	movq	%rdi, 0x20(%rsp)
180005170:     	leaq	0xa0(%rsp), %rcx
180005178:     	movq	%r8, %rbp
18000517b:     	movq	%r9, %r12
18000517e:     	callq	0x180004d60 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x27f0>
180005183:     	cmpb	$0x0, (%rbx)
180005186:     	jne	0x18000535d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2ded>
18000518c:     	cmpb	$0x0, 0xb8(%rsp)
180005194:     	setne	%al
180005197:     	cmpb	$0x0, 0xa8(%rsp)
18000519f:     	setne	%cl
1800051a2:     	addsd	0xa0(%rsp), %xmm7
1800051ab:     	addsd	0xb0(%rsp), %xmm8
1800051b5:     	decq	0x8(%rdi)
1800051b9:     	movl	%r13d, %r11d
1800051bc:     	andb	%cl, %r11b
1800051bf:     	movzbl	0x58(%rsp), %r13d
1800051c5:     	andb	%al, %r13b
1800051c8:     	movq	%rsi, %rcx
1800051cb:     	movq	%rbp, %r8
1800051ce:     	movq	%r12, %r9
1800051d1:     	movq	0x190(%rsp), %r12
1800051d9:     	movq	0x38(%r9,%r15,8), %rax
1800051de:     	testq	%rax, %rax
1800051e1:     	js	0x18000529b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2d2b>
1800051e7:     	movq	0x8(%rdi), %rdx
1800051eb:     	leaq	0x1(%rdx), %r10
1800051ef:     	movq	%r10, 0x8(%rdi)
1800051f3:     	cmpq	0x10(%rdi), %rdx
1800051f7:     	jge	0x180005342 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2dd2>
1800051fd:     	movl	%r11d, %ebp
180005200:     	movq	%rcx, %rsi
180005203:     	movsd	%xmm6, 0x48(%rsp)
180005209:     	movq	%r14, 0x40(%rsp)
18000520e:     	movq	%rax, 0x38(%rsp)
180005213:     	movq	%r12, 0x30(%rsp)
180005218:     	movq	%rbx, 0x28(%rsp)
18000521d:     	movq	%rdi, 0x20(%rsp)
180005222:     	leaq	0x80(%rsp), %rcx
18000522a:     	movq	%r8, 0x58(%rsp)
18000522f:     	movq	%r9, %r12
180005232:     	callq	0x180004d60 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x27f0>
180005237:     	cmpb	$0x0, (%rbx)
18000523a:     	jne	0x18000535d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2ded>
180005240:     	cmpb	$0x0, 0x98(%rsp)
180005248:     	setne	%al
18000524b:     	cmpb	$0x0, 0x88(%rsp)
180005253:     	setne	%cl
180005256:     	addsd	0x80(%rsp), %xmm7
18000525f:     	addsd	0x90(%rsp), %xmm8
180005269:     	decq	0x8(%rdi)
18000526d:     	movl	%ebp, %r11d
180005270:     	andb	%cl, %r11b
180005273:     	andb	%al, %r13b
180005276:     	movq	%r12, %r9
180005279:     	jmp	0x1800052a3 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2d33>
18000527b:     	movb	$0x1, (%rbx)
18000527e:     	movq	$0x3d0921, 0x18(%rdi)   # imm = 0x3D0921
180005286:     	jmp	0x180004f0e <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x299e>
18000528b:     	movb	$0x1, (%rbx)
18000528e:     	movq	$0x3d0926, 0x18(%rdi)   # imm = 0x3D0926
180005296:     	jmp	0x180004f0e <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x299e>
18000529b:     	movq	%r8, 0x58(%rsp)
1800052a0:     	movq	%rcx, %rsi
1800052a3:     	movq	0x40(%r9,%r15,8), %rax
1800052a8:     	testq	%rax, %rax
1800052ab:     	js	0x18000532b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2dbb>
1800052ad:     	movq	0x8(%rdi), %rcx
1800052b1:     	leaq	0x1(%rcx), %rdx
1800052b5:     	movq	%rdx, 0x8(%rdi)
1800052b9:     	cmpq	0x10(%rdi), %rcx
1800052bd:     	jge	0x180005352 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2de2>
1800052c3:     	movl	%r11d, %ebp
1800052c6:     	movsd	%xmm6, 0x48(%rsp)
1800052cc:     	movq	%r14, 0x40(%rsp)
1800052d1:     	movq	%rax, 0x38(%rsp)
1800052d6:     	movq	0x190(%rsp), %rax
1800052de:     	movq	%rax, 0x30(%rsp)
1800052e3:     	movq	%rbx, 0x28(%rsp)
1800052e8:     	movq	%rdi, 0x20(%rsp)
1800052ed:     	leaq	0x60(%rsp), %rcx
1800052f2:     	movq	0x58(%rsp), %r8
1800052f7:     	callq	0x180004d60 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x27f0>
1800052fc:     	cmpb	$0x0, (%rbx)
1800052ff:     	jne	0x18000535d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2ded>
180005301:     	cmpb	$0x0, 0x78(%rsp)
180005306:     	setne	%al
180005309:     	cmpb	$0x0, 0x68(%rsp)
18000530e:     	setne	%cl
180005311:     	addsd	0x60(%rsp), %xmm7
180005317:     	addsd	0x70(%rsp), %xmm8
18000531e:     	decq	0x8(%rdi)
180005322:     	movl	%ebp, %r11d
180005325:     	andb	%cl, %r11b
180005328:     	andb	%al, %r13b
18000532b:     	movb	%r13b, 0x18(%rsi)
18000532f:     	movsd	%xmm8, 0x10(%rsi)
180005335:     	movb	%r11b, 0x8(%rsi)
180005339:     	movsd	%xmm7, (%rsi)
18000533d:     	jmp	0x180004f2d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x29bd>
180005342:     	movb	$0x1, (%rbx)
180005345:     	movq	$0x3d092b, 0x18(%rdi)   # imm = 0x3D092B
18000534d:     	jmp	0x180004f0e <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x299e>
180005352:     	movb	$0x1, (%rbx)
180005355:     	movq	$0x3d0930, 0x18(%rdi)   # imm = 0x3D0930
18000535d:     	movq	$0x0, 0x18(%rsi)
180005365:     	movq	$0x0, 0x10(%rsi)
18000536d:     	movq	$0x0, 0x8(%rsi)
180005375:     	movq	$0x0, (%rsi)
18000537c:     	jmp	0x180004f2d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x29bd>
180005381:     	nopw	%cs:(%rax,%rax)
18000538b:     	nopl	(%rax,%rax)
180005390:     	pushq	%r15
180005392:     	pushq	%r14
180005394:     	pushq	%r13
180005396:     	pushq	%r12
180005398:     	pushq	%rsi
180005399:     	pushq	%rdi
18000539a:     	pushq	%rbp
18000539b:     	pushq	%rbx
18000539c:     	subq	$0x148, %rsp            # imm = 0x148
1800053a3:     	movq	0x1c8(%rsp), %rax
1800053ab:     	movq	0x1c0(%rsp), %r13
1800053b3:     	movq	0x1b8(%rsp), %r15
1800053bb:     	movq	0x1b0(%rsp), %r12
1800053c3:     	movb	$0x0, 0x6f(%rsp)
1800053c8:     	movq	$0x0, 0xf0(%rsp)
1800053d4:     	movb	$0x0, 0x5f(%rsp)
1800053d9:     	movq	$0x0, 0xe8(%rsp)
1800053e5:     	movb	$0x0, 0x5e(%rsp)
1800053ea:     	movq	$0x0, 0xe0(%rsp)
1800053f6:     	movb	$0x0, 0x5d(%rsp)
1800053fb:     	movq	$0x0, 0xd8(%rsp)
180005407:     	movb	$0x0, 0x5c(%rsp)
18000540c:     	movq	$0x0, 0xd0(%rsp)
180005418:     	movb	$0x0, 0x6e(%rsp)
18000541d:     	movq	$0x0, 0xc8(%rsp)
180005429:     	movb	$0x0, 0x6d(%rsp)
18000542e:     	movq	$0x0, 0xc0(%rsp)
18000543a:     	movb	$0x0, 0x6c(%rsp)
18000543f:     	movq	$0x0, 0xb8(%rsp)
18000544b:     	movb	$0x0, 0x6b(%rsp)
180005450:     	movq	$0x0, 0xb0(%rsp)
18000545c:     	cmpq	$0x1, %rax
180005460:     	je	0x180005508 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2f98>
180005466:     	testq	%rax, %rax
180005469:     	jne	0x180005965 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x33f5>
18000546f:     	movq	0x1d0(%rsp), %rbx
180005477:     	movq	(%r9,%rbx,8), %rax
18000547b:     	testq	%rax, %rax
18000547e:     	js	0x180005534 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2fc4>
180005484:     	movq	0x1d8(%rsp), %r14
18000548c:     	testq	%r14, %r14
18000548f:     	js	0x180005534 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2fc4>
180005495:     	movq	0x10(%r9,%r14,8), %r11
18000549a:     	testq	%r11, %r11
18000549d:     	js	0x1800055c6 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3056>
1800054a3:     	movsd	(%r8,%r11,8), %xmm0
1800054a9:     	movsd	0x8(%r8,%rax,8), %xmm2
1800054b0:     	movsd	0x10(%r8,%rax,8), %xmm1
1800054b7:     	movapd	%xmm1, %xmm3
1800054bb:     	subsd	%xmm2, %xmm3
1800054bf:     	xorl	%r10d, %r10d
1800054c2:     	ucomisd	%xmm3, %xmm0
1800054c6:     	jb	0x1800055e8 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3078>
1800054cc:     	addsd	%xmm2, %xmm1
1800054d0:     	ucomisd	%xmm0, %xmm1
1800054d4:     	jbe	0x1800055e8 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3078>
1800054da:     	movsd	0x10(%r8,%r11,8), %xmm0
1800054e1:     	movsd	(%r8,%rax,8), %xmm1
1800054e7:     	movsd	0x18(%r8,%rax,8), %xmm2
1800054ee:     	movapd	%xmm2, %xmm3
1800054f2:     	subsd	%xmm1, %xmm3
1800054f6:     	ucomisd	%xmm3, %xmm0
1800054fa:     	jae	0x1800055dc <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x306c>
180005500:     	xorl	%r10d, %r10d
180005503:     	jmp	0x1800055e8 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3078>
180005508:     	movq	0x1e0(%rsp), %rbp
180005510:     	testq	%rbp, %rbp
180005513:     	js	0x180005546 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2fd6>
180005515:     	movq	(%r9,%rbp,8), %rax
180005519:     	testq	%rax, %rax
18000551c:     	js	0x180005546 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2fd6>
18000551e:     	movq	(%r12), %r10
180005522:     	leaq	0x4(%r10), %r11
180005526:     	cmpq	%r13, %r11
180005529:     	jle	0x180005558 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2fe8>
18000552b:     	movb	$0x2, (%r15)
18000552f:     	jmp	0x180005965 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x33f5>
180005534:     	movb	$0x1, (%r15)
180005538:     	movq	$0x2dc6c2, 0x18(%r12)   # imm = 0x2DC6C2
180005541:     	jmp	0x180005965 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x33f5>
180005546:     	movb	$0x1, (%r15)
18000554a:     	movq	$0x989682, 0x18(%r12)   # imm = 0x989682
180005553:     	jmp	0x180005965 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x33f5>
180005558:     	movsd	0x10(%r8,%rax,8), %xmm2
18000555f:     	movsd	0x18(%r8,%rax,8), %xmm1
180005566:     	movsd	0x4e42(%rip), %xmm0     # 0x18000a3b0
18000556e:     	movsd	0x8(%r8,%rax,8), %xmm3
180005575:     	mulsd	%xmm0, %xmm3
180005579:     	mulsd	(%r8,%rax,8), %xmm0
18000557f:     	movq	%r11, (%r12)
180005583:     	cmpb	$0x0, (%r15)
180005587:     	jne	0x180005965 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x33f5>
18000558d:     	movapd	%xmm2, %xmm4
180005591:     	addsd	%xmm3, %xmm4
180005595:     	movapd	%xmm1, %xmm5
180005599:     	subsd	%xmm0, %xmm5
18000559d:     	testq	%r10, %r10
1800055a0:     	js	0x1800056fd <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x318d>
1800055a6:     	movsd	%xmm4, 0x10(%r8,%r10,8)
1800055ad:     	movsd	%xmm5, 0x18(%r8,%r10,8)
1800055b4:     	movsd	%xmm3, 0x8(%r8,%r10,8)
1800055bb:     	movsd	%xmm0, (%r8,%r10,8)
1800055c1:     	jmp	0x18000570a <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x319a>
1800055c6:     	movb	$0x1, (%r15)
1800055ca:     	movq	$0x7a1202, 0x18(%r12)   # imm = 0x7A1202
1800055d3:     	cmpb	$0x0, (%r15)
1800055d7:     	jmp	0x180005965 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x33f5>
1800055dc:     	addsd	%xmm1, %xmm2
1800055e0:     	ucomisd	%xmm0, %xmm2
1800055e4:     	seta	%r10b
1800055e8:     	cmpb	$0x0, (%r15)
1800055ec:     	jne	0x180005965 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x33f5>
1800055f2:     	testb	%r10b, %r10b
1800055f5:     	je	0x180005965 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x33f5>
1800055fb:     	movq	0x18(%r9,%rbx,8), %r10
180005600:     	movq	0x30(%r9,%rbx,8), %rax
180005605:     	movq	(%r9,%rax,8), %r11
180005609:     	cmpq	0x8(%r9,%rbx,8), %r11
18000560e:     	jge	0x180005824 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x32b4>
180005614:     	testq	%r10, %r10
180005617:     	jne	0x18000582d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x32bd>
18000561d:     	leaq	(%r9,%rax,8), %rsi
180005621:     	movq	%rax, %r10
180005624:     	sarq	$0x3f, %r10
180005628:     	andq	%r13, %r10
18000562b:     	movq	(%rsi,%r10,8), %rbp
18000562f:     	xorl	%r11d, %r11d
180005632:     	cmpq	$-0x1, %rax
180005636:     	cmovlq	%r13, %r11
18000563a:     	cmpq	0x8(%rsi,%r11,8), %rbp
18000563f:     	jne	0x180005d3d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x37cd>
180005645:     	movq	%rsi, 0x120(%rsp)
18000564d:     	leaq	(%rbp,%rbp), %rdx
180005652:     	testq	%rbp, %rbp
180005655:     	movl	$0x4, %edi
18000565a:     	cmovneq	%rdx, %rdi
18000565e:     	movq	(%r12), %rsi
180005662:     	movq	%rsi, 0x78(%rsp)
180005667:     	leaq	(%rsi,%rdi), %rdx
18000566b:     	cmpq	%r13, %rdx
18000566e:     	jg	0x18000552b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2fbb>
180005674:     	movq	%rdx, (%r12)
180005678:     	cmpb	$0x0, (%r15)
18000567c:     	jne	0x180005965 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x33f5>
180005682:     	movq	%rdi, 0x108(%rsp)
18000568a:     	movq	%r11, 0x110(%rsp)
180005692:     	movq	%r10, 0x118(%rsp)
18000569a:     	xorl	%edx, %edx
18000569c:     	cmpq	$-0x2, %rax
1800056a0:     	cmovlq	%r13, %rdx
1800056a4:     	movq	%rdx, 0x98(%rsp)
1800056ac:     	movq	%rbp, 0xa0(%rsp)
1800056b4:     	testq	%rbp, %rbp
1800056b7:     	jle	0x180005cfe <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x378e>
1800056bd:     	leaq	(%r9,%rax,8), %rdx
1800056c1:     	movq	0x98(%rsp), %r10
1800056c9:     	movq	0x10(%rdx,%r10,8), %rdi
1800056ce:     	movq	0xa0(%rsp), %rdx
1800056d6:     	movl	%edx, %esi
1800056d8:     	andl	$0x7, %esi
1800056db:     	cmpq	$0x7, %rdx
1800056df:     	ja	0x180005a35 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x34c5>
1800056e5:     	leaq	(,%r13,8), %rdx
1800056ed:     	movq	%rdx, 0xa8(%rsp)
1800056f5:     	xorl	%r11d, %r11d
1800056f8:     	jmp	0x180005cbe <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x374e>
1800056fd:     	movb	$0x1, (%r15)
180005701:     	movq	$0xf4242, 0x18(%r12)    # imm = 0xF4242
18000570a:     	cmpb	$0x0, (%r15)
18000570e:     	jne	0x180005965 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x33f5>
180005714:     	movq	(%r12), %rax
180005718:     	leaq	0xb(%rax), %rsi
18000571c:     	cmpq	%r13, %rsi
18000571f:     	jg	0x18000552b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2fbb>
180005725:     	movq	0x8(%r9,%rbp,8), %r11
18000572a:     	movq	%rsi, (%r12)
18000572e:     	cmpb	$0x0, (%r15)
180005732:     	jne	0x180005965 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x33f5>
180005738:     	movq	%r10, (%r9,%rax,8)
18000573c:     	movq	%r11, 0x8(%r9,%rax,8)
180005741:     	movq	(%r12), %r11
180005745:     	cmpq	%r13, %r11
180005748:     	movq	%r11, %r10
18000574b:     	jle	0x180005758 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x31e8>
18000574d:     	movb	$0x2, (%r15)
180005751:     	movq	(%r12), %r11
180005755:     	xorl	%r10d, %r10d
180005758:     	leaq	0x3(%r11), %rsi
18000575c:     	cmpq	%r13, %rsi
18000575f:     	jg	0x18000552b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2fbb>
180005765:     	movq	%rsi, (%r12)
180005769:     	cmpb	$0x0, (%r15)
18000576d:     	jne	0x180005965 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x33f5>
180005773:     	movq	%r11, %rsi
180005776:     	sarq	$0x3f, %rsi
18000577a:     	andq	%r13, %rsi
18000577d:     	leaq	(%r9,%r11,8), %rdi
180005781:     	movq	$0x0, (%rdi,%rsi,8)
180005789:     	xorl	%esi, %esi
18000578b:     	cmpq	$-0x1, %r11
18000578f:     	movl	$0x0, %ebx
180005794:     	cmovlq	%r13, %rbx
180005798:     	movq	$0x0, 0x8(%rdi,%rbx,8)
1800057a1:     	cmpq	$-0x2, %r11
1800057a5:     	cmovlq	%r13, %rsi
1800057a9:     	movq	%r10, 0x10(%rdi,%rsi,8)
1800057ae:     	cmpb	$0x0, (%r15)
1800057b2:     	jne	0x180005965 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x33f5>
1800057b8:     	leaq	(%r9,%rax,8), %r10
1800057bc:     	movq	%r11, 0x30(%r10)
1800057c0:     	movq	$0x0, 0x18(%r10)
1800057c8:     	movq	(%r12), %r11
1800057cc:     	leaq	0x4(%r11), %rsi
1800057d0:     	cmpq	%r13, %rsi
1800057d3:     	jg	0x18000552b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2fbb>
1800057d9:     	movq	%rsi, (%r12)
1800057dd:     	cmpb	$0x0, (%r15)
1800057e1:     	jne	0x180005965 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x33f5>
1800057e7:     	movq	%rdx, %r14
1800057ea:     	movq	%r8, %rdi
1800057ed:     	movq	%r9, %rsi
1800057f0:     	movq	%rcx, %rbx
1800057f3:     	testq	%r11, %r11
1800057f6:     	js	0x180005fd3 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3a63>
1800057fc:     	movq	$0x0, (%rdi,%r11,8)
180005804:     	leaq	(%rsi,%r11,8), %rcx
180005808:     	movq	$0x1, 0x8(%rsi,%r11,8)
180005811:     	movq	$0x0, 0x10(%rdi,%r11,8)
18000581a:     	movl	$0x1, %edx
18000581f:     	jmp	0x180005fdf <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3a6f>
180005824:     	testq	%r10, %r10
180005827:     	je	0x1800058c1 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3351>
18000582d:     	movq	0x20(%r9,%rbx,8), %rax
180005832:     	testq	%rax, %rax
180005835:     	js	0x180005958 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x33e8>
18000583b:     	movq	0x8(%r12), %r10
180005840:     	leaq	0x1(%r10), %r11
180005844:     	movq	%r11, 0x8(%r12)
180005849:     	cmpq	0x10(%r12), %r10
18000584e:     	jge	0x180005958 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x33e8>
180005854:     	movq	%rdx, 0x60(%rsp)
180005859:     	movq	%rcx, %rbp
18000585c:     	movb	$0x0, 0x5f(%rsp)
180005861:     	movq	%r14, 0x48(%rsp)
180005866:     	movq	%rax, 0x40(%rsp)
18000586b:     	movq	%r13, 0x30(%rsp)
180005870:     	movq	%r15, 0x28(%rsp)
180005875:     	movq	%r12, 0x20(%rsp)
18000587a:     	movq	$-0x1, 0x50(%rsp)
180005883:     	movq	$0x0, 0x38(%rsp)
18000588c:     	leaq	0x5f(%rsp), %rcx
180005891:     	leaq	0xe8(%rsp), %rdx
180005899:     	movq	%r8, %rdi
18000589c:     	movq	%r9, %rsi
18000589f:     	callq	0x180005390 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2e20>
1800058a4:     	testl	%eax, %eax
1800058a6:     	jne	0x180005f0d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x399d>
1800058ac:     	cmpb	$0x0, (%r15)
1800058b0:     	movq	%rbp, %rax
1800058b3:     	je	0x18000598d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x341d>
1800058b9:     	movb	$0x0, (%rax)
1800058bc:     	jmp	0x180005968 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x33f8>
1800058c1:     	movq	0x8(%r12), %rax
1800058c6:     	leaq	0x1(%rax), %r10
1800058ca:     	movq	%r10, 0x8(%r12)
1800058cf:     	cmpq	0x10(%r12), %rax
1800058d4:     	jge	0x18000597e <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x340e>
1800058da:     	movq	%rdx, %rsi
1800058dd:     	movq	%rcx, %rdi
1800058e0:     	movq	%rbx, 0x50(%rsp)
1800058e5:     	movq	%r13, 0x30(%rsp)
1800058ea:     	movq	%r15, 0x28(%rsp)
1800058ef:     	movq	%r12, 0x20(%rsp)
1800058f4:     	movq	$-0x1, 0x48(%rsp)
1800058fd:     	movq	$-0x1, 0x40(%rsp)
180005906:     	movq	$0x1, 0x38(%rsp)
18000590f:     	leaq	0x6f(%rsp), %rcx
180005914:     	leaq	0xf0(%rsp), %rdx
18000591c:     	movq	%r8, 0x60(%rsp)
180005921:     	movq	%r9, %rbp
180005924:     	callq	0x180005390 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2e20>
180005929:     	testl	%eax, %eax
18000592b:     	jne	0x180005f22 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x39b2>
180005931:     	cmpb	$0x0, (%r15)
180005935:     	movq	%rdi, %rcx
180005938:     	jne	0x180005965 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x33f5>
18000593a:     	movq	%rsi, %rdx
18000593d:     	decq	0x8(%r12)
180005942:     	movq	%rbp, %r9
180005945:     	movq	0x60(%rsp), %r8
18000594a:     	movq	0x20(%r9,%rbx,8), %rax
18000594f:     	testq	%rax, %rax
180005952:     	jns	0x18000583b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x32cb>
180005958:     	movb	$0x1, (%r15)
18000595c:     	movq	$0x2dc6cd, 0x18(%r12)   # imm = 0x2DC6CD
180005965:     	movb	$0x0, (%rcx)
180005968:     	xorl	%eax, %eax
18000596a:     	addq	$0x148, %rsp            # imm = 0x148
180005971:     	popq	%rbx
180005972:     	popq	%rbp
180005973:     	popq	%rdi
180005974:     	popq	%rsi
180005975:     	popq	%r12
180005977:     	popq	%r13
180005979:     	popq	%r14
18000597b:     	popq	%r15
18000597d:     	retq
18000597e:     	movb	$0x1, (%r15)
180005982:     	movq	$0x2dc6cb, 0x18(%r12)   # imm = 0x2DC6CB
18000598b:     	jmp	0x180005965 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x33f5>
18000598d:     	movzbl	0x5f(%rsp), %ecx
180005992:     	movq	0x8(%r12), %rdx
180005997:     	leaq	-0x1(%rdx), %r8
18000599b:     	movq	%r8, 0x8(%r12)
1800059a0:     	testb	$0x1, %cl
1800059a3:     	je	0x1800059aa <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x343a>
1800059a5:     	movb	$0x1, (%rax)
1800059a8:     	jmp	0x180005968 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x33f8>
1800059aa:     	movq	0x28(%rsi,%rbx,8), %rcx
1800059af:     	testq	%rcx, %rcx
1800059b2:     	js	0x1800059c0 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3450>
1800059b4:     	movq	%rdx, 0x8(%r12)
1800059b9:     	cmpq	0x10(%r12), %rdx
1800059be:     	jle	0x1800059d2 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3462>
1800059c0:     	movb	$0x1, (%r15)
1800059c4:     	movq	$0x2dc6ce, 0x18(%r12)   # imm = 0x2DC6CE
1800059cd:     	jmp	0x1800058b9 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3349>
1800059d2:     	movq	%rsi, %r9
1800059d5:     	movb	$0x0, 0x5e(%rsp)
1800059da:     	movq	%r14, 0x48(%rsp)
1800059df:     	movq	%rcx, 0x40(%rsp)
1800059e4:     	movq	%r13, 0x30(%rsp)
1800059e9:     	movq	%r15, 0x28(%rsp)
1800059ee:     	movq	%r12, 0x20(%rsp)
1800059f3:     	movq	$-0x1, 0x50(%rsp)
1800059fc:     	movq	$0x0, 0x38(%rsp)
180005a05:     	leaq	0x5e(%rsp), %rcx
180005a0a:     	leaq	0xe0(%rsp), %rdx
180005a12:     	movq	%rdi, %r8
180005a15:     	callq	0x180005390 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2e20>
180005a1a:     	testl	%eax, %eax
180005a1c:     	jne	0x18000604a <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3ada>
180005a22:     	cmpb	$0x0, (%r15)
180005a26:     	je	0x180005ea6 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3936>
180005a2c:     	movb	$0x0, (%rbp)
180005a30:     	jmp	0x180005968 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x33f8>
180005a35:     	movq	%rax, 0xf8(%rsp)
180005a3d:     	movq	%rsi, 0x100(%rsp)
180005a45:     	movabsq	$0x7ffffffffffffff8, %r11 # imm = 0x7FFFFFFFFFFFFFF8
180005a4f:     	andq	%rdx, %r11
180005a52:     	movq	0x78(%rsp), %rdx
180005a57:     	leaq	(%r9,%rdx,8), %rax
180005a5b:     	movq	%rax, 0x128(%rsp)
180005a63:     	leaq	(,%r13,8), %rdx
180005a6b:     	movq	%rdx, 0xa8(%rsp)
180005a73:     	xorl	%esi, %esi
180005a75:     	movq	%r11, 0x130(%rsp)
180005a7d:     	leaq	(%rdi,%rsi), %rbp
180005a81:     	movq	%rbp, %rdx
180005a84:     	sarq	$0x3f, %rdx
180005a88:     	leaq	(,%r13,8), %rax
180005a90:     	andq	%rax, %rdx
180005a93:     	leaq	(%r9,%rdi,8), %r10
180005a97:     	movq	%r10, 0x60(%rsp)
180005a9c:     	addq	%r10, %rdx
180005a9f:     	movq	(%rdx,%rsi,8), %r11
180005aa3:     	movq	0x78(%rsp), %rdx
180005aa8:     	leaq	(%rdx,%rsi), %r10
180005aac:     	movq	%r10, %rdx
180005aaf:     	sarq	$0x3f, %rdx
180005ab3:     	andq	%rax, %rdx
180005ab6:     	movq	0x128(%rsp), %rax
180005abe:     	addq	%rax, %rdx
180005ac1:     	movq	%r11, (%rdx,%rsi,8)
180005ac5:     	movq	%rbp, %rdx
180005ac8:     	incq	%rdx
180005acb:     	movl	$0x8, %edx
180005ad0:     	leaq	0x8(,%r13,8), %r11
180005ad8:     	movq	%r11, 0x70(%rsp)
180005add:     	cmovsq	%r11, %rdx
180005ae1:     	addq	0x60(%rsp), %rdx
180005ae6:     	movq	(%rdx,%rsi,8), %rdx
180005aea:     	movq	%r10, %r11
180005aed:     	incq	%r11
180005af0:     	movl	$0x8, %r11d
180005af6:     	cmovsq	0x70(%rsp), %r11
180005afc:     	addq	%rax, %r11
180005aff:     	movq	%rdx, (%r11,%rsi,8)
180005b03:     	movq	%rbp, %rdx
180005b06:     	addq	$0x2, %rdx
180005b0a:     	movl	$0x10, %edx
180005b0f:     	leaq	0x10(,%r13,8), %r11
180005b17:     	movq	%r11, 0x80(%rsp)
180005b1f:     	cmovsq	%r11, %rdx
180005b23:     	addq	0x60(%rsp), %rdx
180005b28:     	movq	(%rdx,%rsi,8), %rdx
180005b2c:     	movq	%r10, %r11
180005b2f:     	addq	$0x2, %r11
180005b33:     	movl	$0x10, %r11d
180005b39:     	cmovsq	0x80(%rsp), %r11
180005b42:     	addq	%rax, %r11
180005b45:     	movq	%rdx, (%r11,%rsi,8)
180005b49:     	movq	%rbp, %rdx
180005b4c:     	addq	$0x3, %rdx
180005b50:     	movl	$0x18, %edx
180005b55:     	leaq	0x18(,%r13,8), %r11
180005b5d:     	movq	%r11, 0x90(%rsp)
180005b65:     	cmovsq	%r11, %rdx
180005b69:     	addq	0x60(%rsp), %rdx
180005b6e:     	movq	(%rdx,%rsi,8), %rdx
180005b72:     	movq	%r10, %r11
180005b75:     	addq	$0x3, %r11
180005b79:     	movl	$0x18, %r11d
180005b7f:     	cmovsq	0x90(%rsp), %r11
180005b88:     	addq	%rax, %r11
180005b8b:     	movq	%rdx, (%r11,%rsi,8)
180005b8f:     	movq	%rbp, %rdx
180005b92:     	addq	$0x4, %rdx
180005b96:     	movl	$0x20, %edx
180005b9b:     	leaq	0x20(,%r13,8), %r11
180005ba3:     	movq	%r11, 0x88(%rsp)
180005bab:     	cmovsq	%r11, %rdx
180005baf:     	addq	0x60(%rsp), %rdx
180005bb4:     	movq	(%rdx,%rsi,8), %rdx
180005bb8:     	movq	%r10, %r11
180005bbb:     	addq	$0x4, %r11
180005bbf:     	movl	$0x20, %r11d
180005bc5:     	cmovsq	0x88(%rsp), %r11
180005bce:     	addq	%rax, %r11
180005bd1:     	movq	%rdx, (%r11,%rsi,8)
180005bd5:     	movq	%rbp, %rdx
180005bd8:     	addq	$0x5, %rdx
180005bdc:     	movl	$0x28, %edx
180005be1:     	leaq	0x28(,%r13,8), %r11
180005be9:     	movq	%r11, 0x140(%rsp)
180005bf1:     	cmovsq	%r11, %rdx
180005bf5:     	addq	0x60(%rsp), %rdx
180005bfa:     	movq	(%rdx,%rsi,8), %rdx
180005bfe:     	movq	%r10, %r11
180005c01:     	addq	$0x5, %r11
180005c05:     	movl	$0x28, %r11d
180005c0b:     	cmovsq	0x140(%rsp), %r11
180005c14:     	addq	%rax, %r11
180005c17:     	movq	%rdx, (%r11,%rsi,8)
180005c1b:     	movq	%rbp, %rdx
180005c1e:     	addq	$0x6, %rdx
180005c22:     	movl	$0x30, %edx
180005c27:     	leaq	0x30(,%r13,8), %r11
180005c2f:     	movq	%r11, 0x138(%rsp)
180005c37:     	cmovsq	%r11, %rdx
180005c3b:     	addq	0x60(%rsp), %rdx
180005c40:     	movq	(%rdx,%rsi,8), %rdx
180005c44:     	movq	%r10, %r11
180005c47:     	addq	$0x6, %r11
180005c4b:     	movl	$0x30, %r11d
180005c51:     	cmovsq	0x138(%rsp), %r11
180005c5a:     	addq	%rax, %r11
180005c5d:     	movq	%rdx, (%r11,%rsi,8)
180005c61:     	movq	0x130(%rsp), %r11
180005c69:     	addq	$0x7, %rbp
180005c6d:     	movl	$0x38, %edx
180005c72:     	leaq	0x38(,%r13,8), %rbp
180005c7a:     	cmovsq	%rbp, %rdx
180005c7e:     	addq	0x60(%rsp), %rdx
180005c83:     	movq	(%rdx,%rsi,8), %rdx
180005c87:     	addq	$0x7, %r10
180005c8b:     	movl	$0x38, %r10d
180005c91:     	cmovsq	%rbp, %r10
180005c95:     	addq	%rax, %r10
180005c98:     	movq	%rdx, (%r10,%rsi,8)
180005c9c:     	addq	$0x8, %rsi
180005ca0:     	cmpq	%rsi, %r11
180005ca3:     	jne	0x180005a7d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x350d>
180005ca9:     	movq	0x100(%rsp), %rsi
180005cb1:     	testq	%rsi, %rsi
180005cb4:     	movq	0xf8(%rsp), %rax
180005cbc:     	je	0x180005cfe <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x378e>
180005cbe:     	movq	0x78(%rsp), %rdx
180005cc3:     	addq	%r11, %rdx
180005cc6:     	addq	%r11, %rdi
180005cc9:     	movq	0xa8(%rsp), %rbp
180005cd1:     	movq	%rdi, %r10
180005cd4:     	sarq	$0x3f, %r10
180005cd8:     	andq	%rbp, %r10
180005cdb:     	addq	%r9, %r10
180005cde:     	movq	(%r10,%rdi,8), %r10
180005ce2:     	movq	%rdx, %r11
180005ce5:     	sarq	$0x3f, %r11
180005ce9:     	andq	%rbp, %r11
180005cec:     	addq	%r9, %r11
180005cef:     	movq	%r10, (%r11,%rdx,8)
180005cf3:     	incq	%rdx
180005cf6:     	incq	%rdi
180005cf9:     	decq	%rsi
180005cfc:     	jne	0x180005cd1 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3761>
180005cfe:     	movq	0x110(%rsp), %rdx
180005d06:     	movq	0x108(%rsp), %r10
180005d0e:     	movq	0x120(%rsp), %rsi
180005d16:     	movq	%r10, 0x8(%rsi,%rdx,8)
180005d1b:     	movq	0x78(%rsp), %rdx
180005d20:     	movq	0x98(%rsp), %r10
180005d28:     	movq	%rdx, 0x10(%rsi,%r10,8)
180005d2d:     	movq	0x118(%rsp), %r10
180005d35:     	movq	0xa0(%rsp), %rbp
180005d3d:     	leaq	0x1(%rbp), %rdx
180005d41:     	movq	%rdx, (%rsi,%r10,8)
180005d45:     	cmpb	$0x0, (%r15)
180005d49:     	jne	0x180005965 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x33f5>
180005d4f:     	xorl	%edx, %edx
180005d51:     	cmpq	$-0x2, %rax
180005d55:     	cmovlq	%r13, %rdx
180005d59:     	addq	0x10(%rsi,%rdx,8), %rbp
180005d5e:     	movq	%rbp, %rax
180005d61:     	sarq	$0x3f, %rax
180005d65:     	andq	%r13, %rax
180005d68:     	leaq	(%r9,%rbp,8), %rdx
180005d6c:     	movq	%r14, (%rdx,%rax,8)
180005d70:     	movsd	0x48(%r8,%rbx,8), %xmm1
180005d77:     	movsd	0x8(%r8,%r14,8), %xmm2
180005d7e:     	movapd	%xmm1, %xmm0
180005d82:     	addsd	%xmm2, %xmm0
180005d86:     	xorpd	%xmm3, %xmm3
180005d8a:     	ucomisd	%xmm3, %xmm0
180005d8e:     	jbe	0x180005e85 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3915>
180005d94:     	movq	0x10(%r9,%rbx,8), %rax
180005d99:     	testq	%rax, %rax
180005d9c:     	js	0x180005e97 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3927>
180005da2:     	cmpq	$0x0, 0x8(%r9,%rax,8)
180005da8:     	mulsd	(%r8,%rax,8), %xmm1
180005dae:     	je	0x180005dda <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x386a>
180005db0:     	cmpq	$0x0, 0x50(%r9,%rbx,8)
180005db6:     	je	0x180005dda <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x386a>
180005db8:     	movapd	0x4600(%rip), %xmm3     # 0x18000a3c0
180005dc0:     	andpd	%xmm1, %xmm3
180005dc4:     	ucomisd	0x4604(%rip), %xmm3     # 0x18000a3d0
180005dcc:     	jae	0x180005e97 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3927>
180005dd2:     	xorpd	%xmm3, %xmm3
180005dd6:     	addsd	%xmm3, %xmm1
180005dda:     	movq	0x10(%r9,%r14,8), %rdx
180005ddf:     	testq	%rdx, %rdx
180005de2:     	js	0x180005e97 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3927>
180005de8:     	mulsd	(%r8,%rdx,8), %xmm2
180005dee:     	addsd	%xmm2, %xmm1
180005df2:     	divsd	%xmm0, %xmm1
180005df6:     	movsd	%xmm1, (%r8,%rax,8)
180005dfc:     	movq	$0x0, 0x8(%r9,%rax,8)
180005e05:     	movq	0x10(%r9,%rbx,8), %rax
180005e0a:     	testq	%rax, %rax
180005e0d:     	js	0x180005ec6 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3956>
180005e13:     	movsd	0x10(%r8,%rax,8), %xmm1
180005e1a:     	movq	%r9, %rdx
180005e1d:     	cmpq	$0x0, 0x18(%r9,%rax,8)
180005e23:     	mulsd	0x48(%r8,%rbx,8), %xmm1
180005e2a:     	je	0x180005e52 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x38e2>
180005e2c:     	cmpq	$0x0, 0x50(%rdx,%rbx,8)
180005e32:     	je	0x180005e52 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x38e2>
180005e34:     	movapd	0x4584(%rip), %xmm2     # 0x18000a3c0
180005e3c:     	andpd	%xmm1, %xmm2
180005e40:     	ucomisd	0x4588(%rip), %xmm2     # 0x18000a3d0
180005e48:     	jae	0x180005ec6 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3956>
180005e4a:     	xorpd	%xmm2, %xmm2
180005e4e:     	addsd	%xmm2, %xmm1
180005e52:     	movq	0x10(%rdx,%r14,8), %r9
180005e57:     	testq	%r9, %r9
180005e5a:     	js	0x180005ec6 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3956>
180005e5c:     	movsd	0x10(%r8,%r9,8), %xmm2
180005e63:     	mulsd	0x8(%r8,%r14,8), %xmm2
180005e6a:     	addsd	%xmm2, %xmm1
180005e6e:     	divsd	%xmm0, %xmm1
180005e72:     	movsd	%xmm1, 0x10(%r8,%rax,8)
180005e79:     	movq	%rdx, %r9
180005e7c:     	movq	$0x0, 0x18(%rdx,%rax,8)
180005e85:     	movsd	%xmm0, 0x48(%r8,%rbx,8)
180005e8c:     	movq	$0x0, 0x50(%r9,%rbx,8)
180005e95:     	jmp	0x180005ed3 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3963>
180005e97:     	movb	$0x1, (%r15)
180005e9b:     	movq	$0x895447, 0x18(%r12)   # imm = 0x895447
180005ea4:     	jmp	0x180005ed3 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3963>
180005ea6:     	movzbl	0x5e(%rsp), %eax
180005eab:     	movq	0x8(%r12), %rcx
180005eb0:     	leaq	-0x1(%rcx), %rdx
180005eb4:     	movq	%rdx, 0x8(%r12)
180005eb9:     	testb	$0x1, %al
180005ebb:     	je	0x180005ee5 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3975>
180005ebd:     	movb	$0x1, (%rbp)
180005ec1:     	jmp	0x180005968 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x33f8>
180005ec6:     	movb	$0x1, (%r15)
180005eca:     	movq	$0x895449, 0x18(%r12)   # imm = 0x895449
180005ed3:     	cmpb	$0x0, (%r15)
180005ed7:     	jne	0x180005965 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x33f5>
180005edd:     	movb	$0x1, (%rcx)
180005ee0:     	jmp	0x180005968 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x33f8>
180005ee5:     	movq	0x38(%rsi,%rbx,8), %rax
180005eea:     	testq	%rax, %rax
180005eed:     	js	0x180005efb <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x398b>
180005eef:     	movq	%rcx, 0x8(%r12)
180005ef4:     	cmpq	0x10(%r12), %rcx
180005ef9:     	jle	0x180005f32 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x39c2>
180005efb:     	movb	$0x1, (%r15)
180005eff:     	movq	$0x2dc6cf, 0x18(%r12)   # imm = 0x2DC6CF
180005f08:     	jmp	0x180005a2c <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x34bc>
180005f0d:     	movq	0xe8(%rsp), %rdx
180005f15:     	movq	0x60(%rsp), %rcx
180005f1a:     	movq	%rdx, (%rcx)
180005f1d:     	jmp	0x18000596a <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x33fa>
180005f22:     	movq	0xf0(%rsp), %rcx
180005f2a:     	movq	%rcx, (%rsi)
180005f2d:     	jmp	0x18000596a <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x33fa>
180005f32:     	movb	$0x0, 0x5d(%rsp)
180005f37:     	movq	%r14, 0x48(%rsp)
180005f3c:     	movq	%rax, 0x40(%rsp)
180005f41:     	movq	%r13, 0x30(%rsp)
180005f46:     	movq	%r15, 0x28(%rsp)
180005f4b:     	movq	%r12, 0x20(%rsp)
180005f50:     	movq	$-0x1, 0x50(%rsp)
180005f59:     	movq	$0x0, 0x38(%rsp)
180005f62:     	leaq	0x5d(%rsp), %rcx
180005f67:     	leaq	0xd8(%rsp), %rdx
180005f6f:     	movq	%rdi, %r8
180005f72:     	movq	%rsi, %r9
180005f75:     	callq	0x180005390 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2e20>
180005f7a:     	testl	%eax, %eax
180005f7c:     	jne	0x18000620e <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3c9e>
180005f82:     	cmpb	$0x0, (%r15)
180005f86:     	jne	0x180005a2c <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x34bc>
180005f8c:     	movzbl	0x5d(%rsp), %eax
180005f91:     	movq	0x8(%r12), %rcx
180005f96:     	leaq	-0x1(%rcx), %rdx
180005f9a:     	movq	%rdx, 0x8(%r12)
180005f9f:     	testb	$0x1, %al
180005fa1:     	jne	0x180005ebd <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x394d>
180005fa7:     	movq	0x40(%rsi,%rbx,8), %rax
180005fac:     	testq	%rax, %rax
180005faf:     	js	0x180005fc1 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3a51>
180005fb1:     	movq	%rcx, 0x8(%r12)
180005fb6:     	cmpq	0x10(%r12), %rcx
180005fbb:     	jle	0x18000608b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3b1b>
180005fc1:     	movb	$0x1, (%r15)
180005fc5:     	movq	$0x2dc6d0, 0x18(%r12)   # imm = 0x2DC6D0
180005fce:     	jmp	0x180005a2c <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x34bc>
180005fd3:     	movb	$0x1, (%r15)
180005fd7:     	movl	$0x6acfc2, %edx         # imm = 0x6ACFC2
180005fdc:     	movq	%r12, %rcx
180005fdf:     	movq	%rdx, 0x18(%rcx)
180005fe3:     	cmpb	$0x0, (%r15)
180005fe7:     	movq	%rbx, %rcx
180005fea:     	jne	0x180005965 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x33f5>
180005ff0:     	movq	%r11, 0x10(%r10)
180005ff4:     	movq	$0x0, 0x48(%rdi,%rax,8)
180005ffd:     	movq	$0x1, 0x50(%r10)
180006005:     	movq	$-0x1, 0x20(%r10)
18000600d:     	movq	$-0x1, 0x28(%r10)
180006015:     	movq	$-0x1, 0x38(%r10)
18000601d:     	movq	$-0x1, 0x40(%r10)
180006025:     	cmpb	$0x0, (%r15)
180006029:     	jne	0x180005965 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x33f5>
18000602f:     	movq	%rax, 0x20(%rsi,%rbp,8)
180006034:     	movq	(%r12), %rcx
180006038:     	leaq	0x4(%rcx), %rax
18000603c:     	cmpq	%r13, %rax
18000603f:     	jle	0x180006057 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3ae7>
180006041:     	movb	$0x2, (%r15)
180006045:     	jmp	0x18000610f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3b9f>
18000604a:     	movq	0xe0(%rsp), %rdx
180006052:     	jmp	0x180005f15 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x39a5>
180006057:     	movq	%rax, (%r12)
18000605b:     	cmpb	$0x0, (%r15)
18000605f:     	jne	0x18000610f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3b9f>
180006065:     	subsd	%xmm3, %xmm2
180006069:     	testq	%rcx, %rcx
18000606c:     	js	0x1800060fc <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3b8c>
180006072:     	movsd	%xmm2, 0x10(%rdi,%rcx,8)
180006078:     	movsd	%xmm5, 0x18(%rdi,%rcx,8)
18000607e:     	movsd	%xmm3, 0x8(%rdi,%rcx,8)
180006084:     	movsd	%xmm0, (%rdi,%rcx,8)
180006089:     	jmp	0x180006109 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3b99>
18000608b:     	movb	$0x0, 0x5c(%rsp)
180006090:     	movq	%r14, 0x48(%rsp)
180006095:     	movq	%rax, 0x40(%rsp)
18000609a:     	movq	%r13, 0x30(%rsp)
18000609f:     	movq	%r15, 0x28(%rsp)
1800060a4:     	movq	%r12, 0x20(%rsp)
1800060a9:     	movq	$-0x1, 0x50(%rsp)
1800060b2:     	movq	$0x0, 0x38(%rsp)
1800060bb:     	leaq	0x5c(%rsp), %rcx
1800060c0:     	leaq	0xd0(%rsp), %rdx
1800060c8:     	movq	%rdi, %r8
1800060cb:     	movq	%rsi, %r9
1800060ce:     	callq	0x180005390 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2e20>
1800060d3:     	testl	%eax, %eax
1800060d5:     	jne	0x18000621b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3cab>
1800060db:     	cmpb	$0x0, (%r15)
1800060df:     	jne	0x180005a2c <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x34bc>
1800060e5:     	movzbl	0x5c(%rsp), %eax
1800060ea:     	decq	0x8(%r12)
1800060ef:     	testb	$0x1, %al
1800060f1:     	je	0x180005a2c <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x34bc>
1800060f7:     	jmp	0x180005ebd <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x394d>
1800060fc:     	movb	$0x1, (%r15)
180006100:     	movq	$0xf4242, 0x18(%r12)    # imm = 0xF4242
180006109:     	cmpb	$0x0, (%r15)
18000610d:     	je	0x180006117 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3ba7>
18000610f:     	movb	$0x0, (%rbx)
180006112:     	jmp	0x180005968 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x33f8>
180006117:     	movq	(%r12), %rax
18000611b:     	leaq	0xb(%rax), %r8
18000611f:     	cmpq	%r13, %r8
180006122:     	jg	0x180006041 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3ad1>
180006128:     	movq	0x8(%rsi,%rbp,8), %rdx
18000612d:     	movq	%r8, (%r12)
180006131:     	cmpb	$0x0, (%r15)
180006135:     	jne	0x18000610f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3b9f>
180006137:     	movq	%rcx, (%rsi,%rax,8)
18000613b:     	movq	%rdx, 0x8(%rsi,%rax,8)
180006140:     	movq	(%r12), %rdx
180006144:     	cmpq	%r13, %rdx
180006147:     	movq	%rdx, %rcx
18000614a:     	jle	0x180006156 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3be6>
18000614c:     	movb	$0x2, (%r15)
180006150:     	movq	(%r12), %rdx
180006154:     	xorl	%ecx, %ecx
180006156:     	leaq	0x3(%rdx), %r8
18000615a:     	cmpq	%r13, %r8
18000615d:     	jg	0x180006041 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3ad1>
180006163:     	movq	%r8, (%r12)
180006167:     	cmpb	$0x0, (%r15)
18000616b:     	jne	0x18000610f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3b9f>
18000616d:     	movq	%rdx, %r8
180006170:     	sarq	$0x3f, %r8
180006174:     	andq	%r13, %r8
180006177:     	leaq	(%rsi,%rdx,8), %r9
18000617b:     	movq	$0x0, (%r9,%r8,8)
180006183:     	xorl	%r8d, %r8d
180006186:     	cmpq	$-0x1, %rdx
18000618a:     	movl	$0x0, %r10d
180006190:     	cmovlq	%r13, %r10
180006194:     	movq	$0x0, 0x8(%r9,%r10,8)
18000619d:     	cmpq	$-0x2, %rdx
1800061a1:     	cmovlq	%r13, %r8
1800061a5:     	movq	%rcx, 0x10(%r9,%r8,8)
1800061aa:     	cmpb	$0x0, (%r15)
1800061ae:     	jne	0x18000610f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3b9f>
1800061b4:     	leaq	(%rsi,%rax,8), %rcx
1800061b8:     	movq	%rdx, 0x30(%rcx)
1800061bc:     	movq	$0x0, 0x18(%rcx)
1800061c4:     	movq	(%r12), %rdx
1800061c8:     	leaq	0x4(%rdx), %r8
1800061cc:     	cmpq	%r13, %r8
1800061cf:     	jg	0x180006041 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3ad1>
1800061d5:     	movq	%r8, (%r12)
1800061d9:     	cmpb	$0x0, (%r15)
1800061dd:     	jne	0x18000610f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3b9f>
1800061e3:     	testq	%rdx, %rdx
1800061e6:     	js	0x180006228 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3cb8>
1800061e8:     	movq	$0x0, (%rdi,%rdx,8)
1800061f0:     	leaq	(%rsi,%rdx,8), %r8
1800061f4:     	movq	$0x1, 0x8(%rsi,%rdx,8)
1800061fd:     	movq	$0x0, 0x10(%rdi,%rdx,8)
180006206:     	movl	$0x1, %r9d
18000620c:     	jmp	0x180006235 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3cc5>
18000620e:     	movq	0xd8(%rsp), %rdx
180006216:     	jmp	0x180005f15 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x39a5>
18000621b:     	movq	0xd0(%rsp), %rdx
180006223:     	jmp	0x180005f15 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x39a5>
180006228:     	movb	$0x1, (%r15)
18000622c:     	movl	$0x6acfc2, %r9d         # imm = 0x6ACFC2
180006232:     	movq	%r12, %r8
180006235:     	movq	%r9, 0x18(%r8)
180006239:     	cmpb	$0x0, (%r15)
18000623d:     	jne	0x18000610f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3b9f>
180006243:     	movq	%rdx, 0x10(%rcx)
180006247:     	movq	$0x0, 0x48(%rdi,%rax,8)
180006250:     	movq	$0x1, 0x50(%rcx)
180006258:     	movq	$-0x1, 0x20(%rcx)
180006260:     	movq	$-0x1, 0x28(%rcx)
180006268:     	movq	$-0x1, 0x38(%rcx)
180006270:     	movq	$-0x1, 0x40(%rcx)
180006278:     	cmpb	$0x0, (%r15)
18000627c:     	jne	0x18000610f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3b9f>
180006282:     	movq	%rax, 0x28(%rsi,%rbp,8)
180006287:     	movq	(%r12), %rcx
18000628b:     	leaq	0x4(%rcx), %rax
18000628f:     	cmpq	%r13, %rax
180006292:     	jg	0x180006041 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3ad1>
180006298:     	movq	%rax, (%r12)
18000629c:     	cmpb	$0x0, (%r15)
1800062a0:     	jne	0x18000610f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3b9f>
1800062a6:     	addsd	%xmm0, %xmm1
1800062aa:     	testq	%rcx, %rcx
1800062ad:     	js	0x1800062c8 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3d58>
1800062af:     	movsd	%xmm4, 0x10(%rdi,%rcx,8)
1800062b5:     	movsd	%xmm1, 0x18(%rdi,%rcx,8)
1800062bb:     	movsd	%xmm3, 0x8(%rdi,%rcx,8)
1800062c1:     	movsd	%xmm0, (%rdi,%rcx,8)
1800062c6:     	jmp	0x1800062d5 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3d65>
1800062c8:     	movb	$0x1, (%r15)
1800062cc:     	movq	$0xf4242, 0x18(%r12)    # imm = 0xF4242
1800062d5:     	cmpb	$0x0, (%r15)
1800062d9:     	jne	0x18000610f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3b9f>
1800062df:     	movq	(%r12), %rax
1800062e3:     	leaq	0xb(%rax), %r8
1800062e7:     	cmpq	%r13, %r8
1800062ea:     	jg	0x180006041 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3ad1>
1800062f0:     	movq	0x8(%rsi,%rbp,8), %rdx
1800062f5:     	movq	%r8, (%r12)
1800062f9:     	cmpb	$0x0, (%r15)
1800062fd:     	jne	0x18000610f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3b9f>
180006303:     	movq	%rcx, (%rsi,%rax,8)
180006307:     	movq	%rdx, 0x8(%rsi,%rax,8)
18000630c:     	movq	(%r12), %rdx
180006310:     	cmpq	%r13, %rdx
180006313:     	movq	%rdx, %rcx
180006316:     	jle	0x180006322 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3db2>
180006318:     	movb	$0x2, (%r15)
18000631c:     	movq	(%r12), %rdx
180006320:     	xorl	%ecx, %ecx
180006322:     	leaq	0x3(%rdx), %r8
180006326:     	cmpq	%r13, %r8
180006329:     	jg	0x180006041 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3ad1>
18000632f:     	movq	%r8, (%r12)
180006333:     	cmpb	$0x0, (%r15)
180006337:     	jne	0x18000610f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3b9f>
18000633d:     	movq	%rdx, %r8
180006340:     	sarq	$0x3f, %r8
180006344:     	andq	%r13, %r8
180006347:     	leaq	(%rsi,%rdx,8), %r9
18000634b:     	movq	$0x0, (%r9,%r8,8)
180006353:     	xorl	%r8d, %r8d
180006356:     	cmpq	$-0x1, %rdx
18000635a:     	movl	$0x0, %r10d
180006360:     	cmovlq	%r13, %r10
180006364:     	movq	$0x0, 0x8(%r9,%r10,8)
18000636d:     	cmpq	$-0x2, %rdx
180006371:     	cmovlq	%r13, %r8
180006375:     	movq	%rcx, 0x10(%r9,%r8,8)
18000637a:     	cmpb	$0x0, (%r15)
18000637e:     	jne	0x18000610f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3b9f>
180006384:     	leaq	(%rsi,%rax,8), %rcx
180006388:     	movq	%rdx, 0x30(%rcx)
18000638c:     	movq	$0x0, 0x18(%rcx)
180006394:     	movq	(%r12), %rdx
180006398:     	leaq	0x4(%rdx), %r8
18000639c:     	cmpq	%r13, %r8
18000639f:     	jg	0x180006041 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3ad1>
1800063a5:     	movq	%r8, (%r12)
1800063a9:     	cmpb	$0x0, (%r15)
1800063ad:     	jne	0x18000610f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3b9f>
1800063b3:     	testq	%rdx, %rdx
1800063b6:     	js	0x1800063de <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3e6e>
1800063b8:     	movq	$0x0, (%rdi,%rdx,8)
1800063c0:     	leaq	(%rsi,%rdx,8), %r8
1800063c4:     	movq	$0x1, 0x8(%rsi,%rdx,8)
1800063cd:     	movq	$0x0, 0x10(%rdi,%rdx,8)
1800063d6:     	movl	$0x1, %r9d
1800063dc:     	jmp	0x1800063eb <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3e7b>
1800063de:     	movb	$0x1, (%r15)
1800063e2:     	movl	$0x6acfc2, %r9d         # imm = 0x6ACFC2
1800063e8:     	movq	%r12, %r8
1800063eb:     	movq	%r9, 0x18(%r8)
1800063ef:     	cmpb	$0x0, (%r15)
1800063f3:     	jne	0x18000610f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3b9f>
1800063f9:     	movq	%rdx, 0x10(%rcx)
1800063fd:     	movq	$0x0, 0x48(%rdi,%rax,8)
180006406:     	movq	$0x1, 0x50(%rcx)
18000640e:     	movq	$-0x1, 0x20(%rcx)
180006416:     	movq	$-0x1, 0x28(%rcx)
18000641e:     	movq	$-0x1, 0x38(%rcx)
180006426:     	movq	$-0x1, 0x40(%rcx)
18000642e:     	cmpb	$0x0, (%r15)
180006432:     	jne	0x18000610f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3b9f>
180006438:     	movq	%rax, 0x38(%rsi,%rbp,8)
18000643d:     	movq	(%r12), %rcx
180006441:     	leaq	0x4(%rcx), %rax
180006445:     	cmpq	%r13, %rax
180006448:     	jg	0x180006041 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3ad1>
18000644e:     	movq	%rax, (%r12)
180006452:     	cmpb	$0x0, (%r15)
180006456:     	jne	0x18000610f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3b9f>
18000645c:     	testq	%rcx, %rcx
18000645f:     	js	0x18000647a <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3f0a>
180006461:     	movsd	%xmm2, 0x10(%rdi,%rcx,8)
180006467:     	movsd	%xmm1, 0x18(%rdi,%rcx,8)
18000646d:     	movsd	%xmm3, 0x8(%rdi,%rcx,8)
180006473:     	movsd	%xmm0, (%rdi,%rcx,8)
180006478:     	jmp	0x180006487 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3f17>
18000647a:     	movb	$0x1, (%r15)
18000647e:     	movq	$0xf4242, 0x18(%r12)    # imm = 0xF4242
180006487:     	cmpb	$0x0, (%r15)
18000648b:     	jne	0x18000610f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3b9f>
180006491:     	movq	(%r12), %rax
180006495:     	leaq	0xb(%rax), %r8
180006499:     	cmpq	%r13, %r8
18000649c:     	jg	0x180006041 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3ad1>
1800064a2:     	movq	0x8(%rsi,%rbp,8), %rdx
1800064a7:     	movq	%r8, (%r12)
1800064ab:     	cmpb	$0x0, (%r15)
1800064af:     	jne	0x18000610f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3b9f>
1800064b5:     	movq	%rcx, (%rsi,%rax,8)
1800064b9:     	movq	%rdx, 0x8(%rsi,%rax,8)
1800064be:     	movq	(%r12), %rdx
1800064c2:     	cmpq	%r13, %rdx
1800064c5:     	movq	%rdx, %rcx
1800064c8:     	jle	0x1800064d4 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3f64>
1800064ca:     	movb	$0x2, (%r15)
1800064ce:     	movq	(%r12), %rdx
1800064d2:     	xorl	%ecx, %ecx
1800064d4:     	leaq	0x3(%rdx), %r8
1800064d8:     	cmpq	%r13, %r8
1800064db:     	jg	0x180006041 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3ad1>
1800064e1:     	movq	%r8, (%r12)
1800064e5:     	cmpb	$0x0, (%r15)
1800064e9:     	jne	0x18000610f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3b9f>
1800064ef:     	movq	%rdx, %r8
1800064f2:     	sarq	$0x3f, %r8
1800064f6:     	andq	%r13, %r8
1800064f9:     	leaq	(%rsi,%rdx,8), %r9
1800064fd:     	movq	$0x0, (%r9,%r8,8)
180006505:     	xorl	%r8d, %r8d
180006508:     	cmpq	$-0x1, %rdx
18000650c:     	movl	$0x0, %r10d
180006512:     	cmovlq	%r13, %r10
180006516:     	movq	$0x0, 0x8(%r9,%r10,8)
18000651f:     	cmpq	$-0x2, %rdx
180006523:     	cmovlq	%r13, %r8
180006527:     	movq	%rcx, 0x10(%r9,%r8,8)
18000652c:     	cmpb	$0x0, (%r15)
180006530:     	jne	0x18000610f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3b9f>
180006536:     	leaq	(%rsi,%rax,8), %rcx
18000653a:     	movq	%rdx, 0x30(%rcx)
18000653e:     	movq	$0x0, 0x18(%rcx)
180006546:     	movq	(%r12), %rdx
18000654a:     	leaq	0x4(%rdx), %r8
18000654e:     	cmpq	%r13, %r8
180006551:     	jg	0x180006041 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3ad1>
180006557:     	movq	%r8, (%r12)
18000655b:     	cmpb	$0x0, (%r15)
18000655f:     	jne	0x18000610f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3b9f>
180006565:     	testq	%rdx, %rdx
180006568:     	js	0x180006590 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4020>
18000656a:     	movq	$0x0, (%rdi,%rdx,8)
180006572:     	leaq	(%rsi,%rdx,8), %r8
180006576:     	movq	$0x1, 0x8(%rsi,%rdx,8)
18000657f:     	movq	$0x0, 0x10(%rdi,%rdx,8)
180006588:     	movl	$0x1, %r9d
18000658e:     	jmp	0x18000659d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x402d>
180006590:     	movb	$0x1, (%r15)
180006594:     	movl	$0x6acfc2, %r9d         # imm = 0x6ACFC2
18000659a:     	movq	%r12, %r8
18000659d:     	movq	%r9, 0x18(%r8)
1800065a1:     	cmpb	$0x0, (%r15)
1800065a5:     	jne	0x18000610f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3b9f>
1800065ab:     	movq	%rdx, 0x10(%rcx)
1800065af:     	movq	$0x0, 0x48(%rdi,%rax,8)
1800065b8:     	movq	$0x1, 0x50(%rcx)
1800065c0:     	movq	$-0x1, 0x20(%rcx)
1800065c8:     	movq	$-0x1, 0x28(%rcx)
1800065d0:     	movq	$-0x1, 0x38(%rcx)
1800065d8:     	movq	$-0x1, 0x40(%rcx)
1800065e0:     	cmpb	$0x0, (%r15)
1800065e4:     	jne	0x18000610f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3b9f>
1800065ea:     	movq	%rax, 0x40(%rsi,%rbp,8)
1800065ef:     	movq	$0x1, 0x18(%rsi,%rbp,8)
1800065f8:     	movq	0x30(%rsi,%rbp,8), %rax
1800065fd:     	movq	%rax, %rdx
180006600:     	sarq	$0x3f, %rdx
180006604:     	andq	%r13, %rdx
180006607:     	leaq	(%rsi,%rax,8), %rcx
18000660b:     	movq	%rdx, 0x90(%rsp)
180006613:     	movq	%rcx, 0x80(%rsp)
18000661b:     	cmpq	$0x0, (%rcx,%rdx,8)
180006620:     	jle	0x1800068b7 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4347>
180006626:     	leaq	(,%r13,8), %rcx
18000662e:     	xorl	%edx, %edx
180006630:     	cmpq	$-0x2, %rax
180006634:     	movl	$0x0, %eax
180006639:     	movq	%rax, 0x70(%rsp)
18000663e:     	cmovgeq	%rdx, %rcx
180006642:     	movq	%rcx, 0x88(%rsp)
18000664a:     	movq	0x20(%rsi,%rbp,8), %rax
18000664f:     	testq	%rax, %rax
180006652:     	js	0x18000693b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x43cb>
180006658:     	movq	0x80(%rsp), %rcx
180006660:     	movq	0x88(%rsp), %rdx
180006668:     	movq	0x10(%rcx,%rdx), %rcx
18000666d:     	addq	0x70(%rsp), %rcx
180006672:     	leaq	(%rsi,%rcx,8), %rdx
180006676:     	sarq	$0x3f, %rcx
18000667a:     	andq	%r13, %rcx
18000667d:     	movq	(%rdx,%rcx,8), %rcx
180006681:     	movq	%rcx, 0x60(%rsp)
180006686:     	movq	0x8(%r12), %rcx
18000668b:     	leaq	0x1(%rcx), %rdx
18000668f:     	movq	%rdx, 0x8(%r12)
180006694:     	cmpq	0x10(%r12), %rcx
180006699:     	jge	0x18000693b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x43cb>
18000669f:     	movq	0x60(%rsp), %rcx
1800066a4:     	movq	%rcx, 0x48(%rsp)
1800066a9:     	movq	%rax, 0x40(%rsp)
1800066ae:     	movq	%r13, 0x30(%rsp)
1800066b3:     	movq	%r15, 0x28(%rsp)
1800066b8:     	movq	%r12, 0x20(%rsp)
1800066bd:     	movq	$-0x1, 0x50(%rsp)
1800066c6:     	movq	$0x0, 0x38(%rsp)
1800066cf:     	leaq	0x6e(%rsp), %rcx
1800066d4:     	leaq	0xc8(%rsp), %rdx
1800066dc:     	movq	%rdi, %r8
1800066df:     	movq	%rsi, %r9
1800066e2:     	callq	0x180005390 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2e20>
1800066e7:     	testl	%eax, %eax
1800066e9:     	jne	0x18000694d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x43dd>
1800066ef:     	cmpb	$0x0, (%r15)
1800066f3:     	jne	0x18000610f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3b9f>
1800066f9:     	movq	0x8(%r12), %rcx
1800066fe:     	leaq	-0x1(%rcx), %rax
180006702:     	movq	%rax, 0x8(%r12)
180006707:     	movq	0x28(%rsi,%rbp,8), %rax
18000670c:     	testq	%rax, %rax
18000670f:     	js	0x180006957 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x43e7>
180006715:     	movq	%rcx, 0x8(%r12)
18000671a:     	cmpq	0x10(%r12), %rcx
18000671f:     	jg	0x180006957 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x43e7>
180006725:     	movq	0x60(%rsp), %rcx
18000672a:     	movq	%rcx, 0x48(%rsp)
18000672f:     	movq	%rax, 0x40(%rsp)
180006734:     	movq	%r13, 0x30(%rsp)
180006739:     	movq	%r15, 0x28(%rsp)
18000673e:     	movq	%r12, 0x20(%rsp)
180006743:     	movq	$-0x1, 0x50(%rsp)
18000674c:     	movq	$0x0, 0x38(%rsp)
180006755:     	leaq	0x6d(%rsp), %rcx
18000675a:     	leaq	0xc0(%rsp), %rdx
180006762:     	movq	%rdi, %r8
180006765:     	movq	%rsi, %r9
180006768:     	callq	0x180005390 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2e20>
18000676d:     	testl	%eax, %eax
18000676f:     	jne	0x180006969 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x43f9>
180006775:     	cmpb	$0x0, (%r15)
180006779:     	jne	0x18000610f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3b9f>
18000677f:     	movq	0x8(%r12), %rcx
180006784:     	leaq	-0x1(%rcx), %rax
180006788:     	movq	%rax, 0x8(%r12)
18000678d:     	movq	0x38(%rsi,%rbp,8), %rax
180006792:     	testq	%rax, %rax
180006795:     	js	0x180006973 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4403>
18000679b:     	movq	%rcx, 0x8(%r12)
1800067a0:     	cmpq	0x10(%r12), %rcx
1800067a5:     	jg	0x180006973 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4403>
1800067ab:     	movq	0x60(%rsp), %rcx
1800067b0:     	movq	%rcx, 0x48(%rsp)
1800067b5:     	movq	%rax, 0x40(%rsp)
1800067ba:     	movq	%r13, 0x30(%rsp)
1800067bf:     	movq	%r15, 0x28(%rsp)
1800067c4:     	movq	%r12, 0x20(%rsp)
1800067c9:     	movq	$-0x1, 0x50(%rsp)
1800067d2:     	movq	$0x0, 0x38(%rsp)
1800067db:     	leaq	0x6c(%rsp), %rcx
1800067e0:     	leaq	0xb8(%rsp), %rdx
1800067e8:     	movq	%rdi, %r8
1800067eb:     	movq	%rsi, %r9
1800067ee:     	callq	0x180005390 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2e20>
1800067f3:     	testl	%eax, %eax
1800067f5:     	jne	0x180006985 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4415>
1800067fb:     	cmpb	$0x0, (%r15)
1800067ff:     	jne	0x18000610f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3b9f>
180006805:     	movq	0x8(%r12), %rcx
18000680a:     	leaq	-0x1(%rcx), %rax
18000680e:     	movq	%rax, 0x8(%r12)
180006813:     	movq	0x40(%rsi,%rbp,8), %rax
180006818:     	testq	%rax, %rax
18000681b:     	js	0x18000698f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x441f>
180006821:     	movq	%rcx, 0x8(%r12)
180006826:     	cmpq	0x10(%r12), %rcx
18000682b:     	jg	0x18000698f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x441f>
180006831:     	movq	0x60(%rsp), %rcx
180006836:     	movq	%rcx, 0x48(%rsp)
18000683b:     	movq	%rax, 0x40(%rsp)
180006840:     	movq	%r13, 0x30(%rsp)
180006845:     	movq	%r15, 0x28(%rsp)
18000684a:     	movq	%r12, 0x20(%rsp)
18000684f:     	movq	$-0x1, 0x50(%rsp)
180006858:     	movq	$0x0, 0x38(%rsp)
180006861:     	leaq	0x6b(%rsp), %rcx
180006866:     	leaq	0xb0(%rsp), %rdx
18000686e:     	movq	%rdi, %r8
180006871:     	movq	%rsi, %r9
180006874:     	callq	0x180005390 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x2e20>
180006879:     	testl	%eax, %eax
18000687b:     	jne	0x1800069a1 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4431>
180006881:     	cmpb	$0x0, (%r15)
180006885:     	jne	0x18000610f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3b9f>
18000688b:     	movq	0x70(%rsp), %r8
180006890:     	incq	%r8
180006893:     	decq	0x8(%r12)
180006898:     	movq	0x90(%rsp), %rax
1800068a0:     	movq	0x80(%rsp), %rcx
1800068a8:     	movq	%r8, 0x70(%rsp)
1800068ad:     	cmpq	(%rcx,%rax,8), %r8
1800068b1:     	jl	0x18000664a <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x40da>
1800068b7:     	movq	(%r12), %rcx
1800068bb:     	cmpq	%r13, %rcx
1800068be:     	movq	%rcx, %rdx
1800068c1:     	jle	0x1800068cd <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x435d>
1800068c3:     	movb	$0x2, (%r15)
1800068c7:     	movq	(%r12), %rcx
1800068cb:     	xorl	%edx, %edx
1800068cd:     	leaq	0x3(%rcx), %rax
1800068d1:     	cmpq	%r13, %rax
1800068d4:     	jg	0x180006041 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3ad1>
1800068da:     	movq	%rax, (%r12)
1800068de:     	cmpb	$0x0, (%r15)
1800068e2:     	jne	0x18000610f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3b9f>
1800068e8:     	movq	%rcx, %rax
1800068eb:     	sarq	$0x3f, %rax
1800068ef:     	andq	%r13, %rax
1800068f2:     	leaq	(%rsi,%rcx,8), %r8
1800068f6:     	movq	$0x0, (%r8,%rax,8)
1800068fe:     	xorl	%eax, %eax
180006900:     	cmpq	$-0x1, %rcx
180006904:     	movl	$0x0, %r9d
18000690a:     	cmovlq	%r13, %r9
18000690e:     	movq	$0x0, 0x8(%r8,%r9,8)
180006917:     	cmpq	$-0x2, %rcx
18000691b:     	cmovgeq	%rax, %r13
18000691f:     	movq	%rdx, 0x10(%r8,%r13,8)
180006924:     	cmpb	$0x0, (%r15)
180006928:     	jne	0x18000610f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3b9f>
18000692e:     	movq	%rcx, 0x30(%rsi,%rbp,8)
180006933:     	movb	$0x0, (%rbx)
180006936:     	jmp	0x18000596a <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x33fa>
18000693b:     	movb	$0x1, (%r15)
18000693f:     	movq	$0x989697, 0x18(%r12)   # imm = 0x989697
180006948:     	jmp	0x18000610f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3b9f>
18000694d:     	movq	0xc8(%rsp), %rcx
180006955:     	jmp	0x1800069a9 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4439>
180006957:     	movb	$0x1, (%r15)
18000695b:     	movq	$0x989698, 0x18(%r12)   # imm = 0x989698
180006964:     	jmp	0x18000610f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3b9f>
180006969:     	movq	0xc0(%rsp), %rcx
180006971:     	jmp	0x1800069a9 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4439>
180006973:     	movb	$0x1, (%r15)
180006977:     	movq	$0x989699, 0x18(%r12)   # imm = 0x989699
180006980:     	jmp	0x18000610f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3b9f>
180006985:     	movq	0xb8(%rsp), %rcx
18000698d:     	jmp	0x1800069a9 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4439>
18000698f:     	movb	$0x1, (%r15)
180006993:     	movq	$0x98969a, 0x18(%r12)   # imm = 0x98969A
18000699c:     	jmp	0x18000610f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x3b9f>
1800069a1:     	movq	0xb0(%rsp), %rcx
1800069a9:     	movq	%rcx, (%r14)
1800069ac:     	jmp	0x18000596a <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x33fa>
1800069b1:     	int3
1800069b2:     	int3
1800069b3:     	int3
1800069b4:     	int3
1800069b5:     	int3
1800069b6:     	int3
1800069b7:     	int3
1800069b8:     	int3
1800069b9:     	int3
1800069ba:     	int3
1800069bb:     	int3
1800069bc:     	int3
1800069bd:     	int3
1800069be:     	int3
1800069bf:     	int3
1800069c0:     	pushq	%rbx
1800069c2:     	subq	$0x20, %rsp
1800069c6:     	movq	%rcx, %rbx
1800069c9:     	callq	*0x3721(%rip)           # 0x18000a0f0
1800069cf:     	movl	%eax, (%rbx)
1800069d1:     	addq	$0x20, %rsp
1800069d5:     	popq	%rbx
1800069d6:     	retq
1800069d7:     	int3
1800069d8:     	int3
1800069d9:     	int3
1800069da:     	int3
1800069db:     	int3
1800069dc:     	int3
1800069dd:     	int3
1800069de:     	int3
1800069df:     	int3
1800069e0:     	movl	(%rcx), %ecx
1800069e2:     	jmpq	*0x3827(%rip)           # 0x18000a210
1800069e9:     	int3
1800069ea:     	int3
1800069eb:     	int3
1800069ec:     	int3
1800069ed:     	int3
1800069ee:     	int3
1800069ef:     	int3
1800069f0:     	pushq	%rbp
1800069f2:     	pushq	%rbx
1800069f3:     	pushq	%rsi
1800069f4:     	pushq	%rdi
1800069f5:     	pushq	%r14
1800069f7:     	pushq	%r15
1800069f9:     	movq	%rsp, %rbp
1800069fc:     	subq	$0x48, %rsp
180006a00:     	movq	0x37d9(%rip), %rax      # 0x18000a1e0
180006a07:     	xorl	%r15d, %r15d
180006a0a:     	movq	%rcx, %rsi
180006a0d:     	movq	%r15, 0x38(%rbp)
180006a11:     	movl	%r15d, %r14d
180006a14:     	movq	%r15, 0x50(%rbp)
180006a18:     	movq	%r15, 0x48(%rbp)
180006a1c:     	cmpq	%rax, 0x8(%rcx)
180006a20:     	jne	0x180006b8e <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x461e>
180006a26:     	leaq	0x48(%rbp), %rax
180006a2a:     	leaq	0x50(%rbp), %r9
180006a2e:     	movq	%rax, 0x20(%rsp)
180006a33:     	leaq	0x38(%rbp), %r8
180006a37:     	leaq	0x46e6(%rip), %rdx      # 0x18000b124
180006a3e:     	callq	*0x36ec(%rip)           # 0x18000a130
180006a44:     	testl	%eax, %eax
180006a46:     	jne	0x180006b84 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4614>
180006a4c:     	movq	0x48(%rbp), %rbx
180006a50:     	testq	%rbx, %rbx
180006a53:     	je	0x180006b75 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4605>
180006a59:     	cmpq	0x3870(%rip), %rbx      # 0x18000a2d0
180006a60:     	je	0x180006b75 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4605>
180006a66:     	movq	0x8(%rbx), %rax
180006a6a:     	testl	$0x4000000, 0xa8(%rax)  # imm = 0x4000000
180006a74:     	je	0x180006b75 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4605>
180006a7a:     	movq	0x20(%rbx), %rcx
180006a7e:     	callq	*0x36fc(%rip)           # 0x18000a180
180006a84:     	movq	0x28(%rbx), %rcx
180006a88:     	movq	%rax, %rdi
180006a8b:     	callq	*0x36ef(%rip)           # 0x18000a180
180006a91:     	movq	0x30(%rbx), %rcx
180006a95:     	movq	%rax, %r14
180006a98:     	callq	*0x36f2(%rip)           # 0x18000a190
180006a9e:     	leaq	-0x10(%rbp), %r8
180006aa2:     	movl	%eax, %ebx
180006aa4:     	leaq	-0x18(%rbp), %rdx
180006aa8:     	leaq	0x40(%rbp), %rcx
180006aac:     	callq	*0x36ee(%rip)           # 0x18000a1a0
180006ab2:     	callq	*0x36a8(%rip)           # 0x18000a160
180006ab8:     	movq	%rax, %rsi
180006abb:     	testq	%rax, %rax
180006abe:     	je	0x180006b6b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x45fb>
180006ac4:     	movl	%ebx, %r8d
180006ac7:     	movq	%rdi, %rdx
180006aca:     	movq	%r14, %rcx
180006acd:     	callq	*0x3785(%rip)           # 0x18000a258
180006ad3:     	movq	%rax, %rdi
180006ad6:     	testq	%rax, %rax
180006ad9:     	je	0x180006b6b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x45fb>
180006adf:     	callq	*0x3783(%rip)           # 0x18000a268
180006ae5:     	xorl	%r9d, %r9d
180006ae8:     	movq	%rsi, %r8
180006aeb:     	movq	%rax, %rcx
180006aee:     	movq	%rdi, %rdx
180006af1:     	callq	*0x3749(%rip)           # 0x18000a240
180006af7:     	movl	(%rsi), %ecx
180006af9:     	movq	%rax, %rbx
180006afc:     	testl	%ecx, %ecx
180006afe:     	js	0x180006b10 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x45a0>
180006b00:     	subl	$0x1, %ecx
180006b03:     	movl	%ecx, (%rsi)
180006b05:     	jne	0x180006b10 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x45a0>
180006b07:     	movq	%rsi, %rcx
180006b0a:     	callq	*0x36b8(%rip)           # 0x18000a1c8
180006b10:     	movl	(%rdi), %eax
180006b12:     	testl	%eax, %eax
180006b14:     	js	0x180006b26 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x45b6>
180006b16:     	subl	$0x1, %eax
180006b19:     	movl	%eax, (%rdi)
180006b1b:     	jne	0x180006b26 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x45b6>
180006b1d:     	movq	%rdi, %rcx
180006b20:     	callq	*0x36a2(%rip)           # 0x18000a1c8
180006b26:     	testq	%rbx, %rbx
180006b29:     	je	0x180006b6b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x45fb>
180006b2b:     	movq	-0x10(%rbp), %r8
180006b2f:     	movq	-0x18(%rbp), %rdx
180006b33:     	movq	0x40(%rbp), %rcx
180006b37:     	callq	*0x3693(%rip)           # 0x18000a1d0
180006b3d:     	movq	%rbx, %rcx
180006b40:     	callq	*0x36e2(%rip)           # 0x18000a228
180006b46:     	movl	(%rbx), %eax
180006b48:     	testl	%eax, %eax
180006b4a:     	js	0x180006b75 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4605>
180006b4c:     	subl	$0x1, %eax
180006b4f:     	movl	%eax, (%rbx)
180006b51:     	jne	0x180006b75 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4605>
180006b53:     	movq	%rbx, %rcx
180006b56:     	callq	*0x366c(%rip)           # 0x18000a1c8
180006b5c:     	xorl	%eax, %eax
180006b5e:     	addq	$0x48, %rsp
180006b62:     	popq	%r15
180006b64:     	popq	%r14
180006b66:     	popq	%rdi
180006b67:     	popq	%rsi
180006b68:     	popq	%rbx
180006b69:     	popq	%rbp
180006b6a:     	retq
180006b6b:     	movq	0x40(%rbp), %rcx
180006b6f:     	callq	*0x368b(%rip)           # 0x18000a200
180006b75:     	xorl	%eax, %eax
180006b77:     	addq	$0x48, %rsp
180006b7b:     	popq	%r15
180006b7d:     	popq	%r14
180006b7f:     	popq	%rdi
180006b80:     	popq	%rsi
180006b81:     	popq	%rbx
180006b82:     	popq	%rbp
180006b83:     	retq
180006b84:     	movq	0x38(%rbp), %rbx
180006b88:     	movq	0x50(%rbp), %r14
180006b8c:     	jmp	0x180006b95 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4625>
180006b8e:     	movq	%rsi, %rbx
180006b91:     	movq	%rbx, 0x38(%rbp)
180006b95:     	cmpq	0x3734(%rip), %rbx      # 0x18000a2d0
180006b9c:     	jne	0x180006c34 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x46c4>
180006ba2:     	leaq	-0x18(%rbp), %r8
180006ba6:     	leaq	-0x10(%rbp), %rdx
180006baa:     	leaq	0x40(%rbp), %rcx
180006bae:     	callq	*0x356c(%rip)           # 0x18000a120
180006bb4:     	movq	0x3715(%rip), %rax      # 0x18000a2d0
180006bbb:     	cmpq	%rax, 0x40(%rbp)
180006bbf:     	jne	0x180006bd4 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4664>
180006bc1:     	movq	0x36e8(%rip), %rcx      # 0x18000a2b0
180006bc8:     	leaq	0x4509(%rip), %rdx      # 0x18000b0d8
180006bcf:     	jmp	0x180006cf5 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4785>
180006bd4:     	movq	0x40(%rbp), %rcx
180006bd8:     	testq	%rcx, %rcx
180006bdb:     	je	0x180006bea <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x467a>
180006bdd:     	movl	(%rcx), %eax
180006bdf:     	cmpl	$0xc0000000, %eax       # imm = 0xC0000000
180006be4:     	jae	0x180006bea <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x467a>
180006be6:     	incl	%eax
180006be8:     	movl	%eax, (%rcx)
180006bea:     	movq	-0x10(%rbp), %rcx
180006bee:     	testq	%rcx, %rcx
180006bf1:     	je	0x180006c00 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4690>
180006bf3:     	movl	(%rcx), %eax
180006bf5:     	cmpl	$0xc0000000, %eax       # imm = 0xC0000000
180006bfa:     	jae	0x180006c00 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4690>
180006bfc:     	incl	%eax
180006bfe:     	movl	%eax, (%rcx)
180006c00:     	movq	-0x18(%rbp), %r8
180006c04:     	testq	%r8, %r8
180006c07:     	je	0x180006c1c <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x46ac>
180006c09:     	movl	(%r8), %eax
180006c0c:     	cmpl	$0xc0000000, %eax       # imm = 0xC0000000
180006c11:     	jae	0x180006c1c <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x46ac>
180006c13:     	incl	%eax
180006c15:     	movl	%eax, (%r8)
180006c18:     	movq	-0x18(%rbp), %r8
180006c1c:     	movq	-0x10(%rbp), %rdx
180006c20:     	movq	0x40(%rbp), %rcx
180006c24:     	callq	*0x35a6(%rip)           # 0x18000a1d0
180006c2a:     	movl	$0x1, %ebx
180006c2f:     	jmp	0x180006d01 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4791>
180006c34:     	movq	0x8(%rbx), %rcx
180006c38:     	movl	0xa8(%rcx), %eax
180006c3e:     	testl	%eax, %eax
180006c40:     	jns	0x180006cd6 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4766>
180006c46:     	testl	$0x40000000, 0xa8(%rbx) # imm = 0x40000000
180006c50:     	je	0x180006cd6 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4766>
180006c56:     	movq	%r14, %rdx
180006c59:     	movq	%rbx, %rcx
180006c5c:     	callq	*0x3486(%rip)           # 0x18000a0e8
180006c62:     	movq	%rax, %rdi
180006c65:     	testq	%rax, %rax
180006c68:     	je	0x180006cfe <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x478e>
180006c6e:     	movq	0x8(%rax), %rax
180006c72:     	testl	$0x40000000, 0xa8(%rax) # imm = 0x40000000
180006c7c:     	jne	0x180006cad <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x473d>
180006c7e:     	movq	0x361b(%rip), %rcx      # 0x18000a2a0
180006c85:     	leaq	0x446c(%rip), %rdx      # 0x18000b0f8
180006c8c:     	movq	(%rcx), %rcx
180006c8f:     	callq	*0x3613(%rip)           # 0x18000a2a8
180006c95:     	movl	(%rdi), %eax
180006c97:     	testl	%eax, %eax
180006c99:     	js	0x180006cfe <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x478e>
180006c9b:     	subl	$0x1, %eax
180006c9e:     	movl	%eax, (%rdi)
180006ca0:     	jne	0x180006cfe <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x478e>
180006ca2:     	movq	%rdi, %rcx
180006ca5:     	callq	*0x351d(%rip)           # 0x18000a1c8
180006cab:     	jmp	0x180006cfe <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x478e>
180006cad:     	movl	(%rdi), %eax
180006caf:     	testl	%eax, %eax
180006cb1:     	js	0x180006cc3 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4753>
180006cb3:     	subl	$0x1, %eax
180006cb6:     	movl	%eax, (%rdi)
180006cb8:     	jne	0x180006cc3 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4753>
180006cba:     	movq	%rdi, %rcx
180006cbd:     	callq	*0x3505(%rip)           # 0x18000a1c8
180006cc3:     	movq	%r14, %rdx
180006cc6:     	movq	%rbx, %rcx
180006cc9:     	callq	*0x3591(%rip)           # 0x18000a260
180006ccf:     	movl	$0x1, %ebx
180006cd4:     	jmp	0x180006d01 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4791>
180006cd6:     	btl	$0x1e, %eax
180006cda:     	jae	0x180006ce7 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4777>
180006cdc:     	movq	%rbx, %rdx
180006cdf:     	callq	*0x357b(%rip)           # 0x18000a260
180006ce5:     	jmp	0x180006cfe <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x478e>
180006ce7:     	movq	0x35b2(%rip), %rcx      # 0x18000a2a0
180006cee:     	leaq	0x4403(%rip), %rdx      # 0x18000b0f8
180006cf5:     	movq	(%rcx), %rcx
180006cf8:     	callq	*0x35aa(%rip)           # 0x18000a2a8
180006cfe:     	movl	%r15d, %ebx
180006d01:     	movq	0x48(%rbp), %rdi
180006d05:     	testq	%rdi, %rdi
180006d08:     	je	0x180006e2b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x48bb>
180006d0e:     	cmpq	0x35bb(%rip), %rdi      # 0x18000a2d0
180006d15:     	je	0x180006e2b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x48bb>
180006d1b:     	movq	0x8(%rdi), %rax
180006d1f:     	testl	$0x4000000, 0xa8(%rax)  # imm = 0x4000000
180006d29:     	je	0x180006e2b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x48bb>
180006d2f:     	movq	0x20(%rdi), %rcx
180006d33:     	movq	%r12, 0x40(%rsp)
180006d38:     	callq	*0x3442(%rip)           # 0x18000a180
180006d3e:     	movq	0x28(%rdi), %rcx
180006d42:     	movq	%rax, %r14
180006d45:     	callq	*0x3435(%rip)           # 0x18000a180
180006d4b:     	movq	0x30(%rdi), %rcx
180006d4f:     	movq	%rax, %r12
180006d52:     	callq	*0x3438(%rip)           # 0x18000a190
180006d58:     	leaq	-0x10(%rbp), %r8
180006d5c:     	movl	%eax, %edi
180006d5e:     	leaq	-0x18(%rbp), %rdx
180006d62:     	leaq	0x40(%rbp), %rcx
180006d66:     	callq	*0x3434(%rip)           # 0x18000a1a0
180006d6c:     	callq	*0x33ee(%rip)           # 0x18000a160
180006d72:     	movq	%rax, %r15
180006d75:     	testq	%rax, %rax
180006d78:     	je	0x180006e1c <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x48ac>
180006d7e:     	movl	%edi, %r8d
180006d81:     	movq	%r14, %rdx
180006d84:     	movq	%r12, %rcx
180006d87:     	callq	*0x34cb(%rip)           # 0x18000a258
180006d8d:     	movq	%rax, %r14
180006d90:     	testq	%rax, %rax
180006d93:     	je	0x180006e1c <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x48ac>
180006d99:     	callq	*0x34c9(%rip)           # 0x18000a268
180006d9f:     	xorl	%r9d, %r9d
180006da2:     	movq	%r15, %r8
180006da5:     	movq	%rax, %rcx
180006da8:     	movq	%r14, %rdx
180006dab:     	callq	*0x348f(%rip)           # 0x18000a240
180006db1:     	movl	(%r15), %ecx
180006db4:     	movq	%rax, %rdi
180006db7:     	testl	%ecx, %ecx
180006db9:     	js	0x180006dcc <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x485c>
180006dbb:     	subl	$0x1, %ecx
180006dbe:     	movl	%ecx, (%r15)
180006dc1:     	jne	0x180006dcc <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x485c>
180006dc3:     	movq	%r15, %rcx
180006dc6:     	callq	*0x33fc(%rip)           # 0x18000a1c8
180006dcc:     	movl	(%r14), %eax
180006dcf:     	testl	%eax, %eax
180006dd1:     	js	0x180006de4 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4874>
180006dd3:     	subl	$0x1, %eax
180006dd6:     	movl	%eax, (%r14)
180006dd9:     	jne	0x180006de4 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4874>
180006ddb:     	movq	%r14, %rcx
180006dde:     	callq	*0x33e4(%rip)           # 0x18000a1c8
180006de4:     	testq	%rdi, %rdi
180006de7:     	je	0x180006e1c <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x48ac>
180006de9:     	movq	-0x10(%rbp), %r8
180006ded:     	movq	-0x18(%rbp), %rdx
180006df1:     	movq	0x40(%rbp), %rcx
180006df5:     	callq	*0x33d5(%rip)           # 0x18000a1d0
180006dfb:     	movq	%rdi, %rcx
180006dfe:     	callq	*0x3424(%rip)           # 0x18000a228
180006e04:     	movl	(%rdi), %eax
180006e06:     	testl	%eax, %eax
180006e08:     	js	0x180006e26 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x48b6>
180006e0a:     	subl	$0x1, %eax
180006e0d:     	movl	%eax, (%rdi)
180006e0f:     	jne	0x180006e26 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x48b6>
180006e11:     	movq	%rdi, %rcx
180006e14:     	callq	*0x33ae(%rip)           # 0x18000a1c8
180006e1a:     	jmp	0x180006e26 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x48b6>
180006e1c:     	movq	0x40(%rbp), %rcx
180006e20:     	callq	*0x33da(%rip)           # 0x18000a200
180006e26:     	movq	0x40(%rsp), %r12
180006e2b:     	movl	(%rsi), %ecx
180006e2d:     	testl	%ecx, %ecx
180006e2f:     	js	0x180006e41 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x48d1>
180006e31:     	subl	$0x1, %ecx
180006e34:     	movl	%ecx, (%rsi)
180006e36:     	jne	0x180006e41 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x48d1>
180006e38:     	movq	%rsi, %rcx
180006e3b:     	callq	*0x3387(%rip)           # 0x18000a1c8
180006e41:     	movl	%ebx, %eax
180006e43:     	addq	$0x48, %rsp
180006e47:     	popq	%r15
180006e49:     	popq	%r14
180006e4b:     	popq	%rdi
180006e4c:     	popq	%rsi
180006e4d:     	popq	%rbx
180006e4e:     	popq	%rbp
180006e4f:     	retq
180006e50:     	movq	%rbx, 0x8(%rsp)
180006e55:     	movq	%rsi, 0x10(%rsp)
180006e5a:     	pushq	%rdi
180006e5b:     	subq	$0x20, %rsp
180006e5f:     	cmpq	$0x0, 0xae31(%rip)      # 0x180011c98
180006e67:     	movq	%rcx, %rsi
180006e6a:     	movslq	%edx, %rdi
180006e6d:     	jne	0x180006ebd <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x494d>
180006e6f:     	leaq	0x42b2(%rip), %rcx      # 0x18000b128
180006e76:     	callq	*0x33bc(%rip)           # 0x18000a238
180006e7c:     	movq	%rax, %rbx
180006e7f:     	testq	%rax, %rax
180006e82:     	je	0x180006ed1 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4961>
180006e84:     	leaq	0x42a5(%rip), %rdx      # 0x18000b130
180006e8b:     	movq	%rax, %rcx
180006e8e:     	callq	*0x32d4(%rip)           # 0x18000a168
180006e94:     	movl	(%rbx), %ecx
180006e96:     	movq	%rax, 0xadfb(%rip)      # 0x180011c98
180006e9d:     	testl	%ecx, %ecx
180006e9f:     	js	0x180006eb8 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4948>
180006ea1:     	subl	$0x1, %ecx
180006ea4:     	movl	%ecx, (%rbx)
180006ea6:     	jne	0x180006eb8 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4948>
180006ea8:     	movq	%rbx, %rcx
180006eab:     	callq	*0x3317(%rip)           # 0x18000a1c8
180006eb1:     	movq	0xade0(%rip), %rax      # 0x180011c98
180006eb8:     	testq	%rax, %rax
180006ebb:     	je	0x180006ed1 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4961>
180006ebd:     	movq	%rdi, %rdx
180006ec0:     	movq	%rsi, %rcx
180006ec3:     	callq	*0x33ef(%rip)           # 0x18000a2b8
180006ec9:     	movq	%rax, %rbx
180006ecc:     	testq	%rax, %rax
180006ecf:     	jne	0x180006ee3 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4973>
180006ed1:     	xorl	%eax, %eax
180006ed3:     	movq	0x30(%rsp), %rbx
180006ed8:     	movq	0x38(%rsp), %rsi
180006edd:     	addq	$0x20, %rsp
180006ee1:     	popq	%rdi
180006ee2:     	retq
180006ee3:     	movq	0xadae(%rip), %rcx      # 0x180011c98
180006eea:     	xorl	%r8d, %r8d
180006eed:     	movq	%rbx, %rdx
180006ef0:     	callq	*0x32a2(%rip)           # 0x18000a198
180006ef6:     	movl	(%rbx), %ecx
180006ef8:     	movq	%rax, %rdi
180006efb:     	testl	%ecx, %ecx
180006efd:     	js	0x180006f0f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x499f>
180006eff:     	subl	$0x1, %ecx
180006f02:     	movl	%ecx, (%rbx)
180006f04:     	jne	0x180006f0f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x499f>
180006f06:     	movq	%rbx, %rcx
180006f09:     	callq	*0x32b9(%rip)           # 0x18000a1c8
180006f0f:     	movq	0x30(%rsp), %rbx
180006f14:     	movq	%rdi, %rax
180006f17:     	movq	0x38(%rsp), %rsi
180006f1c:     	addq	$0x20, %rsp
180006f20:     	popq	%rdi
180006f21:     	retq
180006f22:     	int3
180006f23:     	int3
180006f24:     	int3
180006f25:     	int3
180006f26:     	int3
180006f27:     	int3
180006f28:     	int3
180006f29:     	int3
180006f2a:     	int3
180006f2b:     	int3
180006f2c:     	int3
180006f2d:     	int3
180006f2e:     	int3
180006f2f:     	int3
180006f30:     	movq	%rbx, 0x8(%rsp)
180006f35:     	movq	%rsi, 0x10(%rsp)
180006f3a:     	pushq	%rdi
180006f3b:     	subq	$0x20, %rsp
180006f3f:     	movq	0xad4a(%rip), %rax      # 0x180011c90
180006f46:     	movq	%rdx, %rdi
180006f49:     	movq	%rcx, %rsi
180006f4c:     	testq	%rax, %rax
180006f4f:     	jne	0x180006fb1 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4a41>
180006f51:     	leaq	0x41e0(%rip), %rcx      # 0x18000b138
180006f58:     	callq	*0x32da(%rip)           # 0x18000a238
180006f5e:     	movq	%rax, %rbx
180006f61:     	testq	%rax, %rax
180006f64:     	je	0x180006f9f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4a2f>
180006f66:     	leaq	0x41e3(%rip), %rdx      # 0x18000b150
180006f6d:     	movq	%rax, %rcx
180006f70:     	callq	*0x31f2(%rip)           # 0x18000a168
180006f76:     	movl	(%rbx), %ecx
180006f78:     	movq	%rax, 0xad11(%rip)      # 0x180011c90
180006f7f:     	testl	%ecx, %ecx
180006f81:     	js	0x180006f9a <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4a2a>
180006f83:     	subl	$0x1, %ecx
180006f86:     	movl	%ecx, (%rbx)
180006f88:     	jne	0x180006f9a <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4a2a>
180006f8a:     	movq	%rbx, %rcx
180006f8d:     	callq	*0x3235(%rip)           # 0x18000a1c8
180006f93:     	movq	0xacf6(%rip), %rax      # 0x180011c90
180006f9a:     	testq	%rax, %rax
180006f9d:     	jne	0x180006fb1 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4a41>
180006f9f:     	xorl	%eax, %eax
180006fa1:     	movq	0x30(%rsp), %rbx
180006fa6:     	movq	0x38(%rsp), %rsi
180006fab:     	addq	$0x20, %rsp
180006faf:     	popq	%rdi
180006fb0:     	retq
180006fb1:     	xorl	%r9d, %r9d
180006fb4:     	movq	%rdi, %r8
180006fb7:     	movq	%rsi, %rdx
180006fba:     	movq	%rax, %rcx
180006fbd:     	movq	0x30(%rsp), %rbx
180006fc2:     	movq	0x38(%rsp), %rsi
180006fc7:     	addq	$0x20, %rsp
180006fcb:     	popq	%rdi
180006fcc:     	jmpq	*0x31c5(%rip)           # 0x18000a198
180006fd3:     	int3
180006fd4:     	int3
180006fd5:     	int3
180006fd6:     	int3
180006fd7:     	int3
180006fd8:     	int3
180006fd9:     	int3
180006fda:     	int3
180006fdb:     	int3
180006fdc:     	int3
180006fdd:     	int3
180006fde:     	int3
180006fdf:     	int3
180006fe0:     	movq	%rbx, 0x8(%rsp)
180006fe5:     	movq	%rsi, 0x10(%rsp)
180006fea:     	pushq	%rdi
180006feb:     	subq	$0x20, %rsp
180006fef:     	movq	%rcx, %rbx
180006ff2:     	movq	%r8, %rdi
180006ff5:     	movq	0x10(%rcx), %rcx
180006ff9:     	movq	%rdx, %rsi
180006ffc:     	testq	%rcx, %rcx
180006fff:     	je	0x18000700a <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4a9a>
180007001:     	movq	%r8, %rdx
180007004:     	callq	*%rsi
180007006:     	testl	%eax, %eax
180007008:     	jne	0x18000702d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4abd>
18000700a:     	movq	0x18(%rbx), %rcx
18000700e:     	testq	%rcx, %rcx
180007011:     	je	0x18000702b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4abb>
180007013:     	movq	%rdi, %rdx
180007016:     	movq	%rsi, %rax
180007019:     	movq	0x30(%rsp), %rbx
18000701e:     	movq	0x38(%rsp), %rsi
180007023:     	addq	$0x20, %rsp
180007027:     	popq	%rdi
180007028:     	jmpq	*%rax
18000702b:     	xorl	%eax, %eax
18000702d:     	movq	0x30(%rsp), %rbx
180007032:     	movq	0x38(%rsp), %rsi
180007037:     	addq	$0x20, %rsp
18000703b:     	popq	%rdi
18000703c:     	retq
18000703d:     	int3
18000703e:     	int3
18000703f:     	int3
180007040:     	pushq	%rbx
180007042:     	subq	$0x20, %rsp
180007046:     	movq	%rcx, %rbx
180007049:     	movq	0x10(%rcx), %rcx
18000704d:     	testq	%rcx, %rcx
180007050:     	je	0x18000706d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4afd>
180007052:     	movq	$0x0, 0x10(%rbx)
18000705a:     	movl	(%rcx), %eax
18000705c:     	testl	%eax, %eax
18000705e:     	js	0x18000706d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4afd>
180007060:     	subl	$0x1, %eax
180007063:     	movl	%eax, (%rcx)
180007065:     	jne	0x18000706d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4afd>
180007067:     	callq	*0x315b(%rip)           # 0x18000a1c8
18000706d:     	movq	0x18(%rbx), %rcx
180007071:     	testq	%rcx, %rcx
180007074:     	je	0x180007091 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4b21>
180007076:     	movq	$0x0, 0x18(%rbx)
18000707e:     	movl	(%rcx), %eax
180007080:     	testl	%eax, %eax
180007082:     	js	0x180007091 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4b21>
180007084:     	subl	$0x1, %eax
180007087:     	movl	%eax, (%rcx)
180007089:     	jne	0x180007091 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4b21>
18000708b:     	callq	*0x3137(%rip)           # 0x18000a1c8
180007091:     	xorl	%eax, %eax
180007093:     	addq	$0x20, %rsp
180007097:     	popq	%rbx
180007098:     	retq
180007099:     	int3
18000709a:     	int3
18000709b:     	int3
18000709c:     	int3
18000709d:     	int3
18000709e:     	int3
18000709f:     	int3
1800070a0:     	pushq	%rbx
1800070a2:     	subq	$0x20, %rsp
1800070a6:     	movq	%rcx, %rbx
1800070a9:     	callq	*0x3169(%rip)           # 0x18000a218
1800070af:     	movq	0x10(%rbx), %rcx
1800070b3:     	testq	%rcx, %rcx
1800070b6:     	je	0x1800070d3 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4b63>
1800070b8:     	movq	$0x0, 0x10(%rbx)
1800070c0:     	movl	(%rcx), %eax
1800070c2:     	testl	%eax, %eax
1800070c4:     	js	0x1800070d3 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4b63>
1800070c6:     	subl	$0x1, %eax
1800070c9:     	movl	%eax, (%rcx)
1800070cb:     	jne	0x1800070d3 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4b63>
1800070cd:     	callq	*0x30f5(%rip)           # 0x18000a1c8
1800070d3:     	movq	0x18(%rbx), %rcx
1800070d7:     	testq	%rcx, %rcx
1800070da:     	je	0x1800070f7 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4b87>
1800070dc:     	movq	$0x0, 0x18(%rbx)
1800070e4:     	movl	(%rcx), %eax
1800070e6:     	testl	%eax, %eax
1800070e8:     	js	0x1800070f7 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4b87>
1800070ea:     	subl	$0x1, %eax
1800070ed:     	movl	%eax, (%rcx)
1800070ef:     	jne	0x1800070f7 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4b87>
1800070f1:     	callq	*0x30d1(%rip)           # 0x18000a1c8
1800070f7:     	movq	0x8(%rbx), %rax
1800070fb:     	movq	%rbx, %rcx
1800070fe:     	addq	$0x20, %rsp
180007102:     	popq	%rbx
180007103:     	jmpq	*0x140(%rax)
18000710a:     	int3
18000710b:     	int3
18000710c:     	int3
18000710d:     	int3
18000710e:     	int3
18000710f:     	int3
180007110:     	pushq	%rbx
180007112:     	subq	$0x30, %rsp
180007116:     	movq	%r8, %r10
180007119:     	leaq	0x58(%rsp), %rax
18000711e:     	movq	%rax, 0x28(%rsp)
180007123:     	leaq	0xa8a6(%rip), %r9       # 0x1800119d0
18000712a:     	movq	0x30b7(%rip), %rax      # 0x18000a1e8
180007131:     	leaq	0x4048(%rip), %r8       # 0x18000b180
180007138:     	movq	%rdx, %r11
18000713b:     	movq	%rax, 0x20(%rsp)
180007140:     	movq	%rcx, %rbx
180007143:     	movq	%r10, %rdx
180007146:     	movq	%r11, %rcx
180007149:     	callq	*0x2fa9(%rip)           # 0x18000a0f8
18000714f:     	testl	%eax, %eax
180007151:     	je	0x1800071ac <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4c3c>
180007153:     	xorl	%r8d, %r8d
180007156:     	xorl	%edx, %edx
180007158:     	movq	%rbx, %rcx
18000715b:     	callq	*0x30e7(%rip)           # 0x18000a248
180007161:     	movq	%rax, %rbx
180007164:     	testq	%rax, %rax
180007167:     	je	0x1800071ac <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4c3c>
180007169:     	movq	0x58(%rsp), %rax
18000716e:     	movl	(%rax), %ecx
180007170:     	cmpl	$0xc0000000, %ecx       # imm = 0xC0000000
180007176:     	jae	0x180007181 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4c11>
180007178:     	incl	%ecx
18000717a:     	movl	%ecx, (%rax)
18000717c:     	movq	0x58(%rsp), %rax
180007181:     	xorl	%ecx, %ecx
180007183:     	movq	%rax, 0x10(%rbx)
180007187:     	callq	*0x2feb(%rip)           # 0x18000a178
18000718d:     	movq	%rax, 0x18(%rbx)
180007191:     	testq	%rax, %rax
180007194:     	jne	0x1800071b4 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4c44>
180007196:     	movl	(%rbx), %eax
180007198:     	testl	%eax, %eax
18000719a:     	js	0x1800071ac <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4c3c>
18000719c:     	subl	$0x1, %eax
18000719f:     	movl	%eax, (%rbx)
1800071a1:     	jne	0x1800071ac <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4c3c>
1800071a3:     	movq	%rbx, %rcx
1800071a6:     	callq	*0x301c(%rip)           # 0x18000a1c8
1800071ac:     	xorl	%eax, %eax
1800071ae:     	addq	$0x30, %rsp
1800071b2:     	popq	%rbx
1800071b3:     	retq
1800071b4:     	movq	%rbx, %rax
1800071b7:     	addq	$0x30, %rsp
1800071bb:     	popq	%rbx
1800071bc:     	retq
1800071bd:     	int3
1800071be:     	int3
1800071bf:     	int3
1800071c0:     	movq	%rbx, 0x8(%rsp)
1800071c5:     	movq	%rsi, 0x10(%rsp)
1800071ca:     	pushq	%rdi
1800071cb:     	subq	$0x20, %rsp
1800071cf:     	movq	%rcx, %rbx
1800071d2:     	movq	%r8, %rdi
1800071d5:     	movq	0x18(%rcx), %rcx
1800071d9:     	movq	%rdx, %rsi
1800071dc:     	testq	%rcx, %rcx
1800071df:     	je	0x1800071ea <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4c7a>
1800071e1:     	movq	%r8, %rdx
1800071e4:     	callq	*%rsi
1800071e6:     	testl	%eax, %eax
1800071e8:     	jne	0x18000720d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4c9d>
1800071ea:     	movq	0x40(%rbx), %rcx
1800071ee:     	testq	%rcx, %rcx
1800071f1:     	je	0x18000720b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4c9b>
1800071f3:     	movq	%rdi, %rdx
1800071f6:     	movq	%rsi, %rax
1800071f9:     	movq	0x30(%rsp), %rbx
1800071fe:     	movq	0x38(%rsp), %rsi
180007203:     	addq	$0x20, %rsp
180007207:     	popq	%rdi
180007208:     	jmpq	*%rax
18000720b:     	xorl	%eax, %eax
18000720d:     	movq	0x30(%rsp), %rbx
180007212:     	movq	0x38(%rsp), %rsi
180007217:     	addq	$0x20, %rsp
18000721b:     	popq	%rdi
18000721c:     	retq
18000721d:     	int3
18000721e:     	int3
18000721f:     	int3
180007220:     	pushq	%rbx
180007222:     	subq	$0x20, %rsp
180007226:     	movq	%rcx, %rbx
180007229:     	callq	*0x2fe9(%rip)           # 0x18000a218
18000722f:     	cmpq	$0x0, 0x48(%rbx)
180007234:     	je	0x18000723f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4ccf>
180007236:     	movq	%rbx, %rcx
180007239:     	callq	*0x2f49(%rip)           # 0x18000a188
18000723f:     	movq	0x20(%rbx), %rcx
180007243:     	callq	*0x2f6f(%rip)           # 0x18000a1b8
180007249:     	movq	0x38(%rbx), %rcx
18000724d:     	callq	*0x2f65(%rip)           # 0x18000a1b8
180007253:     	movq	0x18(%rbx), %rcx
180007257:     	testq	%rcx, %rcx
18000725a:     	je	0x18000726f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4cff>
18000725c:     	movl	(%rcx), %eax
18000725e:     	testl	%eax, %eax
180007260:     	js	0x18000726f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4cff>
180007262:     	subl	$0x1, %eax
180007265:     	movl	%eax, (%rcx)
180007267:     	jne	0x18000726f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4cff>
180007269:     	callq	*0x2f59(%rip)           # 0x18000a1c8
18000726f:     	movq	0x40(%rbx), %rcx
180007273:     	testq	%rcx, %rcx
180007276:     	je	0x18000728b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4d1b>
180007278:     	movl	(%rcx), %eax
18000727a:     	testl	%eax, %eax
18000727c:     	js	0x18000728b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4d1b>
18000727e:     	subl	$0x1, %eax
180007281:     	movl	%eax, (%rcx)
180007283:     	jne	0x18000728b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4d1b>
180007285:     	callq	*0x2f3d(%rip)           # 0x18000a1c8
18000728b:     	movq	0x8(%rbx), %rax
18000728f:     	movq	%rbx, %rcx
180007292:     	addq	$0x20, %rsp
180007296:     	popq	%rbx
180007297:     	jmpq	*0x140(%rax)
18000729e:     	int3
18000729f:     	int3
1800072a0:     	pushq	%rbx
1800072a2:     	subq	$0x20, %rsp
1800072a6:     	callq	*0x2ed4(%rip)           # 0x18000a180
1800072ac:     	movq	%rax, %rbx
1800072af:     	testq	%rax, %rax
1800072b2:     	jne	0x1800072ba <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4d4a>
1800072b4:     	addq	$0x20, %rsp
1800072b8:     	popq	%rbx
1800072b9:     	retq
1800072ba:     	movq	%rbx, %rcx
1800072bd:     	movq	%rdi, 0x30(%rsp)
1800072c2:     	callq	0x180009625 <numba_list_iter_next+0xed5>
1800072c7:     	leaq	0x1(%rax), %rcx
1800072cb:     	callq	*0x2f7f(%rip)           # 0x18000a250
1800072d1:     	movq	%rax, %rdi
1800072d4:     	testq	%rax, %rax
1800072d7:     	jne	0x1800072ec <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4d7c>
1800072d9:     	callq	*0x2e61(%rip)           # 0x18000a140
1800072df:     	movq	0x30(%rsp), %rdi
1800072e4:     	xorl	%eax, %eax
1800072e6:     	addq	$0x20, %rsp
1800072ea:     	popq	%rbx
1800072eb:     	retq
1800072ec:     	movq	%rbx, %rdx
1800072ef:     	movq	%rdi, %rcx
1800072f2:     	callq	0x18000961f <numba_list_iter_next+0xecf>
1800072f7:     	movq	%rdi, %rax
1800072fa:     	movq	0x30(%rsp), %rdi
1800072ff:     	addq	$0x20, %rsp
180007303:     	popq	%rbx
180007304:     	retq
180007305:     	int3
180007306:     	int3
180007307:     	int3
180007308:     	int3
180007309:     	int3
18000730a:     	int3
18000730b:     	int3
18000730c:     	int3
18000730d:     	int3
18000730e:     	int3
18000730f:     	int3
180007310:     	movq	0x18(%rcx), %rcx
180007314:     	movq	%rdx, %rax
180007317:     	testq	%rcx, %rcx
18000731a:     	je	0x180007322 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4db2>
18000731c:     	movq	%r8, %rdx
18000731f:     	jmpq	*%rax
180007322:     	xorl	%eax, %eax
180007324:     	retq
180007325:     	int3
180007326:     	int3
180007327:     	int3
180007328:     	int3
180007329:     	int3
18000732a:     	int3
18000732b:     	int3
18000732c:     	int3
18000732d:     	int3
18000732e:     	int3
18000732f:     	int3
180007330:     	movq	%rbx, 0x8(%rsp)
180007335:     	pushq	%rdi
180007336:     	subq	$0x20, %rsp
18000733a:     	movq	0x28(%rcx), %rax
18000733e:     	xorl	%edi, %edi
180007340:     	movq	%rcx, %rbx
180007343:     	testq	%rax, %rax
180007346:     	je	0x180007352 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4de2>
180007348:     	addq	$0x38, %rcx
18000734c:     	callq	*%rax
18000734e:     	movq	%rdi, 0x28(%rbx)
180007352:     	movq	0x18(%rbx), %rcx
180007356:     	testq	%rcx, %rcx
180007359:     	je	0x180007372 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4e02>
18000735b:     	movq	%rdi, 0x18(%rbx)
18000735f:     	movl	(%rcx), %eax
180007361:     	testl	%eax, %eax
180007363:     	js	0x180007372 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4e02>
180007365:     	subl	$0x1, %eax
180007368:     	movl	%eax, (%rcx)
18000736a:     	jne	0x180007372 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4e02>
18000736c:     	callq	*0x2e56(%rip)           # 0x18000a1c8
180007372:     	movq	%rdi, 0x20(%rbx)
180007376:     	xorl	%eax, %eax
180007378:     	movq	0x30(%rsp), %rbx
18000737d:     	addq	$0x20, %rsp
180007381:     	popq	%rdi
180007382:     	retq
180007383:     	int3
180007384:     	int3
180007385:     	int3
180007386:     	int3
180007387:     	int3
180007388:     	int3
180007389:     	int3
18000738a:     	int3
18000738b:     	int3
18000738c:     	int3
18000738d:     	int3
18000738e:     	int3
18000738f:     	int3
180007390:     	pushq	%rbx
180007392:     	subq	$0x20, %rsp
180007396:     	movq	%rcx, %rbx
180007399:     	callq	*0x2e79(%rip)           # 0x18000a218
18000739f:     	cmpq	$0x0, 0x30(%rbx)
1800073a4:     	je	0x1800073af <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4e3f>
1800073a6:     	movq	%rbx, %rcx
1800073a9:     	callq	*0x2dd9(%rip)           # 0x18000a188
1800073af:     	callq	*0x2d53(%rip)           # 0x18000a108
1800073b5:     	testl	%eax, %eax
1800073b7:     	jne	0x1800073c8 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4e58>
1800073b9:     	movq	0x28(%rbx), %rax
1800073bd:     	testq	%rax, %rax
1800073c0:     	je	0x1800073c8 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4e58>
1800073c2:     	leaq	0x38(%rbx), %rcx
1800073c6:     	callq	*%rax
1800073c8:     	movq	0x18(%rbx), %rcx
1800073cc:     	testq	%rcx, %rcx
1800073cf:     	je	0x1800073e4 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4e74>
1800073d1:     	movl	(%rcx), %eax
1800073d3:     	testl	%eax, %eax
1800073d5:     	js	0x1800073e4 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4e74>
1800073d7:     	subl	$0x1, %eax
1800073da:     	movl	%eax, (%rcx)
1800073dc:     	jne	0x1800073e4 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4e74>
1800073de:     	callq	*0x2de4(%rip)           # 0x18000a1c8
1800073e4:     	movq	0x8(%rbx), %rax
1800073e8:     	movq	%rbx, %rcx
1800073eb:     	addq	$0x20, %rsp
1800073ef:     	popq	%rbx
1800073f0:     	jmpq	*0x140(%rax)
1800073f7:     	int3
1800073f8:     	int3
1800073f9:     	int3
1800073fa:     	int3
1800073fb:     	int3
1800073fc:     	int3
1800073fd:     	int3
1800073fe:     	int3
1800073ff:     	int3
180007400:     	pushq	%rdi
180007402:     	subq	$0x20, %rsp
180007406:     	cmpq	$0x0, 0x20(%rcx)
18000740b:     	movq	%rcx, %rdi
18000740e:     	jne	0x18000742f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4ebf>
180007410:     	movq	0x2e99(%rip), %rcx      # 0x18000a2b0
180007417:     	leaq	0x3db2(%rip), %rdx      # 0x18000b1d0
18000741e:     	movq	(%rcx), %rcx
180007421:     	callq	*0x2e81(%rip)           # 0x18000a2a8
180007427:     	xorl	%eax, %eax
180007429:     	addq	$0x20, %rsp
18000742d:     	popq	%rdi
18000742e:     	retq
18000742f:     	movq	%rdi, %rdx
180007432:     	movq	%rbx, 0x30(%rsp)
180007437:     	movl	$0x1, %ecx
18000743c:     	callq	*0x2ec6(%rip)           # 0x18000a308
180007442:     	movq	%rax, %rbx
180007445:     	testq	%rax, %rax
180007448:     	jne	0x180007455 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4ee5>
18000744a:     	movq	0x30(%rsp), %rbx
18000744f:     	addq	$0x20, %rsp
180007453:     	popq	%rdi
180007454:     	retq
180007455:     	xorl	%r8d, %r8d
180007458:     	movq	%rbx, %rdx
18000745b:     	movq	%rdi, %rcx
18000745e:     	callq	*0x20(%rdi)
180007461:     	movl	(%rbx), %ecx
180007463:     	movq	%rax, %rdi
180007466:     	testl	%ecx, %ecx
180007468:     	js	0x18000747a <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4f0a>
18000746a:     	subl	$0x1, %ecx
18000746d:     	movl	%ecx, (%rbx)
18000746f:     	jne	0x18000747a <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4f0a>
180007471:     	movq	%rbx, %rcx
180007474:     	callq	*0x2d4e(%rip)           # 0x18000a1c8
18000747a:     	movq	0x30(%rsp), %rbx
18000747f:     	movq	%rdi, %rax
180007482:     	addq	$0x20, %rsp
180007486:     	popq	%rdi
180007487:     	retq
180007488:     	int3
180007489:     	int3
18000748a:     	int3
18000748b:     	int3
18000748c:     	int3
18000748d:     	int3
18000748e:     	int3
18000748f:     	int3
180007490:     	movq	%rbx, 0x8(%rsp)
180007495:     	pushq	%rdi
180007496:     	subq	$0x20, %rsp
18000749a:     	movq	%r8, %rbx
18000749d:     	callq	*0x2c4d(%rip)           # 0x18000a0f0
1800074a3:     	movl	(%rbx), %ecx
1800074a5:     	movl	%eax, %edi
1800074a7:     	testl	%ecx, %ecx
1800074a9:     	js	0x1800074bb <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4f4b>
1800074ab:     	subl	$0x1, %ecx
1800074ae:     	movl	%ecx, (%rbx)
1800074b0:     	jne	0x1800074bb <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4f4b>
1800074b2:     	movq	%rbx, %rcx
1800074b5:     	callq	*0x2d0d(%rip)           # 0x18000a1c8
1800074bb:     	movl	%edi, %ecx
1800074bd:     	movq	0x30(%rsp), %rbx
1800074c2:     	addq	$0x20, %rsp
1800074c6:     	popq	%rdi
1800074c7:     	jmpq	*0x2d42(%rip)           # 0x18000a210
1800074ce:     	int3
1800074cf:     	int3
1800074d0:     	movq	%rbx, 0x8(%rsp)
1800074d5:     	pushq	%rdi
1800074d6:     	subq	$0x20, %rsp
1800074da:     	movl	(%rdx), %eax
1800074dc:     	movq	%rdx, %rbx
1800074df:     	movq	%rcx, %rdi
1800074e2:     	cmpl	$0xc0000000, %eax       # imm = 0xC0000000
1800074e7:     	jae	0x1800074ed <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4f7d>
1800074e9:     	incl	%eax
1800074eb:     	movl	%eax, (%rdx)
1800074ed:     	movl	$0x30, %ecx
1800074f2:     	callq	*0xa770(%rip)           # 0x180011c68
1800074f8:     	cmpb	$0x0, 0xa741(%rip)      # 0x180011c40
1800074ff:     	je	0x180007509 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4f99>
180007501:     	lock
180007502:     	incq	0xa73f(%rip)            # 0x180011c48
180007509:     	testq	%rax, %rax
18000750c:     	je	0x180007543 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4fd3>
18000750e:     	movl	$0x1, %ecx
180007513:     	leaq	-0x8a(%rip), %rdx       # 0x180007490 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4f20>
18000751a:     	xchgq	%rcx, (%rax)
18000751d:     	xorl	%ecx, %ecx
18000751f:     	movq	%rdx, 0x8(%rax)
180007523:     	movq	%rcx, 0x20(%rax)
180007527:     	movq	%rcx, 0x28(%rax)
18000752b:     	movq	%rbx, 0x10(%rax)
18000752f:     	movq	%rdi, 0x18(%rax)
180007533:     	cmpb	%cl, 0xa707(%rip)       # 0x180011c40
180007539:     	je	0x180007543 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4fd3>
18000753b:     	lock
18000753c:     	incq	0xa715(%rip)            # 0x180011c58
180007543:     	movq	0x30(%rsp), %rbx
180007548:     	addq	$0x20, %rsp
18000754c:     	popq	%rdi
18000754d:     	retq
18000754e:     	int3
18000754f:     	int3
180007550:     	movq	%rbx, 0x8(%rsp)
180007555:     	pushq	%rdi
180007556:     	subq	$0x30, %rsp
18000755a:     	movq	%rcx, %rdi
18000755d:     	leaq	0xa45c(%rip), %r9       # 0x1800119c0
180007564:     	movq	%r8, %rax
180007567:     	leaq	0x58(%rsp), %rcx
18000756c:     	movq	%rdx, %r10
18000756f:     	movq	%rcx, 0x20(%rsp)
180007574:     	movq	%r10, %rcx
180007577:     	leaq	0x3c9a(%rip), %r8       # 0x18000b218
18000757e:     	movq	%rax, %rdx
180007581:     	callq	*0x2b71(%rip)           # 0x18000a0f8
180007587:     	testl	%eax, %eax
180007589:     	je	0x1800075b3 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5043>
18000758b:     	movq	0x58(%rsp), %rcx
180007590:     	callq	*0x2b4a(%rip)           # 0x18000a0e0
180007596:     	movq	%rax, %rbx
180007599:     	callq	*0x2d49(%rip)           # 0x18000a2e8
18000759f:     	testq	%rax, %rax
1800075a2:     	jne	0x1800075b3 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5043>
1800075a4:     	movq	%rbx, 0x10(%rdi)
1800075a8:     	movq	0x40(%rsp), %rbx
1800075ad:     	addq	$0x30, %rsp
1800075b1:     	popq	%rdi
1800075b2:     	retq
1800075b3:     	movq	0x40(%rsp), %rbx
1800075b8:     	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
1800075bd:     	addq	$0x30, %rsp
1800075c1:     	popq	%rdi
1800075c2:     	retq
1800075c3:     	int3
1800075c4:     	int3
1800075c5:     	int3
1800075c6:     	int3
1800075c7:     	int3
1800075c8:     	int3
1800075c9:     	int3
1800075ca:     	int3
1800075cb:     	int3
1800075cc:     	int3
1800075cd:     	int3
1800075ce:     	int3
1800075cf:     	int3
1800075d0:     	subq	$0x38, %rsp
1800075d4:     	movl	%r8d, %eax
1800075d7:     	movq	%rdx, %r10
1800075da:     	movq	0x10(%rcx), %r8
1800075de:     	movq	%rcx, %rdx
1800075e1:     	movl	%eax, 0x28(%rsp)
1800075e5:     	movq	%r10, %rcx
1800075e8:     	movl	$0x0, 0x20(%rsp)
1800075f0:     	movq	0x20(%r8), %r9
1800075f4:     	movq	0x18(%r8), %r8
1800075f8:     	callq	*0x2c0a(%rip)           # 0x18000a208
1800075fe:     	addq	$0x38, %rsp
180007602:     	retq
180007603:     	int3
180007604:     	int3
180007605:     	int3
180007606:     	int3
180007607:     	int3
180007608:     	int3
180007609:     	int3
18000760a:     	int3
18000760b:     	int3
18000760c:     	int3
18000760d:     	int3
18000760e:     	int3
18000760f:     	int3
180007610:     	movq	0x10(%rcx), %rax
180007614:     	lock
180007615:     	incq	(%rax)
180007618:     	movq	0x2cb1(%rip), %rax      # 0x18000a2d0
18000761f:     	retq
180007620:     	subq	$0x28, %rsp
180007624:     	movq	0x10(%rcx), %rcx
180007628:     	callq	0x180008920 <numba_list_iter_next+0x1d0>
18000762d:     	movq	0x2c9c(%rip), %rax      # 0x18000a2d0
180007634:     	addq	$0x28, %rsp
180007638:     	retq
180007639:     	int3
18000763a:     	int3
18000763b:     	int3
18000763c:     	int3
18000763d:     	int3
18000763e:     	int3
18000763f:     	int3
180007640:     	movq	0x10(%rcx), %rcx
180007644:     	movq	0x18(%rcx), %rcx
180007648:     	jmpq	*0x2b09(%rip)           # 0x18000a158
18000764f:     	int3
180007650:     	subq	$0x28, %rsp
180007654:     	movq	0x10(%rcx), %rax
180007658:     	testq	%rax, %rax
18000765b:     	je	0x180007679 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5109>
18000765d:     	cmpq	$0x0, 0x18(%rax)
180007662:     	je	0x180007679 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5109>
180007664:     	movq	(%rax), %rcx
180007667:     	nop
180007668:     	cmpq	$-0x1, %rcx
18000766c:     	je	0x180007679 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5109>
18000766e:     	addq	$0x28, %rsp
180007672:     	jmpq	*0x2aaf(%rip)           # 0x18000a128
180007679:     	movq	0x2b78(%rip), %rcx      # 0x18000a1f8
180007680:     	leaq	0x3b99(%rip), %rdx      # 0x18000b220
180007687:     	movq	(%rcx), %rcx
18000768a:     	callq	*0x2c18(%rip)           # 0x18000a2a8
180007690:     	xorl	%eax, %eax
180007692:     	addq	$0x28, %rsp
180007696:     	retq
180007697:     	int3
180007698:     	int3
180007699:     	int3
18000769a:     	int3
18000769b:     	int3
18000769c:     	int3
18000769d:     	int3
18000769e:     	int3
18000769f:     	int3
1800076a0:     	movq	0x10(%rcx), %rcx
1800076a4:     	movq	0x28(%rcx), %rcx
1800076a8:     	jmpq	*0x2aa9(%rip)           # 0x18000a158
1800076af:     	int3
1800076b0:     	movq	0x10(%rcx), %rax
1800076b4:     	movq	0x10(%rax), %rax
1800076b8:     	testq	%rax, %rax
1800076bb:     	je	0x1800076cc <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x515c>
1800076bd:     	movl	(%rax), %ecx
1800076bf:     	cmpl	$0xc0000000, %ecx       # imm = 0xC0000000
1800076c5:     	jae	0x1800076ea <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x517a>
1800076c7:     	incl	%ecx
1800076c9:     	movl	%ecx, (%rax)
1800076cb:     	retq
1800076cc:     	movq	0x2bfd(%rip), %rcx      # 0x18000a2d0
1800076d3:     	movl	(%rcx), %eax
1800076d5:     	cmpl	$0xc0000000, %eax       # imm = 0xC0000000
1800076da:     	jae	0x1800076e7 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5177>
1800076dc:     	incl	%eax
1800076de:     	movl	%eax, (%rcx)
1800076e0:     	movq	0x2be9(%rip), %rcx      # 0x18000a2d0
1800076e7:     	movq	%rcx, %rax
1800076ea:     	retq
1800076eb:     	int3
1800076ec:     	int3
1800076ed:     	int3
1800076ee:     	int3
1800076ef:     	int3
1800076f0:     	pushq	%rbx
1800076f2:     	subq	$0x20, %rsp
1800076f6:     	movq	%rcx, %rbx
1800076f9:     	movq	0x10(%rcx), %rcx
1800076fd:     	callq	0x180008920 <numba_list_iter_next+0x1d0>
180007702:     	movq	0x8(%rbx), %rax
180007706:     	movq	%rbx, %rcx
180007709:     	addq	$0x20, %rsp
18000770d:     	popq	%rbx
18000770e:     	jmpq	*0x140(%rax)
180007715:     	int3
180007716:     	int3
180007717:     	int3
180007718:     	int3
180007719:     	int3
18000771a:     	int3
18000771b:     	int3
18000771c:     	int3
18000771d:     	int3
18000771e:     	int3
18000771f:     	int3
180007720:     	movq	%rdi, 0x18(%rsp)
180007725:     	pushq	%r14
180007727:     	subq	$0x20, %rsp
18000772b:     	movq	0xa54e(%rip), %rax      # 0x180011c80
180007732:     	movq	%rdx, %r14
180007735:     	movq	%rcx, %rdi
180007738:     	movq	0x8(%rcx), %rcx
18000773c:     	movq	0x10(%rax), %rdx
180007740:     	cmpq	%rdx, %rcx
180007743:     	je	0x180007760 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x51f0>
180007745:     	callq	*0x2a8d(%rip)           # 0x18000a1d8
18000774b:     	testl	%eax, %eax
18000774d:     	jne	0x180007760 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x51f0>
18000774f:     	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
180007754:     	movq	0x40(%rsp), %rdi
180007759:     	addq	$0x20, %rsp
18000775d:     	popq	%r14
18000775f:     	retq
180007760:     	movq	%rbx, 0x30(%rsp)
180007765:     	movq	%rdi, %rdx
180007768:     	movq	0x10(%rdi), %rbx
18000776c:     	movq	%rbx, %rcx
18000776f:     	movq	%rsi, 0x38(%rsp)
180007774:     	movl	0x18(%rdi), %esi
180007777:     	callq	0x1800074d0 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4f60>
18000777c:     	movq	%rax, (%r14)
18000777f:     	movq	0xa4fa(%rip), %rax      # 0x180011c80
180007786:     	movq	%rbx, 0x20(%r14)
18000778a:     	movl	0x18(%rdi), %edx
18000778d:     	movq	0x20(%rdi), %rcx
180007791:     	callq	*0x4f0(%rax)
180007797:     	cmpl	$0x12, 0xa4ee(%rip)     # 0x180011c8c
18000779e:     	movq	0x30(%rsp), %rbx
1800077a3:     	movq	%rax, 0x10(%r14)
1800077a7:     	movq	0x38(%rdi), %rax
1800077ab:     	jl	0x1800077b3 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5243>
1800077ad:     	movq	0x28(%rax), %rax
1800077b1:     	jmp	0x1800077b7 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5247>
1800077b3:     	movslq	0x20(%rax), %rax
1800077b7:     	xorl	%r8d, %r8d
1800077ba:     	movq	%rax, 0x18(%r14)
1800077be:     	movq	%rdi, 0x8(%r14)
1800077c2:     	leaq	0x28(%r14), %rax
1800077c6:     	testl	%esi, %esi
1800077c8:     	jle	0x18000780b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x529b>
1800077ca:     	nopw	(%rax,%rax)
1800077d0:     	movq	0x20(%rdi), %rcx
1800077d4:     	movq	(%rcx,%r8,8), %rdx
1800077d8:     	incl	%r8d
1800077db:     	movq	%rdx, (%rax)
1800077de:     	addq	$0x8, %rax
1800077e2:     	cmpl	%esi, %r8d
1800077e5:     	jl	0x1800077d0 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5260>
1800077e7:     	xorl	%r8d, %r8d
1800077ea:     	nopw	(%rax,%rax)
1800077f0:     	movq	0x28(%rdi), %rcx
1800077f4:     	leaq	0x8(%rax), %rax
1800077f8:     	movslq	%r8d, %rdx
1800077fb:     	incl	%r8d
1800077fe:     	movq	(%rcx,%rdx,8), %rdx
180007802:     	movq	%rdx, -0x8(%rax)
180007806:     	cmpl	%esi, %r8d
180007809:     	jl	0x1800077f0 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5280>
18000780b:     	movq	0x38(%rsp), %rsi
180007810:     	xorl	%eax, %eax
180007812:     	movq	0x40(%rsp), %rdi
180007817:     	addq	$0x20, %rsp
18000781b:     	popq	%r14
18000781d:     	retq
18000781e:     	int3
18000781f:     	int3
180007820:     	pushq	%rbx
180007822:     	pushq	%rbp
180007823:     	pushq	%rsi
180007824:     	pushq	%rdi
180007825:     	subq	$0x28, %rsp
180007829:     	cmpq	$0x0, 0xa467(%rip)      # 0x180011c98
180007831:     	movq	%rcx, %rbp
180007834:     	movslq	0x8(%rdx), %rdi
180007838:     	movq	(%rdx), %rsi
18000783b:     	jne	0x180007893 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5323>
18000783d:     	leaq	0x38e4(%rip), %rcx      # 0x18000b128
180007844:     	callq	*0x29ee(%rip)           # 0x18000a238
18000784a:     	movq	%rax, %rbx
18000784d:     	testq	%rax, %rax
180007850:     	je	0x18000791a <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x53aa>
180007856:     	leaq	0x38d3(%rip), %rdx      # 0x18000b130
18000785d:     	movq	%rax, %rcx
180007860:     	callq	*0x2902(%rip)           # 0x18000a168
180007866:     	movl	(%rbx), %edx
180007868:     	movq	%rax, 0xa429(%rip)      # 0x180011c98
18000786f:     	testl	%edx, %edx
180007871:     	js	0x18000788a <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x531a>
180007873:     	subl	$0x1, %edx
180007876:     	movl	%edx, (%rbx)
180007878:     	jne	0x18000788a <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x531a>
18000787a:     	movq	%rbx, %rcx
18000787d:     	callq	*0x2945(%rip)           # 0x18000a1c8
180007883:     	movq	0xa40e(%rip), %rax      # 0x180011c98
18000788a:     	testq	%rax, %rax
18000788d:     	je	0x18000791a <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x53aa>
180007893:     	movq	%rdi, %rdx
180007896:     	movq	%rsi, %rcx
180007899:     	callq	*0x2a19(%rip)           # 0x18000a2b8
18000789f:     	movq	%rax, %rdi
1800078a2:     	testq	%rax, %rax
1800078a5:     	je	0x18000791a <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x53aa>
1800078a7:     	movq	0xa3ea(%rip), %rcx      # 0x180011c98
1800078ae:     	xorl	%r8d, %r8d
1800078b1:     	movq	%rax, %rdx
1800078b4:     	callq	*0x28de(%rip)           # 0x18000a198
1800078ba:     	movl	(%rdi), %ecx
1800078bc:     	movq	%rax, %rbx
1800078bf:     	testl	%ecx, %ecx
1800078c1:     	js	0x1800078d3 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5363>
1800078c3:     	subl	$0x1, %ecx
1800078c6:     	movl	%ecx, (%rdi)
1800078c8:     	jne	0x1800078d3 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5363>
1800078ca:     	movq	%rdi, %rcx
1800078cd:     	callq	*0x28f5(%rip)           # 0x18000a1c8
1800078d3:     	testq	%rbx, %rbx
1800078d6:     	je	0x18000791a <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x53aa>
1800078d8:     	movq	0x8(%rbx), %r8
1800078dc:     	testl	$0x2000000, 0xa8(%r8)   # imm = 0x2000000
1800078e7:     	jne	0x180007925 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x53b5>
1800078e9:     	movq	0x29b0(%rip), %rcx      # 0x18000a2a0
1800078f0:     	leaq	0x3a31(%rip), %rdx      # 0x18000b328
1800078f7:     	movq	0x18(%r8), %r8
1800078fb:     	movq	(%rcx), %rcx
1800078fe:     	callq	*0x28ec(%rip)           # 0x18000a1f0
180007904:     	movl	(%rbx), %eax
180007906:     	testl	%eax, %eax
180007908:     	js	0x18000791a <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x53aa>
18000790a:     	subl	$0x1, %eax
18000790d:     	movl	%eax, (%rbx)
18000790f:     	jne	0x18000791a <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x53aa>
180007911:     	movq	%rbx, %rcx
180007914:     	callq	*0x28ae(%rip)           # 0x18000a1c8
18000791a:     	xorl	%eax, %eax
18000791c:     	addq	$0x28, %rsp
180007920:     	popq	%rdi
180007921:     	popq	%rsi
180007922:     	popq	%rbp
180007923:     	popq	%rbx
180007924:     	retq
180007925:     	xorl	%r8d, %r8d
180007928:     	leaq	0x9a11(%rip), %rcx      # 0x180011340
18000792f:     	xorl	%edx, %edx
180007931:     	callq	*0x2911(%rip)           # 0x18000a248
180007937:     	movq	%rax, %rdi
18000793a:     	testq	%rax, %rax
18000793d:     	je	0x180007904 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5394>
18000793f:     	movq	%rbp, %rcx
180007942:     	movq	%rbx, 0x18(%rax)
180007946:     	callq	*0x2874(%rip)           # 0x18000a1c0
18000794c:     	movq	%rax, 0x10(%rdi)
180007950:     	movq	%rax, %rcx
180007953:     	testq	%rax, %rax
180007956:     	jne	0x18000796a <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x53fa>
180007958:     	movl	(%rdi), %eax
18000795a:     	testl	%eax, %eax
18000795c:     	js	0x18000791a <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x53aa>
18000795e:     	subl	$0x1, %eax
180007961:     	movl	%eax, (%rdi)
180007963:     	jne	0x18000791a <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x53aa>
180007965:     	movq	%rdi, %rcx
180007968:     	jmp	0x180007914 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x53a4>
18000796a:     	movl	(%rax), %eax
18000796c:     	cmpl	$0xc0000000, %eax       # imm = 0xC0000000
180007971:     	jae	0x180007977 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5407>
180007973:     	incl	%eax
180007975:     	movl	%eax, (%rcx)
180007977:     	movq	%rdi, %rax
18000797a:     	addq	$0x28, %rsp
18000797e:     	popq	%rdi
18000797f:     	popq	%rsi
180007980:     	popq	%rbp
180007981:     	popq	%rbx
180007982:     	retq
180007983:     	int3
180007984:     	int3
180007985:     	int3
180007986:     	int3
180007987:     	int3
180007988:     	int3
180007989:     	int3
18000798a:     	int3
18000798b:     	int3
18000798c:     	int3
18000798d:     	int3
18000798e:     	int3
18000798f:     	int3
180007990:     	movq	%r9, 0x20(%rsp)
180007995:     	movq	%r8, 0x18(%rsp)
18000799a:     	movq	%rdx, 0x10(%rsp)
18000799f:     	movq	%rcx, 0x8(%rsp)
1800079a4:     	pushq	%rbx
1800079a5:     	pushq	%rbp
1800079a6:     	pushq	%rsi
1800079a7:     	pushq	%rdi
1800079a8:     	pushq	%r12
1800079aa:     	pushq	%r13
1800079ac:     	pushq	%r14
1800079ae:     	pushq	%r15
1800079b0:     	subq	$0x68, %rsp
1800079b4:     	movq	%rcx, %r14
1800079b7:     	movq	%r9, %r15
1800079ba:     	leaq	0x341f(%rip), %rcx      # 0x18000ade0
1800079c1:     	movq	%r8, %r13
1800079c4:     	movq	%rdx, %rsi
1800079c7:     	callq	*0x286b(%rip)           # 0x18000a238
1800079cd:     	movq	%rax, %rdi
1800079d0:     	testq	%rax, %rax
1800079d3:     	jne	0x180007a0c <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x549c>
1800079d5:     	movq	0x275c(%rip), %rcx      # 0x18000a138
1800079dc:     	movq	(%rcx), %rcx
1800079df:     	callq	*0x27cb(%rip)           # 0x18000a1b0
1800079e5:     	testl	%eax, %eax
1800079e7:     	je	0x180007b07 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5597>
1800079ed:     	callq	*0x28cd(%rip)           # 0x18000a2c0
1800079f3:     	leaq	0x3406(%rip), %rcx      # 0x18000ae00
1800079fa:     	callq	*0x2838(%rip)           # 0x18000a238
180007a00:     	movq	%rax, %rdi
180007a03:     	testq	%rax, %rax
180007a06:     	je	0x180007b07 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5597>
180007a0c:     	leaq	0x340d(%rip), %rdx      # 0x18000ae20
180007a13:     	movq	%rdi, %rcx
180007a16:     	callq	*0x274c(%rip)           # 0x18000a168
180007a1c:     	movl	(%rdi), %ecx
180007a1e:     	movq	%rax, %rbx
180007a21:     	testl	%ecx, %ecx
180007a23:     	js	0x180007a35 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x54c5>
180007a25:     	subl	$0x1, %ecx
180007a28:     	movl	%ecx, (%rdi)
180007a2a:     	jne	0x180007a35 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x54c5>
180007a2c:     	movq	%rdi, %rcx
180007a2f:     	callq	*0x2793(%rip)           # 0x18000a1c8
180007a35:     	testq	%rbx, %rbx
180007a38:     	je	0x180007b07 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5597>
180007a3e:     	movq	0x26bb(%rip), %rax      # 0x18000a100
180007a45:     	cmpq	%rax, 0x8(%rbx)
180007a49:     	je	0x180007a85 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5515>
180007a4b:     	movq	0x285e(%rip), %rcx      # 0x18000a2b0
180007a52:     	leaq	0x33d7(%rip), %rdx      # 0x18000ae30
180007a59:     	movq	(%rcx), %rcx
180007a5c:     	callq	*0x2846(%rip)           # 0x18000a2a8
180007a62:     	movl	(%rbx), %eax
180007a64:     	testl	%eax, %eax
180007a66:     	js	0x180007b07 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5597>
180007a6c:     	subl	$0x1, %eax
180007a6f:     	movl	%eax, (%rbx)
180007a71:     	jne	0x180007b07 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5597>
180007a77:     	movq	%rbx, %rcx
180007a7a:     	callq	*0x2748(%rip)           # 0x18000a1c8
180007a80:     	jmp	0x180007b07 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5597>
180007a85:     	xorl	%edx, %edx
180007a87:     	movq	%rbx, %rcx
180007a8a:     	callq	*0x2718(%rip)           # 0x18000a1a8
180007a90:     	movl	(%rbx), %ecx
180007a92:     	movq	%rax, 0xa1e7(%rip)      # 0x180011c80
180007a99:     	testl	%ecx, %ecx
180007a9b:     	js	0x180007ab4 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5544>
180007a9d:     	subl	$0x1, %ecx
180007aa0:     	movl	%ecx, (%rbx)
180007aa2:     	jne	0x180007ab4 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5544>
180007aa4:     	movq	%rbx, %rcx
180007aa7:     	callq	*0x271b(%rip)           # 0x18000a1c8
180007aad:     	movq	0xa1cc(%rip), %rax      # 0x180011c80
180007ab4:     	testq	%rax, %rax
180007ab7:     	jne	0x180007ad2 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5562>
180007ab9:     	leaq	0x3398(%rip), %rdx      # 0x18000ae58
180007ac0:     	movq	0x27e9(%rip), %rcx      # 0x18000a2b0
180007ac7:     	movq	(%rcx), %rcx
180007aca:     	callq	*0x27d8(%rip)           # 0x18000a2a8
180007ad0:     	jmp	0x180007b07 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5597>
180007ad2:     	callq	*(%rax)
180007ad4:     	cmpl	$0x2000000, %eax        # imm = 0x2000000
180007ad9:     	jbe	0x180007b3a <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x55ca>
180007adb:     	movq	0x27ce(%rip), %rax      # 0x18000a2b0
180007ae2:     	movq	(%rax), %rbx
180007ae5:     	movq	0xa194(%rip), %rax      # 0x180011c80
180007aec:     	callq	*(%rax)
180007aee:     	movl	$0x2000000, %r8d        # imm = 0x2000000
180007af4:     	leaq	0x3385(%rip), %rdx      # 0x18000ae80
180007afb:     	movl	%eax, %r9d
180007afe:     	movq	%rbx, %rcx
180007b01:     	callq	*0x26e9(%rip)           # 0x18000a1f0
180007b07:     	callq	*0x260b(%rip)           # 0x18000a118
180007b0d:     	movq	0x25fc(%rip), %rcx      # 0x18000a110
180007b14:     	leaq	0x358d(%rip), %rdx      # 0x18000b0a8
180007b1b:     	movq	(%rcx), %rcx
180007b1e:     	callq	*0x2784(%rip)           # 0x18000a2a8
180007b24:     	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
180007b29:     	addq	$0x68, %rsp
180007b2d:     	popq	%r15
180007b2f:     	popq	%r14
180007b31:     	popq	%r13
180007b33:     	popq	%r12
180007b35:     	popq	%rdi
180007b36:     	popq	%rsi
180007b37:     	popq	%rbp
180007b38:     	popq	%rbx
180007b39:     	retq
180007b3a:     	movq	0xa13f(%rip), %rax      # 0x180011c80
180007b41:     	callq	*0x698(%rax)
180007b47:     	movl	%eax, 0xa13f(%rip)      # 0x180011c8c
180007b4d:     	cmpl	$0x10, %eax
180007b50:     	jge	0x180007b6e <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x55fe>
180007b52:     	movq	0x2757(%rip), %rcx      # 0x18000a2b0
180007b59:     	leaq	0x3370(%rip), %rdx      # 0x18000aed0
180007b60:     	movl	%eax, %r9d
180007b63:     	movl	$0x10, %r8d
180007b69:     	movq	(%rcx), %rcx
180007b6c:     	jmp	0x180007b01 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5591>
180007b6e:     	movq	0xa10b(%rip), %rax      # 0x180011c80
180007b75:     	callq	*0x690(%rax)
180007b7b:     	testl	%eax, %eax
180007b7d:     	jne	0x180007b8b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x561b>
180007b7f:     	leaq	0x349a(%rip), %rdx      # 0x18000b020
180007b86:     	jmp	0x180007ac0 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5550>
180007b8b:     	cmpl	$0x1, %eax
180007b8e:     	je	0x180007b9c <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x562c>
180007b90:     	leaq	0x34b9(%rip), %rdx      # 0x18000b050
180007b97:     	jmp	0x180007ac0 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5550>
180007b9c:     	leaq	0x9c7d(%rip), %rcx      # 0x180011820
180007ba3:     	callq	*0x25c7(%rip)           # 0x18000a170
180007ba9:     	testl	%eax, %eax
180007bab:     	jne	0x180007b24 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x55b4>
180007bb1:     	leaq	0x9788(%rip), %rcx      # 0x180011340
180007bb8:     	callq	*0x25b2(%rip)           # 0x18000a170
180007bbe:     	testl	%eax, %eax
180007bc0:     	jne	0x180007b24 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x55b4>
180007bc6:     	leaq	0x9ab3(%rip), %rcx      # 0x180011680
180007bcd:     	callq	*0x259d(%rip)           # 0x18000a170
180007bd3:     	testl	%eax, %eax
180007bd5:     	jne	0x180007b24 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x55b4>
180007bdb:     	xorl	%ebx, %ebx
180007bdd:     	cmpl	%ebx, 0xa0a5(%rip)      # 0x180011c88
180007be3:     	jne	0x180007c26 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x56b6>
180007be5:     	movq	%gs:0x58, %rax
180007bee:     	movl	0xa0ac(%rip), %ecx      # 0x180011ca0
180007bf4:     	movl	$0x1, 0xa08a(%rip)      # 0x180011c88
180007bfe:     	movq	(%rax,%rcx,8), %rdx
180007c02:     	movl	$0x10, %eax
180007c07:     	movl	%ebx, 0x9d0(%rax,%rdx)
180007c0e:     	movl	$0x9f0, %eax            # imm = 0x9F0
180007c13:     	movl	%ebx, 0x9d0(%rax,%rdx)
180007c1a:     	movl	$0x13d0, %eax           # imm = 0x13D0
180007c1f:     	movl	%ebx, 0x9d0(%rax,%rdx)
180007c26:     	movl	%ebx, 0xa00c(%rip)      # 0x180011c38
180007c2c:     	movq	%rbx, %rax
180007c2f:     	movb	%bl, 0xa00b(%rip)       # 0x180011c40
180007c35:     	movq	%rbx, %rcx
180007c38:     	xchgq	%rax, 0xa009(%rip)      # 0x180011c48
180007c3f:     	xchgq	%rcx, 0xa00a(%rip)      # 0x180011c50
180007c46:     	movq	%rbx, %rax
180007c49:     	movq	%rbx, %rcx
180007c4c:     	xchgq	%rax, 0xa005(%rip)      # 0x180011c58
180007c53:     	xchgq	%rcx, 0xa006(%rip)      # 0x180011c60
180007c5a:     	movq	0x23ff(%rip), %rax      # 0x18000a060
180007c61:     	leaq	0x9878(%rip), %rcx      # 0x1800114e0
180007c68:     	movq	%rax, 0x9ff9(%rip)      # 0x180011c68
180007c6f:     	movq	0x23fa(%rip), %rax      # 0x18000a070
180007c76:     	movq	%rax, 0x9ff3(%rip)      # 0x180011c70
180007c7d:     	movq	0x23e4(%rip), %rax      # 0x18000a068
180007c84:     	movq	%rax, 0x9fed(%rip)      # 0x180011c78
180007c8b:     	movq	0x25b6(%rip), %rax      # 0x18000a248
180007c92:     	movq	%rax, 0x997f(%rip)      # 0x180011618
180007c99:     	callq	*0x24d1(%rip)           # 0x18000a170
180007c9f:     	testl	%eax, %eax
180007ca1:     	jne	0x180007b24 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x55b4>
180007ca7:     	leaq	0x3512(%rip), %rdx      # 0x18000b1c0
180007cae:     	movq	%r14, %rcx
180007cb1:     	callq	*0x24b1(%rip)           # 0x18000a168
180007cb7:     	movq	%rax, 0x28(%rsp)
180007cbc:     	movq	%rax, %rdi
180007cbf:     	testq	%rax, %rax
180007cc2:     	je	0x180007b24 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x55b4>
180007cc8:     	leaq	0x368a(%rip), %rcx      # 0x18000b359
180007ccf:     	callq	*0x25ab(%rip)           # 0x18000a280
180007cd5:     	movq	%rax, 0x20(%rsp)
180007cda:     	movq	%rax, %r12
180007cdd:     	testq	%rax, %rax
180007ce0:     	je	0x180008024 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5ab4>
180007ce6:     	movl	%ebx, %ebp
180007ce8:     	cmpq	%rbx, (%rsi)
180007ceb:     	je	0x180007e94 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5924>
180007cf1:     	movslq	%ebp, %rbx
180007cf4:     	leaq	0x30(%rsp), %rdx
180007cf9:     	movq	%r14, %rcx
180007cfc:     	leaq	(%rbx,%rbx,4), %rax
180007d00:     	movups	(%r13,%rax,8), %xmm0
180007d06:     	movups	0x10(%r13,%rax,8), %xmm1
180007d0c:     	movaps	%xmm0, 0x30(%rsp)
180007d11:     	movsd	0x20(%r13,%rax,8), %xmm0
180007d18:     	movsd	%xmm0, 0x50(%rsp)
180007d1e:     	movaps	%xmm1, 0x40(%rsp)
180007d23:     	callq	0x180007820 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x52b0>
180007d28:     	movq	%rax, %r14
180007d2b:     	testq	%rax, %rax
180007d2e:     	je	0x180008000 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5a90>
180007d34:     	movq	(%rsi), %rcx
180007d37:     	callq	*0x2543(%rip)           # 0x18000a280
180007d3d:     	movq	%rax, %r13
180007d40:     	testq	%rax, %rax
180007d43:     	je	0x180008047 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5ad7>
180007d49:     	movq	(%r15,%rbx,8), %rcx
180007d4d:     	xorl	%edx, %edx
180007d4f:     	movq	%r14, (%rcx)
180007d52:     	leaq	0x9ac7(%rip), %rcx      # 0x180011820
180007d59:     	movq	0x8(%rsi), %r12
180007d5d:     	callq	*0x23ed(%rip)           # 0x18000a150
180007d63:     	movq	%rax, %rbx
180007d66:     	testq	%rax, %rax
180007d69:     	je	0x180007de6 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5876>
180007d6b:     	movq	%r13, %rcx
180007d6e:     	callq	*0x240c(%rip)           # 0x18000a180
180007d74:     	movq	%rax, %rdi
180007d77:     	testq	%rax, %rax
180007d7a:     	je	0x180007d9c <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x582c>
180007d7c:     	movq	%rax, %rcx
180007d7f:     	callq	0x180009625 <numba_list_iter_next+0xed5>
180007d84:     	leaq	0x1(%rax), %rcx
180007d88:     	callq	*0x24c2(%rip)           # 0x18000a250
180007d8e:     	movq	%rax, %rsi
180007d91:     	testq	%rax, %rax
180007d94:     	jne	0x180007da4 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5834>
180007d96:     	callq	*0x23a4(%rip)           # 0x18000a140
180007d9c:     	xorl	%eax, %eax
180007d9e:     	movq	%rax, 0x20(%rbx)
180007da2:     	jmp	0x180007dd5 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5865>
180007da4:     	movq	%rdi, %rdx
180007da7:     	movq	%rsi, %rcx
180007daa:     	callq	0x18000961f <numba_list_iter_next+0xecf>
180007daf:     	movq	0x20(%rsp), %rcx
180007db4:     	movq	%rsi, 0x20(%rbx)
180007db8:     	movq	%r12, 0x28(%rbx)
180007dbc:     	movl	$0x3, 0x30(%rbx)
180007dc3:     	callq	0x1800072a0 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x4d30>
180007dc8:     	movq	%rax, 0x38(%rbx)
180007dcc:     	testq	%rax, %rax
180007dcf:     	jne	0x180007f40 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x59d0>
180007dd5:     	movl	(%rbx), %eax
180007dd7:     	testl	%eax, %eax
180007dd9:     	js	0x180007de6 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5876>
180007ddb:     	subl	$0x1, %eax
180007dde:     	movl	%eax, (%rbx)
180007de0:     	je	0x180007f8d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5a1d>
180007de6:     	xorl	%edi, %edi
180007de8:     	movl	(%r14), %eax
180007deb:     	testl	%eax, %eax
180007ded:     	js	0x180007e00 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5890>
180007def:     	subl	$0x1, %eax
180007df2:     	movl	%eax, (%r14)
180007df5:     	jne	0x180007e00 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5890>
180007df7:     	movq	%r14, %rcx
180007dfa:     	callq	*0x23c8(%rip)           # 0x18000a1c8
180007e00:     	movl	(%r13), %eax
180007e04:     	testl	%eax, %eax
180007e06:     	js	0x180007e1a <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x58aa>
180007e08:     	subl	$0x1, %eax
180007e0b:     	movl	%eax, (%r13)
180007e0f:     	jne	0x180007e1a <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x58aa>
180007e11:     	movq	%r13, %rcx
180007e14:     	callq	*0x23ae(%rip)           # 0x18000a1c8
180007e1a:     	testq	%rdi, %rdi
180007e1d:     	je	0x180008000 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5a90>
180007e23:     	movq	0xb8(%rsp), %rsi
180007e2b:     	movq	%rdi, %r8
180007e2e:     	movq	0xb0(%rsp), %r14
180007e36:     	movq	%r14, %rcx
180007e39:     	movq	(%rsi), %rdx
180007e3c:     	callq	*0x23de(%rip)           # 0x18000a220
180007e42:     	movl	(%rdi), %ecx
180007e44:     	testl	%eax, %eax
180007e46:     	jne	0x180007fea <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5a7a>
180007e4c:     	testl	%ecx, %ecx
180007e4e:     	js	0x180007e62 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x58f2>
180007e50:     	leal	-0x1(%rcx), %eax
180007e53:     	movl	%eax, (%rdi)
180007e55:     	testl	%eax, %eax
180007e57:     	jne	0x180007e62 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x58f2>
180007e59:     	movq	%rdi, %rcx
180007e5c:     	callq	*0x2366(%rip)           # 0x18000a1c8
180007e62:     	movq	0xc8(%rsp), %r15
180007e6a:     	addq	$0x20, %rsi
180007e6e:     	movq	0xc0(%rsp), %r13
180007e76:     	incl	%ebp
180007e78:     	movq	%rsi, 0xb8(%rsp)
180007e80:     	cmpq	$0x0, (%rsi)
180007e84:     	jne	0x180007cf1 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5781>
180007e8a:     	movq	0x20(%rsp), %r12
180007e8f:     	movq	0x28(%rsp), %rdi
180007e94:     	movslq	%ebp, %rax
180007e97:     	cmpq	$0x0, (%r15,%rax,8)
180007e9c:     	je	0x180007f09 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5999>
180007e9e:     	nop
180007ea0:     	movslq	%ebp, %rbx
180007ea3:     	leaq	0x30(%rsp), %rdx
180007ea8:     	movq	%r14, %rcx
180007eab:     	leaq	(%rbx,%rbx,4), %rax
180007eaf:     	movups	(%r13,%rax,8), %xmm0
180007eb5:     	movups	0x10(%r13,%rax,8), %xmm1
180007ebb:     	movaps	%xmm0, 0x30(%rsp)
180007ec0:     	movsd	0x20(%r13,%rax,8), %xmm0
180007ec7:     	movsd	%xmm0, 0x50(%rsp)
180007ecd:     	movaps	%xmm1, 0x40(%rsp)
180007ed2:     	callq	0x180007820 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x52b0>
180007ed7:     	testq	%rax, %rax
180007eda:     	je	0x180008005 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5a95>
180007ee0:     	movq	(%r15,%rbx,8), %rcx
180007ee4:     	movq	%rax, (%rcx)
180007ee7:     	movl	(%rax), %ecx
180007ee9:     	testl	%ecx, %ecx
180007eeb:     	js	0x180007efd <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x598d>
180007eed:     	subl	$0x1, %ecx
180007ef0:     	movl	%ecx, (%rax)
180007ef2:     	jne	0x180007efd <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x598d>
180007ef4:     	movq	%rax, %rcx
180007ef7:     	callq	*0x22cb(%rip)           # 0x18000a1c8
180007efd:     	incl	%ebp
180007eff:     	movslq	%ebp, %rax
180007f02:     	cmpq	$0x0, (%r15,%rax,8)
180007f07:     	jne	0x180007ea0 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5930>
180007f09:     	movl	(%r12), %eax
180007f0d:     	testl	%eax, %eax
180007f0f:     	js	0x180007f23 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x59b3>
180007f11:     	subl	$0x1, %eax
180007f14:     	movl	%eax, (%r12)
180007f18:     	jne	0x180007f23 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x59b3>
180007f1a:     	movq	%r12, %rcx
180007f1d:     	callq	*0x22a5(%rip)           # 0x18000a1c8
180007f23:     	movl	(%rdi), %eax
180007f25:     	testl	%eax, %eax
180007f27:     	js	0x180007f39 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x59c9>
180007f29:     	subl	$0x1, %eax
180007f2c:     	movl	%eax, (%rdi)
180007f2e:     	jne	0x180007f39 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x59c9>
180007f30:     	movq	%rdi, %rcx
180007f33:     	callq	*0x228f(%rip)           # 0x18000a1c8
180007f39:     	xorl	%eax, %eax
180007f3b:     	jmp	0x180007b29 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x55b9>
180007f40:     	movl	(%r14), %eax
180007f43:     	cmpl	$0xc0000000, %eax       # imm = 0xC0000000
180007f48:     	jae	0x180007f4f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x59df>
180007f4a:     	incl	%eax
180007f4c:     	movl	%eax, (%r14)
180007f4f:     	movq	0xb0(%rsp), %rcx
180007f57:     	leaq	0x3262(%rip), %rdx      # 0x18000b1c0
180007f5e:     	movq	%r14, 0x18(%rbx)
180007f62:     	movq	$0x0, 0x40(%rbx)
180007f6a:     	callq	*0x21f8(%rip)           # 0x18000a168
180007f70:     	movq	%rax, %rsi
180007f73:     	testq	%rax, %rax
180007f76:     	jne	0x180007f9b <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5a2b>
180007f78:     	movl	(%rbx), %eax
180007f7a:     	testl	%eax, %eax
180007f7c:     	js	0x180007de6 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5876>
180007f82:     	subl	$0x1, %eax
180007f85:     	movl	%eax, (%rbx)
180007f87:     	jne	0x180007de6 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5876>
180007f8d:     	movq	%rbx, %rcx
180007f90:     	callq	*0x2232(%rip)           # 0x18000a1c8
180007f96:     	jmp	0x180007de6 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5876>
180007f9b:     	xorl	%r9d, %r9d
180007f9e:     	leaq	0x20(%rbx), %rcx
180007fa2:     	movq	%rsi, %r8
180007fa5:     	movq	%rbx, %rdx
180007fa8:     	callq	*0x219a(%rip)           # 0x18000a148
180007fae:     	movq	%rax, %rdi
180007fb1:     	movl	(%rbx), %eax
180007fb3:     	testl	%eax, %eax
180007fb5:     	js	0x180007fc7 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5a57>
180007fb7:     	subl	$0x1, %eax
180007fba:     	movl	%eax, (%rbx)
180007fbc:     	jne	0x180007fc7 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5a57>
180007fbe:     	movq	%rbx, %rcx
180007fc1:     	callq	*0x2201(%rip)           # 0x18000a1c8
180007fc7:     	movl	(%rsi), %eax
180007fc9:     	testl	%eax, %eax
180007fcb:     	js	0x180007de8 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5878>
180007fd1:     	subl	$0x1, %eax
180007fd4:     	movl	%eax, (%rsi)
180007fd6:     	jne	0x180007de8 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5878>
180007fdc:     	movq	%rsi, %rcx
180007fdf:     	callq	*0x21e3(%rip)           # 0x18000a1c8
180007fe5:     	jmp	0x180007de8 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5878>
180007fea:     	testl	%ecx, %ecx
180007fec:     	js	0x180008000 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5a90>
180007fee:     	leal	-0x1(%rcx), %eax
180007ff1:     	movl	%eax, (%rdi)
180007ff3:     	testl	%eax, %eax
180007ff5:     	jne	0x180008000 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5a90>
180007ff7:     	movq	%rdi, %rcx
180007ffa:     	callq	*0x21c8(%rip)           # 0x18000a1c8
180008000:     	movq	0x20(%rsp), %r12
180008005:     	movl	(%r12), %eax
180008009:     	testl	%eax, %eax
18000800b:     	js	0x18000801f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5aaf>
18000800d:     	subl	$0x1, %eax
180008010:     	movl	%eax, (%r12)
180008014:     	jne	0x18000801f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5aaf>
180008016:     	movq	%r12, %rcx
180008019:     	callq	*0x21a9(%rip)           # 0x18000a1c8
18000801f:     	movq	0x28(%rsp), %rdi
180008024:     	movl	(%rdi), %eax
180008026:     	testl	%eax, %eax
180008028:     	js	0x180007b24 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x55b4>
18000802e:     	subl	$0x1, %eax
180008031:     	movl	%eax, (%rdi)
180008033:     	jne	0x180007b24 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x55b4>
180008039:     	movq	%rdi, %rcx
18000803c:     	callq	*0x2186(%rip)           # 0x18000a1c8
180008042:     	jmp	0x180007b24 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x55b4>
180008047:     	movl	(%r14), %eax
18000804a:     	testl	%eax, %eax
18000804c:     	js	0x180008000 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5a90>
18000804e:     	subl	$0x1, %eax
180008051:     	movl	%eax, (%r14)
180008054:     	jne	0x180008000 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5a90>
180008056:     	movq	%r14, %rcx
180008059:     	jmp	0x180007ffa <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5a8a>
18000805b:     	int3
18000805c:     	int3
18000805d:     	int3
18000805e:     	int3
18000805f:     	int3
180008060:     	leaq	0x9ca1(%rip), %rax      # 0x180011d08
180008067:     	retq
180008068:     	int3
180008069:     	int3
18000806a:     	int3
18000806b:     	int3
18000806c:     	int3
18000806d:     	int3
18000806e:     	int3
18000806f:     	int3

0000000180008070 <numba_list_set_method_table>:
180008070:     	movups	(%rdx), %xmm0
180008073:     	movups	%xmm0, 0x20(%rcx)
180008077:     	retq
180008078:     	int3
180008079:     	int3
18000807a:     	int3
18000807b:     	int3
18000807c:     	int3
18000807d:     	int3
18000807e:     	int3
18000807f:     	int3

0000000180008080 <numba_list_new>:
180008080:     	pushq	%rbx
180008082:     	pushq	%rbp
180008083:     	pushq	%rsi
180008084:     	pushq	%rdi
180008085:     	subq	$0x28, %rsp
180008089:     	movq	%rcx, %rsi
18000808c:     	movq	%r8, %rdi
18000808f:     	movl	$0x38, %ecx
180008094:     	movq	%rdx, %rbp
180008097:     	callq	*0x1fc3(%rip)           # 0x18000a060
18000809d:     	movq	%rax, %rbx
1800080a0:     	testq	%rax, %rax
1800080a3:     	je	0x18000810d <numba_list_new+0x8d>
1800080a5:     	movq	$0x0, (%rax)
1800080ac:     	xorps	%xmm0, %xmm0
1800080af:     	movq	%rbp, 0x8(%rax)
1800080b3:     	movq	%rdi, 0x10(%rax)
1800080b7:     	movl	$0x1, 0x18(%rax)
1800080be:     	movups	%xmm0, 0x20(%rax)
1800080c2:     	testq	%rdi, %rdi
1800080c5:     	je	0x18000811b <numba_list_new+0x9b>
1800080c7:     	imulq	%rbp, %rdi
1800080cb:     	movl	$0x8, %ecx
1800080d0:     	movq	%rdi, %rax
1800080d3:     	cqto
1800080d5:     	andl	$0x7, %edx
1800080d8:     	addq	%rdx, %rax
1800080db:     	andl	$0x7, %eax
1800080de:     	subq	%rdx, %rax
1800080e1:     	subq	%rax, %rcx
1800080e4:     	movq	%rcx, %rax
1800080e7:     	cqto
1800080e9:     	andl	$0x7, %edx
1800080ec:     	leaq	(%rdx,%rax), %rcx
1800080f0:     	andl	$0x7, %ecx
1800080f3:     	subq	%rdx, %rcx
1800080f6:     	addq	%rdi, %rcx
1800080f9:     	callq	*0x1f61(%rip)           # 0x18000a060
1800080ff:     	testq	%rax, %rax
180008102:     	jne	0x18000811d <numba_list_new+0x9d>
180008104:     	movq	%rbx, %rcx
180008107:     	callq	*0x1f5b(%rip)           # 0x18000a068
18000810d:     	movl	$0xfffffffe, %eax       # imm = 0xFFFFFFFE
180008112:     	addq	$0x28, %rsp
180008116:     	popq	%rdi
180008117:     	popq	%rsi
180008118:     	popq	%rbp
180008119:     	popq	%rbx
18000811a:     	retq
18000811b:     	xorl	%eax, %eax
18000811d:     	movq	%rax, 0x30(%rbx)
180008121:     	xorl	%eax, %eax
180008123:     	movq	%rbx, (%rsi)
180008126:     	addq	$0x28, %rsp
18000812a:     	popq	%rdi
18000812b:     	popq	%rsi
18000812c:     	popq	%rbp
18000812d:     	popq	%rbx
18000812e:     	retq
18000812f:     	int3

0000000180008130 <numba_list_free>:
180008130:     	pushq	%rbx
180008132:     	subq	$0x20, %rsp
180008136:     	cmpq	$0x0, 0x28(%rcx)
18000813b:     	movq	%rcx, %rbx
18000813e:     	je	0x180008174 <numba_list_free+0x44>
180008140:     	movq	%rdi, 0x30(%rsp)
180008145:     	xorl	%edi, %edi
180008147:     	cmpq	%rdi, (%rcx)
18000814a:     	jle	0x18000816f <numba_list_free+0x3f>
18000814c:     	nopl	(%rax)
180008150:     	movq	0x28(%rbx), %rax
180008154:     	testq	%rax, %rax
180008157:     	je	0x180008167 <numba_list_free+0x37>
180008159:     	movq	%rdi, %rcx
18000815c:     	imulq	0x8(%rbx), %rcx
180008161:     	addq	0x30(%rbx), %rcx
180008165:     	callq	*%rax
180008167:     	incq	%rdi
18000816a:     	cmpq	(%rbx), %rdi
18000816d:     	jl	0x180008150 <numba_list_free+0x20>
18000816f:     	movq	0x30(%rsp), %rdi
180008174:     	movq	0x30(%rbx), %rcx
180008178:     	testq	%rcx, %rcx
18000817b:     	je	0x180008183 <numba_list_free+0x53>
18000817d:     	callq	*0x1ee5(%rip)           # 0x18000a068
180008183:     	movq	%rbx, %rcx
180008186:     	addq	$0x20, %rsp
18000818a:     	popq	%rbx
18000818b:     	jmpq	*0x1ed6(%rip)           # 0x18000a068
180008192:     	int3
180008193:     	int3
180008194:     	int3
180008195:     	int3
180008196:     	int3
180008197:     	int3
180008198:     	int3
180008199:     	int3
18000819a:     	int3
18000819b:     	int3
18000819c:     	int3
18000819d:     	int3
18000819e:     	int3
18000819f:     	int3

00000001800081a0 <numba_list_base_ptr>:
1800081a0:     	movq	0x30(%rcx), %rax
1800081a4:     	retq
1800081a5:     	int3
1800081a6:     	int3
1800081a7:     	int3
1800081a8:     	int3
1800081a9:     	int3
1800081aa:     	int3
1800081ab:     	int3
1800081ac:     	int3
1800081ad:     	int3
1800081ae:     	int3
1800081af:     	int3

00000001800081b0 <numba_list_size_address>:
1800081b0:     	movq	%rcx, %rax
1800081b3:     	retq
1800081b4:     	int3
1800081b5:     	int3
1800081b6:     	int3
1800081b7:     	int3
1800081b8:     	int3
1800081b9:     	int3
1800081ba:     	int3
1800081bb:     	int3
1800081bc:     	int3
1800081bd:     	int3
1800081be:     	int3
1800081bf:     	int3

00000001800081c0 <numba_list_length>:
1800081c0:     	movq	(%rcx), %rax
1800081c3:     	retq
1800081c4:     	int3
1800081c5:     	int3
1800081c6:     	int3
1800081c7:     	int3
1800081c8:     	int3
1800081c9:     	int3
1800081ca:     	int3
1800081cb:     	int3
1800081cc:     	int3
1800081cd:     	int3
1800081ce:     	int3
1800081cf:     	int3

00000001800081d0 <numba_list_allocated>:
1800081d0:     	movq	0x10(%rcx), %rax
1800081d4:     	retq
1800081d5:     	int3
1800081d6:     	int3
1800081d7:     	int3
1800081d8:     	int3
1800081d9:     	int3
1800081da:     	int3
1800081db:     	int3
1800081dc:     	int3
1800081dd:     	int3
1800081de:     	int3
1800081df:     	int3

00000001800081e0 <numba_list_is_mutable>:
1800081e0:     	movl	0x18(%rcx), %eax
1800081e3:     	retq
1800081e4:     	int3
1800081e5:     	int3
1800081e6:     	int3
1800081e7:     	int3
1800081e8:     	int3
1800081e9:     	int3
1800081ea:     	int3
1800081eb:     	int3
1800081ec:     	int3
1800081ed:     	int3
1800081ee:     	int3
1800081ef:     	int3

00000001800081f0 <numba_list_set_is_mutable>:
1800081f0:     	movl	%edx, 0x18(%rcx)
1800081f3:     	retq
1800081f4:     	int3
1800081f5:     	int3
1800081f6:     	int3
1800081f7:     	int3
1800081f8:     	int3
1800081f9:     	int3
1800081fa:     	int3
1800081fb:     	int3
1800081fc:     	int3
1800081fd:     	int3
1800081fe:     	int3
1800081ff:     	int3

0000000180008200 <numba_list_setitem>:
180008200:     	movq	%rbx, 0x10(%rsp)
180008205:     	pushq	%rsi
180008206:     	subq	$0x20, %rsp
18000820a:     	cmpl	$0x0, 0x18(%rcx)
18000820e:     	movq	%r8, %rsi
180008211:     	movq	%rcx, %rbx
180008214:     	jne	0x180008226 <numba_list_setitem+0x26>
180008216:     	movl	$0xfffffffb, %eax       # imm = 0xFFFFFFFB
18000821b:     	movq	0x38(%rsp), %rbx
180008220:     	addq	$0x20, %rsp
180008224:     	popq	%rsi
180008225:     	retq
180008226:     	cmpq	(%rcx), %rdx
180008229:     	jb	0x18000823b <numba_list_setitem+0x3b>
18000822b:     	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
180008230:     	movq	0x38(%rsp), %rbx
180008235:     	addq	$0x20, %rsp
180008239:     	popq	%rsi
18000823a:     	retq
18000823b:     	imulq	0x8(%rcx), %rdx
180008240:     	movq	0x28(%rcx), %rax
180008244:     	movq	%rdi, 0x30(%rsp)
180008249:     	movq	0x30(%rcx), %rdi
18000824d:     	addq	%rdx, %rdi
180008250:     	testq	%rax, %rax
180008253:     	je	0x18000825a <numba_list_setitem+0x5a>
180008255:     	movq	%rdi, %rcx
180008258:     	callq	*%rax
18000825a:     	movq	0x8(%rbx), %r8
18000825e:     	movq	%rsi, %rdx
180008261:     	movq	%rdi, %rcx
180008264:     	callq	0x180009613 <numba_list_iter_next+0xec3>
180008269:     	movq	0x20(%rbx), %rax
18000826d:     	testq	%rax, %rax
180008270:     	je	0x180008277 <numba_list_setitem+0x77>
180008272:     	movq	%rdi, %rcx
180008275:     	callq	*%rax
180008277:     	movq	0x30(%rsp), %rdi
18000827c:     	xorl	%eax, %eax
18000827e:     	movq	0x38(%rsp), %rbx
180008283:     	addq	$0x20, %rsp
180008287:     	popq	%rsi
180008288:     	retq
180008289:     	int3
18000828a:     	int3
18000828b:     	int3
18000828c:     	int3
18000828d:     	int3
18000828e:     	int3
18000828f:     	int3

0000000180008290 <numba_list_getitem>:
180008290:     	subq	$0x28, %rsp
180008294:     	movq	%r8, %r9
180008297:     	movq	%rdx, %rax
18000829a:     	cmpq	(%rcx), %rdx
18000829d:     	jb	0x1800082a9 <numba_list_getitem+0x19>
18000829f:     	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
1800082a4:     	addq	$0x28, %rsp
1800082a8:     	retq
1800082a9:     	movq	0x8(%rcx), %r8
1800082ad:     	movq	%r8, %rdx
1800082b0:     	imulq	%rax, %rdx
1800082b4:     	addq	0x30(%rcx), %rdx
1800082b8:     	movq	%r9, %rcx
1800082bb:     	callq	0x180009613 <numba_list_iter_next+0xec3>
1800082c0:     	xorl	%eax, %eax
1800082c2:     	addq	$0x28, %rsp
1800082c6:     	retq
1800082c7:     	int3
1800082c8:     	int3
1800082c9:     	int3
1800082ca:     	int3
1800082cb:     	int3
1800082cc:     	int3
1800082cd:     	int3
1800082ce:     	int3
1800082cf:     	int3

00000001800082d0 <numba_list_append>:
1800082d0:     	movq	%rbx, 0x10(%rsp)
1800082d5:     	pushq	%rsi
1800082d6:     	subq	$0x20, %rsp
1800082da:     	cmpl	$0x0, 0x18(%rcx)
1800082de:     	movq	%rdx, %rsi
1800082e1:     	movq	%rcx, %rbx
1800082e4:     	jne	0x1800082f6 <numba_list_append+0x26>
1800082e6:     	movl	$0xfffffffb, %eax       # imm = 0xFFFFFFFB
1800082eb:     	movq	0x38(%rsp), %rbx
1800082f0:     	addq	$0x20, %rsp
1800082f4:     	popq	%rsi
1800082f5:     	retq
1800082f6:     	movq	(%rcx), %rdx
1800082f9:     	incq	%rdx
1800082fc:     	callq	0x180008350 <numba_list_resize>
180008301:     	testl	%eax, %eax
180008303:     	js	0x18000833c <numba_list_append+0x6c>
180008305:     	movq	0x8(%rbx), %r8
180008309:     	movq	%rsi, %rdx
18000830c:     	movq	%rdi, 0x30(%rsp)
180008311:     	movq	(%rbx), %rdi
180008314:     	decq	%rdi
180008317:     	imulq	%r8, %rdi
18000831b:     	addq	0x30(%rbx), %rdi
18000831f:     	movq	%rdi, %rcx
180008322:     	callq	0x180009613 <numba_list_iter_next+0xec3>
180008327:     	movq	0x20(%rbx), %rax
18000832b:     	testq	%rax, %rax
18000832e:     	je	0x180008335 <numba_list_append+0x65>
180008330:     	movq	%rdi, %rcx
180008333:     	callq	*%rax
180008335:     	movq	0x30(%rsp), %rdi
18000833a:     	xorl	%eax, %eax
18000833c:     	movq	0x38(%rsp), %rbx
180008341:     	addq	$0x20, %rsp
180008345:     	popq	%rsi
180008346:     	retq
180008347:     	int3
180008348:     	int3
180008349:     	int3
18000834a:     	int3
18000834b:     	int3
18000834c:     	int3
18000834d:     	int3
18000834e:     	int3
18000834f:     	int3

0000000180008350 <numba_list_resize>:
180008350:     	movq	%rsi, 0x18(%rsp)
180008355:     	pushq	%rdi
180008356:     	subq	$0x20, %rsp
18000835a:     	cmpl	$0x0, 0x18(%rcx)
18000835e:     	movq	%rdx, %rsi
180008361:     	movq	%rcx, %rdi
180008364:     	jne	0x180008376 <numba_list_resize+0x26>
180008366:     	movl	$0xfffffffb, %eax       # imm = 0xFFFFFFFB
18000836b:     	movq	0x40(%rsp), %rsi
180008370:     	addq	$0x20, %rsp
180008374:     	popq	%rdi
180008375:     	retq
180008376:     	movq	0x10(%rcx), %rax
18000837a:     	cmpq	%rsi, %rax
18000837d:     	jl	0x180008397 <numba_list_resize+0x47>
18000837f:     	sarq	%rax
180008382:     	cmpq	%rax, %rsi
180008385:     	jl	0x180008397 <numba_list_resize+0x47>
180008387:     	movq	%rsi, (%rcx)
18000838a:     	xorl	%eax, %eax
18000838c:     	movq	0x40(%rsp), %rsi
180008391:     	addq	$0x20, %rsp
180008395:     	popq	%rdi
180008396:     	retq
180008397:     	cmpq	$0x9, %rsi
18000839b:     	movq	%rbp, 0x38(%rsp)
1800083a0:     	movl	$0x3, %ecx
1800083a5:     	movl	$0x6, %eax
1800083aa:     	cmovll	%ecx, %eax
1800083ad:     	movq	%rsi, %r8
1800083b0:     	movq	0x8(%rdi), %rcx
1800083b4:     	addq	%rsi, %rax
1800083b7:     	sarq	$0x3, %r8
1800083bb:     	xorl	%edx, %edx
1800083bd:     	addq	%rax, %r8
1800083c0:     	movabsq	$0x7fffffffffffffff, %rax # imm = 0x7FFFFFFFFFFFFFFF
1800083ca:     	divq	%rcx
1800083cd:     	cmpq	%rax, %r8
1800083d0:     	ja	0x18000844b <numba_list_resize+0xfb>
1800083d2:     	xorl	%ebp, %ebp
1800083d4:     	movq	%rbx, 0x30(%rsp)
1800083d9:     	testq	%rsi, %rsi
1800083dc:     	cmovneq	%r8, %rbp
1800083e0:     	movq	%rbp, %rbx
1800083e3:     	imulq	%rcx, %rbx
1800083e7:     	movl	$0x8, %ecx
1800083ec:     	movq	%rbx, %rax
1800083ef:     	cqto
1800083f1:     	andl	$0x7, %edx
1800083f4:     	addq	%rdx, %rax
1800083f7:     	andl	$0x7, %eax
1800083fa:     	subq	%rdx, %rax
1800083fd:     	subq	%rax, %rcx
180008400:     	movq	%rcx, %rax
180008403:     	movq	0x30(%rdi), %rcx
180008407:     	cqto
180008409:     	andl	$0x7, %edx
18000840c:     	addq	%rdx, %rax
18000840f:     	andl	$0x7, %eax
180008412:     	subq	%rdx, %rax
180008415:     	leaq	(%rbx,%rax), %rdx
180008419:     	callq	*0x1c51(%rip)           # 0x18000a070
18000841f:     	testq	%rbx, %rbx
180008422:     	movq	0x30(%rsp), %rbx
180008427:     	je	0x18000842e <numba_list_resize+0xde>
180008429:     	testq	%rax, %rax
18000842c:     	je	0x18000844b <numba_list_resize+0xfb>
18000842e:     	movq	%rax, 0x30(%rdi)
180008432:     	xorl	%eax, %eax
180008434:     	movq	%rbp, 0x10(%rdi)
180008438:     	movq	0x38(%rsp), %rbp
18000843d:     	movq	%rsi, (%rdi)
180008440:     	movq	0x40(%rsp), %rsi
180008445:     	addq	$0x20, %rsp
180008449:     	popq	%rdi
18000844a:     	retq
18000844b:     	movq	0x38(%rsp), %rbp
180008450:     	movl	$0xfffffffe, %eax       # imm = 0xFFFFFFFE
180008455:     	movq	0x40(%rsp), %rsi
18000845a:     	addq	$0x20, %rsp
18000845e:     	popq	%rdi
18000845f:     	retq

0000000180008460 <numba_list_delitem>:
180008460:     	movq	%rbx, 0x10(%rsp)
180008465:     	pushq	%rdi
180008466:     	subq	$0x20, %rsp
18000846a:     	cmpl	$0x0, 0x18(%rcx)
18000846e:     	movq	%rdx, %rdi
180008471:     	movq	%rcx, %rbx
180008474:     	jne	0x180008486 <numba_list_delitem+0x26>
180008476:     	movl	$0xfffffffb, %eax       # imm = 0xFFFFFFFB
18000847b:     	movq	0x38(%rsp), %rbx
180008480:     	addq	$0x20, %rsp
180008484:     	popq	%rdi
180008485:     	retq
180008486:     	cmpq	(%rcx), %rdi
180008489:     	jb	0x18000849b <numba_list_delitem+0x3b>
18000848b:     	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
180008490:     	movq	0x38(%rsp), %rbx
180008495:     	addq	$0x20, %rsp
180008499:     	popq	%rdi
18000849a:     	retq
18000849b:     	movq	0x28(%rcx), %rax
18000849f:     	movq	%rsi, 0x30(%rsp)
1800084a4:     	movq	%rdi, %rsi
1800084a7:     	imulq	0x8(%rcx), %rsi
1800084ac:     	addq	0x30(%rcx), %rsi
1800084b0:     	testq	%rax, %rax
1800084b3:     	je	0x1800084ba <numba_list_delitem+0x5a>
1800084b5:     	movq	%rsi, %rcx
1800084b8:     	callq	*%rax
1800084ba:     	movq	(%rbx), %r8
1800084bd:     	leaq	-0x1(%r8), %rax
1800084c1:     	cmpq	%rax, %rdi
1800084c4:     	je	0x1800084e6 <numba_list_delitem+0x86>
1800084c6:     	subq	%rdi, %r8
1800084c9:     	leaq	0x1(%rdi), %rdx
1800084cd:     	imulq	0x8(%rbx), %rdx
1800084d2:     	decq	%r8
1800084d5:     	movq	%rsi, %rcx
1800084d8:     	imulq	0x8(%rbx), %r8
1800084dd:     	addq	0x30(%rbx), %rdx
1800084e1:     	callq	0x180009619 <numba_list_iter_next+0xec9>
1800084e6:     	movq	(%rbx), %rdx
1800084e9:     	movq	%rbx, %rcx
1800084ec:     	decq	%rdx
1800084ef:     	callq	0x180008350 <numba_list_resize>
1800084f4:     	movq	0x30(%rsp), %rsi
1800084f9:     	xorl	%ecx, %ecx
1800084fb:     	movq	0x38(%rsp), %rbx
180008500:     	testl	%eax, %eax
180008502:     	cmovsl	%eax, %ecx
180008505:     	movl	%ecx, %eax
180008507:     	addq	$0x20, %rsp
18000850b:     	popq	%rdi
18000850c:     	retq
18000850d:     	int3
18000850e:     	int3
18000850f:     	int3

0000000180008510 <numba_list_delete_slice>:
180008510:     	pushq	%rbx
180008512:     	pushq	%rbp
180008513:     	pushq	%rdi
180008514:     	pushq	%r15
180008516:     	subq	$0x38, %rsp
18000851a:     	cmpl	$0x0, 0x18(%rcx)
18000851e:     	movq	%r9, %rdi
180008521:     	movq	%r8, %rbp
180008524:     	movq	%rdx, %r15
180008527:     	movq	%rcx, %rbx
18000852a:     	jne	0x18000853b <numba_list_delete_slice+0x2b>
18000852c:     	movl	$0xfffffffb, %eax       # imm = 0xFFFFFFFB
180008531:     	addq	$0x38, %rsp
180008535:     	popq	%r15
180008537:     	popq	%rdi
180008538:     	popq	%rbp
180008539:     	popq	%rbx
18000853a:     	retq
18000853b:     	movq	%r13, 0x78(%rsp)
180008540:     	testq	%rdi, %rdi
180008543:     	jle	0x180008562 <numba_list_delete_slice+0x52>
180008545:     	cmpq	%r8, %r15
180008548:     	jge	0x180008701 <numba_list_delete_slice+0x1f1>
18000854e:     	movq	%r8, %rax
180008551:     	subq	%r15, %rax
180008554:     	decq	%rax
180008557:     	cqto
180008559:     	idivq	%rdi
18000855c:     	leal	0x1(%rax), %r13d
180008560:     	jmp	0x180008582 <numba_list_delete_slice+0x72>
180008562:     	cmpq	%r15, %r8
180008565:     	jge	0x180008701 <numba_list_delete_slice+0x1f1>
18000856b:     	movq	%r15, %rax
18000856e:     	movl	$0x1, %r13d
180008574:     	subq	%r8, %rax
180008577:     	decq	%rax
18000857a:     	cqto
18000857c:     	idivq	%rdi
18000857f:     	subl	%eax, %r13d
180008582:     	testl	%r13d, %r13d
180008585:     	jle	0x180008701 <numba_list_delete_slice+0x1f1>
18000858b:     	movq	%rsi, 0x68(%rsp)
180008590:     	movl	(%rcx), %esi
180008592:     	subl	%r13d, %esi
180008595:     	movl	%esi, 0x20(%rsp)
180008599:     	testq	%rdi, %rdi
18000859c:     	jns	0x1800085b7 <numba_list_delete_slice+0xa7>
18000859e:     	leaq	0x1(%r15), %rbp
1800085a2:     	leal	-0x1(%r13), %eax
1800085a6:     	movslq	%eax, %rcx
1800085a9:     	leaq	-0x1(%rbp), %r15
1800085ad:     	imulq	%rdi, %rcx
1800085b1:     	addq	%rcx, %r15
1800085b4:     	negq	%rdi
1800085b7:     	cmpq	$0x1, %rdi
1800085bb:     	jne	0x180008607 <numba_list_delete_slice+0xf7>
1800085bd:     	cmpq	$0x0, 0x28(%rbx)
1800085c2:     	je	0x1800085e9 <numba_list_delete_slice+0xd9>
1800085c4:     	movslq	%r15d, %rdi
1800085c7:     	cmpq	%rbp, %rdi
1800085ca:     	jge	0x1800085e9 <numba_list_delete_slice+0xd9>
1800085cc:     	nopl	(%rax)
1800085d0:     	movslq	%edi, %rcx
1800085d3:     	imulq	0x8(%rbx), %rcx
1800085d8:     	addq	0x30(%rbx), %rcx
1800085dc:     	callq	*0x28(%rbx)
1800085df:     	incl	%edi
1800085e1:     	movslq	%edi, %rax
1800085e4:     	cmpq	%rbp, %rax
1800085e7:     	jl	0x1800085d0 <numba_list_delete_slice+0xc0>
1800085e9:     	movq	0x8(%rbx), %rcx
1800085ed:     	movq	(%rbx), %r8
1800085f0:     	movq	%rcx, %rdx
1800085f3:     	subq	%rbp, %r8
1800085f6:     	imulq	%rcx, %r8
1800085fa:     	imulq	%rbp, %rdx
1800085fe:     	imulq	%r15, %rcx
180008602:     	jmp	0x1800086cc <numba_list_delete_slice+0x1bc>
180008607:     	movq	%r14, 0x30(%rsp)
18000860c:     	movq	%r15, %r14
18000860f:     	movl	$0x0, 0x60(%rsp)
180008617:     	cmpq	%rbp, %r15
18000861a:     	jge	0x180008699 <numba_list_delete_slice+0x189>
18000861c:     	movq	%r12, 0x70(%rsp)
180008621:     	movq	(%rbx), %rax
180008624:     	leaq	(%r14,%rdi), %r12
180008628:     	cmpq	%rax, %r12
18000862b:     	jl	0x180008638 <numba_list_delete_slice+0x128>
18000862d:     	movq	%r14, %rsi
180008630:     	notq	%rsi
180008633:     	addq	%rax, %rsi
180008636:     	jmp	0x18000863c <numba_list_delete_slice+0x12c>
180008638:     	leaq	-0x1(%rdi), %rsi
18000863c:     	movq	0x28(%rbx), %rax
180008640:     	testq	%rax, %rax
180008643:     	je	0x180008653 <numba_list_delete_slice+0x143>
180008645:     	movq	%r14, %rcx
180008648:     	imulq	0x8(%rbx), %rcx
18000864d:     	addq	0x30(%rbx), %rcx
180008651:     	callq	*%rax
180008653:     	movq	0x8(%rbx), %r9
180008657:     	leaq	0x1(%r14), %rdx
18000865b:     	movq	0x30(%rbx), %r10
18000865f:     	movq	%r9, %r8
180008662:     	imulq	%rsi, %r8
180008666:     	imulq	%r9, %rdx
18000866a:     	movslq	0x60(%rsp), %rsi
18000866f:     	subq	%rsi, %r14
180008672:     	imulq	%r9, %r14
180008676:     	addq	%r10, %rdx
180008679:     	leaq	(%r10,%r14), %rcx
18000867d:     	callq	0x180009619 <numba_list_iter_next+0xec9>
180008682:     	incl	%esi
180008684:     	movq	%r12, %r14
180008687:     	movl	%esi, 0x60(%rsp)
18000868b:     	cmpq	%rbp, %r12
18000868e:     	jl	0x180008621 <numba_list_delete_slice+0x111>
180008690:     	movq	0x70(%rsp), %r12
180008695:     	movl	0x20(%rsp), %esi
180008699:     	movq	(%rbx), %r8
18000869c:     	movq	0x30(%rsp), %r14
1800086a1:     	movslq	%r13d, %r10
1800086a4:     	movq	%r10, %rcx
1800086a7:     	imulq	%rdi, %rcx
1800086ab:     	addq	%r15, %rcx
1800086ae:     	cmpq	%r8, %rcx
1800086b1:     	jge	0x1800086d9 <numba_list_delete_slice+0x1c9>
1800086b3:     	movq	0x8(%rbx), %rax
1800086b7:     	subq	%rcx, %r8
1800086ba:     	movq	%rax, %rdx
1800086bd:     	imulq	%rcx, %rdx
1800086c1:     	imulq	%rax, %r8
1800086c5:     	subq	%r10, %rcx
1800086c8:     	imulq	%rax, %rcx
1800086cc:     	addq	0x30(%rbx), %rdx
1800086d0:     	addq	0x30(%rbx), %rcx
1800086d4:     	callq	0x180009619 <numba_list_iter_next+0xec9>
1800086d9:     	movslq	%esi, %rdx
1800086dc:     	movq	%rbx, %rcx
1800086df:     	callq	0x180008350 <numba_list_resize>
1800086e4:     	movq	0x68(%rsp), %rsi
1800086e9:     	xorl	%ecx, %ecx
1800086eb:     	movq	0x78(%rsp), %r13
1800086f0:     	testl	%eax, %eax
1800086f2:     	cmovsl	%eax, %ecx
1800086f5:     	movl	%ecx, %eax
1800086f7:     	addq	$0x38, %rsp
1800086fb:     	popq	%r15
1800086fd:     	popq	%rdi
1800086fe:     	popq	%rbp
1800086ff:     	popq	%rbx
180008700:     	retq
180008701:     	movq	0x78(%rsp), %r13
180008706:     	xorl	%eax, %eax
180008708:     	addq	$0x38, %rsp
18000870c:     	popq	%r15
18000870e:     	popq	%rdi
18000870f:     	popq	%rbp
180008710:     	popq	%rbx
180008711:     	retq
180008712:     	int3
180008713:     	int3
180008714:     	int3
180008715:     	int3
180008716:     	int3
180008717:     	int3
180008718:     	int3
180008719:     	int3
18000871a:     	int3
18000871b:     	int3
18000871c:     	int3
18000871d:     	int3
18000871e:     	int3
18000871f:     	int3

0000000180008720 <numba_list_iter_sizeof>:
180008720:     	movl	$0x18, %eax
180008725:     	retq
180008726:     	int3
180008727:     	int3
180008728:     	int3
180008729:     	int3
18000872a:     	int3
18000872b:     	int3
18000872c:     	int3
18000872d:     	int3
18000872e:     	int3
18000872f:     	int3

0000000180008730 <numba_list_iter>:
180008730:     	movq	%rdx, (%rcx)
180008733:     	movq	(%rdx), %rax
180008736:     	movq	%rax, 0x8(%rcx)
18000873a:     	movq	$0x0, 0x10(%rcx)
180008742:     	retq
180008743:     	int3
180008744:     	int3
180008745:     	int3
180008746:     	int3
180008747:     	int3
180008748:     	int3
180008749:     	int3
18000874a:     	int3
18000874b:     	int3
18000874c:     	int3
18000874d:     	int3
18000874e:     	int3
18000874f:     	int3

0000000180008750 <numba_list_iter_next>:
180008750:     	movq	(%rcx), %r8
180008753:     	movq	(%r8), %r9
180008756:     	cmpq	0x8(%rcx), %r9
18000875a:     	je	0x180008762 <numba_list_iter_next+0x12>
18000875c:     	movl	$0xfffffffd, %eax       # imm = 0xFFFFFFFD
180008761:     	retq
180008762:     	movq	0x10(%rcx), %rax
180008766:     	cmpq	%r9, %rax
180008769:     	jge	0x18000877e <numba_list_iter_next+0x2e>
18000876b:     	imulq	0x8(%r8), %rax
180008770:     	addq	0x30(%r8), %rax
180008774:     	movq	%rax, (%rdx)
180008777:     	incq	0x10(%rcx)
18000877b:     	xorl	%eax, %eax
18000877d:     	retq
18000877e:     	movl	$0xfffffffc, %eax       # imm = 0xFFFFFFFC
180008783:     	retq
180008784:     	int3
180008785:     	int3
180008786:     	int3
180008787:     	int3
180008788:     	int3
180008789:     	int3
18000878a:     	int3
18000878b:     	int3
18000878c:     	int3
18000878d:     	int3
18000878e:     	int3
18000878f:     	int3
180008790:     	pushq	%rbx
180008792:     	subq	$0x20, %rsp
180008796:     	movq	%rcx, %rbx
180008799:     	addq	$0x30, %rcx
18000879d:     	callq	*0x94c5(%rip)           # 0x180011c68
1800087a3:     	cmpb	$0x0, 0x9496(%rip)      # 0x180011c40
1800087aa:     	je	0x1800087b4 <numba_list_iter_next+0x64>
1800087ac:     	lock
1800087ad:     	incq	0x9494(%rip)            # 0x180011c48
1800087b4:     	testq	%rax, %rax
1800087b7:     	je	0x1800087f8 <numba_list_iter_next+0xa8>
1800087b9:     	leaq	0x30(%rax), %rdx
1800087bd:     	testq	%rdx, %rdx
1800087c0:     	je	0x1800087f8 <numba_list_iter_next+0xa8>
1800087c2:     	xorl	%r8d, %r8d
1800087c5:     	movl	$0x1, %ecx
1800087ca:     	xchgq	%rcx, (%rax)
1800087cd:     	movq	%r8, 0x8(%rax)
1800087d1:     	movq	%r8, 0x10(%rax)
1800087d5:     	movq	%rdx, 0x18(%rax)
1800087d9:     	movq	%rbx, 0x20(%rax)
1800087dd:     	movq	%r8, 0x28(%rax)
1800087e1:     	cmpb	%r8b, 0x9458(%rip)      # 0x180011c40
1800087e8:     	je	0x1800087fa <numba_list_iter_next+0xaa>
1800087ea:     	lock
1800087eb:     	incq	0x9466(%rip)            # 0x180011c58
1800087f2:     	addq	$0x20, %rsp
1800087f6:     	popq	%rbx
1800087f7:     	retq
1800087f8:     	xorl	%eax, %eax
1800087fa:     	addq	$0x20, %rsp
1800087fe:     	popq	%rbx
1800087ff:     	retq
180008800:     	movq	%rbx, 0x8(%rsp)
180008805:     	pushq	%rdi
180008806:     	subq	$0x20, %rsp
18000880a:     	movq	%rcx, %rdi
18000880d:     	movq	%rdx, %rbx
180008810:     	addq	$0x30, %rcx
180008814:     	testq	%rdx, %rdx
180008817:     	je	0x180008821 <numba_list_iter_next+0xd1>
180008819:     	movq	0x18(%rdx), %rdx
18000881d:     	callq	*(%rbx)
18000881f:     	jmp	0x180008827 <numba_list_iter_next+0xd7>
180008821:     	callq	*0x9441(%rip)           # 0x180011c68
180008827:     	cmpb	$0x0, 0x9412(%rip)      # 0x180011c40
18000882e:     	movq	%rax, %r8
180008831:     	je	0x18000883b <numba_list_iter_next+0xeb>
180008833:     	lock
180008834:     	incq	0x940d(%rip)            # 0x180011c48
18000883b:     	xorl	%edx, %edx
18000883d:     	leaq	0x30(%r8), %rax
180008841:     	testq	%r8, %r8
180008844:     	movl	%edx, %ecx
180008846:     	cmovneq	%rax, %rcx
18000884a:     	testq	%rcx, %rcx
18000884d:     	jne	0x18000885c <numba_list_iter_next+0x10c>
18000884f:     	xorl	%eax, %eax
180008851:     	movq	0x30(%rsp), %rbx
180008856:     	addq	$0x20, %rsp
18000885a:     	popq	%rdi
18000885b:     	retq
18000885c:     	movl	$0x1, %eax
180008861:     	xchgq	%rax, (%r8)
180008864:     	movq	%rdx, 0x8(%r8)
180008868:     	movq	%rdx, 0x10(%r8)
18000886c:     	movq	%rcx, 0x18(%r8)
180008870:     	movq	%rdi, 0x20(%r8)
180008874:     	movq	%rbx, 0x28(%r8)
180008878:     	cmpb	%dl, 0x93c2(%rip)       # 0x180011c40
18000887e:     	je	0x180008888 <numba_list_iter_next+0x138>
180008880:     	lock
180008881:     	incq	0x93d0(%rip)            # 0x180011c58
180008888:     	movq	0x30(%rsp), %rbx
18000888d:     	movq	%r8, %rax
180008890:     	addq	$0x20, %rsp
180008894:     	popq	%rdi
180008895:     	retq
180008896:     	int3
180008897:     	int3
180008898:     	int3
180008899:     	int3
18000889a:     	int3
18000889b:     	int3
18000889c:     	int3
18000889d:     	int3
18000889e:     	int3
18000889f:     	int3
1800088a0:     	lock
1800088a1:     	incq	(%rcx)
1800088a4:     	retq
1800088a5:     	int3
1800088a6:     	int3
1800088a7:     	int3
1800088a8:     	int3
1800088a9:     	int3
1800088aa:     	int3
1800088ab:     	int3
1800088ac:     	int3
1800088ad:     	int3
1800088ae:     	int3
1800088af:     	int3
1800088b0:     	pushq	%rbx
1800088b2:     	subq	$0x20, %rsp
1800088b6:     	movq	0x8(%rcx), %rax
1800088ba:     	movq	%rcx, %rbx
1800088bd:     	testq	%rax, %rax
1800088c0:     	je	0x1800088d9 <numba_list_iter_next+0x189>
1800088c2:     	cmpl	$0x0, 0x936f(%rip)      # 0x180011c38
1800088c9:     	jne	0x1800088d9 <numba_list_iter_next+0x189>
1800088cb:     	movq	0x10(%rcx), %r8
1800088cf:     	movq	0x20(%rcx), %rdx
1800088d3:     	movq	0x18(%rcx), %rcx
1800088d7:     	callq	*%rax
1800088d9:     	movq	0x28(%rbx), %rax
1800088dd:     	movq	%rbx, %rcx
1800088e0:     	testq	%rax, %rax
1800088e3:     	je	0x1800088ee <numba_list_iter_next+0x19e>
1800088e5:     	movq	0x18(%rax), %rdx
1800088e9:     	callq	*0x10(%rax)
1800088ec:     	jmp	0x1800088f4 <numba_list_iter_next+0x1a4>
1800088ee:     	callq	*0x9384(%rip)           # 0x180011c78
1800088f4:     	cmpb	$0x0, 0x9345(%rip)      # 0x180011c40
1800088fb:     	je	0x180008919 <numba_list_iter_next+0x1c9>
1800088fd:     	leaq	0x934c(%rip), %rax      # 0x180011c50
180008904:     	lock
180008905:     	incq	(%rax)
180008908:     	cmpb	$0x0, 0x9331(%rip)      # 0x180011c40
18000890f:     	je	0x180008919 <numba_list_iter_next+0x1c9>
180008911:     	lock
180008912:     	incq	0x9347(%rip)            # 0x180011c60
180008919:     	addq	$0x20, %rsp
18000891d:     	popq	%rbx
18000891e:     	retq
18000891f:     	int3
180008920:     	pushq	%rbx
180008922:     	subq	$0x20, %rsp
180008926:     	movq	%rcx, %rbx
180008929:     	movq	$-0x1, %rax
180008930:     	lock
180008931:     	xaddq	%rax, (%rcx)
180008935:     	cmpq	$0x1, %rax
180008939:     	jne	0x18000899b <numba_list_iter_next+0x24b>
18000893b:     	movq	0x8(%rcx), %rax
18000893f:     	testq	%rax, %rax
180008942:     	je	0x18000895b <numba_list_iter_next+0x20b>
180008944:     	cmpl	$0x0, 0x92ed(%rip)      # 0x180011c38
18000894b:     	jne	0x18000895b <numba_list_iter_next+0x20b>
18000894d:     	movq	0x10(%rcx), %r8
180008951:     	movq	0x20(%rcx), %rdx
180008955:     	movq	0x18(%rcx), %rcx
180008959:     	callq	*%rax
18000895b:     	movq	0x28(%rbx), %rax
18000895f:     	movq	%rbx, %rcx
180008962:     	testq	%rax, %rax
180008965:     	je	0x180008970 <numba_list_iter_next+0x220>
180008967:     	movq	0x18(%rax), %rdx
18000896b:     	callq	*0x10(%rax)
18000896e:     	jmp	0x180008976 <numba_list_iter_next+0x226>
180008970:     	callq	*0x9302(%rip)           # 0x180011c78
180008976:     	cmpb	$0x0, 0x92c3(%rip)      # 0x180011c40
18000897d:     	je	0x18000899b <numba_list_iter_next+0x24b>
18000897f:     	leaq	0x92ca(%rip), %rax      # 0x180011c50
180008986:     	lock
180008987:     	incq	(%rax)
18000898a:     	cmpb	$0x0, 0x92af(%rip)      # 0x180011c40
180008991:     	je	0x18000899b <numba_list_iter_next+0x24b>
180008993:     	lock
180008994:     	incq	0x92c5(%rip)            # 0x180011c60
18000899b:     	addq	$0x20, %rsp
18000899f:     	popq	%rbx
1800089a0:     	retq
1800089a1:     	int3
1800089a2:     	int3
1800089a3:     	int3
1800089a4:     	int3
1800089a5:     	int3
1800089a6:     	int3
1800089a7:     	int3
1800089a8:     	int3
1800089a9:     	int3
1800089aa:     	int3
1800089ab:     	int3
1800089ac:     	int3
1800089ad:     	int3
1800089ae:     	int3
1800089af:     	int3
1800089b0:     	movq	0x18(%rcx), %rax
1800089b4:     	retq
1800089b5:     	int3
1800089b6:     	int3
1800089b7:     	int3
1800089b8:     	int3
1800089b9:     	int3
1800089ba:     	int3
1800089bb:     	int3
1800089bc:     	int3
1800089bd:     	int3
1800089be:     	int3
1800089bf:     	int3
1800089c0:     	subq	$0x28, %rsp
1800089c4:     	callq	*0x92ae(%rip)           # 0x180011c78
1800089ca:     	cmpb	$0x0, 0x926f(%rip)      # 0x180011c40
1800089d1:     	je	0x1800089db <numba_list_iter_next+0x28b>
1800089d3:     	lock
1800089d4:     	incq	0x9275(%rip)            # 0x180011c50
1800089db:     	addq	$0x28, %rsp
1800089df:     	retq
1800089e0:     	jmpq	*%r8
1800089e3:     	int3
1800089e4:     	int3
1800089e5:     	int3
1800089e6:     	int3
1800089e7:     	int3
1800089e8:     	int3
1800089e9:     	int3
1800089ea:     	int3
1800089eb:     	int3
1800089ec:     	int3
1800089ed:     	int3
1800089ee:     	int3
1800089ef:     	int3
1800089f0:     	movq	%rbx, 0x8(%rsp)
1800089f5:     	pushq	%rdi
1800089f6:     	subq	$0x20, %rsp
1800089fa:     	movq	%rcx, %rdi
1800089fd:     	movq	%rdx, %rbx
180008a00:     	movl	$0x30, %ecx
180008a05:     	callq	*0x925d(%rip)           # 0x180011c68
180008a0b:     	cmpb	$0x0, 0x922e(%rip)      # 0x180011c40
180008a12:     	je	0x180008a1c <numba_list_iter_next+0x2cc>
180008a14:     	lock
180008a15:     	incq	0x922c(%rip)            # 0x180011c48
180008a1c:     	testq	%rax, %rax
180008a1f:     	je	0x180008a56 <numba_list_iter_next+0x306>
180008a21:     	leaq	-0x48(%rip), %rcx       # 0x1800089e0 <numba_list_iter_next+0x290>
180008a28:     	movl	$0x1, %edx
180008a2d:     	xchgq	%rdx, (%rax)
180008a30:     	movq	%rcx, 0x8(%rax)
180008a34:     	xorl	%ecx, %ecx
180008a36:     	movq	%rcx, 0x20(%rax)
180008a3a:     	movq	%rcx, 0x28(%rax)
180008a3e:     	movq	%rbx, 0x10(%rax)
180008a42:     	movq	%rdi, 0x18(%rax)
180008a46:     	cmpb	%cl, 0x91f4(%rip)       # 0x180011c40
180008a4c:     	je	0x180008a56 <numba_list_iter_next+0x306>
180008a4e:     	lock
180008a4f:     	incq	0x9202(%rip)            # 0x180011c58
180008a56:     	movq	0x30(%rsp), %rbx
180008a5b:     	addq	$0x20, %rsp
180008a5f:     	popq	%rdi
180008a60:     	retq
180008a61:     	jmpq	*0x18a9(%rip)           # 0x18000a310
180008a67:     	jmpq	*0x1893(%rip)           # 0x18000a300
180008a6d:     	jmpq	*0x1885(%rip)           # 0x18000a2f8
180008a73:     	jmpq	*0x1877(%rip)           # 0x18000a2f0
180008a79:     	jmpq	*0x1869(%rip)           # 0x18000a2e8
180008a7f:     	jmpq	*0x185b(%rip)           # 0x18000a2e0
180008a85:     	jmpq	*0x184d(%rip)           # 0x18000a2d8
180008a8b:     	jmpq	*0x1837(%rip)           # 0x18000a2c8
180008a91:     	jmpq	*0x1829(%rip)           # 0x18000a2c0
180008a97:     	jmpq	*0x181b(%rip)           # 0x18000a2b8
180008a9d:     	jmpq	*0x1805(%rip)           # 0x18000a2a8
180008aa3:     	jmpq	*0x17df(%rip)           # 0x18000a288
180008aa9:     	jmpq	*0x17d1(%rip)           # 0x18000a280
180008aaf:     	jmpq	*0x17c3(%rip)           # 0x18000a278
180008ab5:     	jmpq	*0x17b5(%rip)           # 0x18000a270
180008abb:     	jmpq	*0x176f(%rip)           # 0x18000a230
180008ac1:     	int3
180008ac2:     	int3
180008ac3:     	int3
180008ac4:     	int3
180008ac5:     	int3
180008ac6:     	int3
180008ac7:     	int3
180008ac8:     	int3
180008ac9:     	int3
180008aca:     	int3
180008acb:     	int3
180008acc:     	int3
180008acd:     	int3
180008ace:     	int3
180008acf:     	int3
180008ad0:     	int3
180008ad1:     	int3
180008ad2:     	int3
180008ad3:     	int3
180008ad4:     	int3
180008ad5:     	int3
180008ad6:     	nopw	(%rax,%rax)
180008ae0:     	cmpq	0x8619(%rip), %rcx      # 0x180011100
180008ae7:     	jne	0x180008af9 <numba_list_iter_next+0x3a9>
180008ae9:     	rolq	$0x10, %rcx
180008aed:     	testw	$0xffff, %cx            # imm = 0xFFFF
180008af2:     	jne	0x180008af5 <numba_list_iter_next+0x3a5>
180008af4:     	retq
180008af5:     	rorq	$0x10, %rcx
180008af9:     	jmp	0x180008e54 <numba_list_iter_next+0x704>
180008afe:     	int3
180008aff:     	int3
180008b00:     	subq	$0x28, %rsp
180008b04:     	testl	%edx, %edx
180008b06:     	je	0x180008b41 <numba_list_iter_next+0x3f1>
180008b08:     	subl	$0x1, %edx
180008b0b:     	je	0x180008b35 <numba_list_iter_next+0x3e5>
180008b0d:     	subl	$0x1, %edx
180008b10:     	je	0x180008b28 <numba_list_iter_next+0x3d8>
180008b12:     	cmpl	$0x1, %edx
180008b15:     	je	0x180008b21 <numba_list_iter_next+0x3d1>
180008b17:     	movl	$0x1, %eax
180008b1c:     	addq	$0x28, %rsp
180008b20:     	retq
180008b21:     	callq	0x180009020 <numba_list_iter_next+0x8d0>
180008b26:     	jmp	0x180008b2d <numba_list_iter_next+0x3dd>
180008b28:     	callq	0x180008ff8 <numba_list_iter_next+0x8a8>
180008b2d:     	movzbl	%al, %eax
180008b30:     	addq	$0x28, %rsp
180008b34:     	retq
180008b35:     	movq	%r8, %rdx
180008b38:     	addq	$0x28, %rsp
180008b3c:     	jmp	0x180008b50 <numba_list_iter_next+0x400>
180008b41:     	testq	%r8, %r8
180008b44:     	setne	%cl
180008b47:     	addq	$0x28, %rsp
180008b4b:     	jmp	0x180008c68 <numba_list_iter_next+0x518>
180008b50:     	movq	%rbx, 0x8(%rsp)
180008b55:     	movq	%rsi, 0x10(%rsp)
180008b5a:     	movq	%rdi, 0x20(%rsp)
180008b5f:     	pushq	%r14
180008b61:     	subq	$0x20, %rsp
180008b65:     	movq	%rdx, %rsi
180008b68:     	movq	%rcx, %r14
180008b6b:     	xorl	%ecx, %ecx
180008b6d:     	callq	0x1800090dc <numba_list_iter_next+0x98c>
180008b72:     	testb	%al, %al
180008b74:     	je	0x180008c42 <numba_list_iter_next+0x4f2>
180008b7a:     	callq	0x180008f70 <numba_list_iter_next+0x820>
180008b7f:     	movb	%al, %bl
180008b81:     	movb	%al, 0x40(%rsp)
180008b85:     	movb	$0x1, %dil
180008b88:     	cmpl	$0x0, 0x8e79(%rip)      # 0x180011a08
180008b8f:     	jne	0x180008c5a <numba_list_iter_next+0x50a>
180008b95:     	movl	$0x1, 0x8e69(%rip)      # 0x180011a08
180008b9f:     	callq	0x180008fe0 <numba_list_iter_next+0x890>
180008ba4:     	testb	%al, %al
180008ba6:     	je	0x180008bf7 <numba_list_iter_next+0x4a7>
180008ba8:     	callq	0x18000929c <numba_list_iter_next+0xb4c>
180008bad:     	callq	0x180008f30 <numba_list_iter_next+0x7e0>
180008bb2:     	callq	0x180008f54 <numba_list_iter_next+0x804>
180008bb7:     	leaq	0x17b2(%rip), %rdx      # 0x18000a370
180008bbe:     	leaq	0x17a3(%rip), %rcx      # 0x18000a368
180008bc5:     	callq	0x1800095e2 <numba_list_iter_next+0xe92>
180008bca:     	testl	%eax, %eax
180008bcc:     	jne	0x180008bf7 <numba_list_iter_next+0x4a7>
180008bce:     	callq	0x180008fac <numba_list_iter_next+0x85c>
180008bd3:     	testb	%al, %al
180008bd5:     	je	0x180008bf7 <numba_list_iter_next+0x4a7>
180008bd7:     	leaq	0x1782(%rip), %rdx      # 0x18000a360
180008bde:     	leaq	0x1773(%rip), %rcx      # 0x18000a358
180008be5:     	callq	0x1800095dc <numba_list_iter_next+0xe8c>
180008bea:     	movl	$0x2, 0x8e14(%rip)      # 0x180011a08
180008bf4:     	xorb	%dil, %dil
180008bf7:     	movb	%bl, %cl
180008bf9:     	callq	0x18000923c <numba_list_iter_next+0xaec>
180008bfe:     	testb	%dil, %dil
180008c01:     	jne	0x180008c42 <numba_list_iter_next+0x4f2>
180008c03:     	callq	0x18000928c <numba_list_iter_next+0xb3c>
180008c08:     	movq	%rax, %rbx
180008c0b:     	cmpq	$0x0, (%rax)
180008c0f:     	je	0x180008c35 <numba_list_iter_next+0x4e5>
180008c11:     	movq	%rax, %rcx
180008c14:     	callq	0x1800091a4 <numba_list_iter_next+0xa54>
180008c19:     	testb	%al, %al
180008c1b:     	je	0x180008c35 <numba_list_iter_next+0x4e5>
180008c1d:     	movq	%rsi, %r8
180008c20:     	movl	$0x2, %edx
180008c25:     	movq	%r14, %rcx
180008c28:     	movq	(%rbx), %rax
180008c2b:     	movq	0x16fe(%rip), %r9       # 0x18000a330
180008c32:     	callq	*%r9
180008c35:     	incl	0x8da5(%rip)            # 0x1800119e0
180008c3b:     	movl	$0x1, %eax
180008c40:     	jmp	0x180008c44 <numba_list_iter_next+0x4f4>
180008c42:     	xorl	%eax, %eax
180008c44:     	movq	0x30(%rsp), %rbx
180008c49:     	movq	0x38(%rsp), %rsi
180008c4e:     	movq	0x48(%rsp), %rdi
180008c53:     	addq	$0x20, %rsp
180008c57:     	popq	%r14
180008c59:     	retq
180008c5a:     	movl	$0x7, %ecx
180008c5f:     	callq	0x180009294 <numba_list_iter_next+0xb44>
180008c64:     	nop
180008c65:     	int3
180008c66:     	int3
180008c67:     	int3
180008c68:     	movq	%rbx, 0x8(%rsp)
180008c6d:     	pushq	%rdi
180008c6e:     	subq	$0x30, %rsp
180008c72:     	movb	%cl, %dil
180008c75:     	movl	0x8d65(%rip), %eax      # 0x1800119e0
180008c7b:     	testl	%eax, %eax
180008c7d:     	jg	0x180008c8c <numba_list_iter_next+0x53c>
180008c7f:     	xorl	%eax, %eax
180008c81:     	movq	0x40(%rsp), %rbx
180008c86:     	addq	$0x30, %rsp
180008c8a:     	popq	%rdi
180008c8b:     	retq
180008c8c:     	decl	%eax
180008c8e:     	movl	%eax, 0x8d4c(%rip)      # 0x1800119e0
180008c94:     	callq	0x180008f70 <numba_list_iter_next+0x820>
180008c99:     	movb	%al, %bl
180008c9b:     	movb	%al, 0x20(%rsp)
180008c9f:     	cmpl	$0x2, 0x8d62(%rip)      # 0x180011a08
180008ca6:     	jne	0x180008cde <numba_list_iter_next+0x58e>
180008ca8:     	callq	0x180009098 <numba_list_iter_next+0x948>
180008cad:     	callq	0x180008f40 <numba_list_iter_next+0x7f0>
180008cb2:     	callq	0x1800092d8 <numba_list_iter_next+0xb88>
180008cb7:     	movl	$0x0, 0x8d47(%rip)      # 0x180011a08
180008cc1:     	movb	%bl, %cl
180008cc3:     	callq	0x18000923c <numba_list_iter_next+0xaec>
180008cc8:     	xorl	%edx, %edx
180008cca:     	movb	%dil, %cl
180008ccd:     	callq	0x180009260 <numba_list_iter_next+0xb10>
180008cd2:     	movzbl	%al, %ebx
180008cd5:     	callq	0x1800090c8 <numba_list_iter_next+0x978>
180008cda:     	movl	%ebx, %eax
180008cdc:     	jmp	0x180008c81 <numba_list_iter_next+0x531>
180008cde:     	movl	$0x7, %ecx
180008ce3:     	callq	0x180009294 <numba_list_iter_next+0xb44>
180008ce8:     	nop
180008ce9:     	nop
180008cea:     	int3
180008ceb:     	int3
180008cec:     	movq	%rsp, %rax
180008cef:     	movq	%rbx, 0x20(%rax)
180008cf3:     	movq	%r8, 0x18(%rax)
180008cf7:     	movl	%edx, 0x10(%rax)
180008cfa:     	movq	%rcx, 0x8(%rax)
180008cfe:     	pushq	%rsi
180008cff:     	pushq	%rdi
180008d00:     	pushq	%r14
180008d02:     	subq	$0x40, %rsp
180008d06:     	movq	%r8, %rsi
180008d09:     	movl	%edx, %edi
180008d0b:     	movq	%rcx, %r14
180008d0e:     	testl	%edx, %edx
180008d10:     	jne	0x180008d21 <numba_list_iter_next+0x5d1>
180008d12:     	cmpl	%edx, 0x8cc8(%rip)      # 0x1800119e0
180008d18:     	jg	0x180008d21 <numba_list_iter_next+0x5d1>
180008d1a:     	xorl	%eax, %eax
180008d1c:     	jmp	0x180008e06 <numba_list_iter_next+0x6b6>
180008d21:     	leal	-0x1(%rdx), %eax
180008d24:     	cmpl	$0x1, %eax
180008d27:     	ja	0x180008d69 <numba_list_iter_next+0x619>
180008d29:     	movq	0x2090(%rip), %rax      # 0x18000adc0
180008d30:     	testq	%rax, %rax
180008d33:     	jne	0x180008d3a <numba_list_iter_next+0x5ea>
180008d35:     	leal	0x1(%rax), %ebx
180008d38:     	jmp	0x180008d42 <numba_list_iter_next+0x5f2>
180008d3a:     	callq	*0x15f0(%rip)           # 0x18000a330
180008d40:     	movl	%eax, %ebx
180008d42:     	movl	%ebx, 0x30(%rsp)
180008d46:     	testl	%ebx, %ebx
180008d48:     	je	0x180008dfc <numba_list_iter_next+0x6ac>
180008d4e:     	movq	%rsi, %r8
180008d51:     	movl	%edi, %edx
180008d53:     	movq	%r14, %rcx
180008d56:     	callq	0x180008b00 <numba_list_iter_next+0x3b0>
180008d5b:     	movl	%eax, %ebx
180008d5d:     	movl	%eax, 0x30(%rsp)
180008d61:     	testl	%eax, %eax
180008d63:     	je	0x180008dfc <numba_list_iter_next+0x6ac>
180008d69:     	movq	%rsi, %r8
180008d6c:     	movl	%edi, %edx
180008d6e:     	movq	%r14, %rcx
180008d71:     	callq	0x180008f0c <numba_list_iter_next+0x7bc>
180008d76:     	movl	%eax, %ebx
180008d78:     	movl	%eax, 0x30(%rsp)
180008d7c:     	cmpl	$0x1, %edi
180008d7f:     	jne	0x180008db7 <numba_list_iter_next+0x667>
180008d81:     	testl	%eax, %eax
180008d83:     	jne	0x180008db7 <numba_list_iter_next+0x667>
180008d85:     	movq	%rsi, %r8
180008d88:     	xorl	%edx, %edx
180008d8a:     	movq	%r14, %rcx
180008d8d:     	callq	0x180008f0c <numba_list_iter_next+0x7bc>
180008d92:     	testq	%rsi, %rsi
180008d95:     	setne	%cl
180008d98:     	callq	0x180008c68 <numba_list_iter_next+0x518>
180008d9d:     	movq	0x201c(%rip), %rax      # 0x18000adc0
180008da4:     	testq	%rax, %rax
180008da7:     	je	0x180008db7 <numba_list_iter_next+0x667>
180008da9:     	movq	%rsi, %r8
180008dac:     	xorl	%edx, %edx
180008dae:     	movq	%r14, %rcx
180008db1:     	callq	*0x1579(%rip)           # 0x18000a330
180008db7:     	testl	%edi, %edi
180008db9:     	je	0x180008dc0 <numba_list_iter_next+0x670>
180008dbb:     	cmpl	$0x3, %edi
180008dbe:     	jne	0x180008dfc <numba_list_iter_next+0x6ac>
180008dc0:     	movq	%rsi, %r8
180008dc3:     	movl	%edi, %edx
180008dc5:     	movq	%r14, %rcx
180008dc8:     	callq	0x180008b00 <numba_list_iter_next+0x3b0>
180008dcd:     	movl	%eax, %ebx
180008dcf:     	movl	%eax, 0x30(%rsp)
180008dd3:     	testl	%eax, %eax
180008dd5:     	je	0x180008dfc <numba_list_iter_next+0x6ac>
180008dd7:     	movq	0x1fe2(%rip), %rax      # 0x18000adc0
180008dde:     	testq	%rax, %rax
180008de1:     	jne	0x180008de8 <numba_list_iter_next+0x698>
180008de3:     	leal	0x1(%rax), %ebx
180008de6:     	jmp	0x180008df8 <numba_list_iter_next+0x6a8>
180008de8:     	movq	%rsi, %r8
180008deb:     	movl	%edi, %edx
180008ded:     	movq	%r14, %rcx
180008df0:     	callq	*0x153a(%rip)           # 0x18000a330
180008df6:     	movl	%eax, %ebx
180008df8:     	movl	%ebx, 0x30(%rsp)
180008dfc:     	jmp	0x180008e04 <numba_list_iter_next+0x6b4>
180008dfe:     	xorl	%ebx, %ebx
180008e00:     	movl	%ebx, 0x30(%rsp)
180008e04:     	movl	%ebx, %eax
180008e06:     	movq	0x78(%rsp), %rbx
180008e0b:     	addq	$0x40, %rsp
180008e0f:     	popq	%r14
180008e11:     	popq	%rdi
180008e12:     	popq	%rsi
180008e13:     	retq
180008e14:     	movq	%rbx, 0x8(%rsp)
180008e19:     	movq	%rsi, 0x10(%rsp)
180008e1e:     	pushq	%rdi
180008e1f:     	subq	$0x20, %rsp
180008e23:     	movq	%r8, %rdi
180008e26:     	movl	%edx, %ebx
180008e28:     	movq	%rcx, %rsi
180008e2b:     	cmpl	$0x1, %edx
180008e2e:     	jne	0x180008e35 <numba_list_iter_next+0x6e5>
180008e30:     	callq	0x180008e5c <numba_list_iter_next+0x70c>
180008e35:     	movq	%rdi, %r8
180008e38:     	movl	%ebx, %edx
180008e3a:     	movq	%rsi, %rcx
180008e3d:     	movq	0x30(%rsp), %rbx
180008e42:     	movq	0x38(%rsp), %rsi
180008e47:     	addq	$0x20, %rsp
180008e4b:     	popq	%rdi
180008e4c:     	jmp	0x180008cec <numba_list_iter_next+0x59c>
180008e51:     	int3
180008e52:     	int3
180008e53:     	int3
180008e54:     	movl	$0x2, %ecx
180008e59:     	int	$0x29
180008e5b:     	retq
180008e5c:     	movq	%rbx, 0x18(%rsp)
180008e61:     	pushq	%rbp
180008e62:     	movq	%rsp, %rbp
180008e65:     	subq	$0x30, %rsp
180008e69:     	movq	0x8290(%rip), %rax      # 0x180011100
180008e70:     	movabsq	$0x2b992ddfa232, %rbx   # imm = 0x2B992DDFA232
180008e7a:     	cmpq	%rbx, %rax
180008e7d:     	jne	0x180008ef6 <numba_list_iter_next+0x7a6>
180008e7f:     	leaq	0x10(%rbp), %rcx
180008e83:     	movq	$0x0, 0x10(%rbp)
180008e8b:     	callq	*0x118f(%rip)           # 0x18000a020
180008e91:     	movq	0x10(%rbp), %rax
180008e95:     	movq	%rax, -0x10(%rbp)
180008e99:     	callq	*0x1179(%rip)           # 0x18000a018
180008e9f:     	movl	%eax, %eax
180008ea1:     	xorq	%rax, -0x10(%rbp)
180008ea5:     	callq	*0x1165(%rip)           # 0x18000a010
180008eab:     	movl	%eax, %eax
180008ead:     	leaq	0x18(%rbp), %rcx
180008eb1:     	xorq	%rax, -0x10(%rbp)
180008eb5:     	callq	*0x1145(%rip)           # 0x18000a000
180008ebb:     	movl	0x18(%rbp), %eax
180008ebe:     	leaq	-0x10(%rbp), %rcx
180008ec2:     	shlq	$0x20, %rax
180008ec6:     	xorq	0x18(%rbp), %rax
180008eca:     	xorq	-0x10(%rbp), %rax
180008ece:     	xorq	%rcx, %rax
180008ed1:     	movabsq	$0xffffffffffff, %rcx   # imm = 0xFFFFFFFFFFFF
180008edb:     	andq	%rcx, %rax
180008ede:     	movabsq	$0x2b992ddfa233, %rcx   # imm = 0x2B992DDFA233
180008ee8:     	cmpq	%rbx, %rax
180008eeb:     	cmoveq	%rcx, %rax
180008eef:     	movq	%rax, 0x820a(%rip)      # 0x180011100
180008ef6:     	movq	0x50(%rsp), %rbx
180008efb:     	notq	%rax
180008efe:     	movq	%rax, 0x823b(%rip)      # 0x180011140
180008f05:     	addq	$0x30, %rsp
180008f09:     	popq	%rbp
180008f0a:     	retq
180008f0b:     	int3
180008f0c:     	subq	$0x28, %rsp
180008f10:     	cmpl	$0x1, %edx
180008f13:     	jne	0x180008f25 <numba_list_iter_next+0x7d5>
180008f15:     	cmpq	$0x0, 0x1ea3(%rip)      # 0x18000adc0
180008f1d:     	jne	0x180008f25 <numba_list_iter_next+0x7d5>
180008f1f:     	callq	*0x1103(%rip)           # 0x18000a028
180008f25:     	movl	$0x1, %eax
180008f2a:     	addq	$0x28, %rsp
180008f2e:     	retq
180008f2f:     	int3
180008f30:     	leaq	0x8ab9(%rip), %rcx      # 0x1800119f0
180008f37:     	jmpq	*0x10ca(%rip)           # 0x18000a008
180008f3e:     	int3
180008f3f:     	int3
180008f40:     	leaq	0x8aa9(%rip), %rcx      # 0x1800119f0
180008f47:     	jmp	0x1800095d6 <numba_list_iter_next+0xe86>
180008f4c:     	leaq	0x8aad(%rip), %rax      # 0x180011a00
180008f53:     	retq
180008f54:     	subq	$0x28, %rsp
180008f58:     	callq	0x180008060 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x5af0>
180008f5d:     	orq	$0x24, (%rax)
180008f61:     	callq	0x180008f4c <numba_list_iter_next+0x7fc>
180008f66:     	orq	$0x2, (%rax)
180008f6a:     	addq	$0x28, %rsp
180008f6e:     	retq
180008f6f:     	int3
180008f70:     	subq	$0x28, %rsp
180008f74:     	callq	0x1800095bc <numba_list_iter_next+0xe6c>
180008f79:     	testl	%eax, %eax
180008f7b:     	je	0x180008f9e <numba_list_iter_next+0x84e>
180008f7d:     	movq	%gs:0x30, %rax
180008f86:     	movq	0x8(%rax), %rcx
180008f8a:     	jmp	0x180008f91 <numba_list_iter_next+0x841>
180008f8c:     	cmpq	%rax, %rcx
180008f8f:     	je	0x180008fa5 <numba_list_iter_next+0x855>
180008f91:     	xorl	%eax, %eax
180008f93:     	lock
180008f94:     	cmpxchgq	%rcx, 0x8a74(%rip)      # 0x180011a10
180008f9c:     	jne	0x180008f8c <numba_list_iter_next+0x83c>
180008f9e:     	xorb	%al, %al
180008fa0:     	addq	$0x28, %rsp
180008fa4:     	retq
180008fa5:     	movb	$0x1, %al
180008fa7:     	jmp	0x180008fa0 <numba_list_iter_next+0x850>
180008fa9:     	int3
180008faa:     	int3
180008fab:     	int3
180008fac:     	subq	$0x28, %rsp
180008fb0:     	callq	0x1800095bc <numba_list_iter_next+0xe6c>
180008fb5:     	testl	%eax, %eax
180008fb7:     	je	0x180008fc0 <numba_list_iter_next+0x870>
180008fb9:     	callq	0x180009318 <numba_list_iter_next+0xbc8>
180008fbe:     	jmp	0x180008fd9 <numba_list_iter_next+0x889>
180008fc0:     	callq	0x1800095b4 <numba_list_iter_next+0xe64>
180008fc5:     	movl	%eax, %ecx
180008fc7:     	callq	0x1800095ee <numba_list_iter_next+0xe9e>
180008fcc:     	testl	%eax, %eax
180008fce:     	je	0x180008fd4 <numba_list_iter_next+0x884>
180008fd0:     	xorb	%al, %al
180008fd2:     	jmp	0x180008fdb <numba_list_iter_next+0x88b>
180008fd4:     	callq	0x1800095f4 <numba_list_iter_next+0xea4>
180008fd9:     	movb	$0x1, %al
180008fdb:     	addq	$0x28, %rsp
180008fdf:     	retq
180008fe0:     	subq	$0x28, %rsp
180008fe4:     	xorl	%ecx, %ecx
180008fe6:     	callq	0x180009118 <numba_list_iter_next+0x9c8>
180008feb:     	testb	%al, %al
180008fed:     	setne	%al
180008ff0:     	addq	$0x28, %rsp
180008ff4:     	retq
180008ff5:     	int3
180008ff6:     	int3
180008ff7:     	int3
180008ff8:     	subq	$0x28, %rsp
180008ffc:     	callq	0x18000960c <numba_list_iter_next+0xebc>
180009001:     	testb	%al, %al
180009003:     	jne	0x180009009 <numba_list_iter_next+0x8b9>
180009005:     	xorb	%al, %al
180009007:     	jmp	0x18000901b <numba_list_iter_next+0x8cb>
180009009:     	callq	0x18000960c <numba_list_iter_next+0xebc>
18000900e:     	testb	%al, %al
180009010:     	jne	0x180009019 <numba_list_iter_next+0x8c9>
180009012:     	callq	0x18000960c <numba_list_iter_next+0xebc>
180009017:     	jmp	0x180009005 <numba_list_iter_next+0x8b5>
180009019:     	movb	$0x1, %al
18000901b:     	addq	$0x28, %rsp
18000901f:     	retq
180009020:     	subq	$0x28, %rsp
180009024:     	callq	0x18000960c <numba_list_iter_next+0xebc>
180009029:     	callq	0x18000960c <numba_list_iter_next+0xebc>
18000902e:     	movb	$0x1, %al
180009030:     	addq	$0x28, %rsp
180009034:     	retq
180009035:     	int3
180009036:     	int3
180009037:     	int3
180009038:     	movq	%rbx, 0x8(%rsp)
18000903d:     	movq	%rbp, 0x10(%rsp)
180009042:     	movq	%rsi, 0x18(%rsp)
180009047:     	pushq	%rdi
180009048:     	subq	$0x20, %rsp
18000904c:     	movq	%r9, %rdi
18000904f:     	movq	%r8, %rsi
180009052:     	movl	%edx, %ebx
180009054:     	movq	%rcx, %rbp
180009057:     	callq	0x1800095bc <numba_list_iter_next+0xe6c>
18000905c:     	testl	%eax, %eax
18000905e:     	jne	0x180009076 <numba_list_iter_next+0x926>
180009060:     	cmpl	$0x1, %ebx
180009063:     	jne	0x180009076 <numba_list_iter_next+0x926>
180009065:     	movq	%rsi, %r8
180009068:     	xorl	%edx, %edx
18000906a:     	movq	%rbp, %rcx
18000906d:     	movq	%rdi, %rax
180009070:     	callq	*0x12ba(%rip)           # 0x18000a330
180009076:     	movq	0x58(%rsp), %rdx
18000907b:     	movl	0x50(%rsp), %ecx
18000907f:     	movq	0x30(%rsp), %rbx
180009084:     	movq	0x38(%rsp), %rbp
180009089:     	movq	0x40(%rsp), %rsi
18000908e:     	addq	$0x20, %rsp
180009092:     	popq	%rdi
180009093:     	jmp	0x1800095e8 <numba_list_iter_next+0xe98>
180009098:     	subq	$0x28, %rsp
18000909c:     	callq	0x1800095bc <numba_list_iter_next+0xe6c>
1800090a1:     	testl	%eax, %eax
1800090a3:     	je	0x1800090b5 <numba_list_iter_next+0x965>
1800090a5:     	leaq	0x8974(%rip), %rcx      # 0x180011a20
1800090ac:     	addq	$0x28, %rsp
1800090b0:     	jmp	0x180009600 <numba_list_iter_next+0xeb0>
1800090b5:     	callq	0x180009610 <numba_list_iter_next+0xec0>
1800090ba:     	testl	%eax, %eax
1800090bc:     	jne	0x1800090c3 <numba_list_iter_next+0x973>
1800090be:     	callq	0x180009606 <numba_list_iter_next+0xeb6>
1800090c3:     	addq	$0x28, %rsp
1800090c7:     	retq
1800090c8:     	subq	$0x28, %rsp
1800090cc:     	xorl	%ecx, %ecx
1800090ce:     	callq	0x18000960c <numba_list_iter_next+0xebc>
1800090d3:     	addq	$0x28, %rsp
1800090d7:     	jmp	0x18000960c <numba_list_iter_next+0xebc>
1800090dc:     	subq	$0x28, %rsp
1800090e0:     	testl	%ecx, %ecx
1800090e2:     	jne	0x1800090eb <numba_list_iter_next+0x99b>
1800090e4:     	movb	$0x1, 0x892d(%rip)      # 0x180011a18
1800090eb:     	callq	0x180009318 <numba_list_iter_next+0xbc8>
1800090f0:     	callq	0x18000960c <numba_list_iter_next+0xebc>
1800090f5:     	testb	%al, %al
1800090f7:     	jne	0x1800090fd <numba_list_iter_next+0x9ad>
1800090f9:     	xorb	%al, %al
1800090fb:     	jmp	0x180009111 <numba_list_iter_next+0x9c1>
1800090fd:     	callq	0x18000960c <numba_list_iter_next+0xebc>
180009102:     	testb	%al, %al
180009104:     	jne	0x18000910f <numba_list_iter_next+0x9bf>
180009106:     	xorl	%ecx, %ecx
180009108:     	callq	0x18000960c <numba_list_iter_next+0xebc>
18000910d:     	jmp	0x1800090f9 <numba_list_iter_next+0x9a9>
18000910f:     	movb	$0x1, %al
180009111:     	addq	$0x28, %rsp
180009115:     	retq
180009116:     	int3
180009117:     	int3
180009118:     	pushq	%rbx
18000911a:     	subq	$0x20, %rsp
18000911e:     	cmpb	$0x0, 0x88f4(%rip)      # 0x180011a19
180009125:     	movl	%ecx, %ebx
180009127:     	jne	0x180009190 <numba_list_iter_next+0xa40>
180009129:     	cmpl	$0x1, %ecx
18000912c:     	ja	0x180009198 <numba_list_iter_next+0xa48>
18000912e:     	callq	0x1800095bc <numba_list_iter_next+0xe6c>
180009133:     	testl	%eax, %eax
180009135:     	je	0x18000915f <numba_list_iter_next+0xa0f>
180009137:     	testl	%ebx, %ebx
180009139:     	jne	0x18000915f <numba_list_iter_next+0xa0f>
18000913b:     	leaq	0x88de(%rip), %rcx      # 0x180011a20
180009142:     	callq	0x1800095fa <numba_list_iter_next+0xeaa>
180009147:     	testl	%eax, %eax
180009149:     	jne	0x18000915b <numba_list_iter_next+0xa0b>
18000914b:     	leaq	0x88e6(%rip), %rcx      # 0x180011a38
180009152:     	callq	0x1800095fa <numba_list_iter_next+0xeaa>
180009157:     	testl	%eax, %eax
180009159:     	je	0x180009189 <numba_list_iter_next+0xa39>
18000915b:     	xorb	%al, %al
18000915d:     	jmp	0x180009192 <numba_list_iter_next+0xa42>
18000915f:     	movdqa	0x1c69(%rip), %xmm0     # 0x18000add0
180009167:     	orq	$-0x1, %rax
18000916b:     	movdqu	%xmm0, 0x88ad(%rip)     # 0x180011a20
180009173:     	movq	%rax, 0x88b6(%rip)      # 0x180011a30
18000917a:     	movdqu	%xmm0, 0x88b6(%rip)     # 0x180011a38
180009182:     	movq	%rax, 0x88bf(%rip)      # 0x180011a48
180009189:     	movb	$0x1, 0x8889(%rip)      # 0x180011a19
180009190:     	movb	$0x1, %al
180009192:     	addq	$0x20, %rsp
180009196:     	popq	%rbx
180009197:     	retq
180009198:     	movl	$0x5, %ecx
18000919d:     	callq	0x180009294 <numba_list_iter_next+0xb44>
1800091a2:     	int3
1800091a3:     	int3
1800091a4:     	subq	$0x18, %rsp
1800091a8:     	movq	%rcx, %r8
1800091ab:     	movl	$0x5a4d, %eax           # imm = 0x5A4D
1800091b0:     	cmpw	%ax, -0x91b7(%rip)      # 0x180000000
1800091b7:     	jne	0x180009231 <numba_list_iter_next+0xae1>
1800091b9:     	movslq	-0x9184(%rip), %rcx     # 0x18000003c
1800091c0:     	leaq	-0x91c7(%rip), %rdx     # 0x180000000
1800091c7:     	addq	%rdx, %rcx
1800091ca:     	cmpl	$0x4550, (%rcx)         # imm = 0x4550
1800091d0:     	jne	0x180009231 <numba_list_iter_next+0xae1>
1800091d2:     	movl	$0x20b, %eax            # imm = 0x20B
1800091d7:     	cmpw	%ax, 0x18(%rcx)
1800091db:     	jne	0x180009231 <numba_list_iter_next+0xae1>
1800091dd:     	subq	%rdx, %r8
1800091e0:     	movzwl	0x14(%rcx), %edx
1800091e4:     	addq	$0x18, %rdx
1800091e8:     	addq	%rcx, %rdx
1800091eb:     	movzwl	0x6(%rcx), %eax
1800091ef:     	leaq	(%rax,%rax,4), %rcx
1800091f3:     	leaq	(%rdx,%rcx,8), %r9
1800091f7:     	movq	%rdx, (%rsp)
1800091fb:     	cmpq	%r9, %rdx
1800091fe:     	je	0x180009218 <numba_list_iter_next+0xac8>
180009200:     	movl	0xc(%rdx), %ecx
180009203:     	cmpq	%rcx, %r8
180009206:     	jb	0x180009212 <numba_list_iter_next+0xac2>
180009208:     	movl	0x8(%rdx), %eax
18000920b:     	addl	%ecx, %eax
18000920d:     	cmpq	%rax, %r8
180009210:     	jb	0x18000921a <numba_list_iter_next+0xaca>
180009212:     	addq	$0x28, %rdx
180009216:     	jmp	0x1800091f7 <numba_list_iter_next+0xaa7>
180009218:     	xorl	%edx, %edx
18000921a:     	testq	%rdx, %rdx
18000921d:     	jne	0x180009223 <numba_list_iter_next+0xad3>
18000921f:     	xorb	%al, %al
180009221:     	jmp	0x180009237 <numba_list_iter_next+0xae7>
180009223:     	cmpl	$0x0, 0x24(%rdx)
180009227:     	jge	0x18000922d <numba_list_iter_next+0xadd>
180009229:     	xorb	%al, %al
18000922b:     	jmp	0x180009237 <numba_list_iter_next+0xae7>
18000922d:     	movb	$0x1, %al
18000922f:     	jmp	0x180009237 <numba_list_iter_next+0xae7>
180009231:     	xorb	%al, %al
180009233:     	jmp	0x180009237 <numba_list_iter_next+0xae7>
180009235:     	xorb	%al, %al
180009237:     	addq	$0x18, %rsp
18000923b:     	retq
18000923c:     	pushq	%rbx
18000923e:     	subq	$0x20, %rsp
180009242:     	movb	%cl, %bl
180009244:     	callq	0x1800095bc <numba_list_iter_next+0xe6c>
180009249:     	xorl	%edx, %edx
18000924b:     	testl	%eax, %eax
18000924d:     	je	0x18000925a <numba_list_iter_next+0xb0a>
18000924f:     	testb	%bl, %bl
180009251:     	jne	0x18000925a <numba_list_iter_next+0xb0a>
180009253:     	xchgq	%rdx, 0x87b6(%rip)      # 0x180011a10
18000925a:     	addq	$0x20, %rsp
18000925e:     	popq	%rbx
18000925f:     	retq
180009260:     	pushq	%rbx
180009262:     	subq	$0x20, %rsp
180009266:     	cmpb	$0x0, 0x87ab(%rip)      # 0x180011a18
18000926d:     	movb	%cl, %bl
18000926f:     	je	0x180009275 <numba_list_iter_next+0xb25>
180009271:     	testb	%dl, %dl
180009273:     	jne	0x180009281 <numba_list_iter_next+0xb31>
180009275:     	callq	0x18000960c <numba_list_iter_next+0xebc>
18000927a:     	movb	%bl, %cl
18000927c:     	callq	0x18000960c <numba_list_iter_next+0xebc>
180009281:     	movb	$0x1, %al
180009283:     	addq	$0x20, %rsp
180009287:     	popq	%rbx
180009288:     	retq
180009289:     	int3
18000928a:     	int3
18000928b:     	int3
18000928c:     	leaq	0x8a6d(%rip), %rax      # 0x180011d00
180009293:     	retq
180009294:     	movl	%ecx, %ecx
180009296:     	int	$0x29
180009298:     	retq
180009299:     	int3
18000929a:     	int3
18000929b:     	int3
18000929c:     	movq	%rbx, 0x8(%rsp)
1800092a1:     	pushq	%rdi
1800092a2:     	subq	$0x20, %rsp
1800092a6:     	leaq	0x451b(%rip), %rbx      # 0x18000d7c8
1800092ad:     	leaq	0x4514(%rip), %rdi      # 0x18000d7c8
1800092b4:     	jmp	0x1800092c8 <numba_list_iter_next+0xb78>
1800092b6:     	movq	(%rbx), %rax
1800092b9:     	testq	%rax, %rax
1800092bc:     	je	0x1800092c4 <numba_list_iter_next+0xb74>
1800092be:     	callq	*0x106c(%rip)           # 0x18000a330
1800092c4:     	addq	$0x8, %rbx
1800092c8:     	cmpq	%rdi, %rbx
1800092cb:     	jb	0x1800092b6 <numba_list_iter_next+0xb66>
1800092cd:     	movq	0x30(%rsp), %rbx
1800092d2:     	addq	$0x20, %rsp
1800092d6:     	popq	%rdi
1800092d7:     	retq
1800092d8:     	movq	%rbx, 0x8(%rsp)
1800092dd:     	pushq	%rdi
1800092de:     	subq	$0x20, %rsp
1800092e2:     	leaq	0x44ef(%rip), %rbx      # 0x18000d7d8
1800092e9:     	leaq	0x44e8(%rip), %rdi      # 0x18000d7d8
1800092f0:     	jmp	0x180009304 <numba_list_iter_next+0xbb4>
1800092f2:     	movq	(%rbx), %rax
1800092f5:     	testq	%rax, %rax
1800092f8:     	je	0x180009300 <numba_list_iter_next+0xbb0>
1800092fa:     	callq	*0x1030(%rip)           # 0x18000a330
180009300:     	addq	$0x8, %rbx
180009304:     	cmpq	%rdi, %rbx
180009307:     	jb	0x1800092f2 <numba_list_iter_next+0xba2>
180009309:     	movq	0x30(%rsp), %rbx
18000930e:     	addq	$0x20, %rsp
180009312:     	popq	%rdi
180009313:     	retq
180009314:     	retq	$0x0
180009317:     	int3
180009318:     	movq	%rbx, 0x10(%rsp)
18000931d:     	movq	%rbp, 0x18(%rsp)
180009322:     	movq	%rsi, 0x20(%rsp)
180009327:     	pushq	%rdi
180009328:     	subq	$0x10, %rsp
18000932c:     	xorl	%eax, %eax
18000932e:     	xorl	%ecx, %ecx
180009330:     	cpuid
180009332:     	xorl	$0x6c65746e, %ecx       # imm = 0x6C65746E
180009338:     	xorl	$0x49656e69, %edx       # imm = 0x49656E69
18000933e:     	orl	%ecx, %edx
180009340:     	movl	%eax, %ebp
180009342:     	movl	$0x1, %eax
180009347:     	xorl	$0x756e6547, %ebx       # imm = 0x756E6547
18000934d:     	orl	%ebx, %edx
18000934f:     	leal	-0x1(%rax), %ecx
180009352:     	cpuid
180009354:     	movl	%ecx, %edi
180009356:     	jne	0x1800093b6 <numba_list_iter_next+0xc66>
180009358:     	andl	$0xfff3ff0, %eax        # imm = 0xFFF3FF0
18000935d:     	movq	$0x8000, 0x7df0(%rip)   # imm = 0x8000
                                                # 0x180011158
180009368:     	movq	$-0x1, 0x7ded(%rip)     # 0x180011160
180009373:     	cmpl	$0x106c0, %eax          # imm = 0x106C0
180009378:     	je	0x1800093a2 <numba_list_iter_next+0xc52>
18000937a:     	cmpl	$0x20660, %eax          # imm = 0x20660
18000937f:     	je	0x1800093a2 <numba_list_iter_next+0xc52>
180009381:     	cmpl	$0x20670, %eax          # imm = 0x20670
180009386:     	je	0x1800093a2 <numba_list_iter_next+0xc52>
180009388:     	addl	$0xfffcf9b0, %eax       # imm = 0xFFFCF9B0
18000938d:     	cmpl	$0x20, %eax
180009390:     	ja	0x1800093b6 <numba_list_iter_next+0xc66>
180009392:     	movabsq	$0x100010001, %rcx      # imm = 0x100010001
18000939c:     	btq	%rax, %rcx
1800093a0:     	jae	0x1800093b6 <numba_list_iter_next+0xc66>
1800093a2:     	movl	0x86ab(%rip), %r8d      # 0x180011a54
1800093a9:     	orl	$0x1, %r8d
1800093ad:     	movl	%r8d, 0x86a0(%rip)      # 0x180011a54
1800093b4:     	jmp	0x1800093bd <numba_list_iter_next+0xc6d>
1800093b6:     	movl	0x8697(%rip), %r8d      # 0x180011a54
1800093bd:     	xorl	%r9d, %r9d
1800093c0:     	movl	%r9d, %r11d
1800093c3:     	cmpl	$0x7, %ebp
1800093c6:     	jl	0x18000940a <numba_list_iter_next+0xcba>
1800093c8:     	xorl	%ecx, %ecx
1800093ca:     	leal	0x7(%r9), %eax
1800093ce:     	cpuid
1800093d0:     	movl	%edx, %esi
1800093d2:     	movl	%ebx, %r10d
1800093d5:     	btl	$0x9, %ebx
1800093d9:     	jae	0x1800093e6 <numba_list_iter_next+0xc96>
1800093db:     	orl	$0x2, %r8d
1800093df:     	movl	%r8d, 0x866e(%rip)      # 0x180011a54
1800093e6:     	cmpl	$0x1, %eax
1800093e9:     	jl	0x1800093f8 <numba_list_iter_next+0xca8>
1800093eb:     	movl	$0x7, %eax
1800093f0:     	leal	-0x6(%rax), %ecx
1800093f3:     	cpuid
1800093f5:     	movl	%edx, %r9d
1800093f8:     	movl	$0x24, %eax
1800093fd:     	cmpl	%eax, %ebp
1800093ff:     	jl	0x180009410 <numba_list_iter_next+0xcc0>
180009401:     	xorl	%ecx, %ecx
180009403:     	cpuid
180009405:     	movl	%ebx, %r11d
180009408:     	jmp	0x180009410 <numba_list_iter_next+0xcc0>
18000940a:     	movl	%r9d, %r10d
18000940d:     	movl	%r9d, %esi
180009410:     	movq	0x7d51(%rip), %rax      # 0x180011168
180009417:     	andq	$-0x2, %rax
18000941b:     	movl	$0x1, 0x7d2b(%rip)      # 0x180011150
180009425:     	movl	$0x2, 0x7d25(%rip)      # 0x180011154
18000942f:     	movq	%rax, 0x7d32(%rip)      # 0x180011168
180009436:     	btl	$0x14, %edi
18000943a:     	jae	0x18000945b <numba_list_iter_next+0xd0b>
18000943c:     	andq	$-0x11, %rax
180009440:     	movl	$0x2, 0x7d06(%rip)      # 0x180011150
18000944a:     	movq	%rax, 0x7d17(%rip)      # 0x180011168
180009451:     	movl	$0x6, 0x7cf9(%rip)      # 0x180011154
18000945b:     	btl	$0x1b, %edi
18000945f:     	jae	0x18000959c <numba_list_iter_next+0xe4c>
180009465:     	xorl	%ecx, %ecx
180009467:     	xgetbv
18000946a:     	shlq	$0x20, %rdx
18000946e:     	orq	%rax, %rdx
180009471:     	movq	%rdx, 0x20(%rsp)
180009476:     	btl	$0x1c, %edi
18000947a:     	jae	0x180009580 <numba_list_iter_next+0xe30>
180009480:     	movq	0x20(%rsp), %rax
180009485:     	andb	$0x6, %al
180009487:     	cmpb	$0x6, %al
180009489:     	jne	0x180009580 <numba_list_iter_next+0xe30>
18000948f:     	movl	0x7cbf(%rip), %eax      # 0x180011154
180009495:     	movb	$-0x20, %dl
180009497:     	orl	$0x8, %eax
18000949a:     	movl	$0x3, 0x7cac(%rip)      # 0x180011150
1800094a4:     	movl	%eax, 0x7caa(%rip)      # 0x180011154
1800094aa:     	testb	$0x20, %r10b
1800094ae:     	je	0x180009512 <numba_list_iter_next+0xdc2>
1800094b0:     	orl	$0x20, %eax
1800094b3:     	movl	$0x5, 0x7c93(%rip)      # 0x180011150
1800094bd:     	movl	%eax, 0x7c91(%rip)      # 0x180011154
1800094c3:     	movl	$0xd0030000, %ecx       # imm = 0xD0030000
1800094c8:     	movq	0x7c99(%rip), %rax      # 0x180011168
1800094cf:     	andl	%ecx, %r10d
1800094d2:     	andq	$-0x3, %rax
1800094d6:     	movq	%rax, 0x7c8b(%rip)      # 0x180011168
1800094dd:     	cmpl	%ecx, %r10d
1800094e0:     	jne	0x180009519 <numba_list_iter_next+0xdc9>
1800094e2:     	movq	0x20(%rsp), %rax
1800094e7:     	andb	%dl, %al
1800094e9:     	cmpb	%dl, %al
1800094eb:     	jne	0x180009512 <numba_list_iter_next+0xdc2>
1800094ed:     	movq	0x7c74(%rip), %rax      # 0x180011168
1800094f4:     	orl	$0x40, 0x7c59(%rip)     # 0x180011154
1800094fb:     	andq	$-0x25, %rax
1800094ff:     	movl	$0x6, 0x7c47(%rip)      # 0x180011150
180009509:     	movq	%rax, 0x7c58(%rip)      # 0x180011168
180009510:     	jmp	0x180009519 <numba_list_iter_next+0xdc9>
180009512:     	movq	0x7c4f(%rip), %rax      # 0x180011168
180009519:     	btl	$0x17, %esi
18000951d:     	jae	0x18000952b <numba_list_iter_next+0xddb>
18000951f:     	btrq	$0x18, %rax
180009524:     	movq	%rax, 0x7c3d(%rip)      # 0x180011168
18000952b:     	btl	$0x13, %r9d
180009530:     	jae	0x180009580 <numba_list_iter_next+0xe30>
180009532:     	movq	0x20(%rsp), %rax
180009537:     	andb	%dl, %al
180009539:     	cmpb	%dl, %al
18000953b:     	jne	0x180009580 <numba_list_iter_next+0xe30>
18000953d:     	movq	0x7c24(%rip), %rdx      # 0x180011168
180009544:     	movl	%r11d, %eax
180009547:     	shrq	$0x10, %rax
18000954b:     	movl	%r11d, %ecx
18000954e:     	andl	$0x6, %eax
180009551:     	andl	$0x400ff, %ecx          # imm = 0x400FF
180009557:     	orq	$0x1000029, %rax        # imm = 0x1000029
18000955d:     	movl	%ecx, 0x84f5(%rip)      # 0x180011a58
180009563:     	notq	%rax
180009566:     	andq	%rax, %rdx
180009569:     	movq	%rdx, 0x7bf8(%rip)      # 0x180011168
180009570:     	cmpb	$0x1, %cl
180009573:     	jbe	0x180009580 <numba_list_iter_next+0xe30>
180009575:     	andq	$-0x41, %rdx
180009579:     	movq	%rdx, 0x7be8(%rip)      # 0x180011168
180009580:     	btl	$0x15, %r9d
180009585:     	jae	0x18000959c <numba_list_iter_next+0xe4c>
180009587:     	movq	0x20(%rsp), %rax
18000958c:     	btq	$0x13, %rax
180009591:     	jae	0x18000959c <numba_list_iter_next+0xe4c>
180009593:     	btrq	$0x7, 0x7bcc(%rip)      # 0x180011168
18000959c:     	movq	0x28(%rsp), %rbx
1800095a1:     	xorl	%eax, %eax
1800095a3:     	movq	0x30(%rsp), %rbp
1800095a8:     	movq	0x38(%rsp), %rsi
1800095ad:     	addq	$0x10, %rsp
1800095b1:     	popq	%rdi
1800095b2:     	retq
1800095b3:     	int3
1800095b4:     	movl	$0x1, %eax
1800095b9:     	retq
1800095ba:     	int3
1800095bb:     	int3
1800095bc:     	xorl	%eax, %eax
1800095be:     	cmpl	%eax, 0x7bac(%rip)      # 0x180011170
1800095c4:     	setne	%al
1800095c7:     	retq
1800095c8:     	int3
1800095c9:     	int3
1800095ca:     	int3
1800095cb:     	int3
1800095cc:     	int3
1800095cd:     	int3
1800095ce:     	int3
1800095cf:     	int3
1800095d0:     	jmpq	*0xa72(%rip)            # 0x18000a048
1800095d6:     	jmpq	*0xa74(%rip)            # 0x18000a050
1800095dc:     	jmpq	*0xaae(%rip)            # 0x18000a090
1800095e2:     	jmpq	*0xab0(%rip)            # 0x18000a098
1800095e8:     	jmpq	*0xab2(%rip)            # 0x18000a0a0
1800095ee:     	jmpq	*0xab4(%rip)            # 0x18000a0a8
1800095f4:     	jmpq	*0xab6(%rip)            # 0x18000a0b0
1800095fa:     	jmpq	*0xa80(%rip)            # 0x18000a080
180009600:     	jmpq	*0xab2(%rip)            # 0x18000a0b8
180009606:     	jmpq	*0xa7c(%rip)            # 0x18000a088
18000960c:     	movb	$0x1, %al
18000960e:     	retq
18000960f:     	int3
180009610:     	xorl	%eax, %eax
180009612:     	retq
180009613:     	jmpq	*0xa1f(%rip)            # 0x18000a038
180009619:     	jmpq	*0xa21(%rip)            # 0x18000a040
18000961f:     	jmpq	*0xaa3(%rip)            # 0x18000a0c8
180009625:     	jmpq	*0xaa5(%rip)            # 0x18000a0d0
18000962b:     	int3
18000962c:     	int3
18000962d:     	int3
18000962e:     	int3
18000962f:     	int3
180009630:     	int3
180009631:     	int3
180009632:     	int3
180009633:     	int3
180009634:     	int3
180009635:     	int3
180009636:     	nopw	(%rax,%rax)
180009640:     	jmpq	*%rax
180009642:     	int3
180009643:     	int3
180009644:     	int3
180009645:     	int3
180009646:     	int3
180009647:     	int3
180009648:     	int3
180009649:     	int3
18000964a:     	int3
18000964b:     	int3
18000964c:     	int3
18000964d:     	int3
18000964e:     	int3
18000964f:     	int3
180009650:     	int3
180009651:     	int3
180009652:     	int3
180009653:     	int3
180009654:     	int3
180009655:     	int3
180009656:     	nopw	(%rax,%rax)
180009660:     	jmpq	*0xcca(%rip)            # 0x18000a330
180009666:     	pushq	%rbp
180009668:     	subq	$0x20, %rsp
18000966c:     	movq	%rdx, %rbp
18000966f:     	movb	0x40(%rbp), %cl
180009672:     	addq	$0x20, %rsp
180009676:     	popq	%rbp
180009677:     	jmp	0x18000923c <numba_list_iter_next+0xaec>
18000967c:     	int3
18000967d:     	pushq	%rbp
18000967f:     	subq	$0x20, %rsp
180009683:     	movq	%rdx, %rbp
180009686:     	movb	0x20(%rbp), %cl
180009689:     	callq	0x18000923c <numba_list_iter_next+0xaec>
18000968e:     	nop
18000968f:     	addq	$0x20, %rsp
180009693:     	popq	%rbp
180009694:     	retq
180009695:     	int3
180009696:     	pushq	%rbp
180009698:     	subq	$0x20, %rsp
18000969c:     	movq	%rdx, %rbp
18000969f:     	addq	$0x20, %rsp
1800096a3:     	popq	%rbp
1800096a4:     	jmp	0x1800090c8 <numba_list_iter_next+0x978>
1800096a9:     	int3
1800096aa:     	pushq	%rbp
1800096ac:     	subq	$0x30, %rsp
1800096b0:     	movq	%rdx, %rbp
1800096b3:     	movq	(%rcx), %rax
1800096b6:     	movl	(%rax), %edx
1800096b8:     	movq	%rcx, 0x28(%rsp)
1800096bd:     	movl	%edx, 0x20(%rsp)
1800096c1:     	leaq	-0xbc8(%rip), %r9       # 0x180008b00 <numba_list_iter_next+0x3b0>
1800096c8:     	movq	0x70(%rbp), %r8
1800096cc:     	movl	0x68(%rbp), %edx
1800096cf:     	movq	0x60(%rbp), %rcx
1800096d3:     	callq	0x180009038 <numba_list_iter_next+0x8e8>
1800096d8:     	nop
1800096d9:     	addq	$0x30, %rsp
1800096dd:     	popq	%rbp
1800096de:     	retq
1800096df:     	int3
1800096e0:     	pushq	%rbp
1800096e2:     	movq	%rdx, %rbp
1800096e5:     	movq	(%rcx), %rax
1800096e8:     	xorl	%ecx, %ecx
1800096ea:     	cmpl	$0xc0000005, (%rax)     # imm = 0xC0000005
1800096f0:     	sete	%cl
1800096f3:     	movl	%ecx, %eax
1800096f5:     	popq	%rbp
1800096f6:     	retq
1800096f7:     	int3
