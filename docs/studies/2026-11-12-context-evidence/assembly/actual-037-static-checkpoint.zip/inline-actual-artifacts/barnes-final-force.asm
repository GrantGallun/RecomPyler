# barnes-final force: [0x180002b60, 0x180003100)
# Source/call-target-bound static range; padding included; never cycles.
180002b60:     	pushq	%r15
180002b62:     	pushq	%r14
180002b64:     	pushq	%r13
180002b66:     	pushq	%r12
180002b68:     	pushq	%rsi
180002b69:     	pushq	%rdi
180002b6a:     	pushq	%rbp
180002b6b:     	pushq	%rbx
180002b6c:     	subq	$0xf8, %rsp
180002b73:     	movapd	%xmm8, 0xe0(%rsp)
180002b7d:     	movapd	%xmm7, 0xd0(%rsp)
180002b86:     	movapd	%xmm6, 0xc0(%rsp)
180002b8f:     	movq	$0x0, 0x40(%rsp)
180002b98:     	movb	$0x0, 0x48(%rsp)
180002b9d:     	movq	$0x0, 0x50(%rsp)
180002ba6:     	movq	(%r8), %rax
180002ba9:     	movsd	0x48(%rax,%r9,8), %xmm0
180002bb0:     	xorpd	%xmm1, %xmm1
180002bb4:     	ucomisd	%xmm1, %xmm0
180002bb8:     	jne	0x180002bd1 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x641>
180002bba:     	jp	0x180002bd1 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x641>
180002bbc:     	movb	$0x1, 0x18(%rcx)
180002bc0:     	movq	$0x0, 0x10(%rcx)
180002bc8:     	movb	$0x1, 0x8(%rcx)
180002bcc:     	jmp	0x180002db6 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x826>
180002bd1:     	movq	0x160(%rsp), %rbx
180002bd9:     	movq	0x8(%r8), %r14
180002bdd:     	movq	0x10(%r8), %rsi
180002be1:     	movq	0x18(%r8), %rdi
180002be5:     	movq	0x30(%r14,%r9,8), %rdx
180002bea:     	cmpq	$0x1, (%r14,%rdx,8)
180002bef:     	jne	0x180002bfc <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x66c>
180002bf1:     	movq	0x10(%r14,%rdx,8), %rdx
180002bf6:     	cmpq	%rbx, (%r14,%rdx,8)
180002bfa:     	je	0x180002bbc <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x62c>
180002bfc:     	movq	0x10(%r14,%r9,8), %r11
180002c01:     	movsd	(%rax,%r11,8), %xmm1
180002c07:     	cmpq	$0x0, 0x8(%r14,%r11,8)
180002c0d:     	setne	%bpl
180002c11:     	movq	0x10(%r14,%rbx,8), %r10
180002c16:     	cmpq	$0x0, 0x8(%r14,%r10,8)
180002c1c:     	setne	%dl
180002c1f:     	subsd	(%rax,%r10,8), %xmm1
180002c25:     	andb	%bpl, %dl
180002c28:     	cmpb	$0x1, %dl
180002c2b:     	jne	0x180002c4f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x6bf>
180002c2d:     	movapd	0x778b(%rip), %xmm2     # 0x18000a3c0
180002c35:     	andpd	%xmm1, %xmm2
180002c39:     	ucomisd	0x778f(%rip), %xmm2     # 0x18000a3d0
180002c41:     	jae	0x180002cfd <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x76d>
180002c47:     	xorpd	%xmm2, %xmm2
180002c4b:     	addsd	%xmm2, %xmm1
180002c4f:     	movsd	0x10(%rax,%r11,8), %xmm2
180002c56:     	cmpq	$0x0, 0x18(%r14,%r11,8)
180002c5c:     	subsd	0x10(%rax,%r10,8), %xmm2
180002c63:     	je	0x180002cd1 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x741>
180002c65:     	cmpq	$0x0, 0x18(%r14,%r10,8)
180002c6b:     	je	0x180002cd1 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x741>
180002c6d:     	movapd	0x774b(%rip), %xmm3     # 0x18000a3c0
180002c75:     	andpd	%xmm2, %xmm3
180002c79:     	ucomisd	0x774f(%rip), %xmm3     # 0x18000a3d0
180002c81:     	jae	0x180002d41 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x7b1>
180002c87:     	movapd	%xmm1, %xmm3
180002c8b:     	mulsd	%xmm1, %xmm3
180002c8f:     	ucomisd	0x7739(%rip), %xmm3     # 0x18000a3d0
180002c97:     	setae	%r10b
180002c9b:     	testb	%r10b, %dl
180002c9e:     	jne	0x180002ced <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x75d>
180002ca0:     	xorpd	%xmm4, %xmm4
180002ca4:     	addsd	%xmm4, %xmm2
180002ca8:     	movapd	%xmm2, %xmm4
180002cac:     	mulsd	%xmm2, %xmm4
180002cb0:     	ucomisd	0x7718(%rip), %xmm4     # 0x18000a3d0
180002cb8:     	jae	0x180002ced <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x75d>
180002cba:     	addsd	%xmm4, %xmm3
180002cbe:     	ucomisd	0x770a(%rip), %xmm3     # 0x18000a3d0
180002cc6:     	setae	%r10b
180002cca:     	testb	%r10b, %dl
180002ccd:     	jne	0x180002ced <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x75d>
180002ccf:     	jmp	0x180002d19 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x789>
180002cd1:     	movapd	%xmm1, %xmm3
180002cd5:     	mulsd	%xmm1, %xmm3
180002cd9:     	ucomisd	0x76ef(%rip), %xmm3     # 0x18000a3d0
180002ce1:     	setae	%r10b
180002ce5:     	andb	%r10b, %dl
180002ce8:     	cmpb	$0x1, %dl
180002ceb:     	jne	0x180002d0d <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x77d>
180002ced:     	movb	$0x1, (%rdi)
180002cf0:     	movq	$0x3d090c, 0x18(%rsi)   # imm = 0x3D090C
180002cf8:     	jmp	0x180002d9e <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x80e>
180002cfd:     	movb	$0x1, (%rdi)
180002d00:     	movq	$0x3d090a, 0x18(%rsi)   # imm = 0x3D090A
180002d08:     	jmp	0x180002d9e <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x80e>
180002d0d:     	movapd	%xmm2, %xmm4
180002d11:     	mulsd	%xmm2, %xmm4
180002d15:     	addsd	%xmm4, %xmm3
180002d19:     	xorps	%xmm4, %xmm4
180002d1c:     	sqrtsd	%xmm3, %xmm4
180002d20:     	cmpq	$0x0, 0x18(%r14,%r9,8)
180002d26:     	je	0x180002d73 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x7e3>
180002d28:     	xorpd	%xmm5, %xmm5
180002d2c:     	ucomisd	%xmm5, %xmm3
180002d30:     	jne	0x180002d4e <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x7be>
180002d32:     	jp	0x180002d4e <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x7be>
180002d34:     	movb	$0x1, (%rdi)
180002d37:     	movq	$0x3d090f, 0x18(%rsi)   # imm = 0x3D090F
180002d3f:     	jmp	0x180002d9e <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x80e>
180002d41:     	movb	$0x1, (%rdi)
180002d44:     	movq	$0x3d090b, 0x18(%rsi)   # imm = 0x3D090B
180002d4c:     	jmp	0x180002d9e <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x80e>
180002d4e:     	movsd	0x168(%rsp), %xmm6
180002d57:     	movq	(%r14,%r9,8), %rdx
180002d5b:     	movsd	0x8(%rax,%rdx,8), %xmm3
180002d61:     	addsd	%xmm3, %xmm3
180002d65:     	divsd	%xmm4, %xmm3
180002d69:     	ucomisd	%xmm3, %xmm6
180002d6d:     	jbe	0x180002e25 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x895>
180002d73:     	movsd	0x765d(%rip), %xmm3     # 0x18000a3d8
180002d7b:     	maxsd	%xmm4, %xmm3
180002d7f:     	movapd	%xmm3, %xmm4
180002d83:     	mulsd	%xmm3, %xmm4
180002d87:     	xorpd	%xmm5, %xmm5
180002d8b:     	ucomisd	%xmm5, %xmm4
180002d8f:     	jne	0x180002dec <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x85c>
180002d91:     	jp	0x180002dec <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x85c>
180002d93:     	movb	$0x1, (%rdi)
180002d96:     	movq	$0x3d0915, 0x18(%rsi)   # imm = 0x3D0915
180002d9e:     	movq	$0x0, 0x18(%rcx)
180002da6:     	movq	$0x0, 0x10(%rcx)
180002dae:     	movq	$0x0, 0x8(%rcx)
180002db6:     	movq	$0x0, (%rcx)
180002dbd:     	xorl	%eax, %eax
180002dbf:     	movaps	0xc0(%rsp), %xmm6
180002dc7:     	movaps	0xd0(%rsp), %xmm7
180002dcf:     	movaps	0xe0(%rsp), %xmm8
180002dd8:     	addq	$0xf8, %rsp
180002ddf:     	popq	%rbx
180002de0:     	popq	%rbp
180002de1:     	popq	%rdi
180002de2:     	popq	%rsi
180002de3:     	popq	%r12
180002de5:     	popq	%r13
180002de7:     	popq	%r14
180002de9:     	popq	%r15
180002deb:     	retq
180002dec:     	movsd	0x8(%rax,%rbx,8), %xmm5
180002df2:     	mulsd	0x75e6(%rip), %xmm5     # 0x18000a3e0
180002dfa:     	mulsd	%xmm5, %xmm0
180002dfe:     	divsd	%xmm4, %xmm0
180002e02:     	mulsd	%xmm0, %xmm1
180002e06:     	divsd	%xmm3, %xmm1
180002e0a:     	mulsd	%xmm0, %xmm2
180002e0e:     	divsd	%xmm3, %xmm2
180002e12:     	movsd	%xmm2, 0x10(%rcx)
180002e17:     	movsd	%xmm1, (%rcx)
180002e1b:     	movb	$0x0, 0x18(%rcx)
180002e1f:     	movb	$0x0, 0x8(%rcx)
180002e23:     	jmp	0x180002dbd <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x82d>
180002e25:     	movq	0x20(%r14,%r9,8), %rax
180002e2a:     	testq	%rax, %rax
180002e2d:     	js	0x180002eba <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x92a>
180002e33:     	movq	0x8(%rsi), %rdx
180002e37:     	leaq	0x1(%rdx), %r10
180002e3b:     	movq	%r10, 0x8(%rsi)
180002e3f:     	cmpq	0x10(%rsi), %rdx
180002e43:     	jge	0x180002fd9 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xa49>
180002e49:     	movq	%r9, %r12
180002e4c:     	movq	%rcx, %r13
180002e4f:     	movsd	%xmm6, 0x28(%rsp)
180002e55:     	movq	%rbx, 0x20(%rsp)
180002e5a:     	leaq	0xa0(%rsp), %rcx
180002e62:     	movq	%r8, %rbp
180002e65:     	movq	%rax, %r9
180002e68:     	callq	0x180002b60 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x5d0>
180002e6d:     	cmpb	$0x0, (%rdi)
180002e70:     	jne	0x180002fb4 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xa24>
180002e76:     	cmpb	$0x0, 0xb8(%rsp)
180002e7e:     	setne	%r15b
180002e82:     	cmpb	$0x0, 0xa8(%rsp)
180002e8a:     	setne	%r11b
180002e8e:     	xorpd	%xmm8, %xmm8
180002e93:     	movsd	0xa0(%rsp), %xmm7
180002e9c:     	addsd	%xmm8, %xmm7
180002ea1:     	addsd	0xb0(%rsp), %xmm8
180002eab:     	decq	0x8(%rsi)
180002eaf:     	movq	%r13, %rcx
180002eb2:     	movq	%rbp, %r8
180002eb5:     	movq	%r12, %r9
180002eb8:     	jmp	0x180002ec9 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x939>
180002eba:     	movb	$0x1, %r11b
180002ebd:     	xorpd	%xmm7, %xmm7
180002ec1:     	xorpd	%xmm8, %xmm8
180002ec6:     	movb	$0x1, %r15b
180002ec9:     	movq	0x28(%r14,%r9,8), %rax
180002ece:     	testq	%rax, %rax
180002ed1:     	js	0x180002f66 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x9d6>
180002ed7:     	movq	0x8(%rsi), %rdx
180002edb:     	leaq	0x1(%rdx), %r10
180002edf:     	movq	%r10, 0x8(%rsi)
180002ee3:     	cmpq	0x10(%rsi), %rdx
180002ee7:     	jge	0x180002fe9 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xa59>
180002eed:     	movl	%r15d, %r12d
180002ef0:     	movl	%r11d, %r15d
180002ef3:     	movq	%r9, 0x38(%rsp)
180002ef8:     	movq	%rcx, %r13
180002efb:     	movsd	%xmm6, 0x28(%rsp)
180002f01:     	movq	%rbx, 0x20(%rsp)
180002f06:     	leaq	0x80(%rsp), %rcx
180002f0e:     	movq	%r8, %rbp
180002f11:     	movq	%rax, %r9
180002f14:     	callq	0x180002b60 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x5d0>
180002f19:     	cmpb	$0x0, (%rdi)
180002f1c:     	jne	0x180002fb4 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xa24>
180002f22:     	cmpb	$0x0, 0x98(%rsp)
180002f2a:     	setne	%al
180002f2d:     	cmpb	$0x0, 0x88(%rsp)
180002f35:     	setne	%cl
180002f38:     	addsd	0x80(%rsp), %xmm7
180002f41:     	addsd	0x90(%rsp), %xmm8
180002f4b:     	decq	0x8(%rsi)
180002f4f:     	movl	%r15d, %r11d
180002f52:     	andb	%cl, %r11b
180002f55:     	movl	%r12d, %r15d
180002f58:     	andb	%al, %r15b
180002f5b:     	movq	%r13, %rcx
180002f5e:     	movq	%rbp, %r8
180002f61:     	movq	0x38(%rsp), %r9
180002f66:     	movq	0x38(%r14,%r9,8), %rax
180002f6b:     	testq	%rax, %rax
180002f6e:     	js	0x180003041 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xab1>
180002f74:     	movq	0x8(%rsi), %rdx
180002f78:     	leaq	0x1(%rdx), %r10
180002f7c:     	movq	%r10, 0x8(%rsi)
180002f80:     	cmpq	0x10(%rsi), %rdx
180002f84:     	jge	0x180002ff9 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xa69>
180002f86:     	movl	%r15d, %r12d
180002f89:     	movl	%r11d, %r15d
180002f8c:     	movq	%r9, 0x38(%rsp)
180002f91:     	movq	%rcx, %r13
180002f94:     	movsd	%xmm6, 0x28(%rsp)
180002f9a:     	movq	%rbx, 0x20(%rsp)
180002f9f:     	leaq	0x60(%rsp), %rcx
180002fa4:     	movq	%r8, %rbp
180002fa7:     	movq	%rax, %r9
180002faa:     	callq	0x180002b60 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x5d0>
180002faf:     	cmpb	$0x0, (%rdi)
180002fb2:     	je	0x180003009 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xa79>
180002fb4:     	movq	$0x0, 0x18(%r13)
180002fbc:     	movq	$0x0, 0x10(%r13)
180002fc4:     	movq	$0x0, 0x8(%r13)
180002fcc:     	movq	$0x0, (%r13)
180002fd4:     	jmp	0x180002dbd <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x82d>
180002fd9:     	movb	$0x1, (%rdi)
180002fdc:     	movq	$0x3d0921, 0x18(%rsi)   # imm = 0x3D0921
180002fe4:     	jmp	0x180002d9e <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x80e>
180002fe9:     	movb	$0x1, (%rdi)
180002fec:     	movq	$0x3d0926, 0x18(%rsi)   # imm = 0x3D0926
180002ff4:     	jmp	0x180002d9e <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x80e>
180002ff9:     	movb	$0x1, (%rdi)
180002ffc:     	movq	$0x3d092b, 0x18(%rsi)   # imm = 0x3D092B
180003004:     	jmp	0x180002d9e <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x80e>
180003009:     	cmpb	$0x0, 0x78(%rsp)
18000300e:     	setne	%al
180003011:     	cmpb	$0x0, 0x68(%rsp)
180003016:     	setne	%cl
180003019:     	addsd	0x60(%rsp), %xmm7
18000301f:     	addsd	0x70(%rsp), %xmm8
180003026:     	decq	0x8(%rsi)
18000302a:     	movl	%r15d, %r11d
18000302d:     	andb	%cl, %r11b
180003030:     	movl	%r12d, %r15d
180003033:     	andb	%al, %r15b
180003036:     	movq	%r13, %rcx
180003039:     	movq	%rbp, %r8
18000303c:     	movq	0x38(%rsp), %r9
180003041:     	movq	0x40(%r14,%r9,8), %r9
180003046:     	testq	%r9, %r9
180003049:     	js	0x1800030e2 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xb52>
18000304f:     	movq	0x8(%rsi), %rax
180003053:     	leaq	0x1(%rax), %rdx
180003057:     	movq	%rdx, 0x8(%rsi)
18000305b:     	cmpq	0x10(%rsi), %rax
18000305f:     	jge	0x1800030a5 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xb15>
180003061:     	movl	%r11d, %ebp
180003064:     	movq	%rcx, %r14
180003067:     	movsd	%xmm6, 0x28(%rsp)
18000306d:     	movq	%rbx, 0x20(%rsp)
180003072:     	leaq	0x40(%rsp), %rcx
180003077:     	callq	0x180002b60 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x5d0>
18000307c:     	cmpb	$0x0, (%rdi)
18000307f:     	je	0x1800030b5 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xb25>
180003081:     	movq	$0x0, 0x18(%r14)
180003089:     	movq	$0x0, 0x10(%r14)
180003091:     	movq	$0x0, 0x8(%r14)
180003099:     	movq	$0x0, (%r14)
1800030a0:     	jmp	0x180002dbd <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x82d>
1800030a5:     	movb	$0x1, (%rdi)
1800030a8:     	movq	$0x3d0930, 0x18(%rsi)   # imm = 0x3D0930
1800030b0:     	jmp	0x180002d9e <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x80e>
1800030b5:     	cmpb	$0x0, 0x58(%rsp)
1800030ba:     	setne	%al
1800030bd:     	cmpb	$0x0, 0x48(%rsp)
1800030c2:     	setne	%cl
1800030c5:     	addsd	0x40(%rsp), %xmm7
1800030cb:     	addsd	0x50(%rsp), %xmm8
1800030d2:     	decq	0x8(%rsi)
1800030d6:     	movl	%ebp, %r11d
1800030d9:     	andb	%cl, %r11b
1800030dc:     	andb	%al, %r15b
1800030df:     	movq	%r14, %rcx
1800030e2:     	movb	%r15b, 0x18(%rcx)
1800030e6:     	movsd	%xmm8, 0x10(%rcx)
1800030ec:     	movb	%r11b, 0x8(%rcx)
1800030f0:     	movsd	%xmm7, (%rcx)
1800030f4:     	jmp	0x180002dbd <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x82d>
1800030f9:     	nopl	(%rax)
