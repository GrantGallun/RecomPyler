# barnes-final first-recursive-call: [0x180002e4f, 0x180002e6d)
# Source/call-target-bound static range; padding included; never cycles.
180002e4f:     	movsd	%xmm6, 0x28(%rsp)
180002e55:     	movq	%rbx, 0x20(%rsp)
180002e5a:     	leaq	0xa0(%rsp), %rcx
180002e62:     	movq	%r8, %rbp
180002e65:     	movq	%rax, %r9
180002e68:     	callq	0x180002b60 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x5d0>
