# barnes-current update-loop-item: [0x180002af3, 0x180002b22)
# Source/call-target-bound static range; padding included; never cycles.
180002af3:     	movq	0x78(%rsp), %rdx
180002af8:     	cmpq	(%rbp,%rdx), %rcx
180002afd:     	jge	0x180002c17 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x6a7>
180002b03:     	movq	0x80(%rsp), %rdx
180002b0b:     	movq	0x10(%rbp,%rdx), %r8
180002b10:     	addq	%rcx, %r8
180002b13:     	leaq	(%rdi,%r8,8), %r9
180002b17:     	sarq	$0x3f, %r8
180002b1b:     	andq	%r12, %r8
180002b1e:     	movq	(%r9,%r8,8), %r8
