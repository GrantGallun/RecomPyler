# barnes-final insert-loop-item: [0x18000288d, 0x18000289b)
# Source/call-target-bound static range; padding included; never cycles.
18000288d:     	movq	0x10(%r13,%r14), %rcx
180002892:     	leaq	(%r13,%rcx,8), %rcx
180002897:     	movq	(%rcx,%rdi,8), %rcx
