# barnes-final force-loop-item: [0x180002939, 0x180002952)
# Source/call-target-bound static range; padding included; never cycles.
180002939:     	cmpq	(%r13,%r14), %rbx
18000293e:     	jge	0x180002a44 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4b4>
180002944:     	movq	0x10(%r13,%r14), %rax
180002949:     	leaq	(%r13,%rax,8), %rax
18000294e:     	movq	(%rax,%rbx,8), %rdi
