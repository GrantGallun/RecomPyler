# barnes-current insert-loop-item: [0x1800028aa, 0x1800028c1)
# Source/call-target-bound static range; padding included; never cycles.
1800028aa:     	movq	0x10(%rbp,%rsi), %rcx
1800028af:     	addq	%r14, %rcx
1800028b2:     	leaq	(%rdi,%rcx,8), %rdx
1800028b6:     	sarq	$0x3f, %rcx
1800028ba:     	andq	%r12, %rcx
1800028bd:     	movq	(%rdx,%rcx,8), %rcx
