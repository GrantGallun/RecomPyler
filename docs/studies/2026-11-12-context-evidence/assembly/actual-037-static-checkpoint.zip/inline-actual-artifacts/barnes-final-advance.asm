# barnes-final advance: [0x1800025f0, 0x180002b60)
# Source/call-target-bound static range; padding included; never cycles.
1800025f0:     	pushq	%r15
1800025f2:     	pushq	%r14
1800025f4:     	pushq	%r13
1800025f6:     	pushq	%r12
1800025f8:     	pushq	%rsi
1800025f9:     	pushq	%rdi
1800025fa:     	pushq	%rbp
1800025fb:     	pushq	%rbx
1800025fc:     	subq	$0xc8, %rsp
180002603:     	movapd	%xmm8, 0xb0(%rsp)
18000260d:     	movaps	%xmm7, 0xa0(%rsp)
180002615:     	movapd	%xmm6, 0x90(%rsp)
18000261e:     	movq	0x140(%rsp), %rsi
180002626:     	movabsq	$-0x20000000000001, %rax # imm = 0xFFDFFFFFFFFFFFFF
180002630:     	movabsq	$-0x40000000000001, %r10 # imm = 0xFFBFFFFFFFFFFFFF
18000263a:     	movq	$0x0, 0x60(%rsp)
180002643:     	movq	$0x0, 0x70(%rsp)
18000264c:     	movq	0x10(%r8), %rbp
180002650:     	movq	0x18(%r8), %r15
180002654:     	leaq	(%rsi,%rax), %r11
180002658:     	cmpq	%r10, %r11
18000265b:     	jb	0x18000266d <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xdd>
18000265d:     	movq	0x148(%rsp), %rdi
180002665:     	addq	%rdi, %rax
180002668:     	cmpq	%r10, %rax
18000266b:     	jae	0x1800026af <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x11f>
18000266d:     	movb	$0x1, (%r15)
180002671:     	movq	$0x4, 0x18(%rbp)
180002679:     	xorl	%eax, %eax
18000267b:     	movq	$0x0, (%rcx)
180002682:     	movaps	0x90(%rsp), %xmm6
18000268a:     	movaps	0xa0(%rsp), %xmm7
180002692:     	movaps	0xb0(%rsp), %xmm8
18000269b:     	addq	$0xc8, %rsp
1800026a2:     	popq	%rbx
1800026a3:     	popq	%rbp
1800026a4:     	popq	%rdi
1800026a5:     	popq	%rsi
1800026a6:     	popq	%r12
1800026a8:     	popq	%r13
1800026aa:     	popq	%r14
1800026ac:     	popq	%r15
1800026ae:     	retq
1800026af:     	movq	0x20(%r8), %r10
1800026b3:     	movq	(%rbp), %r11
1800026b7:     	leaq	0x4(%r11), %rax
1800026bb:     	cmpq	%r10, %rax
1800026be:     	jle	0x1800026c6 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x136>
1800026c0:     	movb	$0x2, (%r15)
1800026c4:     	jmp	0x180002679 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xe9>
1800026c6:     	movq	(%r8), %r12
1800026c9:     	movq	0x8(%r8), %r13
1800026cd:     	movq	%rax, (%rbp)
1800026d1:     	xorl	%eax, %eax
1800026d3:     	cmpb	$0x0, (%r15)
1800026d7:     	jne	0x18000267b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xeb>
1800026d9:     	cvtsi2sd	%rsi, %xmm0
1800026de:     	movsd	0x7cca(%rip), %xmm1     # 0x18000a3b0
1800026e6:     	mulsd	%xmm1, %xmm0
1800026ea:     	cvtsi2sd	%rdi, %xmm2
1800026ef:     	mulsd	%xmm1, %xmm2
1800026f3:     	movsd	%xmm0, 0x10(%r12,%r11,8)
1800026fa:     	movsd	%xmm2, 0x18(%r12,%r11,8)
180002701:     	movsd	%xmm0, 0x8(%r12,%r11,8)
180002708:     	movsd	%xmm2, (%r12,%r11,8)
18000270e:     	cmpb	$0x0, (%r15)
180002712:     	jne	0x18000267b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xeb>
180002718:     	movq	(%rbp), %rsi
18000271c:     	leaq	0xb(%rsi), %rdi
180002720:     	cmpq	%r10, %rdi
180002723:     	jle	0x18000272e <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x19e>
180002725:     	movb	$0x2, (%r15)
180002729:     	jmp	0x18000267b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xeb>
18000272e:     	movq	%rdi, (%rbp)
180002732:     	cmpb	$0x0, (%r15)
180002736:     	jne	0x18000267b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xeb>
18000273c:     	movq	%r11, (%r13,%rsi,8)
180002741:     	movq	$0x4, 0x8(%r13,%rsi,8)
18000274a:     	movq	(%rbp), %r11
18000274e:     	cmpq	%r10, %r11
180002751:     	movq	%r11, %rdi
180002754:     	jle	0x180002760 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1d0>
180002756:     	movb	$0x2, (%r15)
18000275a:     	movq	(%rbp), %r11
18000275e:     	xorl	%edi, %edi
180002760:     	leaq	0x3(%r11), %rbx
180002764:     	cmpq	%r10, %rbx
180002767:     	jg	0x180002725 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x195>
180002769:     	movq	%rbx, (%rbp)
18000276d:     	cmpb	$0x0, (%r15)
180002771:     	jne	0x18000267b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xeb>
180002777:     	movq	%r11, %rax
18000277a:     	sarq	$0x3f, %rax
18000277e:     	andq	%r10, %rax
180002781:     	leaq	(%r13,%r11,8), %rbx
180002786:     	movq	$0x0, (%rbx,%rax,8)
18000278e:     	xorl	%eax, %eax
180002790:     	cmpq	$-0x1, %r11
180002794:     	movl	$0x0, %r14d
18000279a:     	cmovlq	%r10, %r14
18000279e:     	movq	$0x0, 0x8(%rbx,%r14,8)
1800027a7:     	cmpq	$-0x2, %r11
1800027ab:     	movl	$0x0, %r14d
1800027b1:     	cmovlq	%r10, %r14
1800027b5:     	movq	%rdi, 0x10(%rbx,%r14,8)
1800027ba:     	cmpb	$0x0, (%r15)
1800027be:     	jne	0x18000267b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xeb>
1800027c4:     	leaq	(%r13,%rsi,8), %rdi
1800027c9:     	movq	%r11, 0x30(%rdi)
1800027cd:     	movq	$0x0, 0x18(%rdi)
1800027d5:     	movq	(%rbp), %r11
1800027d9:     	leaq	0x4(%r11), %rbx
1800027dd:     	cmpq	%r10, %rbx
1800027e0:     	jg	0x180002725 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x195>
1800027e6:     	movq	%r8, 0x58(%rsp)
1800027eb:     	movq	%rdx, 0x50(%rsp)
1800027f0:     	movq	%rbx, (%rbp)
1800027f4:     	cmpb	$0x0, (%r15)
1800027f8:     	jne	0x18000267b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xeb>
1800027fe:     	movq	%rcx, 0x40(%rsp)
180002803:     	movq	$0x0, (%r12,%r11,8)
18000280b:     	movq	$0x1, 0x8(%r13,%r11,8)
180002814:     	movq	$0x0, 0x10(%r12,%r11,8)
18000281d:     	movq	$0x1, 0x18(%r13,%r11,8)
180002826:     	cmpb	$0x0, (%r15)
18000282a:     	jne	0x180002b55 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x5c5>
180002830:     	movq	%r9, %r14
180002833:     	movq	%r11, 0x10(%rdi)
180002837:     	movq	$0x0, 0x48(%r12,%rsi,8)
180002840:     	movq	$0x1, 0x50(%rdi)
180002848:     	movq	$-0x1, 0x20(%rdi)
180002850:     	movq	$-0x1, 0x28(%rdi)
180002858:     	movq	$-0x1, 0x38(%rdi)
180002860:     	movq	$-0x1, 0x40(%rdi)
180002868:     	cmpb	$0x0, (%r15)
18000286c:     	jne	0x180002b55 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x5c5>
180002872:     	cmpq	$0x0, (%r13,%r14,8)
180002878:     	jle	0x180002901 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x371>
18000287e:     	movq	0x8(%rbp), %rax
180002882:     	shlq	$0x3, %r14
180002886:     	xorl	%edi, %edi
180002888:     	leaq	0x4f(%rsp), %rbx
18000288d:     	movq	0x10(%r13,%r14), %rcx
180002892:     	leaq	(%r13,%rcx,8), %rcx
180002897:     	movq	(%rcx,%rdi,8), %rcx
18000289b:     	leaq	0x1(%rax), %rdx
18000289f:     	movq	%rdx, 0x8(%rbp)
1800028a3:     	cmpq	0x10(%rbp), %rax
1800028a7:     	jge	0x180002a33 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4a3>
1800028ad:     	movq	%rcx, 0x28(%rsp)
1800028b2:     	movq	%rsi, 0x20(%rsp)
1800028b7:     	movq	$-0x1, 0x30(%rsp)
1800028c0:     	movq	%rbx, %rcx
1800028c3:     	leaq	0x80(%rsp), %rdx
1800028cb:     	movq	0x58(%rsp), %r8
1800028d0:     	xorl	%r9d, %r9d
1800028d3:     	callq	0x180003100 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xb70>
1800028d8:     	testl	%eax, %eax
1800028da:     	jne	0x180002a29 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x499>
1800028e0:     	cmpb	$0x0, (%r15)
1800028e4:     	jne	0x180002b53 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x5c3>
1800028ea:     	incq	%rdi
1800028ed:     	movq	0x8(%rbp), %rax
1800028f1:     	decq	%rax
1800028f4:     	movq	%rax, 0x8(%rbp)
1800028f8:     	cmpq	(%r13,%r14), %rdi
1800028fd:     	jl	0x18000288d <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2fd>
1800028ff:     	jmp	0x180002905 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x375>
180002901:     	shlq	$0x3, %r14
180002905:     	movsd	0x138(%rsp), %xmm6
18000290e:     	movsd	0x130(%rsp), %xmm7
180002917:     	xorl	%ebx, %ebx
180002919:     	xorpd	%xmm8, %xmm8
18000291e:     	jmp	0x180002939 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3a9>
180002920:     	movb	$0x1, (%r15)
180002924:     	movq	$0x4c4b43, 0x18(%rbp)   # imm = 0x4C4B43
18000292c:     	incq	%rbx
18000292f:     	cmpb	$0x0, (%r15)
180002933:     	jne	0x180002b55 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x5c5>
180002939:     	cmpq	(%r13,%r14), %rbx
18000293e:     	jge	0x180002a44 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4b4>
180002944:     	movq	0x10(%r13,%r14), %rax
180002949:     	leaq	(%r13,%rax,8), %rax
18000294e:     	movq	(%rax,%rbx,8), %rdi
180002952:     	movq	0x8(%rbp), %rax
180002956:     	leaq	0x1(%rax), %rcx
18000295a:     	movq	%rcx, 0x8(%rbp)
18000295e:     	cmpq	0x10(%rbp), %rax
180002962:     	jge	0x180002b47 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x5b7>
180002968:     	movsd	%xmm7, 0x28(%rsp)
18000296e:     	movq	%rdi, 0x20(%rsp)
180002973:     	leaq	0x60(%rsp), %rcx
180002978:     	leaq	0x88(%rsp), %rdx
180002980:     	movq	0x58(%rsp), %r8
180002985:     	movq	%rsi, %r9
180002988:     	callq	0x180002b60 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x5d0>
18000298d:     	testl	%eax, %eax
18000298f:     	jne	0x180002a29 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x499>
180002995:     	xorl	%eax, %eax
180002997:     	cmpb	$0x0, (%r15)
18000299b:     	jne	0x180002b55 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x5c5>
1800029a1:     	movsd	0x60(%rsp), %xmm1
1800029a7:     	movsd	0x70(%rsp), %xmm0
1800029ad:     	decq	0x8(%rbp)
1800029b1:     	movsd	0x8(%r12,%rdi,8), %xmm2
1800029b8:     	ucomisd	%xmm8, %xmm2
1800029bd:     	jne	0x1800029c5 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x435>
1800029bf:     	jnp	0x180002920 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x390>
1800029c5:     	movq	(%r13,%rdi,8), %rcx
1800029ca:     	divsd	%xmm2, %xmm1
1800029ce:     	addsd	(%r12,%rcx,8), %xmm1
1800029d4:     	movsd	%xmm1, (%r12,%rcx,8)
1800029da:     	movq	$0x0, 0x8(%r13,%rcx,8)
1800029e3:     	movsd	0x8(%r12,%rdi,8), %xmm1
1800029ea:     	ucomisd	%xmm8, %xmm1
1800029ef:     	jne	0x180002a04 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x474>
1800029f1:     	jp	0x180002a04 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x474>
1800029f3:     	movb	$0x1, (%r15)
1800029f7:     	movq	$0x4c4b44, 0x18(%rbp)   # imm = 0x4C4B44
1800029ff:     	jmp	0x18000292c <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x39c>
180002a04:     	movq	(%r13,%rdi,8), %rcx
180002a09:     	divsd	%xmm1, %xmm0
180002a0d:     	addsd	0x10(%r12,%rcx,8), %xmm0
180002a14:     	movsd	%xmm0, 0x10(%r12,%rcx,8)
180002a1b:     	movq	$0x0, 0x18(%r13,%rcx,8)
180002a24:     	jmp	0x18000292c <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x39c>
180002a29:     	movq	0x50(%rsp), %rcx
180002a2e:     	jmp	0x18000267b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xeb>
180002a33:     	movb	$0x1, (%r15)
180002a37:     	movq	$0x9, 0x18(%rbp)
180002a3f:     	jmp	0x180002b53 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x5c3>
180002a44:     	xorl	%eax, %eax
180002a46:     	xorl	%ecx, %ecx
180002a48:     	cmpq	(%r13,%r14), %rcx
180002a4d:     	jge	0x180002b55 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x5c5>
180002a53:     	movq	0x10(%r13,%r14), %rdx
180002a58:     	leaq	(%r13,%rdx,8), %rdx
180002a5d:     	movq	(%rdx,%rcx,8), %rdx
180002a61:     	incq	%rcx
180002a64:     	movq	(%r13,%rdx,8), %r8
180002a69:     	movq	0x18(%r13,%rdx,8), %r9
180002a6e:     	movsd	(%r12,%r8,8), %xmm0
180002a74:     	mulsd	%xmm6, %xmm0
180002a78:     	addsd	(%r12,%r9,8), %xmm0
180002a7e:     	movsd	%xmm0, (%r12,%r9,8)
180002a84:     	movq	$0x0, 0x8(%r13,%r9,8)
180002a8d:     	movq	(%r13,%rdx,8), %r8
180002a92:     	movq	0x18(%r13,%rdx,8), %r9
180002a97:     	movsd	0x10(%r12,%r8,8), %xmm0
180002a9e:     	mulsd	%xmm6, %xmm0
180002aa2:     	addsd	0x10(%r12,%r9,8), %xmm0
180002aa9:     	movsd	%xmm0, 0x10(%r12,%r9,8)
180002ab0:     	movq	$0x0, 0x18(%r13,%r9,8)
180002ab9:     	movq	0x10(%r13,%rdx,8), %r8
180002abe:     	movq	0x18(%r13,%rdx,8), %r9
180002ac3:     	movsd	(%r12,%r9,8), %xmm0
180002ac9:     	mulsd	%xmm6, %xmm0
180002acd:     	addsd	(%r12,%r8,8), %xmm0
180002ad3:     	movsd	%xmm0, (%r12,%r8,8)
180002ad9:     	movq	$0x0, 0x8(%r13,%r8,8)
180002ae2:     	movq	0x10(%r13,%rdx,8), %r8
180002ae7:     	movq	0x18(%r13,%rdx,8), %r9
180002aec:     	movsd	0x10(%r12,%r9,8), %xmm0
180002af3:     	mulsd	%xmm6, %xmm0
180002af7:     	addsd	0x10(%r12,%r8,8), %xmm0
180002afe:     	movsd	%xmm0, 0x10(%r12,%r8,8)
180002b05:     	movq	$0x0, 0x18(%r13,%r8,8)
180002b0e:     	movq	(%r13,%rdx,8), %r8
180002b13:     	movq	$0x0, (%r12,%r8,8)
180002b1b:     	movq	$0x1, 0x8(%r13,%r8,8)
180002b24:     	movq	(%r13,%rdx,8), %rdx
180002b29:     	movq	$0x0, 0x10(%r12,%rdx,8)
180002b32:     	movq	$0x1, 0x18(%r13,%rdx,8)
180002b3b:     	cmpb	$0x0, (%r15)
180002b3f:     	je	0x180002a48 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4b8>
180002b45:     	jmp	0x180002b55 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x5c5>
180002b47:     	movb	$0x1, (%r15)
180002b4b:     	movq	$0xd, 0x18(%rbp)
180002b53:     	xorl	%eax, %eax
180002b55:     	movq	0x40(%rsp), %rcx
180002b5a:     	jmp	0x18000267b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xeb>
180002b5f:     	nop
