
D:\Code\Datathon\recompyler-codex-20261111\wave9-native\results-inline\cache\raytrace\final\recompyler\rcaotr_7508da57ea552f418d6e0f1d.cp314-win_amd64.pyd:	file format coff-x86-64

Disassembly of section .text:

0000000180001000 <.text>:
180001000:     	movl	$0x1, %eax
180001005:     	lock
180001006:     	xaddq	%rax, (%rcx)
18000100a:     	incq	%rax
18000100d:     	retq
18000100e:     	nop
180001010:     	movq	$-0x1, %rax
180001017:     	lock
180001018:     	xaddq	%rax, (%rcx)
18000101c:     	decq	%rax
18000101f:     	retq
180001020:     	movq	%rdx, %rax
180001023:     	xorl	%edx, %edx
180001025:     	lock
180001026:     	cmpxchgq	%r8, (%rcx)
18000102a:     	sete	%dl
18000102d:     	movq	%rax, (%r9)
180001030:     	movl	%edx, %eax
180001032:     	retq
180001033:     	nopw	%cs:(%rax,%rax)
18000103d:     	nopl	(%rax)
180001040:     	movq	0x18(%rcx), %rax
180001044:     	retq
180001045:     	nopw	%cs:(%rax,%rax)
18000104f:     	nop
180001050:     	testq	%rcx, %rcx
180001053:     	je	0x180001059 <.text+0x59>
180001055:     	lock
180001056:     	incq	(%rcx)
180001059:     	retq
18000105a:     	nopw	(%rax,%rax)
180001060:     	testq	%rcx, %rcx
180001063:     	je	0x18000106b <.text+0x6b>
180001065:     	lock
180001066:     	decq	(%rcx)
180001069:     	je	0x18000106c <.text+0x6c>
18000106b:     	retq
18000106c:     	jmp	0x180007ca0 <numba_list_iter_next+0x160>
180001071:     	nopw	%cs:(%rax,%rax)
18000107b:     	nopl	(%rax,%rax)
180001080:     	leaq	0x8439(%rip), %rax      # 0x1800094c0
180001087:     	movq	%rax, (%rdx)
18000108a:     	movl	$0x1, %eax
18000108f:     	retq
180001090:     	pushq	%r14
180001092:     	pushq	%rsi
180001093:     	pushq	%rdi
180001094:     	pushq	%rbx
180001095:     	subq	$0x68, %rsp
180001099:     	movq	%rcx, %rsi
18000109c:     	movq	0xf8(%rsp), %rax
1800010a4:     	movq	0xe0(%rsp), %rcx
1800010ac:     	movq	0xc8(%rsp), %r10
1800010b4:     	movq	0xb0(%rsp), %r11
1800010bc:     	movq	0xf0(%rsp), %rdi
1800010c4:     	movq	0xd8(%rsp), %rbx
1800010cc:     	movq	$0x0, 0x30(%rsp)
1800010d5:     	movq	0xc0(%rsp), %r14
1800010dd:     	xorq	%r9, %r14
1800010e0:     	xorq	$0x4, %rbx
1800010e4:     	orq	%r14, %rbx
1800010e7:     	xorq	$0x1, %rdi
1800010eb:     	xorq	$0x8, %r11
1800010ef:     	orq	%rdi, %r11
1800010f2:     	orq	%rbx, %r11
1800010f5:     	xorq	$0x8, %r10
1800010f9:     	xorq	$0x8, %rcx
1800010fd:     	orq	%r10, %rcx
180001100:     	orq	%r11, %rcx
180001103:     	xorq	$0x1, %rax
180001107:     	orq	%rcx, %rax
18000110a:     	jne	0x180001185 <.text+0x185>
18000110c:     	movq	%rdx, %rdi
18000110f:     	movq	0x108(%rsp), %rcx
180001117:     	movq	0x100(%rsp), %rax
18000111f:     	movq	0xe8(%rsp), %rdx
180001127:     	movq	0xd0(%rsp), %r10
18000112f:     	movq	0xb8(%rsp), %r11
180001137:     	movq	%r8, 0x40(%rsp)
18000113c:     	movq	%r11, 0x48(%rsp)
180001141:     	movq	%r10, 0x50(%rsp)
180001146:     	movq	%rdx, 0x58(%rsp)
18000114b:     	movq	%r9, 0x60(%rsp)
180001150:     	movq	$0x0, 0x38(%rsp)
180001159:     	movq	%rcx, 0x20(%rsp)
18000115e:     	leaq	0x38(%rsp), %rcx
180001163:     	leaq	0x30(%rsp), %rdx
180001168:     	leaq	0x40(%rsp), %r8
18000116d:     	movq	%rax, %r9
180001170:     	callq	0x1800019e0 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x60>
180001175:     	testl	%eax, %eax
180001177:     	jne	0x18000119e <.text+0x19e>
180001179:     	movq	0x38(%rsp), %rax
18000117e:     	movq	%rax, (%rsi)
180001181:     	xorl	%eax, %eax
180001183:     	jmp	0x180001194 <.text+0x194>
180001185:     	leaq	0x83f4(%rip), %rax      # 0x180009580
18000118c:     	movq	%rax, (%rdx)
18000118f:     	movl	$0x1, %eax
180001194:     	addq	$0x68, %rsp
180001198:     	popq	%rbx
180001199:     	popq	%rdi
18000119a:     	popq	%rsi
18000119b:     	popq	%r14
18000119d:     	retq
18000119e:     	movq	0x30(%rsp), %rcx
1800011a3:     	movq	%rcx, (%rdi)
1800011a6:     	jmp	0x180001194 <.text+0x194>
1800011a8:     	nopl	(%rax,%rax)
1800011b0:     	pushq	%r15
1800011b2:     	pushq	%r14
1800011b4:     	pushq	%r13
1800011b6:     	pushq	%r12
1800011b8:     	pushq	%rsi
1800011b9:     	pushq	%rdi
1800011ba:     	pushq	%rbp
1800011bb:     	pushq	%rbx
1800011bc:     	subq	$0x218, %rsp            # imm = 0x218
1800011c3:     	movq	%rdx, %rcx
1800011c6:     	leaq	0xe0(%rsp), %rax
1800011ce:     	movq	%rax, 0x48(%rsp)
1800011d3:     	leaq	0xe8(%rsp), %rax
1800011db:     	movq	%rax, 0x40(%rsp)
1800011e0:     	leaq	0xf0(%rsp), %rax
1800011e8:     	movq	%rax, 0x38(%rsp)
1800011ed:     	leaq	0xf8(%rsp), %rax
1800011f5:     	movq	%rax, 0x30(%rsp)
1800011fa:     	leaq	0x100(%rsp), %rax
180001202:     	movq	%rax, 0x28(%rsp)
180001207:     	leaq	0x108(%rsp), %rax
18000120f:     	movq	%rax, 0x20(%rsp)
180001214:     	leaq	0x838d(%rip), %rdx      # 0x1800095a8
18000121b:     	movl	$0x6, %r8d
180001221:     	movl	$0x6, %r9d
180001227:     	callq	0x180007e51 <numba_list_iter_next+0x311>
18000122c:     	testl	%eax, %eax
18000122e:     	movq	$0x0, 0x98(%rsp)
18000123a:     	je	0x180001707 <.text+0x707>
180001240:     	cmpq	$0x0, 0xfa48(%rip)      # 0x180010c90
180001248:     	je	0x180001637 <.text+0x637>
18000124e:     	movq	0x108(%rsp), %rcx
180001256:     	xorps	%xmm0, %xmm0
180001259:     	movaps	%xmm0, 0x1d0(%rsp)
180001261:     	movaps	%xmm0, 0x1e0(%rsp)
180001269:     	movaps	%xmm0, 0x1f0(%rsp)
180001271:     	movq	$0x0, 0x200(%rsp)
18000127d:     	leaq	0x1d0(%rsp), %rdx
180001285:     	callq	0x180006b10 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5190>
18000128a:     	testl	%eax, %eax
18000128c:     	jne	0x18000164f <.text+0x64f>
180001292:     	cmpq	$0x8, 0x1e8(%rsp)
18000129b:     	jne	0x18000164f <.text+0x64f>
1800012a1:     	movq	0x1d0(%rsp), %rsi
1800012a9:     	movq	0x1f0(%rsp), %rdi
1800012b1:     	movq	0x1f8(%rsp), %rbx
1800012b9:     	movq	0x200(%rsp), %r15
1800012c1:     	movq	0x100(%rsp), %rcx
1800012c9:     	xorps	%xmm0, %xmm0
1800012cc:     	movaps	%xmm0, 0x190(%rsp)
1800012d4:     	movaps	%xmm0, 0x1a0(%rsp)
1800012dc:     	movaps	%xmm0, 0x1b0(%rsp)
1800012e4:     	movq	$0x0, 0x1c0(%rsp)
1800012f0:     	leaq	0x190(%rsp), %rdx
1800012f8:     	callq	0x180006b10 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5190>
1800012fd:     	testl	%eax, %eax
1800012ff:     	jne	0x180001667 <.text+0x667>
180001305:     	cmpq	$0x8, 0x1a8(%rsp)
18000130e:     	jne	0x180001667 <.text+0x667>
180001314:     	movq	0x190(%rsp), %r14
18000131c:     	movq	0x1b0(%rsp), %r13
180001324:     	movq	0x1b8(%rsp), %rbp
18000132c:     	movq	0x1c0(%rsp), %r12
180001334:     	movq	0xf8(%rsp), %rcx
18000133c:     	xorps	%xmm0, %xmm0
18000133f:     	movaps	%xmm0, 0x150(%rsp)
180001347:     	movaps	%xmm0, 0x160(%rsp)
18000134f:     	movaps	%xmm0, 0x170(%rsp)
180001357:     	movq	$0x0, 0x180(%rsp)
180001363:     	leaq	0x150(%rsp), %rdx
18000136b:     	callq	0x180006b10 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5190>
180001370:     	testl	%eax, %eax
180001372:     	jne	0x18000167f <.text+0x67f>
180001378:     	cmpq	$0x8, 0x168(%rsp)
180001381:     	jne	0x18000167f <.text+0x67f>
180001387:     	movq	%r12, 0xd8(%rsp)
18000138f:     	movq	0x150(%rsp), %r12
180001397:     	movq	0x170(%rsp), %rax
18000139f:     	movq	%rax, 0xd0(%rsp)
1800013a7:     	movq	0x178(%rsp), %rax
1800013af:     	movq	%rax, 0xc8(%rsp)
1800013b7:     	movq	0x180(%rsp), %rax
1800013bf:     	movq	%rax, 0xc0(%rsp)
1800013c7:     	movq	0xf0(%rsp), %rcx
1800013cf:     	xorps	%xmm0, %xmm0
1800013d2:     	movaps	%xmm0, 0x110(%rsp)
1800013da:     	movaps	%xmm0, 0x120(%rsp)
1800013e2:     	movaps	%xmm0, 0x130(%rsp)
1800013ea:     	movq	$0x0, 0x140(%rsp)
1800013f6:     	leaq	0x110(%rsp), %rdx
1800013fe:     	callq	0x180006b10 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5190>
180001403:     	testl	%eax, %eax
180001405:     	jne	0x180001694 <.text+0x694>
18000140b:     	cmpq	$0x1, 0x128(%rsp)
180001414:     	jne	0x180001694 <.text+0x694>
18000141a:     	movq	%rbp, 0xa0(%rsp)
180001422:     	movq	%r13, 0xa8(%rsp)
18000142a:     	movq	%r12, 0x88(%rsp)
180001432:     	movq	%r15, 0xb0(%rsp)
18000143a:     	movq	%rdi, 0xb8(%rsp)
180001442:     	movq	0x110(%rsp), %rax
18000144a:     	movq	%rax, 0x80(%rsp)
180001452:     	movq	0x130(%rsp), %rdi
18000145a:     	movq	0x138(%rsp), %r12
180001462:     	movq	0x140(%rsp), %r15
18000146a:     	movq	0xe8(%rsp), %rcx
180001472:     	callq	0x180007e57 <numba_list_iter_next+0x317>
180001477:     	testq	%rax, %rax
18000147a:     	movq	%r14, 0x90(%rsp)
180001482:     	je	0x1800016a9 <.text+0x6a9>
180001488:     	movq	%rax, %rbp
18000148b:     	movq	%rax, %rcx
18000148e:     	callq	0x180007e5d <numba_list_iter_next+0x31d>
180001493:     	movq	%rax, %r13
180001496:     	movq	%rbp, %rcx
180001499:     	callq	0x180007e63 <numba_list_iter_next+0x323>
18000149e:     	movq	%rbx, %r14
1800014a1:     	callq	0x180007e69 <numba_list_iter_next+0x329>
1800014a6:     	testq	%rax, %rax
1800014a9:     	jne	0x1800016d2 <.text+0x6d2>
1800014af:     	movq	%rsi, %rbx
1800014b2:     	movq	0xe0(%rsp), %rcx
1800014ba:     	callq	0x180007e57 <numba_list_iter_next+0x317>
1800014bf:     	testq	%rax, %rax
1800014c2:     	je	0x1800016bf <.text+0x6bf>
1800014c8:     	movq	%rax, %rsi
1800014cb:     	movq	%rax, %rcx
1800014ce:     	callq	0x180007e5d <numba_list_iter_next+0x31d>
1800014d3:     	movq	%rax, %rbp
1800014d6:     	movq	%rsi, %rcx
1800014d9:     	callq	0x180007e63 <numba_list_iter_next+0x323>
1800014de:     	callq	0x180007e69 <numba_list_iter_next+0x329>
1800014e3:     	testq	%rax, %rax
1800014e6:     	movq	%rbx, %rsi
1800014e9:     	jne	0x1800016d2 <.text+0x6d2>
1800014ef:     	movq	%rbp, 0x78(%rsp)
1800014f4:     	movq	%r13, 0x70(%rsp)
1800014f9:     	movq	%r15, 0x68(%rsp)
1800014fe:     	movq	%r12, 0x60(%rsp)
180001503:     	movq	%rdi, 0x58(%rsp)
180001508:     	movq	0xc0(%rsp), %rax
180001510:     	movq	%rax, 0x50(%rsp)
180001515:     	movq	0xc8(%rsp), %rax
18000151d:     	movq	%rax, 0x48(%rsp)
180001522:     	movq	0xd0(%rsp), %rax
18000152a:     	movq	%rax, 0x40(%rsp)
18000152f:     	movq	0xd8(%rsp), %rax
180001537:     	movq	%rax, 0x38(%rsp)
18000153c:     	movq	0xa0(%rsp), %rax
180001544:     	movq	%rax, 0x30(%rsp)
180001549:     	movq	0xa8(%rsp), %rax
180001551:     	movq	%rax, 0x28(%rsp)
180001556:     	movq	0xb0(%rsp), %rax
18000155e:     	movq	%rax, 0x20(%rsp)
180001563:     	leaq	0x210(%rsp), %rcx
18000156b:     	leaq	0x98(%rsp), %rdx
180001573:     	movq	0xb8(%rsp), %r8
18000157b:     	movq	%r14, %r9
18000157e:     	callq	0x180001090 <.text+0x90>
180001583:     	movl	%eax, %ebp
180001585:     	movq	0x98(%rsp), %rbx
18000158d:     	movq	%rsi, %rcx
180001590:     	callq	0x180001060 <.text+0x60>
180001595:     	movq	0x90(%rsp), %rcx
18000159d:     	callq	0x180001060 <.text+0x60>
1800015a2:     	movq	0x88(%rsp), %rcx
1800015aa:     	callq	0x180001060 <.text+0x60>
1800015af:     	movq	0x80(%rsp), %rcx
1800015b7:     	callq	0x180001060 <.text+0x60>
1800015bc:     	testl	%ebp, %ebp
1800015be:     	jne	0x1800015e6 <.text+0x5e6>
1800015c0:     	movq	0x7d19(%rip), %rsi      # 0x1800092e0
1800015c7:     	movq	%rsi, %rcx
1800015ca:     	callq	0x180007e6f <numba_list_iter_next+0x32f>
1800015cf:     	movq	%rsi, %rax
1800015d2:     	addq	$0x218, %rsp            # imm = 0x218
1800015d9:     	popq	%rbx
1800015da:     	popq	%rbp
1800015db:     	popq	%rdi
1800015dc:     	popq	%rsi
1800015dd:     	popq	%r12
1800015df:     	popq	%r13
1800015e1:     	popq	%r14
1800015e3:     	popq	%r15
1800015e5:     	retq
1800015e6:     	jle	0x18000170e <.text+0x70e>
1800015ec:     	callq	0x180007e75 <numba_list_iter_next+0x335>
1800015f1:     	movl	0x8(%rbx), %edx
1800015f4:     	movq	(%rbx), %rcx
1800015f7:     	cmpl	$0x0, 0x20(%rbx)
1800015fb:     	jle	0x18000172d <.text+0x72d>
180001601:     	movslq	%edx, %rdx
180001604:     	callq	0x180007e7b <numba_list_iter_next+0x33b>
180001609:     	movq	%rax, %rsi
18000160c:     	movq	0x10(%rbx), %rcx
180001610:     	callq	*0x18(%rbx)
180001613:     	testq	%rax, %rax
180001616:     	je	0x180001756 <.text+0x756>
18000161c:     	movq	%rsi, %rcx
18000161f:     	movq	%rax, %rdx
180001622:     	callq	0x180006320 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x49a0>
180001627:     	movq	%rax, %rsi
18000162a:     	movq	%rbx, %rcx
18000162d:     	callq	0x180007db0 <numba_list_iter_next+0x270>
180001632:     	jmp	0x180001739 <.text+0x739>
180001637:     	movq	0x7c82(%rip), %rcx      # 0x1800092c0
18000163e:     	leaq	0x7f7b(%rip), %rdx      # 0x1800095c0
180001645:     	callq	0x180007e81 <numba_list_iter_next+0x341>
18000164a:     	jmp	0x180001707 <.text+0x707>
18000164f:     	movq	0x7c5a(%rip), %rcx      # 0x1800092b0
180001656:     	leaq	0x8053(%rip), %rdx      # 0x1800096b0
18000165d:     	callq	0x180007e81 <numba_list_iter_next+0x341>
180001662:     	jmp	0x180001707 <.text+0x707>
180001667:     	movq	0x7c42(%rip), %rcx      # 0x1800092b0
18000166e:     	leaq	0x803b(%rip), %rdx      # 0x1800096b0
180001675:     	callq	0x180007e81 <numba_list_iter_next+0x341>
18000167a:     	jmp	0x1800016ff <.text+0x6ff>
18000167f:     	movq	0x7c2a(%rip), %rcx      # 0x1800092b0
180001686:     	leaq	0x8023(%rip), %rdx      # 0x1800096b0
18000168d:     	callq	0x180007e81 <numba_list_iter_next+0x341>
180001692:     	jmp	0x1800016f7 <.text+0x6f7>
180001694:     	movq	0x7c15(%rip), %rcx      # 0x1800092b0
18000169b:     	leaq	0x800e(%rip), %rdx      # 0x1800096b0
1800016a2:     	callq	0x180007e81 <numba_list_iter_next+0x341>
1800016a7:     	jmp	0x1800016ef <.text+0x6ef>
1800016a9:     	xorl	%r13d, %r13d
1800016ac:     	movq	%rbx, %r14
1800016af:     	callq	0x180007e69 <numba_list_iter_next+0x329>
1800016b4:     	testq	%rax, %rax
1800016b7:     	je	0x1800014af <.text+0x4af>
1800016bd:     	jmp	0x1800016d2 <.text+0x6d2>
1800016bf:     	xorl	%ebp, %ebp
1800016c1:     	callq	0x180007e69 <numba_list_iter_next+0x329>
1800016c6:     	testq	%rax, %rax
1800016c9:     	movq	%rbx, %rsi
1800016cc:     	je	0x1800014ef <.text+0x4ef>
1800016d2:     	movq	0x80(%rsp), %rcx
1800016da:     	callq	0x180001060 <.text+0x60>
1800016df:     	movq	0x90(%rsp), %r14
1800016e7:     	movq	0x88(%rsp), %r12
1800016ef:     	movq	%r12, %rcx
1800016f2:     	callq	0x180001060 <.text+0x60>
1800016f7:     	movq	%r14, %rcx
1800016fa:     	callq	0x180001060 <.text+0x60>
1800016ff:     	movq	%rsi, %rcx
180001702:     	callq	0x180001060 <.text+0x60>
180001707:     	xorl	%esi, %esi
180001709:     	jmp	0x1800015cf <.text+0x5cf>
18000170e:     	cmpl	$-0x3, %ebp
180001711:     	je	0x180001748 <.text+0x748>
180001713:     	cmpl	$-0x1, %ebp
180001716:     	je	0x180001707 <.text+0x707>
180001718:     	movq	0x7b89(%rip), %rcx      # 0x1800092a8
18000171f:     	leaq	0x802a(%rip), %rdx      # 0x180009750
180001726:     	callq	0x180007e81 <numba_list_iter_next+0x341>
18000172b:     	jmp	0x180001707 <.text+0x707>
18000172d:     	movq	0x10(%rbx), %r8
180001731:     	callq	0x180006240 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x48c0>
180001736:     	movq	%rax, %rsi
180001739:     	testq	%rsi, %rsi
18000173c:     	je	0x180001707 <.text+0x707>
18000173e:     	movq	%rsi, %rcx
180001741:     	callq	0x180005de0 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4460>
180001746:     	jmp	0x180001707 <.text+0x707>
180001748:     	movq	0x7b51(%rip), %rcx      # 0x1800092a0
18000174f:     	callq	0x180007e87 <numba_list_iter_next+0x347>
180001754:     	jmp	0x180001707 <.text+0x707>
180001756:     	movq	0x7b63(%rip), %rcx      # 0x1800092c0
18000175d:     	leaq	0x7fac(%rip), %rdx      # 0x180009710
180001764:     	callq	0x180007e81 <numba_list_iter_next+0x341>
180001769:     	jmp	0x180001707 <.text+0x707>
18000176b:     	nopl	(%rax,%rax)
180001770:     	pushq	%r15
180001772:     	pushq	%r14
180001774:     	pushq	%r13
180001776:     	pushq	%r12
180001778:     	pushq	%rsi
180001779:     	pushq	%rdi
18000177a:     	pushq	%rbx
18000177b:     	subq	$0xa0, %rsp
180001782:     	movq	0x100(%rsp), %r8
18000178a:     	movq	0x108(%rsp), %r9
180001792:     	movq	0x110(%rsp), %rax
18000179a:     	movq	0x138(%rsp), %rcx
1800017a2:     	movq	0x140(%rsp), %rdx
1800017aa:     	movq	0x148(%rsp), %r10
1800017b2:     	movq	0x170(%rsp), %r11
1800017ba:     	movq	0x178(%rsp), %rsi
1800017c2:     	movq	0x180(%rsp), %rdi
1800017ca:     	movq	0x1a8(%rsp), %rbx
1800017d2:     	movq	0x1b0(%rsp), %r14
1800017da:     	movq	0x1b8(%rsp), %r15
1800017e2:     	movq	0x1c0(%rsp), %r12
1800017ea:     	movq	0x1c8(%rsp), %r13
1800017f2:     	movq	$0x0, 0x98(%rsp)
1800017fe:     	movq	$0x0, 0x90(%rsp)
18000180a:     	movq	%r13, 0x78(%rsp)
18000180f:     	movq	%r12, 0x70(%rsp)
180001814:     	movq	%r15, 0x68(%rsp)
180001819:     	movq	%r14, 0x60(%rsp)
18000181e:     	movq	%rbx, 0x58(%rsp)
180001823:     	movq	%rdi, 0x50(%rsp)
180001828:     	movq	%rsi, 0x48(%rsp)
18000182d:     	movq	%r11, 0x40(%rsp)
180001832:     	movq	%r10, 0x38(%rsp)
180001837:     	movq	%rdx, 0x30(%rsp)
18000183c:     	movq	%rcx, 0x28(%rsp)
180001841:     	movq	%rax, 0x20(%rsp)
180001846:     	leaq	0x98(%rsp), %rcx
18000184e:     	leaq	0x90(%rsp), %rdx
180001856:     	callq	0x180001090 <.text+0x90>
18000185b:     	movl	%eax, %edx
18000185d:     	movq	0x90(%rsp), %rsi
180001865:     	movq	0x98(%rsp), %rax
18000186d:     	movl	$0x0, 0x8c(%rsp)
180001878:     	testl	%edx, %edx
18000187a:     	jne	0x18000188f <.text+0x88f>
18000187c:     	addq	$0xa0, %rsp
180001883:     	popq	%rbx
180001884:     	popq	%rdi
180001885:     	popq	%rsi
180001886:     	popq	%r12
180001888:     	popq	%r13
18000188a:     	popq	%r14
18000188c:     	popq	%r15
18000188e:     	retq
18000188f:     	movq	%rax, %rbx
180001892:     	leaq	0x8c(%rsp), %rcx
18000189a:     	movl	%edx, %edi
18000189c:     	callq	0x180005db0 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4430>
1800018a1:     	testl	%edi, %edi
1800018a3:     	jle	0x1800018e9 <.text+0x8e9>
1800018a5:     	callq	0x180007e75 <numba_list_iter_next+0x335>
1800018aa:     	movl	0x8(%rsi), %edx
1800018ad:     	movq	(%rsi), %rcx
1800018b0:     	cmpl	$0x0, 0x20(%rsi)
1800018b4:     	jle	0x18000190a <.text+0x90a>
1800018b6:     	movslq	%edx, %rdx
1800018b9:     	callq	0x180007e7b <numba_list_iter_next+0x33b>
1800018be:     	movq	%rax, %rdi
1800018c1:     	movq	0x10(%rsi), %rcx
1800018c5:     	callq	*0x18(%rsi)
1800018c8:     	testq	%rax, %rax
1800018cb:     	je	0x180001965 <.text+0x965>
1800018d1:     	movq	%rdi, %rcx
1800018d4:     	movq	%rax, %rdx
1800018d7:     	callq	0x180006320 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x49a0>
1800018dc:     	movq	%rax, %rdi
1800018df:     	movq	%rsi, %rcx
1800018e2:     	callq	0x180007db0 <numba_list_iter_next+0x270>
1800018e7:     	jmp	0x180001916 <.text+0x916>
1800018e9:     	movl	%edi, %eax
1800018eb:     	cmpl	$-0x3, %edi
1800018ee:     	je	0x180001957 <.text+0x957>
1800018f0:     	cmpl	$-0x1, %eax
1800018f3:     	je	0x180001923 <.text+0x923>
1800018f5:     	movq	0x79ac(%rip), %rcx      # 0x1800092a8
1800018fc:     	leaq	0x7ebd(%rip), %rdx      # 0x1800097c0
180001903:     	callq	0x180007e81 <numba_list_iter_next+0x341>
180001908:     	jmp	0x180001923 <.text+0x923>
18000190a:     	movq	0x10(%rsi), %r8
18000190e:     	callq	0x180006240 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x48c0>
180001913:     	movq	%rax, %rdi
180001916:     	testq	%rdi, %rdi
180001919:     	je	0x180001923 <.text+0x923>
18000191b:     	movq	%rdi, %rcx
18000191e:     	callq	0x180005de0 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4460>
180001923:     	leaq	0x7ec6(%rip), %rcx      # 0x1800097f0
18000192a:     	callq	0x180007e8d <numba_list_iter_next+0x34d>
18000192f:     	movq	%rax, %rsi
180001932:     	movq	%rax, %rcx
180001935:     	callq	0x180007e93 <numba_list_iter_next+0x353>
18000193a:     	movq	%rsi, %rcx
18000193d:     	callq	0x180007e63 <numba_list_iter_next+0x323>
180001942:     	leaq	0x8c(%rsp), %rcx
18000194a:     	callq	0x180005dd0 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4450>
18000194f:     	movq	%rbx, %rax
180001952:     	jmp	0x18000187c <.text+0x87c>
180001957:     	movq	0x7942(%rip), %rcx      # 0x1800092a0
18000195e:     	callq	0x180007e87 <numba_list_iter_next+0x347>
180001963:     	jmp	0x180001923 <.text+0x923>
180001965:     	movq	0x7954(%rip), %rcx      # 0x1800092c0
18000196c:     	leaq	0x7e0d(%rip), %rdx      # 0x180009780
180001973:     	callq	0x180007e81 <numba_list_iter_next+0x341>
180001978:     	xorl	%eax, %eax
18000197a:     	jmp	0x18000187c <.text+0x87c>
18000197f:     	nop

0000000180001980 <PyInit_rcaotr_7508da57ea552f418d6e0f1d>:
180001980:     	pushq	%rsi
180001981:     	subq	$0x20, %rsp
180001985:     	leaq	0xe6b4(%rip), %rcx      # 0x180010040
18000198c:     	movl	$0x3f5, %edx            # imm = 0x3F5
180001991:     	callq	0x180007e99 <numba_list_iter_next+0x359>
180001996:     	testq	%rax, %rax
180001999:     	je	0x1800019cb <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4b>
18000199b:     	leaq	0xe65e(%rip), %rdx      # 0x180010000
1800019a2:     	leaq	0x7eb7(%rip), %r8       # 0x180009860
1800019a9:     	leaq	0x7fa0(%rip), %r9       # 0x180009950
1800019b0:     	movq	%rax, %rcx
1800019b3:     	movq	%rax, %rsi
1800019b6:     	callq	0x180006d80 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5400>
1800019bb:     	movl	%eax, %ecx
1800019bd:     	xorl	%eax, %eax
1800019bf:     	testl	%ecx, %ecx
1800019c1:     	cmoveq	%rsi, %rax
1800019c5:     	addq	$0x20, %rsp
1800019c9:     	popq	%rsi
1800019ca:     	retq
1800019cb:     	xorl	%eax, %eax
1800019cd:     	addq	$0x20, %rsp
1800019d1:     	popq	%rsi
1800019d2:     	retq
1800019d3:     	nopw	%cs:(%rax,%rax)
1800019dd:     	nopl	(%rax)
1800019e0:     	pushq	%r15
1800019e2:     	pushq	%r14
1800019e4:     	pushq	%r13
1800019e6:     	pushq	%r12
1800019e8:     	pushq	%rsi
1800019e9:     	pushq	%rdi
1800019ea:     	pushq	%rbp
1800019eb:     	pushq	%rbx
1800019ec:     	subq	$0x1b8, %rsp            # imm = 0x1B8
1800019f3:     	movapd	%xmm15, 0x1a0(%rsp)
1800019fd:     	movapd	%xmm14, 0x190(%rsp)
180001a07:     	movapd	%xmm13, 0x180(%rsp)
180001a11:     	movapd	%xmm12, 0x170(%rsp)
180001a1b:     	movapd	%xmm11, 0x160(%rsp)
180001a25:     	movapd	%xmm10, 0x150(%rsp)
180001a2f:     	movapd	%xmm9, 0x140(%rsp)
180001a39:     	movapd	%xmm8, 0x130(%rsp)
180001a43:     	movapd	%xmm7, 0x120(%rsp)
180001a4c:     	movaps	%xmm6, 0x110(%rsp)
180001a54:     	movq	%r9, %rbx
180001a57:     	movq	%r8, %r14
180001a5a:     	movq	%rdx, 0x100(%rsp)
180001a62:     	movq	%rcx, %rsi
180001a65:     	movq	$0x0, 0x88(%rsp)
180001a71:     	movb	$0x0, 0x90(%rsp)
180001a79:     	movq	$0x0, 0x98(%rsp)
180001a85:     	movb	$0x0, 0xa0(%rsp)
180001a8d:     	movq	$0x0, 0xa8(%rsp)
180001a99:     	movb	$0x0, 0xb0(%rsp)
180001aa1:     	movq	$0x0, 0xb8(%rsp)
180001aad:     	movb	$0x0, 0xc0(%rsp)
180001ab5:     	movq	$0x0, 0xc8(%rsp)
180001ac1:     	movb	$0x0, 0xd0(%rsp)
180001ac9:     	movq	$0x0, 0xd8(%rsp)
180001ad5:     	movb	$0x0, 0xe0(%rsp)
180001add:     	movq	$0x0, 0x108(%rsp)
180001ae9:     	movq	(%r8), %r15
180001aec:     	movq	0x8(%r8), %r12
180001af0:     	movq	0x10(%r8), %rbp
180001af4:     	movq	0x18(%r8), %r13
180001af8:     	movq	0x20(%r8), %rdi
180001afc:     	xorps	%xmm6, %xmm6
180001aff:     	cvtsi2sdq	(%r12,%r9,8), %xmm6
180001b05:     	mulsd	0x78a3(%rip), %xmm6     # 0x1800093b0
180001b0d:     	mulsd	0x78a3(%rip), %xmm6     # 0x1800093b8
180001b15:     	divsd	0x78a3(%rip), %xmm6     # 0x1800093c0
180001b1d:     	movapd	%xmm6, %xmm0
180001b21:     	callq	0x1800089bc <numba_list_iter_next+0xe7c>
180001b26:     	ucomisd	%xmm0, %xmm0
180001b2a:     	jp	0x180001b80 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x200>
180001b2c:     	movq	%xmm0, %rax
180001b31:     	movabsq	$0x7fffffffffffffff, %rcx # imm = 0x7FFFFFFFFFFFFFFF
180001b3b:     	andq	%rcx, %rax
180001b3e:     	movabsq	$0x7ff0000000000000, %rdx # imm = 0x7FF0000000000000
180001b48:     	cmpq	%rdx, %rax
180001b4b:     	setne	%al
180001b4e:     	movq	%xmm6, %r8
180001b53:     	andq	%rcx, %r8
180001b56:     	cmpq	%rdx, %r8
180001b59:     	sete	%cl
180001b5c:     	orb	%al, %cl
180001b5e:     	je	0x180001b80 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x200>
180001b60:     	movq	0x220(%rsp), %rdx
180001b68:     	movq	0x10(%r12,%rdx,8), %rcx
180001b6d:     	movq	%rcx, %rax
180001b70:     	negq	%rax
180001b73:     	jno	0x180001c02 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x282>
180001b79:     	movb	$0x1, (%r13)
180001b7e:     	jmp	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
180001b80:     	movb	$0x1, (%r13)
180001b85:     	movq	$0x3, 0x18(%rbp)
180001b8d:     	xorl	%eax, %eax
180001b8f:     	movq	$0x0, (%rsi)
180001b96:     	movaps	0x110(%rsp), %xmm6
180001b9e:     	movaps	0x120(%rsp), %xmm7
180001ba6:     	movaps	0x130(%rsp), %xmm8
180001baf:     	movaps	0x140(%rsp), %xmm9
180001bb8:     	movaps	0x150(%rsp), %xmm10
180001bc1:     	movaps	0x160(%rsp), %xmm11
180001bca:     	movaps	0x170(%rsp), %xmm12
180001bd3:     	movaps	0x180(%rsp), %xmm13
180001bdc:     	movaps	0x190(%rsp), %xmm14
180001be5:     	movaps	0x1a0(%rsp), %xmm15
180001bee:     	addq	$0x1b8, %rsp            # imm = 0x1B8
180001bf5:     	popq	%rbx
180001bf6:     	popq	%rbp
180001bf7:     	popq	%rdi
180001bf8:     	popq	%rsi
180001bf9:     	popq	%r12
180001bfb:     	popq	%r13
180001bfd:     	popq	%r14
180001bff:     	popq	%r15
180001c01:     	retq
180001c02:     	xorl	%eax, %eax
180001c04:     	cmpb	$0x0, (%r13)
180001c09:     	jne	0x180001b8f <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20f>
180001c0b:     	decq	%rcx
180001c0e:     	je	0x180001c2e <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2ae>
180001c10:     	movabsq	$-0x8000000000000000, %r8 # imm = 0x8000000000000000
180001c1a:     	movq	0x8(%r12,%rdx,8), %rdx
180001c1f:     	cmpq	%r8, %rdx
180001c22:     	jne	0x180001c40 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2c0>
180001c24:     	movb	$0x1, (%r13)
180001c29:     	jmp	0x180001b8f <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20f>
180001c2e:     	movb	$0x1, (%r13)
180001c33:     	movq	$0x7, 0x18(%rbp)
180001c3b:     	jmp	0x180001b8f <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20f>
180001c40:     	decq	%rdx
180001c43:     	je	0x180001d50 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3d0>
180001c49:     	movq	0x10(%r12,%rbx,8), %r8
180001c4e:     	movq	0x20(%r12,%rbx,8), %r9
180001c53:     	movsd	(%r15,%r8,8), %xmm1
180001c59:     	subsd	(%r15,%r9,8), %xmm1
180001c5f:     	movapd	0x7769(%rip), %xmm2     # 0x1800093d0
180001c67:     	andpd	%xmm1, %xmm2
180001c6b:     	ucomisd	0x776d(%rip), %xmm2     # 0x1800093e0
180001c73:     	jae	0x180001d17 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x397>
180001c79:     	movsd	0x10(%r15,%r8,8), %xmm2
180001c80:     	subsd	0x10(%r15,%r9,8), %xmm2
180001c87:     	movapd	0x7741(%rip), %xmm3     # 0x1800093d0
180001c8f:     	andpd	%xmm2, %xmm3
180001c93:     	ucomisd	0x7745(%rip), %xmm3     # 0x1800093e0
180001c9b:     	jae	0x180001d17 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x397>
180001c9d:     	movsd	0x20(%r15,%r8,8), %xmm3
180001ca4:     	subsd	0x20(%r15,%r9,8), %xmm3
180001cab:     	movapd	0x771d(%rip), %xmm4     # 0x1800093d0
180001cb3:     	andpd	%xmm3, %xmm4
180001cb7:     	ucomisd	0x7721(%rip), %xmm4     # 0x1800093e0
180001cbf:     	jae	0x180001d17 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x397>
180001cc1:     	movq	(%rbp), %r10
180001cc5:     	leaq	0x6(%r10), %r8
180001cc9:     	cmpq	%rdi, %r8
180001ccc:     	jg	0x180001d46 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3c6>
180001cce:     	movq	%r8, (%rbp)
180001cd2:     	cmpb	$0x0, (%r13)
180001cd7:     	jne	0x180001b8f <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20f>
180001cdd:     	movsd	%xmm1, (%r15,%r10,8)
180001ce3:     	movsd	%xmm2, 0x10(%r15,%r10,8)
180001cea:     	movsd	%xmm3, 0x20(%r15,%r10,8)
180001cf1:     	movq	%r10, 0x58(%rsp)
180001cf6:     	movzbl	(%r13), %r10d
180001cfb:     	xorl	%r8d, %r8d
180001cfe:     	movl	%r10d, %r11d
180001d01:     	negb	%r11b
180001d04:     	sbbq	%r8, %r8
180001d07:     	orq	0x58(%rsp), %r8
180001d0c:     	testb	%r10b, %r10b
180001d0f:     	jne	0x180001b8f <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20f>
180001d15:     	jmp	0x180001d39 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3b9>
180001d17:     	movb	$0x1, (%r13)
180001d1c:     	movq	$0xf4243, 0x18(%rbp)    # imm = 0xF4243
180001d24:     	movzbl	(%r13), %r10d
180001d29:     	movq	$-0x1, %r8
180001d30:     	testb	%r10b, %r10b
180001d33:     	jne	0x180001b8f <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20f>
180001d39:     	movq	(%rbp), %r11
180001d3d:     	leaq	0x2(%r11), %r10
180001d41:     	cmpq	%rdi, %r10
180001d44:     	jle	0x180001d62 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3e2>
180001d46:     	movb	$0x2, (%r13)
180001d4b:     	jmp	0x180001b8f <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20f>
180001d50:     	movb	$0x1, (%r13)
180001d55:     	movq	$0x8, 0x18(%rbp)
180001d5d:     	jmp	0x180001b8f <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20f>
180001d62:     	movq	%r10, (%rbp)
180001d66:     	cmpb	$0x0, (%r13)
180001d6b:     	jne	0x180001b8f <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20f>
180001d71:     	movq	%r9, (%r12,%r11,8)
180001d75:     	cmpb	$0x0, (%r13)
180001d7a:     	jne	0x180001b8f <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20f>
180001d80:     	movsd	(%r15,%r8,8), %xmm1
180001d86:     	mulsd	%xmm1, %xmm1
180001d8a:     	movapd	0x763e(%rip), %xmm2     # 0x1800093d0
180001d92:     	andpd	%xmm1, %xmm2
180001d96:     	ucomisd	0x7642(%rip), %xmm2     # 0x1800093e0
180001d9e:     	jae	0x180001e16 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x496>
180001da0:     	movsd	0x10(%r15,%r8,8), %xmm2
180001da7:     	mulsd	%xmm2, %xmm2
180001dab:     	movapd	0x761d(%rip), %xmm3     # 0x1800093d0
180001db3:     	andpd	%xmm2, %xmm3
180001db7:     	ucomisd	0x7621(%rip), %xmm3     # 0x1800093e0
180001dbf:     	jae	0x180001e16 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x496>
180001dc1:     	addsd	%xmm2, %xmm1
180001dc5:     	movapd	0x7603(%rip), %xmm2     # 0x1800093d0
180001dcd:     	andpd	%xmm1, %xmm2
180001dd1:     	ucomisd	0x7607(%rip), %xmm2     # 0x1800093e0
180001dd9:     	jae	0x180001e16 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x496>
180001ddb:     	movsd	0x20(%r15,%r8,8), %xmm2
180001de2:     	mulsd	%xmm2, %xmm2
180001de6:     	movapd	0x75e2(%rip), %xmm3     # 0x1800093d0
180001dee:     	andpd	%xmm2, %xmm3
180001df2:     	ucomisd	0x75e6(%rip), %xmm3     # 0x1800093e0
180001dfa:     	jae	0x180001e16 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x496>
180001dfc:     	addsd	%xmm2, %xmm1
180001e00:     	movapd	0x75c8(%rip), %xmm2     # 0x1800093d0
180001e08:     	andpd	%xmm1, %xmm2
180001e0c:     	ucomisd	0x75cc(%rip), %xmm2     # 0x1800093e0
180001e14:     	jb	0x180001e27 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4a7>
180001e16:     	movb	$0x1, (%r13)
180001e1b:     	movq	$0x14fb183, 0x18(%rbp)  # imm = 0x14FB183
180001e23:     	xorpd	%xmm1, %xmm1
180001e27:     	cmpb	$0x0, (%r13)
180001e2c:     	jne	0x180001b8f <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20f>
180001e32:     	sqrtsd	%xmm1, %xmm1
180001e36:     	xorpd	%xmm2, %xmm2
180001e3a:     	ucomisd	%xmm2, %xmm1
180001e3e:     	movq	%r11, 0x58(%rsp)
180001e43:     	jne	0x18000201d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x69d>
180001e49:     	jp	0x18000201d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x69d>
180001e4f:     	movb	$0x1, (%r13)
180001e54:     	movq	$0x3d0902, 0x18(%rbp)   # imm = 0x3D0902
180001e5c:     	movzbl	(%r13), %r8d
180001e61:     	movq	$-0x1, %r9
180001e68:     	testb	%r8b, %r8b
180001e6b:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
180001e71:     	movq	0x58(%rsp), %rax
180001e76:     	movq	%r9, 0x8(%r12,%rax,8)
180001e7b:     	cmpb	$0x0, (%r13)
180001e80:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
180001e86:     	movq	0x58(%rsp), %rax
180001e8b:     	movq	0x8(%r12,%rax,8), %rax
180001e90:     	movq	(%r12), %r8
180001e94:     	movsd	0x10(%r15,%rax,8), %xmm4
180001e9b:     	movsd	0x20(%r15,%r8,8), %xmm5
180001ea2:     	movapd	%xmm4, %xmm1
180001ea6:     	mulsd	%xmm5, %xmm1
180001eaa:     	movapd	0x751e(%rip), %xmm2     # 0x1800093d0
180001eb2:     	andpd	%xmm1, %xmm2
180001eb6:     	ucomisd	0x7522(%rip), %xmm2     # 0x1800093e0
180001ebe:     	jae	0x1800020a5 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x725>
180001ec4:     	movsd	0x20(%r15,%rax,8), %xmm2
180001ecb:     	movsd	0x10(%r15,%r8,8), %xmm3
180001ed2:     	movapd	%xmm2, %xmm6
180001ed6:     	mulsd	%xmm3, %xmm6
180001eda:     	movapd	0x74ee(%rip), %xmm7     # 0x1800093d0
180001ee2:     	andpd	%xmm6, %xmm7
180001ee6:     	ucomisd	0x74f2(%rip), %xmm7     # 0x1800093e0
180001eee:     	jae	0x1800020a5 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x725>
180001ef4:     	subsd	%xmm6, %xmm1
180001ef8:     	movapd	0x74d0(%rip), %xmm6     # 0x1800093d0
180001f00:     	andpd	%xmm1, %xmm6
180001f04:     	ucomisd	0x74d4(%rip), %xmm6     # 0x1800093e0
180001f0c:     	jae	0x1800020a5 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x725>
180001f12:     	movsd	(%r15,%r8,8), %xmm6
180001f18:     	mulsd	%xmm6, %xmm2
180001f1c:     	movapd	0x74ac(%rip), %xmm7     # 0x1800093d0
180001f24:     	andpd	%xmm2, %xmm7
180001f28:     	ucomisd	0x74b0(%rip), %xmm7     # 0x1800093e0
180001f30:     	jae	0x1800020a5 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x725>
180001f36:     	movsd	(%r15,%rax,8), %xmm7
180001f3c:     	mulsd	%xmm7, %xmm5
180001f40:     	movapd	0x7487(%rip), %xmm8     # 0x1800093d0
180001f49:     	andpd	%xmm5, %xmm8
180001f4e:     	ucomisd	0x7489(%rip), %xmm8     # 0x1800093e0
180001f57:     	jae	0x1800020a5 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x725>
180001f5d:     	subsd	%xmm5, %xmm2
180001f61:     	movapd	0x7467(%rip), %xmm5     # 0x1800093d0
180001f69:     	andpd	%xmm2, %xmm5
180001f6d:     	ucomisd	0x746b(%rip), %xmm5     # 0x1800093e0
180001f75:     	jae	0x1800020a5 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x725>
180001f7b:     	mulsd	%xmm7, %xmm3
180001f7f:     	movapd	0x7449(%rip), %xmm5     # 0x1800093d0
180001f87:     	andpd	%xmm3, %xmm5
180001f8b:     	ucomisd	0x744d(%rip), %xmm5     # 0x1800093e0
180001f93:     	jae	0x1800020a5 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x725>
180001f99:     	mulsd	%xmm6, %xmm4
180001f9d:     	movapd	0x742b(%rip), %xmm5     # 0x1800093d0
180001fa5:     	andpd	%xmm4, %xmm5
180001fa9:     	ucomisd	0x742f(%rip), %xmm5     # 0x1800093e0
180001fb1:     	jae	0x1800020a5 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x725>
180001fb7:     	subsd	%xmm4, %xmm3
180001fbb:     	movapd	0x740d(%rip), %xmm4     # 0x1800093d0
180001fc3:     	andpd	%xmm3, %xmm4
180001fc7:     	ucomisd	0x7411(%rip), %xmm4     # 0x1800093e0
180001fcf:     	jae	0x1800020a5 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x725>
180001fd5:     	movq	(%rbp), %r8
180001fd9:     	leaq	0x6(%r8), %rax
180001fdd:     	cmpq	%rdi, %rax
180001fe0:     	jg	0x18000202a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x6aa>
180001fe2:     	movq	%rax, (%rbp)
180001fe6:     	cmpb	$0x0, (%r13)
180001feb:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
180001ff1:     	movsd	%xmm1, (%r15,%r8,8)
180001ff7:     	movsd	%xmm2, 0x10(%r15,%r8,8)
180001ffe:     	movsd	%xmm3, 0x20(%r15,%r8,8)
180002005:     	movzbl	(%r13), %r9d
18000200a:     	xorl	%eax, %eax
18000200c:     	movl	%r9d, %r10d
18000200f:     	negb	%r10b
180002012:     	sbbq	%rax, %rax
180002015:     	orq	%r8, %rax
180002018:     	jmp	0x1800020be <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x73e>
18000201d:     	movq	(%rbp), %rax
180002021:     	leaq	0x6(%rax), %r9
180002025:     	cmpq	%rdi, %r9
180002028:     	jle	0x180002034 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x6b4>
18000202a:     	movb	$0x2, (%r13)
18000202f:     	jmp	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
180002034:     	movsd	(%r15,%r8,8), %xmm2
18000203a:     	movsd	0x10(%r15,%r8,8), %xmm3
180002041:     	movsd	0x20(%r15,%r8,8), %xmm4
180002048:     	movq	%r9, (%rbp)
18000204c:     	cmpb	$0x0, (%r13)
180002051:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
180002057:     	movsd	0x7389(%rip), %xmm5     # 0x1800093e8
18000205f:     	divsd	%xmm1, %xmm5
180002063:     	mulsd	%xmm5, %xmm2
180002067:     	mulsd	%xmm5, %xmm3
18000206b:     	mulsd	%xmm4, %xmm5
18000206f:     	movsd	%xmm2, (%r15,%rax,8)
180002075:     	movsd	%xmm3, 0x10(%r15,%rax,8)
18000207c:     	movsd	%xmm5, 0x20(%r15,%rax,8)
180002083:     	movzbl	(%r13), %r8d
180002088:     	xorl	%r9d, %r9d
18000208b:     	movl	%r8d, %r10d
18000208e:     	negb	%r10b
180002091:     	sbbq	%r9, %r9
180002094:     	orq	%rax, %r9
180002097:     	testb	%r8b, %r8b
18000209a:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
1800020a0:     	jmp	0x180001e71 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4f1>
1800020a5:     	movb	$0x1, (%r13)
1800020aa:     	movq	$0x2dc6c3, 0x18(%rbp)   # imm = 0x2DC6C3
1800020b2:     	movzbl	(%r13), %r9d
1800020b7:     	movq	$-0x1, %rax
1800020be:     	testb	%r9b, %r9b
1800020c1:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
1800020c7:     	movsd	(%r15,%rax,8), %xmm1
1800020cd:     	mulsd	%xmm1, %xmm1
1800020d1:     	movapd	0x72f7(%rip), %xmm2     # 0x1800093d0
1800020d9:     	andpd	%xmm1, %xmm2
1800020dd:     	ucomisd	0x72fb(%rip), %xmm2     # 0x1800093e0
1800020e5:     	jae	0x18000215d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x7dd>
1800020e7:     	movsd	0x10(%r15,%rax,8), %xmm2
1800020ee:     	mulsd	%xmm2, %xmm2
1800020f2:     	movapd	0x72d6(%rip), %xmm3     # 0x1800093d0
1800020fa:     	andpd	%xmm2, %xmm3
1800020fe:     	ucomisd	0x72da(%rip), %xmm3     # 0x1800093e0
180002106:     	jae	0x18000215d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x7dd>
180002108:     	addsd	%xmm2, %xmm1
18000210c:     	movapd	0x72bc(%rip), %xmm2     # 0x1800093d0
180002114:     	andpd	%xmm1, %xmm2
180002118:     	ucomisd	0x72c0(%rip), %xmm2     # 0x1800093e0
180002120:     	jae	0x18000215d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x7dd>
180002122:     	movsd	0x20(%r15,%rax,8), %xmm2
180002129:     	mulsd	%xmm2, %xmm2
18000212d:     	movapd	0x729b(%rip), %xmm3     # 0x1800093d0
180002135:     	andpd	%xmm2, %xmm3
180002139:     	ucomisd	0x729f(%rip), %xmm3     # 0x1800093e0
180002141:     	jae	0x18000215d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x7dd>
180002143:     	addsd	%xmm2, %xmm1
180002147:     	movapd	0x7281(%rip), %xmm2     # 0x1800093d0
18000214f:     	andpd	%xmm1, %xmm2
180002153:     	ucomisd	0x7285(%rip), %xmm2     # 0x1800093e0
18000215b:     	jb	0x18000216e <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x7ee>
18000215d:     	movb	$0x1, (%r13)
180002162:     	movq	$0x14fb183, 0x18(%rbp)  # imm = 0x14FB183
18000216a:     	xorpd	%xmm1, %xmm1
18000216e:     	cmpb	$0x0, (%r13)
180002173:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
180002179:     	sqrtsd	%xmm1, %xmm1
18000217d:     	xorpd	%xmm2, %xmm2
180002181:     	ucomisd	%xmm2, %xmm1
180002185:     	jne	0x18000235a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x9da>
18000218b:     	jp	0x18000235a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x9da>
180002191:     	movb	$0x1, (%r13)
180002196:     	movq	$0x3d0902, 0x18(%rbp)   # imm = 0x3D0902
18000219e:     	movzbl	(%r13), %eax
1800021a3:     	movq	$-0x1, 0x60(%rsp)
1800021ac:     	testb	%al, %al
1800021ae:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
1800021b4:     	movq	0x58(%rsp), %rax
1800021b9:     	movq	0x8(%r12,%rax,8), %rax
1800021be:     	movq	0x60(%rsp), %r8
1800021c3:     	movsd	0x10(%r15,%r8,8), %xmm4
1800021ca:     	movsd	0x20(%r15,%rax,8), %xmm5
1800021d1:     	movapd	%xmm4, %xmm1
1800021d5:     	mulsd	%xmm5, %xmm1
1800021d9:     	movapd	0x71ef(%rip), %xmm2     # 0x1800093d0
1800021e1:     	andpd	%xmm1, %xmm2
1800021e5:     	ucomisd	0x71f3(%rip), %xmm2     # 0x1800093e0
1800021ed:     	jae	0x1800023e0 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xa60>
1800021f3:     	movq	0x60(%rsp), %r8
1800021f8:     	movsd	0x20(%r15,%r8,8), %xmm2
1800021ff:     	movsd	0x10(%r15,%rax,8), %xmm3
180002206:     	movapd	%xmm2, %xmm6
18000220a:     	mulsd	%xmm3, %xmm6
18000220e:     	movapd	0x71ba(%rip), %xmm7     # 0x1800093d0
180002216:     	andpd	%xmm6, %xmm7
18000221a:     	ucomisd	0x71be(%rip), %xmm7     # 0x1800093e0
180002222:     	jae	0x1800023e0 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xa60>
180002228:     	subsd	%xmm6, %xmm1
18000222c:     	movapd	0x719c(%rip), %xmm6     # 0x1800093d0
180002234:     	andpd	%xmm1, %xmm6
180002238:     	ucomisd	0x71a0(%rip), %xmm6     # 0x1800093e0
180002240:     	jae	0x1800023e0 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xa60>
180002246:     	movsd	(%r15,%rax,8), %xmm6
18000224c:     	mulsd	%xmm6, %xmm2
180002250:     	movapd	0x7178(%rip), %xmm7     # 0x1800093d0
180002258:     	andpd	%xmm2, %xmm7
18000225c:     	ucomisd	0x717c(%rip), %xmm7     # 0x1800093e0
180002264:     	jae	0x1800023e0 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xa60>
18000226a:     	movq	0x60(%rsp), %rax
18000226f:     	movsd	(%r15,%rax,8), %xmm7
180002275:     	mulsd	%xmm7, %xmm5
180002279:     	movapd	0x714e(%rip), %xmm8     # 0x1800093d0
180002282:     	andpd	%xmm5, %xmm8
180002287:     	ucomisd	0x7150(%rip), %xmm8     # 0x1800093e0
180002290:     	jae	0x1800023e0 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xa60>
180002296:     	subsd	%xmm5, %xmm2
18000229a:     	movapd	0x712e(%rip), %xmm5     # 0x1800093d0
1800022a2:     	andpd	%xmm2, %xmm5
1800022a6:     	ucomisd	0x7132(%rip), %xmm5     # 0x1800093e0
1800022ae:     	jae	0x1800023e0 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xa60>
1800022b4:     	mulsd	%xmm7, %xmm3
1800022b8:     	movapd	0x7110(%rip), %xmm5     # 0x1800093d0
1800022c0:     	andpd	%xmm3, %xmm5
1800022c4:     	ucomisd	0x7114(%rip), %xmm5     # 0x1800093e0
1800022cc:     	jae	0x1800023e0 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xa60>
1800022d2:     	mulsd	%xmm6, %xmm4
1800022d6:     	movapd	0x70f2(%rip), %xmm5     # 0x1800093d0
1800022de:     	andpd	%xmm4, %xmm5
1800022e2:     	ucomisd	0x70f6(%rip), %xmm5     # 0x1800093e0
1800022ea:     	jae	0x1800023e0 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xa60>
1800022f0:     	subsd	%xmm4, %xmm3
1800022f4:     	movapd	0x70d4(%rip), %xmm4     # 0x1800093d0
1800022fc:     	andpd	%xmm3, %xmm4
180002300:     	ucomisd	0x70d8(%rip), %xmm4     # 0x1800093e0
180002308:     	jae	0x1800023e0 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xa60>
18000230e:     	movq	(%rbp), %r8
180002312:     	leaq	0x6(%r8), %rax
180002316:     	cmpq	%rdi, %rax
180002319:     	jg	0x18000202a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x6aa>
18000231f:     	movq	%rax, (%rbp)
180002323:     	cmpb	$0x0, (%r13)
180002328:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
18000232e:     	movsd	%xmm1, (%r15,%r8,8)
180002334:     	movsd	%xmm2, 0x10(%r15,%r8,8)
18000233b:     	movsd	%xmm3, 0x20(%r15,%r8,8)
180002342:     	movzbl	(%r13), %r9d
180002347:     	xorl	%eax, %eax
180002349:     	movl	%r9d, %r10d
18000234c:     	negb	%r10b
18000234f:     	sbbq	%rax, %rax
180002352:     	orq	%r8, %rax
180002355:     	jmp	0x1800023f9 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xa79>
18000235a:     	movq	(%rbp), %r8
18000235e:     	leaq	0x6(%r8), %r9
180002362:     	cmpq	%rdi, %r9
180002365:     	jg	0x18000202a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x6aa>
18000236b:     	movsd	(%r15,%rax,8), %xmm2
180002371:     	movsd	0x10(%r15,%rax,8), %xmm3
180002378:     	movsd	0x20(%r15,%rax,8), %xmm4
18000237f:     	movq	%r9, (%rbp)
180002383:     	cmpb	$0x0, (%r13)
180002388:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
18000238e:     	movsd	0x7052(%rip), %xmm5     # 0x1800093e8
180002396:     	divsd	%xmm1, %xmm5
18000239a:     	mulsd	%xmm5, %xmm2
18000239e:     	mulsd	%xmm5, %xmm3
1800023a2:     	mulsd	%xmm4, %xmm5
1800023a6:     	movsd	%xmm2, (%r15,%r8,8)
1800023ac:     	movsd	%xmm3, 0x10(%r15,%r8,8)
1800023b3:     	movsd	%xmm5, 0x20(%r15,%r8,8)
1800023ba:     	movzbl	(%r13), %eax
1800023bf:     	xorl	%r10d, %r10d
1800023c2:     	movl	%eax, %r9d
1800023c5:     	negb	%r9b
1800023c8:     	sbbq	%r10, %r10
1800023cb:     	orq	%r8, %r10
1800023ce:     	movq	%r10, 0x60(%rsp)
1800023d3:     	testb	%al, %al
1800023d5:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
1800023db:     	jmp	0x1800021b4 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x834>
1800023e0:     	movb	$0x1, (%r13)
1800023e5:     	movq	$0x2dc6c3, 0x18(%rbp)   # imm = 0x2DC6C3
1800023ed:     	movzbl	(%r13), %r9d
1800023f2:     	movq	$-0x1, %rax
1800023f9:     	testb	%r9b, %r9b
1800023fc:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
180002402:     	movsd	(%r15,%rax,8), %xmm1
180002408:     	mulsd	%xmm1, %xmm1
18000240c:     	movapd	0x6fbc(%rip), %xmm2     # 0x1800093d0
180002414:     	andpd	%xmm1, %xmm2
180002418:     	ucomisd	0x6fc0(%rip), %xmm2     # 0x1800093e0
180002420:     	jae	0x180002498 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xb18>
180002422:     	movsd	0x10(%r15,%rax,8), %xmm2
180002429:     	mulsd	%xmm2, %xmm2
18000242d:     	movapd	0x6f9b(%rip), %xmm3     # 0x1800093d0
180002435:     	andpd	%xmm2, %xmm3
180002439:     	ucomisd	0x6f9f(%rip), %xmm3     # 0x1800093e0
180002441:     	jae	0x180002498 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xb18>
180002443:     	addsd	%xmm2, %xmm1
180002447:     	movapd	0x6f81(%rip), %xmm2     # 0x1800093d0
18000244f:     	andpd	%xmm1, %xmm2
180002453:     	ucomisd	0x6f85(%rip), %xmm2     # 0x1800093e0
18000245b:     	jae	0x180002498 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xb18>
18000245d:     	movsd	0x20(%r15,%rax,8), %xmm2
180002464:     	mulsd	%xmm2, %xmm2
180002468:     	movapd	0x6f60(%rip), %xmm3     # 0x1800093d0
180002470:     	andpd	%xmm2, %xmm3
180002474:     	ucomisd	0x6f64(%rip), %xmm3     # 0x1800093e0
18000247c:     	jae	0x180002498 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xb18>
18000247e:     	addsd	%xmm2, %xmm1
180002482:     	movapd	0x6f46(%rip), %xmm2     # 0x1800093d0
18000248a:     	andpd	%xmm1, %xmm2
18000248e:     	ucomisd	0x6f4a(%rip), %xmm2     # 0x1800093e0
180002496:     	jb	0x1800024a9 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xb29>
180002498:     	movb	$0x1, (%r13)
18000249d:     	movq	$0x14fb183, 0x18(%rbp)  # imm = 0x14FB183
1800024a5:     	xorpd	%xmm1, %xmm1
1800024a9:     	cmpb	$0x0, (%r13)
1800024ae:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
1800024b4:     	sqrtsd	%xmm1, %xmm1
1800024b8:     	xorpd	%xmm2, %xmm2
1800024bc:     	ucomisd	%xmm2, %xmm1
1800024c0:     	jne	0x180002dce <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x144e>
1800024c6:     	jp	0x180002dce <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x144e>
1800024cc:     	movb	$0x1, (%r13)
1800024d1:     	movq	$0x3d0902, 0x18(%rbp)   # imm = 0x3D0902
1800024d9:     	movzbl	(%r13), %eax
1800024de:     	movq	$-0x8, 0x80(%rsp)
1800024ea:     	testb	%al, %al
1800024ec:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
1800024f2:     	movq	0x220(%rsp), %rax
1800024fa:     	movq	0x8(%r12,%rax,8), %rax
1800024ff:     	movq	%rax, 0xe8(%rsp)
180002507:     	testq	%rax, %rax
18000250a:     	jle	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
180002510:     	movsd	0x6eb0(%rip), %xmm6     # 0x1800093c8
180002518:     	movapd	%xmm0, %xmm8
18000251d:     	mulsd	%xmm0, %xmm6
180002521:     	movapd	%xmm0, %xmm7
180002525:     	addsd	%xmm0, %xmm8
18000252a:     	cvtsi2sd	%rcx, %xmm0
18000252f:     	divsd	%xmm0, %xmm8
180002534:     	movapd	%xmm6, %xmm9
180002539:     	addsd	%xmm6, %xmm9
18000253e:     	xorps	%xmm0, %xmm0
180002541:     	cvtsi2sd	%rdx, %xmm0
180002546:     	divsd	%xmm0, %xmm9
18000254b:     	movq	$-0x1, 0x78(%rsp)
180002554:     	movapd	0x6e73(%rip), %xmm10    # 0x1800093d0
18000255d:     	movsd	0x6e7a(%rip), %xmm11    # 0x1800093e0
180002566:     	xorpd	%xmm12, %xmm12
18000256b:     	movsd	0x6e7c(%rip), %xmm13    # 0x1800093f0
180002574:     	movsd	0x6e83(%rip), %xmm15    # 0x180009400
18000257d:     	movq	$0x0, 0x70(%rsp)
180002586:     	movq	0x70(%rsp), %rcx
18000258b:     	leaq	0x1(%rcx), %rax
18000258f:     	movq	%rax, 0x70(%rsp)
180002594:     	movq	0x220(%rsp), %rax
18000259c:     	movq	0x10(%r12,%rax,8), %rdx
1800025a1:     	testq	%rdx, %rdx
1800025a4:     	movl	$0x0, %eax
1800025a9:     	cmovleq	%rax, %rdx
1800025ad:     	movq	%rdx, 0xf8(%rsp)
1800025b5:     	movq	%rcx, 0xf0(%rsp)
1800025bd:     	xorps	%xmm14, %xmm14
1800025c1:     	cvtsi2sd	%rcx, %xmm14
1800025c6:     	mulsd	%xmm9, %xmm14
1800025cb:     	subsd	%xmm6, %xmm14
1800025d0:     	movq	$0x0, 0x68(%rsp)
1800025d9:     	movq	0x68(%rsp), %rax
1800025de:     	cmpq	%rax, 0xf8(%rsp)
1800025e6:     	je	0x180002db1 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1431>
1800025ec:     	movq	(%rbp), %rdx
1800025f0:     	leaq	0x6(%rdx), %rax
1800025f4:     	cmpq	%rdi, %rax
1800025f7:     	jg	0x18000202a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x6aa>
1800025fd:     	movq	0x60(%rsp), %rcx
180002602:     	movsd	(%r15,%rcx,8), %xmm0
180002608:     	movsd	0x10(%r15,%rcx,8), %xmm1
18000260f:     	movsd	0x20(%r15,%rcx,8), %xmm2
180002616:     	movq	%rax, (%rbp)
18000261a:     	cmpb	$0x0, (%r13)
18000261f:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
180002625:     	xorps	%xmm3, %xmm3
180002628:     	cvtsi2sdq	0x68(%rsp), %xmm3
18000262f:     	mulsd	%xmm8, %xmm3
180002634:     	subsd	%xmm7, %xmm3
180002638:     	mulsd	%xmm3, %xmm0
18000263c:     	mulsd	%xmm3, %xmm1
180002640:     	mulsd	%xmm2, %xmm3
180002644:     	movsd	%xmm0, (%r15,%rdx,8)
18000264a:     	movsd	%xmm1, 0x10(%r15,%rdx,8)
180002651:     	movsd	%xmm3, 0x20(%r15,%rdx,8)
180002658:     	cmpb	$0x0, (%r13)
18000265d:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
180002663:     	movq	(%rbp), %rax
180002667:     	leaq	0x6(%rax), %rcx
18000266b:     	cmpq	%rdi, %rcx
18000266e:     	jg	0x18000202a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x6aa>
180002674:     	movq	0x80(%rsp), %r8
18000267c:     	movsd	(%r15,%r8), %xmm0
180002682:     	movsd	0x10(%r15,%r8), %xmm1
180002689:     	movsd	0x20(%r15,%r8), %xmm2
180002690:     	movq	%rcx, (%rbp)
180002694:     	cmpb	$0x0, (%r13)
180002699:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
18000269f:     	mulsd	%xmm14, %xmm0
1800026a4:     	mulsd	%xmm14, %xmm1
1800026a9:     	mulsd	%xmm14, %xmm2
1800026ae:     	movsd	%xmm0, (%r15,%rax,8)
1800026b4:     	movsd	%xmm1, 0x10(%r15,%rax,8)
1800026bb:     	movsd	%xmm2, 0x20(%r15,%rax,8)
1800026c2:     	cmpb	$0x0, (%r13)
1800026c7:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
1800026cd:     	movq	0x58(%rsp), %r8
1800026d2:     	movq	(%r12,%r8,8), %rcx
1800026d6:     	movq	0x8(%r12,%r8,8), %r8
1800026db:     	movsd	(%r15,%r8,8), %xmm0
1800026e1:     	addsd	(%r15,%rdx,8), %xmm0
1800026e7:     	movapd	%xmm0, %xmm1
1800026eb:     	andpd	%xmm10, %xmm1
1800026f0:     	ucomisd	%xmm11, %xmm1
1800026f5:     	jae	0x180002782 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xe02>
1800026fb:     	movsd	0x10(%r15,%r8,8), %xmm1
180002702:     	addsd	0x10(%r15,%rdx,8), %xmm1
180002709:     	movapd	%xmm1, %xmm2
18000270d:     	andpd	%xmm10, %xmm2
180002712:     	ucomisd	%xmm11, %xmm2
180002717:     	jae	0x180002782 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xe02>
180002719:     	movsd	0x20(%r15,%r8,8), %xmm2
180002720:     	addsd	0x20(%r15,%rdx,8), %xmm2
180002727:     	movapd	%xmm2, %xmm3
18000272b:     	andpd	%xmm10, %xmm3
180002730:     	ucomisd	%xmm11, %xmm3
180002735:     	jae	0x180002782 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xe02>
180002737:     	movq	(%rbp), %r8
18000273b:     	leaq	0x6(%r8), %rdx
18000273f:     	cmpq	%rdi, %rdx
180002742:     	jg	0x18000202a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x6aa>
180002748:     	movq	%rdx, (%rbp)
18000274c:     	cmpb	$0x0, (%r13)
180002751:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
180002757:     	movsd	%xmm0, (%r15,%r8,8)
18000275d:     	movsd	%xmm1, 0x10(%r15,%r8,8)
180002764:     	movsd	%xmm2, 0x20(%r15,%r8,8)
18000276b:     	movzbl	(%r13), %r9d
180002770:     	movl	%r9d, %edx
180002773:     	negb	%dl
180002775:     	movl	$0x0, %edx
18000277a:     	sbbq	%rdx, %rdx
18000277d:     	orq	%r8, %rdx
180002780:     	jmp	0x18000279b <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xe1b>
180002782:     	movb	$0x1, (%r13)
180002787:     	movq	$0x5b8d85, 0x18(%rbp)   # imm = 0x5B8D85
18000278f:     	movzbl	(%r13), %r9d
180002794:     	movq	$-0x1, %rdx
18000279b:     	testb	%r9b, %r9b
18000279e:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
1800027a4:     	movsd	(%r15,%rdx,8), %xmm0
1800027aa:     	addsd	(%r15,%rax,8), %xmm0
1800027b0:     	movapd	%xmm0, %xmm1
1800027b4:     	andpd	%xmm10, %xmm1
1800027b9:     	ucomisd	%xmm11, %xmm1
1800027be:     	jae	0x18000284b <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xecb>
1800027c4:     	movsd	0x10(%r15,%rdx,8), %xmm1
1800027cb:     	addsd	0x10(%r15,%rax,8), %xmm1
1800027d2:     	movapd	%xmm1, %xmm2
1800027d6:     	andpd	%xmm10, %xmm2
1800027db:     	ucomisd	%xmm11, %xmm2
1800027e0:     	jae	0x18000284b <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xecb>
1800027e2:     	movsd	0x20(%r15,%rdx,8), %xmm2
1800027e9:     	addsd	0x20(%r15,%rax,8), %xmm2
1800027f0:     	movapd	%xmm2, %xmm3
1800027f4:     	andpd	%xmm10, %xmm3
1800027f9:     	ucomisd	%xmm11, %xmm3
1800027fe:     	jae	0x18000284b <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xecb>
180002800:     	movq	(%rbp), %rax
180002804:     	leaq	0x6(%rax), %rdx
180002808:     	cmpq	%rdi, %rdx
18000280b:     	jg	0x18000202a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x6aa>
180002811:     	movq	%rdx, (%rbp)
180002815:     	cmpb	$0x0, (%r13)
18000281a:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
180002820:     	movsd	%xmm0, (%r15,%rax,8)
180002826:     	movsd	%xmm1, 0x10(%r15,%rax,8)
18000282d:     	movsd	%xmm2, 0x20(%r15,%rax,8)
180002834:     	movzbl	(%r13), %r8d
180002839:     	movl	%r8d, %edx
18000283c:     	negb	%dl
18000283e:     	movl	$0x0, %edx
180002843:     	sbbq	%rdx, %rdx
180002846:     	orq	%rax, %rdx
180002849:     	jmp	0x180002864 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xee4>
18000284b:     	movb	$0x1, (%r13)
180002850:     	movq	$0x5b8d85, 0x18(%rbp)   # imm = 0x5B8D85
180002858:     	movzbl	(%r13), %r8d
18000285d:     	movq	$-0x1, %rdx
180002864:     	testb	%r8b, %r8b
180002867:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
18000286d:     	movq	(%rbp), %rax
180002871:     	leaq	0x2(%rax), %r8
180002875:     	cmpq	%rdi, %r8
180002878:     	jg	0x18000202a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x6aa>
18000287e:     	movq	%r8, (%rbp)
180002882:     	cmpb	$0x0, (%r13)
180002887:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
18000288d:     	movq	%rcx, (%r12,%rax,8)
180002891:     	cmpb	$0x0, (%r13)
180002896:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
18000289c:     	movsd	(%r15,%rdx,8), %xmm0
1800028a2:     	mulsd	%xmm0, %xmm0
1800028a6:     	movapd	%xmm0, %xmm1
1800028aa:     	andpd	%xmm10, %xmm1
1800028af:     	ucomisd	%xmm11, %xmm1
1800028b4:     	jae	0x180002914 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xf94>
1800028b6:     	movsd	0x10(%r15,%rdx,8), %xmm1
1800028bd:     	mulsd	%xmm1, %xmm1
1800028c1:     	movapd	%xmm1, %xmm2
1800028c5:     	andpd	%xmm10, %xmm2
1800028ca:     	ucomisd	%xmm11, %xmm2
1800028cf:     	jae	0x180002914 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xf94>
1800028d1:     	addsd	%xmm1, %xmm0
1800028d5:     	movapd	%xmm0, %xmm1
1800028d9:     	andpd	%xmm10, %xmm1
1800028de:     	ucomisd	%xmm11, %xmm1
1800028e3:     	jae	0x180002914 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xf94>
1800028e5:     	movsd	0x20(%r15,%rdx,8), %xmm1
1800028ec:     	mulsd	%xmm1, %xmm1
1800028f0:     	movapd	%xmm1, %xmm2
1800028f4:     	andpd	%xmm10, %xmm2
1800028f9:     	ucomisd	%xmm11, %xmm2
1800028fe:     	jae	0x180002914 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xf94>
180002900:     	addsd	%xmm1, %xmm0
180002904:     	movapd	%xmm0, %xmm1
180002908:     	andpd	%xmm10, %xmm1
18000290d:     	ucomisd	%xmm11, %xmm1
180002912:     	jb	0x180002925 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xfa5>
180002914:     	movb	$0x1, (%r13)
180002919:     	movq	$0x14fb183, 0x18(%rbp)  # imm = 0x14FB183
180002921:     	xorpd	%xmm0, %xmm0
180002925:     	cmpb	$0x0, (%r13)
18000292a:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
180002930:     	sqrtsd	%xmm0, %xmm0
180002934:     	ucomisd	%xmm12, %xmm0
180002939:     	jne	0x180002958 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xfd8>
18000293b:     	jp	0x180002958 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xfd8>
18000293d:     	movb	$0x1, (%r13)
180002942:     	movq	$0x3d0902, 0x18(%rbp)   # imm = 0x3D0902
18000294a:     	movzbl	(%r13), %edx
18000294f:     	movq	$-0x1, %r8
180002956:     	jmp	0x1800029cf <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x104f>
180002958:     	movq	(%rbp), %rcx
18000295c:     	leaq	0x6(%rcx), %r8
180002960:     	cmpq	%rdi, %r8
180002963:     	jg	0x18000202a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x6aa>
180002969:     	movsd	(%r15,%rdx,8), %xmm1
18000296f:     	movsd	0x10(%r15,%rdx,8), %xmm2
180002976:     	movsd	0x20(%r15,%rdx,8), %xmm3
18000297d:     	movq	%r8, (%rbp)
180002981:     	cmpb	$0x0, (%r13)
180002986:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
18000298c:     	movsd	0x6a54(%rip), %xmm4     # 0x1800093e8
180002994:     	divsd	%xmm0, %xmm4
180002998:     	mulsd	%xmm4, %xmm1
18000299c:     	mulsd	%xmm4, %xmm2
1800029a0:     	mulsd	%xmm3, %xmm4
1800029a4:     	movsd	%xmm1, (%r15,%rcx,8)
1800029aa:     	movsd	%xmm2, 0x10(%r15,%rcx,8)
1800029b1:     	movsd	%xmm4, 0x20(%r15,%rcx,8)
1800029b8:     	movzbl	(%r13), %edx
1800029bd:     	movl	%edx, %r8d
1800029c0:     	negb	%r8b
1800029c3:     	movl	$0x0, %r8d
1800029c9:     	sbbq	%r8, %r8
1800029cc:     	orq	%rcx, %r8
1800029cf:     	testb	%dl, %dl
1800029d1:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
1800029d7:     	movq	%r8, 0x8(%r12,%rax,8)
1800029dc:     	cmpb	$0x0, (%r13)
1800029e1:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
1800029e7:     	movq	0x8(%rbp), %rcx
1800029eb:     	leaq	0x1(%rcx), %rdx
1800029ef:     	movq	%rdx, 0x8(%rbp)
1800029f3:     	cmpq	0x10(%rbp), %rcx
1800029f7:     	jge	0x180002e5d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x14dd>
1800029fd:     	movq	$0x0, 0x88(%rsp)
180002a09:     	movb	$0x0, 0x90(%rsp)
180002a11:     	movq	$0x0, 0x98(%rsp)
180002a1d:     	movb	$0x0, 0xa0(%rsp)
180002a25:     	movq	$0x0, 0xa8(%rsp)
180002a31:     	movb	$0x0, 0xb0(%rsp)
180002a39:     	movq	$0x0, 0xb8(%rsp)
180002a45:     	movb	$0x0, 0xc0(%rsp)
180002a4d:     	movq	$0x0, 0xc8(%rsp)
180002a59:     	movb	$0x0, 0xd0(%rsp)
180002a61:     	movq	$0x0, 0xd8(%rsp)
180002a6d:     	movb	$0x0, 0xe0(%rsp)
180002a75:     	movq	%rax, 0x28(%rsp)
180002a7a:     	movq	%rbx, 0x20(%rsp)
180002a7f:     	movq	$-0x1, 0x50(%rsp)
180002a88:     	movq	$-0x1, 0x48(%rsp)
180002a91:     	movq	$-0x1, 0x40(%rsp)
180002a9a:     	movq	$-0x1, 0x38(%rsp)
180002aa3:     	movq	$-0x1, 0x30(%rsp)
180002aac:     	leaq	0x88(%rsp), %rcx
180002ab4:     	leaq	0x108(%rsp), %rdx
180002abc:     	movq	%r14, %r8
180002abf:     	xorl	%r9d, %r9d
180002ac2:     	callq	0x180002e80 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1500>
180002ac7:     	testl	%eax, %eax
180002ac9:     	jne	0x180002e6f <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x14ef>
180002acf:     	cmpb	$0x0, (%r13)
180002ad4:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
180002ada:     	movsd	0x88(%rsp), %xmm2
180002ae3:     	movsd	0x98(%rsp), %xmm1
180002aec:     	movsd	0xa8(%rsp), %xmm0
180002af5:     	decq	0x8(%rbp)
180002af9:     	movq	0x220(%rsp), %rax
180002b01:     	movq	0x8(%r12,%rax,8), %rax
180002b06:     	movq	%rax, %rcx
180002b09:     	subq	0xf0(%rsp), %rcx
180002b11:     	movq	%rcx, %rdx
180002b14:     	notq	%rdx
180002b17:     	testq	%rdx, %rax
180002b1a:     	js	0x180001b79 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1f9>
180002b20:     	cmpb	$0x0, (%r13)
180002b25:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
180002b2b:     	movabsq	$-0x8000000000000000, %rdx # imm = 0x8000000000000000
180002b35:     	cmpq	%rdx, %rcx
180002b38:     	je	0x180001b79 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1f9>
180002b3e:     	decq	%rcx
180002b41:     	movq	0x220(%rsp), %rdx
180002b49:     	movq	0x10(%r12,%rdx,8), %rdx
180002b4e:     	cvtsi2sd	%rcx, %xmm3
180002b53:     	cvtsi2sd	%rdx, %xmm4
180002b58:     	mulsd	%xmm3, %xmm4
180002b5c:     	andpd	%xmm10, %xmm4
180002b61:     	ucomisd	%xmm13, %xmm4
180002b66:     	jae	0x180001b79 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1f9>
180002b6c:     	imulq	%rdx, %rcx
180002b70:     	addq	0x78(%rsp), %rax
180002b75:     	imulq	%rdx, %rax
180002b79:     	movq	0x68(%rsp), %r8
180002b7e:     	addq	%r8, %rax
180002b81:     	xorq	%rax, %rcx
180002b84:     	movq	%rax, %rdx
180002b87:     	xorq	%r8, %rdx
180002b8a:     	testq	%rdx, %rcx
180002b8d:     	js	0x180001b79 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1f9>
180002b93:     	xorps	%xmm3, %xmm3
180002b96:     	cvtsi2sd	%rax, %xmm3
180002b9b:     	mulsd	0x6855(%rip), %xmm3     # 0x1800093f8
180002ba3:     	andpd	%xmm10, %xmm3
180002ba8:     	ucomisd	%xmm13, %xmm3
180002bad:     	jae	0x180001b79 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1f9>
180002bb3:     	mulsd	%xmm15, %xmm2
180002bb8:     	movapd	%xmm2, %xmm3
180002bbc:     	andpd	%xmm10, %xmm3
180002bc1:     	ucomisd	%xmm11, %xmm3
180002bc6:     	jae	0x180002d71 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x13f1>
180002bcc:     	movsd	0x6834(%rip), %xmm4     # 0x180009408
180002bd4:     	ucomisd	%xmm3, %xmm4
180002bd8:     	jbe	0x180002d71 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x13f1>
180002bde:     	leaq	(%rax,%rax,2), %rcx
180002be2:     	cvttsd2si	%xmm2, %rdx
180002be7:     	testq	%rdx, %rdx
180002bea:     	movl	$0x0, %r8d
180002bf0:     	cmovleq	%r8, %rdx
180002bf4:     	cmpq	$0xff, %rdx
180002bfb:     	movl	$0xff, %r8d
180002c01:     	cmovgeq	%r8, %rdx
180002c05:     	movq	0x220(%rsp), %r8
180002c0d:     	movq	(%r12,%r8,8), %r8
180002c11:     	movq	(%r12,%r8,8), %r10
180002c15:     	testq	%rax, %rax
180002c18:     	movq	%rcx, %r9
180002c1b:     	jns	0x180002c29 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x12a9>
180002c1d:     	movq	%r10, %r9
180002c20:     	addq	%rcx, %r9
180002c23:     	js	0x180002d71 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x13f1>
180002c29:     	cmpq	%r10, %r9
180002c2c:     	jge	0x180002d71 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x13f1>
180002c32:     	movq	0x10(%r12,%r8,8), %r8
180002c37:     	leaq	(%r12,%r8,8), %r8
180002c3b:     	movq	%rdx, (%r8,%r9,8)
180002c3f:     	mulsd	%xmm15, %xmm1
180002c44:     	movapd	%xmm1, %xmm2
180002c48:     	andpd	%xmm10, %xmm2
180002c4d:     	ucomisd	%xmm11, %xmm2
180002c52:     	jae	0x180002d93 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1413>
180002c58:     	movsd	0x67a8(%rip), %xmm3     # 0x180009408
180002c60:     	ucomisd	%xmm2, %xmm3
180002c64:     	jbe	0x180002d93 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1413>
180002c6a:     	cvttsd2si	%xmm1, %r8
180002c6f:     	testq	%r8, %r8
180002c72:     	movl	$0x0, %edx
180002c77:     	cmovleq	%rdx, %r8
180002c7b:     	cmpq	$0xff, %r8
180002c82:     	movl	$0xff, %edx
180002c87:     	cmovgeq	%rdx, %r8
180002c8b:     	leaq	0x1(%rcx), %r9
180002c8f:     	movq	%rcx, %rdx
180002c92:     	notq	%rdx
180002c95:     	testq	%rdx, %r9
180002c98:     	js	0x180001b79 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1f9>
180002c9e:     	cmpb	$0x0, (%r13)
180002ca3:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
180002ca9:     	movq	0x220(%rsp), %r10
180002cb1:     	movq	(%r12,%r10,8), %r10
180002cb5:     	testq	%rax, %rax
180002cb8:     	movq	(%r12,%r10,8), %r11
180002cbc:     	jns	0x180002cc7 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1347>
180002cbe:     	addq	%r11, %r9
180002cc1:     	js	0x180002d93 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1413>
180002cc7:     	cmpq	%r11, %r9
180002cca:     	jge	0x180002d93 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1413>
180002cd0:     	movq	0x10(%r12,%r10,8), %r10
180002cd5:     	leaq	(%r12,%r10,8), %r10
180002cd9:     	movq	%r8, (%r10,%r9,8)
180002cdd:     	mulsd	%xmm15, %xmm0
180002ce2:     	movapd	%xmm0, %xmm1
180002ce6:     	andpd	%xmm10, %xmm1
180002ceb:     	ucomisd	%xmm11, %xmm1
180002cf0:     	jae	0x180002da2 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1422>
180002cf6:     	movsd	0x670a(%rip), %xmm2     # 0x180009408
180002cfe:     	ucomisd	%xmm1, %xmm2
180002d02:     	jbe	0x180002da2 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1422>
180002d08:     	cvttsd2si	%xmm0, %r8
180002d0d:     	testq	%r8, %r8
180002d10:     	movl	$0x0, %r9d
180002d16:     	cmovleq	%r9, %r8
180002d1a:     	cmpq	$0xff, %r8
180002d21:     	movl	$0xff, %r9d
180002d27:     	cmovgeq	%r9, %r8
180002d2b:     	addq	$0x2, %rcx
180002d2f:     	testq	%rdx, %rcx
180002d32:     	js	0x180001b79 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1f9>
180002d38:     	cmpb	$0x0, (%r13)
180002d3d:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
180002d43:     	movq	0x220(%rsp), %rdx
180002d4b:     	movq	(%r12,%rdx,8), %rdx
180002d4f:     	testq	%rax, %rax
180002d52:     	movq	(%r12,%rdx,8), %rax
180002d56:     	jns	0x180002d5d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x13dd>
180002d58:     	addq	%rax, %rcx
180002d5b:     	js	0x180002da2 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1422>
180002d5d:     	cmpq	%rax, %rcx
180002d60:     	jge	0x180002da2 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1422>
180002d62:     	movq	0x10(%r12,%rdx,8), %rax
180002d67:     	leaq	(%r12,%rax,8), %rax
180002d6b:     	movq	%r8, (%rax,%rcx,8)
180002d6f:     	jmp	0x180002d7e <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x13fe>
180002d71:     	movb	$0x1, (%r13)
180002d76:     	movq	$0x7a1203, 0x18(%rbp)   # imm = 0x7A1203
180002d7e:     	incq	0x68(%rsp)
180002d83:     	cmpb	$0x0, (%r13)
180002d88:     	je	0x1800025d9 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xc59>
180002d8e:     	jmp	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
180002d93:     	movb	$0x1, (%r13)
180002d98:     	movq	$0x7a1204, 0x18(%rbp)   # imm = 0x7A1204
180002da0:     	jmp	0x180002d7e <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x13fe>
180002da2:     	movb	$0x1, (%r13)
180002da7:     	movq	$0x7a1205, 0x18(%rbp)   # imm = 0x7A1205
180002daf:     	jmp	0x180002d7e <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x13fe>
180002db1:     	decq	0x78(%rsp)
180002db6:     	movq	0x70(%rsp), %rax
180002dbb:     	cmpq	0xe8(%rsp), %rax
180002dc3:     	jne	0x180002586 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xc06>
180002dc9:     	jmp	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
180002dce:     	movq	(%rbp), %r8
180002dd2:     	leaq	0x6(%r8), %r9
180002dd6:     	cmpq	%rdi, %r9
180002dd9:     	jg	0x18000202a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x6aa>
180002ddf:     	movsd	(%r15,%rax,8), %xmm2
180002de5:     	movsd	0x10(%r15,%rax,8), %xmm3
180002dec:     	movsd	0x20(%r15,%rax,8), %xmm4
180002df3:     	movq	%r9, (%rbp)
180002df7:     	cmpb	$0x0, (%r13)
180002dfc:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
180002e02:     	movsd	0x65de(%rip), %xmm5     # 0x1800093e8
180002e0a:     	divsd	%xmm1, %xmm5
180002e0e:     	mulsd	%xmm5, %xmm2
180002e12:     	mulsd	%xmm5, %xmm3
180002e16:     	mulsd	%xmm4, %xmm5
180002e1a:     	leaq	(,%r8,8), %r9
180002e22:     	movsd	%xmm2, (%r15,%r8,8)
180002e28:     	movsd	%xmm3, 0x10(%r15,%r8,8)
180002e2f:     	movsd	%xmm5, 0x20(%r15,%r8,8)
180002e36:     	movzbl	(%r13), %eax
180002e3b:     	testb	%al, %al
180002e3d:     	movq	$-0x8, %r8
180002e44:     	cmoveq	%r9, %r8
180002e48:     	movq	%r8, 0x80(%rsp)
180002e50:     	testb	%al, %al
180002e52:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
180002e58:     	jmp	0x1800024f2 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xb72>
180002e5d:     	movb	$0x1, (%r13)
180002e62:     	movq	$0x13, 0x18(%rbp)
180002e6a:     	jmp	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
180002e6f:     	movq	0x100(%rsp), %rsi
180002e77:     	jmp	0x180001b8f <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20f>
180002e7c:     	nopl	(%rax)
180002e80:     	pushq	%r15
180002e82:     	pushq	%r14
180002e84:     	pushq	%r13
180002e86:     	pushq	%r12
180002e88:     	pushq	%rsi
180002e89:     	pushq	%rdi
180002e8a:     	pushq	%rbp
180002e8b:     	pushq	%rbx
180002e8c:     	subq	$0x288, %rsp            # imm = 0x288
180002e93:     	movapd	%xmm15, 0x270(%rsp)
180002e9d:     	movapd	%xmm14, 0x260(%rsp)
180002ea7:     	movapd	%xmm13, 0x250(%rsp)
180002eb1:     	movapd	%xmm12, 0x240(%rsp)
180002ebb:     	movapd	%xmm11, 0x230(%rsp)
180002ec5:     	movapd	%xmm10, 0x220(%rsp)
180002ecf:     	movapd	%xmm9, 0x210(%rsp)
180002ed9:     	movapd	%xmm8, 0x200(%rsp)
180002ee3:     	movapd	%xmm7, 0x1f0(%rsp)
180002eec:     	movapd	%xmm6, 0x1e0(%rsp)
180002ef5:     	movq	$0x0, 0x178(%rsp)
180002f01:     	movb	$0x0, 0x180(%rsp)
180002f09:     	movq	$0x0, 0x188(%rsp)
180002f15:     	movb	$0x0, 0x190(%rsp)
180002f1d:     	movq	$0x0, 0x198(%rsp)
180002f29:     	movb	$0x0, 0x1a0(%rsp)
180002f31:     	movq	$0x0, 0x1a8(%rsp)
180002f3d:     	movb	$0x0, 0x1b0(%rsp)
180002f45:     	movq	$0x0, 0x1b8(%rsp)
180002f51:     	movb	$0x0, 0x1c0(%rsp)
180002f59:     	movq	$0x0, 0x1c8(%rsp)
180002f65:     	movb	$0x0, 0x1d0(%rsp)
180002f6d:     	movq	$0x0, 0x118(%rsp)
180002f79:     	movb	$0x0, 0x120(%rsp)
180002f81:     	movq	$0x0, 0x128(%rsp)
180002f8d:     	movb	$0x0, 0x130(%rsp)
180002f95:     	movq	$0x0, 0x138(%rsp)
180002fa1:     	movb	$0x0, 0x140(%rsp)
180002fa9:     	movq	$0x0, 0x148(%rsp)
180002fb5:     	movb	$0x0, 0x150(%rsp)
180002fbd:     	movq	$0x0, 0x158(%rsp)
180002fc9:     	movb	$0x0, 0x160(%rsp)
180002fd1:     	movq	$0x0, 0x168(%rsp)
180002fdd:     	movb	$0x0, 0x170(%rsp)
180002fe5:     	movq	(%r8), %r14
180002fe8:     	movq	0x8(%r8), %rdi
180002fec:     	movq	0x10(%r8), %rbx
180002ff0:     	movq	0x18(%r8), %rsi
180002ff4:     	movq	0x20(%r8), %r15
180002ff8:     	cmpq	$0x1, %r9
180002ffc:     	je	0x180003063 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x16e3>
180002ffe:     	testq	%r9, %r9
180003001:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
180003007:     	movq	0x2f0(%rsp), %r9
18000300f:     	movq	0x28(%rdi,%r9,8), %rdx
180003014:     	cmpq	$0x3, %rdx
180003018:     	jle	0x180003165 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x17e5>
18000301e:     	movb	$0x0, 0x58(%rcx)
180003022:     	movq	$0x0, 0x50(%rcx)
18000302a:     	movb	$0x0, 0x48(%rcx)
18000302e:     	movq	$0x0, 0x40(%rcx)
180003036:     	movb	$0x0, 0x38(%rcx)
18000303a:     	movq	$0x0, 0x30(%rcx)
180003042:     	movb	$0x1, 0x28(%rcx)
180003046:     	movq	$0x0, 0x20(%rcx)
18000304e:     	movb	$0x1, 0x18(%rcx)
180003052:     	movq	$0x0, 0x10(%rcx)
18000305a:     	movb	$0x1, 0x8(%rcx)
18000305e:     	jmp	0x180005492 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3b12>
180003063:     	movq	0x318(%rsp), %r13
18000306b:     	movq	0x300(%rsp), %r12
180003073:     	movq	%r12, %rdx
180003076:     	sarq	$0x3f, %rdx
18000307a:     	andq	%r15, %rdx
18000307d:     	leaq	(%rdi,%r12,8), %rax
180003081:     	movq	(%rax,%rdx,8), %rdx
180003085:     	testq	%rdx, %rdx
180003088:     	je	0x180003b53 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x21d3>
18000308e:     	cmpq	$0x1, %rdx
180003092:     	jne	0x180003b99 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2219>
180003098:     	cmpb	$0x0, (%rsi)
18000309b:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
1800030a1:     	movq	0x8(%rdi), %rdx
1800030a5:     	movsd	(%r14,%r13,8), %xmm0
1800030ab:     	subsd	(%r14,%rdx,8), %xmm0
1800030b1:     	movapd	0x6317(%rip), %xmm1     # 0x1800093d0
1800030b9:     	andpd	%xmm0, %xmm1
1800030bd:     	ucomisd	0x631b(%rip), %xmm1     # 0x1800093e0
1800030c5:     	jae	0x180003ba9 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2229>
1800030cb:     	movsd	0x10(%r14,%r13,8), %xmm1
1800030d2:     	subsd	0x10(%r14,%rdx,8), %xmm1
1800030d9:     	movapd	0x62ef(%rip), %xmm2     # 0x1800093d0
1800030e1:     	andpd	%xmm1, %xmm2
1800030e5:     	ucomisd	0x62f3(%rip), %xmm2     # 0x1800093e0
1800030ed:     	jae	0x180003ba9 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2229>
1800030f3:     	movsd	0x20(%r14,%r13,8), %xmm2
1800030fa:     	subsd	0x20(%r14,%rdx,8), %xmm2
180003101:     	movapd	0x62c7(%rip), %xmm3     # 0x1800093d0
180003109:     	andpd	%xmm2, %xmm3
18000310d:     	ucomisd	0x62cb(%rip), %xmm3     # 0x1800093e0
180003115:     	jae	0x180003ba9 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2229>
18000311b:     	movq	(%rbx), %r10
18000311e:     	leaq	0x6(%r10), %rdx
180003122:     	movb	$0x2, %r9b
180003125:     	cmpq	%r15, %rdx
180003128:     	jg	0x180003de1 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2461>
18000312e:     	movq	%rdx, (%rbx)
180003131:     	cmpb	$0x0, (%rsi)
180003134:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
18000313a:     	movsd	%xmm0, (%r14,%r10,8)
180003140:     	movsd	%xmm1, 0x10(%r14,%r10,8)
180003147:     	movsd	%xmm2, 0x20(%r14,%r10,8)
18000314e:     	movzbl	(%rsi), %r9d
180003152:     	xorl	%edx, %edx
180003154:     	movl	%r9d, %r11d
180003157:     	negb	%r11b
18000315a:     	sbbq	%rdx, %rdx
18000315d:     	orq	%r10, %rdx
180003160:     	jmp	0x180003bbf <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x223f>
180003165:     	leaq	0x1(%rdx), %rax
180003169:     	notq	%rdx
18000316c:     	testq	%rdx, %rax
18000316f:     	js	0x180005437 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3ab7>
180003175:     	cmpb	$0x0, (%rsi)
180003178:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
18000317e:     	movq	%rax, 0x28(%rdi,%r9,8)
180003183:     	movq	(%rbx), %r12
180003186:     	cmpq	%r15, %r12
180003189:     	movq	%r12, %rax
18000318c:     	jle	0x180003196 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1816>
18000318e:     	movb	$0x2, (%rsi)
180003191:     	movq	(%rbx), %r12
180003194:     	xorl	%eax, %eax
180003196:     	leaq	0x3(%r12), %rdx
18000319b:     	cmpq	%r15, %rdx
18000319e:     	jg	0x180003c44 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x22c4>
1800031a4:     	movq	%rdx, (%rbx)
1800031a7:     	cmpb	$0x0, (%rsi)
1800031aa:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
1800031b0:     	movq	%r12, %r11
1800031b3:     	sarq	$0x3f, %r11
1800031b7:     	andq	%r15, %r11
1800031ba:     	leaq	(%rdi,%r12,8), %rbp
1800031be:     	movq	$0x0, (%rbp,%r11,8)
1800031c7:     	xorl	%edx, %edx
1800031c9:     	cmpq	$-0x1, %r12
1800031cd:     	movl	$0x0, %r10d
1800031d3:     	cmovlq	%r15, %r10
1800031d7:     	movq	$0x0, 0x8(%rbp,%r10,8)
1800031e0:     	cmpq	$-0x2, %r12
1800031e4:     	cmovlq	%r15, %rdx
1800031e8:     	movq	%rax, 0x10(%rbp,%rdx,8)
1800031ed:     	cmpb	$0x0, (%rsi)
1800031f0:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
1800031f6:     	movq	%r12, 0x90(%rsp)
1800031fe:     	movq	%rdx, 0xa0(%rsp)
180003206:     	movq	0x18(%rdi,%r9,8), %rax
18000320b:     	cmpq	$0x0, (%rdi,%rax,8)
180003210:     	jle	0x180003b00 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2180>
180003216:     	xorl	%edx, %edx
180003218:     	movapd	0x61b0(%rip), %xmm0     # 0x1800093d0
180003220:     	movsd	0x61b8(%rip), %xmm1     # 0x1800093e0
180003228:     	movsd	0x61e0(%rip), %xmm2     # 0x180009410
180003230:     	movq	%r10, 0xc0(%rsp)
180003238:     	movq	%rbp, 0x98(%rsp)
180003240:     	movq	%rax, 0x68(%rsp)
180003245:     	movq	%r14, 0xf0(%rsp)
18000324d:     	movq	0x10(%rdi,%rax,8), %rax
180003252:     	leaq	(%rdi,%rax,8), %rax
180003256:     	movq	%rdx, 0x100(%rsp)
18000325e:     	movq	(%rax,%rdx,8), %rax
180003262:     	movq	%rax, %rdx
180003265:     	sarq	$0x3f, %rdx
180003269:     	andq	%r15, %rdx
18000326c:     	leaq	(%rdi,%rax,8), %r9
180003270:     	movq	(%r9,%rdx,8), %r13
180003274:     	cmpq	$-0x1, %rax
180003278:     	movl	$0x0, %eax
18000327d:     	cmovlq	%r15, %rax
180003281:     	movq	0x8(%r9,%rax,8), %rax
180003286:     	movq	%rax, 0xf8(%rsp)
18000328e:     	movq	%r13, %rdx
180003291:     	sarq	$0x3f, %rdx
180003295:     	andq	%r15, %rdx
180003298:     	leaq	(%rdi,%r13,8), %rax
18000329c:     	movq	(%rax,%rdx,8), %rdx
1800032a0:     	testq	%rdx, %rdx
1800032a3:     	je	0x180003391 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1a11>
1800032a9:     	cmpq	$0x1, %rdx
1800032ad:     	jne	0x1800055af <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3c2f>
1800032b3:     	cmpb	$0x0, (%rsi)
1800032b6:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
1800032bc:     	movq	0x2f8(%rsp), %rdx
1800032c4:     	movq	0x8(%rdi,%rdx,8), %rdx
1800032c9:     	movq	0x20(%rax), %rax
1800032cd:     	movsd	(%r14,%rdx,8), %xmm4
1800032d3:     	mulsd	(%r14,%rax,8), %xmm4
1800032d9:     	movapd	%xmm4, %xmm3
1800032dd:     	andpd	%xmm0, %xmm3
1800032e1:     	ucomisd	%xmm1, %xmm3
1800032e5:     	jae	0x18000344a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1aca>
1800032eb:     	movsd	0x10(%r14,%rdx,8), %xmm3
1800032f2:     	mulsd	0x10(%r14,%rax,8), %xmm3
1800032f9:     	movapd	%xmm3, %xmm5
1800032fd:     	andpd	%xmm0, %xmm5
180003301:     	ucomisd	%xmm1, %xmm5
180003305:     	jae	0x18000344a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1aca>
18000330b:     	addsd	%xmm3, %xmm4
18000330f:     	movapd	%xmm4, %xmm3
180003313:     	andpd	%xmm0, %xmm3
180003317:     	ucomisd	%xmm1, %xmm3
18000331b:     	jae	0x18000344a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1aca>
180003321:     	movsd	0x20(%r14,%rdx,8), %xmm3
180003328:     	mulsd	0x20(%r14,%rax,8), %xmm3
18000332f:     	movapd	%xmm3, %xmm5
180003333:     	andpd	%xmm0, %xmm5
180003337:     	ucomisd	%xmm1, %xmm5
18000333b:     	jae	0x18000344a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1aca>
180003341:     	addsd	%xmm3, %xmm4
180003345:     	movapd	%xmm4, %xmm3
180003349:     	andpd	%xmm0, %xmm3
18000334d:     	ucomisd	%xmm1, %xmm3
180003351:     	jae	0x18000344a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1aca>
180003357:     	xorpd	%xmm3, %xmm3
18000335b:     	ucomisd	%xmm3, %xmm4
18000335f:     	jne	0x180003367 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x19e7>
180003361:     	jnp	0x180003462 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1ae2>
180003367:     	movapd	%xmm2, %xmm3
18000336b:     	divsd	%xmm4, %xmm3
18000336f:     	movl	$0x1, %eax
180003374:     	movq	%rax, 0x78(%rsp)
180003379:     	movq	(%rbp,%r11,8), %rax
18000337e:     	cmpq	0x8(%rbp,%r10,8), %rax
180003383:     	movq	%rax, %r10
180003386:     	je	0x180003697 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1d17>
18000338c:     	jmp	0x180003a25 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20a5>
180003391:     	cmpb	$0x0, (%rsi)
180003394:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
18000339a:     	movq	0x8(%rax), %rdx
18000339e:     	movq	0x2f8(%rsp), %rax
1800033a6:     	movq	(%rdi,%rax,8), %rax
1800033aa:     	movsd	(%r14,%rdx,8), %xmm3
1800033b0:     	subsd	(%r14,%rax,8), %xmm3
1800033b6:     	movapd	%xmm3, %xmm4
1800033ba:     	andpd	%xmm0, %xmm4
1800033be:     	ucomisd	%xmm1, %xmm4
1800033c2:     	jae	0x180003483 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1b03>
1800033c8:     	movsd	0x10(%r14,%rdx,8), %xmm4
1800033cf:     	subsd	0x10(%r14,%rax,8), %xmm4
1800033d6:     	movapd	%xmm4, %xmm5
1800033da:     	andpd	%xmm0, %xmm5
1800033de:     	ucomisd	%xmm1, %xmm5
1800033e2:     	jae	0x180003483 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1b03>
1800033e8:     	movsd	0x20(%r14,%rdx,8), %xmm5
1800033ef:     	subsd	0x20(%r14,%rax,8), %xmm5
1800033f6:     	movapd	%xmm5, %xmm6
1800033fa:     	andpd	%xmm0, %xmm6
1800033fe:     	ucomisd	%xmm1, %xmm6
180003402:     	jae	0x180003483 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1b03>
180003404:     	movq	(%rbx), %rdx
180003407:     	leaq	0x6(%rdx), %rax
18000340b:     	cmpq	%r15, %rax
18000340e:     	jg	0x180003c44 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x22c4>
180003414:     	movq	%rax, (%rbx)
180003417:     	cmpb	$0x0, (%rsi)
18000341a:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
180003420:     	movsd	%xmm3, (%r14,%rdx,8)
180003426:     	movsd	%xmm4, 0x10(%r14,%rdx,8)
18000342d:     	movsd	%xmm5, 0x20(%r14,%rdx,8)
180003434:     	movzbl	(%rsi), %r9d
180003438:     	movl	%r9d, %eax
18000343b:     	negb	%al
18000343d:     	movl	$0x0, %eax
180003442:     	sbbq	%rax, %rax
180003445:     	orq	%rdx, %rax
180003448:     	jmp	0x180003499 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1b19>
18000344a:     	movb	$0x1, (%rsi)
18000344d:     	movq	$0x14fb183, 0x18(%rbx)  # imm = 0x14FB183
180003455:     	cmpb	$0x0, (%rsi)
180003458:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
18000345e:     	xorpd	%xmm3, %xmm3
180003462:     	movq	$0x0, 0x78(%rsp)
18000346b:     	movq	(%rbp,%r11,8), %rax
180003470:     	cmpq	0x8(%rbp,%r10,8), %rax
180003475:     	movq	%rax, %r10
180003478:     	je	0x180003697 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1d17>
18000347e:     	jmp	0x180003a25 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20a5>
180003483:     	movb	$0x1, (%rsi)
180003486:     	movq	$0xf4243, 0x18(%rbx)    # imm = 0xF4243
18000348e:     	movzbl	(%rsi), %r9d
180003492:     	movq	$-0x1, %rax
180003499:     	xorpd	%xmm3, %xmm3
18000349d:     	testb	%r9b, %r9b
1800034a0:     	je	0x1800034b9 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1b39>
1800034a2:     	movq	$0x0, 0x78(%rsp)
1800034ab:     	cmpb	$0x0, (%rsi)
1800034ae:     	je	0x180003684 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1d04>
1800034b4:     	jmp	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
1800034b9:     	movq	0x2f8(%rsp), %rdx
1800034c1:     	movq	0x8(%rdi,%rdx,8), %rdx
1800034c6:     	movsd	(%r14,%rax,8), %xmm4
1800034cc:     	mulsd	(%r14,%rdx,8), %xmm4
1800034d2:     	movapd	%xmm4, %xmm5
1800034d6:     	andpd	%xmm0, %xmm5
1800034da:     	ucomisd	%xmm1, %xmm5
1800034de:     	jae	0x18000353c <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1bbc>
1800034e0:     	movsd	0x10(%r14,%rax,8), %xmm5
1800034e7:     	mulsd	0x10(%r14,%rdx,8), %xmm5
1800034ee:     	movapd	%xmm5, %xmm6
1800034f2:     	andpd	%xmm0, %xmm6
1800034f6:     	ucomisd	%xmm1, %xmm6
1800034fa:     	jae	0x18000353c <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1bbc>
1800034fc:     	addsd	%xmm5, %xmm4
180003500:     	movapd	%xmm4, %xmm5
180003504:     	andpd	%xmm0, %xmm5
180003508:     	ucomisd	%xmm1, %xmm5
18000350c:     	jae	0x18000353c <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1bbc>
18000350e:     	movsd	0x20(%r14,%rax,8), %xmm5
180003515:     	mulsd	0x20(%r14,%rdx,8), %xmm5
18000351c:     	movapd	%xmm5, %xmm6
180003520:     	andpd	%xmm0, %xmm6
180003524:     	ucomisd	%xmm1, %xmm6
180003528:     	jae	0x18000353c <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1bbc>
18000352a:     	addsd	%xmm5, %xmm4
18000352e:     	movapd	%xmm4, %xmm5
180003532:     	andpd	%xmm0, %xmm5
180003536:     	ucomisd	%xmm1, %xmm5
18000353a:     	jb	0x180003554 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1bd4>
18000353c:     	movb	$0x1, (%rsi)
18000353f:     	movq	$0x14fb183, 0x18(%rbx)  # imm = 0x14FB183
180003547:     	xorpd	%xmm4, %xmm4
18000354b:     	cmpb	$0x0, (%rsi)
18000354e:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
180003554:     	movsd	0x10(%r14,%r13,8), %xmm5
18000355b:     	mulsd	%xmm5, %xmm5
18000355f:     	movapd	%xmm5, %xmm6
180003563:     	andpd	%xmm0, %xmm6
180003567:     	ucomisd	%xmm1, %xmm6
18000356b:     	jae	0x180003667 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1ce7>
180003571:     	movsd	(%r14,%rax,8), %xmm6
180003577:     	mulsd	%xmm6, %xmm6
18000357b:     	movapd	%xmm6, %xmm7
18000357f:     	andpd	%xmm0, %xmm7
180003583:     	ucomisd	%xmm1, %xmm7
180003587:     	jae	0x1800035e5 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1c65>
180003589:     	movsd	0x10(%r14,%rax,8), %xmm7
180003590:     	mulsd	%xmm7, %xmm7
180003594:     	movapd	%xmm7, %xmm8
180003599:     	andpd	%xmm0, %xmm8
18000359e:     	ucomisd	%xmm1, %xmm8
1800035a3:     	jae	0x1800035e5 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1c65>
1800035a5:     	addsd	%xmm7, %xmm6
1800035a9:     	movapd	%xmm6, %xmm7
1800035ad:     	andpd	%xmm0, %xmm7
1800035b1:     	ucomisd	%xmm1, %xmm7
1800035b5:     	jae	0x1800035e5 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1c65>
1800035b7:     	movsd	0x20(%r14,%rax,8), %xmm7
1800035be:     	mulsd	%xmm7, %xmm7
1800035c2:     	movapd	%xmm7, %xmm8
1800035c7:     	andpd	%xmm0, %xmm8
1800035cc:     	ucomisd	%xmm1, %xmm8
1800035d1:     	jae	0x1800035e5 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1c65>
1800035d3:     	addsd	%xmm7, %xmm6
1800035d7:     	movapd	%xmm6, %xmm7
1800035db:     	andpd	%xmm0, %xmm7
1800035df:     	ucomisd	%xmm1, %xmm7
1800035e3:     	jb	0x1800035fd <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1c7d>
1800035e5:     	movb	$0x1, (%rsi)
1800035e8:     	movq	$0x14fb183, 0x18(%rbx)  # imm = 0x14FB183
1800035f0:     	xorpd	%xmm6, %xmm6
1800035f4:     	cmpb	$0x0, (%rsi)
1800035f7:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
1800035fd:     	movapd	%xmm4, %xmm7
180003601:     	mulsd	%xmm4, %xmm7
180003605:     	movapd	%xmm7, %xmm8
18000360a:     	andpd	%xmm0, %xmm8
18000360f:     	ucomisd	%xmm1, %xmm8
180003614:     	jae	0x180003667 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1ce7>
180003616:     	subsd	%xmm7, %xmm6
18000361a:     	movapd	%xmm6, %xmm7
18000361e:     	andpd	%xmm0, %xmm7
180003622:     	ucomisd	%xmm1, %xmm7
180003626:     	jae	0x180003667 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1ce7>
180003628:     	subsd	%xmm6, %xmm5
18000362c:     	movapd	%xmm5, %xmm6
180003630:     	andpd	%xmm0, %xmm6
180003634:     	ucomisd	%xmm1, %xmm6
180003638:     	jae	0x180003667 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1ce7>
18000363a:     	ucomisd	%xmm5, %xmm3
18000363e:     	ja	0x1800034a2 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1b22>
180003644:     	xorps	%xmm3, %xmm3
180003647:     	sqrtsd	%xmm5, %xmm3
18000364b:     	subsd	%xmm3, %xmm4
18000364f:     	movl	$0x1, %eax
180003654:     	movq	%rax, 0x78(%rsp)
180003659:     	movapd	%xmm4, %xmm3
18000365d:     	cmpb	$0x0, (%rsi)
180003660:     	je	0x180003684 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1d04>
180003662:     	jmp	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
180003667:     	movb	$0x1, (%rsi)
18000366a:     	movq	$0xe4e1c4, 0x18(%rbx)   # imm = 0xE4E1C4
180003672:     	movq	$0x0, 0x78(%rsp)
18000367b:     	cmpb	$0x0, (%rsi)
18000367e:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
180003684:     	movq	(%rbp,%r11,8), %rax
180003689:     	cmpq	0x8(%rbp,%r10,8), %rax
18000368e:     	movq	%rax, %r10
180003691:     	jne	0x180003a25 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20a5>
180003697:     	leaq	(%r10,%r10), %r12
18000369b:     	testq	%r10, %r10
18000369e:     	movl	$0x4, %eax
1800036a3:     	cmoveq	%rax, %r12
1800036a7:     	movq	(%rbx), %rdx
1800036aa:     	leaq	(%rdx,%r12), %rax
1800036ae:     	cmpq	%r15, %rax
1800036b1:     	jg	0x180003c44 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x22c4>
1800036b7:     	movq	%rdx, 0x60(%rsp)
1800036bc:     	movq	%rax, (%rbx)
1800036bf:     	cmpb	$0x0, (%rsi)
1800036c2:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
1800036c8:     	movq	%r10, 0xb8(%rsp)
1800036d0:     	testq	%r10, %r10
1800036d3:     	jle	0x1800039ee <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x206e>
1800036d9:     	movq	0x98(%rsp), %rax
1800036e1:     	movq	0xa0(%rsp), %rdx
1800036e9:     	movq	0x10(%rax,%rdx,8), %r10
1800036ee:     	movq	0xb8(%rsp), %rax
1800036f6:     	movl	%eax, %ebp
1800036f8:     	andl	$0x7, %ebp
1800036fb:     	cmpq	$0x8, %rax
1800036ff:     	jae	0x180003711 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1d91>
180003701:     	xorl	%r9d, %r9d
180003704:     	leaq	(,%r15,8), %r14
18000370c:     	jmp	0x1800039b6 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2036>
180003711:     	movq	%rsi, 0x70(%rsp)
180003716:     	movq	%r12, 0x1d8(%rsp)
18000371e:     	movq	%r13, 0xb0(%rsp)
180003726:     	movq	%r11, 0xe0(%rsp)
18000372e:     	movq	%rbx, 0xe8(%rsp)
180003736:     	movq	%rax, %r9
180003739:     	movabsq	$0x7ffffffffffffff8, %rax # imm = 0x7FFFFFFFFFFFFFF8
180003743:     	andq	%rax, %r9
180003746:     	leaq	(%rdi,%r10,8), %r13
18000374a:     	movq	0x60(%rsp), %rax
18000374f:     	leaq	(%rdi,%rax,8), %r11
180003753:     	xorl	%eax, %eax
180003755:     	leaq	(,%r15,8), %r14
18000375d:     	leaq	0x8(,%r15,8), %rdx
180003765:     	movq	%rdx, 0x88(%rsp)
18000376d:     	leaq	0x10(,%r15,8), %rdx
180003775:     	movq	%rdx, 0xa8(%rsp)
18000377d:     	leaq	0x18(,%r15,8), %rdx
180003785:     	movq	%rdx, 0xd8(%rsp)
18000378d:     	leaq	0x20(,%r15,8), %rdx
180003795:     	movq	%rdx, 0xd0(%rsp)
18000379d:     	leaq	0x28(,%r15,8), %rdx
1800037a5:     	movq	%rdx, 0x110(%rsp)
1800037ad:     	leaq	0x30(,%r15,8), %rdx
1800037b5:     	movq	%rdx, 0xc8(%rsp)
1800037bd:     	leaq	0x38(,%r15,8), %rdx
1800037c5:     	movq	%rdx, 0x108(%rsp)
1800037cd:     	movq	%r9, 0x80(%rsp)
1800037d5:     	leaq	(%r10,%rax), %r12
1800037d9:     	movq	%r12, %rdx
1800037dc:     	sarq	$0x3f, %rdx
1800037e0:     	andq	%r14, %rdx
1800037e3:     	addq	%r13, %rdx
1800037e6:     	movq	(%rdx,%rax,8), %rbx
1800037ea:     	movq	0x60(%rsp), %rdx
1800037ef:     	leaq	(%rdx,%rax), %r9
1800037f3:     	movq	%r9, %rdx
1800037f6:     	sarq	$0x3f, %rdx
1800037fa:     	andq	%r14, %rdx
1800037fd:     	addq	%r11, %rdx
180003800:     	movq	%rbx, (%rdx,%rax,8)
180003804:     	movq	%r12, %rdx
180003807:     	incq	%rdx
18000380a:     	movl	$0x8, %edx
18000380f:     	movq	0x88(%rsp), %rsi
180003817:     	cmovsq	%rsi, %rdx
18000381b:     	addq	%r13, %rdx
18000381e:     	movq	(%rdx,%rax,8), %rdx
180003822:     	movq	%r9, %rbx
180003825:     	incq	%rbx
180003828:     	movl	$0x8, %ebx
18000382d:     	cmovsq	%rsi, %rbx
180003831:     	addq	%r11, %rbx
180003834:     	movq	%rdx, (%rbx,%rax,8)
180003838:     	movq	%r12, %rdx
18000383b:     	addq	$0x2, %rdx
18000383f:     	movl	$0x10, %edx
180003844:     	movq	0xa8(%rsp), %rsi
18000384c:     	cmovsq	%rsi, %rdx
180003850:     	addq	%r13, %rdx
180003853:     	movq	(%rdx,%rax,8), %rdx
180003857:     	movq	%r9, %rbx
18000385a:     	addq	$0x2, %rbx
18000385e:     	movl	$0x10, %ebx
180003863:     	cmovsq	%rsi, %rbx
180003867:     	addq	%r11, %rbx
18000386a:     	movq	%rdx, (%rbx,%rax,8)
18000386e:     	movq	%r12, %rdx
180003871:     	addq	$0x3, %rdx
180003875:     	movl	$0x18, %edx
18000387a:     	movq	0xd8(%rsp), %rsi
180003882:     	cmovsq	%rsi, %rdx
180003886:     	addq	%r13, %rdx
180003889:     	movq	(%rdx,%rax,8), %rdx
18000388d:     	movq	%r9, %rbx
180003890:     	addq	$0x3, %rbx
180003894:     	movl	$0x18, %ebx
180003899:     	cmovsq	%rsi, %rbx
18000389d:     	addq	%r11, %rbx
1800038a0:     	movq	%rdx, (%rbx,%rax,8)
1800038a4:     	movq	%r12, %rdx
1800038a7:     	addq	$0x4, %rdx
1800038ab:     	movl	$0x20, %edx
1800038b0:     	movq	0xd0(%rsp), %rsi
1800038b8:     	cmovsq	%rsi, %rdx
1800038bc:     	addq	%r13, %rdx
1800038bf:     	movq	(%rdx,%rax,8), %rdx
1800038c3:     	movq	%r9, %rbx
1800038c6:     	addq	$0x4, %rbx
1800038ca:     	movl	$0x20, %ebx
1800038cf:     	cmovsq	%rsi, %rbx
1800038d3:     	addq	%r11, %rbx
1800038d6:     	movq	%rdx, (%rbx,%rax,8)
1800038da:     	movq	%r12, %rdx
1800038dd:     	addq	$0x5, %rdx
1800038e1:     	movl	$0x28, %edx
1800038e6:     	movq	0x110(%rsp), %rsi
1800038ee:     	cmovsq	%rsi, %rdx
1800038f2:     	addq	%r13, %rdx
1800038f5:     	movq	(%rdx,%rax,8), %rdx
1800038f9:     	movq	%r9, %rbx
1800038fc:     	addq	$0x5, %rbx
180003900:     	movl	$0x28, %ebx
180003905:     	cmovsq	%rsi, %rbx
180003909:     	addq	%r11, %rbx
18000390c:     	movq	%rdx, (%rbx,%rax,8)
180003910:     	movq	%r12, %rdx
180003913:     	addq	$0x6, %rdx
180003917:     	movl	$0x30, %edx
18000391c:     	movq	0xc8(%rsp), %rsi
180003924:     	cmovsq	%rsi, %rdx
180003928:     	addq	%r13, %rdx
18000392b:     	movq	(%rdx,%rax,8), %rdx
18000392f:     	movq	%r9, %rbx
180003932:     	addq	$0x6, %rbx
180003936:     	movl	$0x30, %ebx
18000393b:     	cmovsq	%rsi, %rbx
18000393f:     	addq	%r11, %rbx
180003942:     	movq	%rdx, (%rbx,%rax,8)
180003946:     	addq	$0x7, %r12
18000394a:     	movl	$0x38, %edx
18000394f:     	movq	0x108(%rsp), %rsi
180003957:     	cmovsq	%rsi, %rdx
18000395b:     	addq	%r13, %rdx
18000395e:     	movq	(%rdx,%rax,8), %rdx
180003962:     	addq	$0x7, %r9
180003966:     	movl	$0x38, %r9d
18000396c:     	cmovsq	%rsi, %r9
180003970:     	addq	%r11, %r9
180003973:     	movq	%rdx, (%r9,%rax,8)
180003977:     	movq	0x80(%rsp), %r9
18000397f:     	addq	$0x8, %rax
180003983:     	cmpq	%rax, %r9
180003986:     	jne	0x1800037d5 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1e55>
18000398c:     	testq	%rbp, %rbp
18000398f:     	movq	0xe8(%rsp), %rbx
180003997:     	movq	0xe0(%rsp), %r11
18000399f:     	movq	0xb0(%rsp), %r13
1800039a7:     	movq	0x1d8(%rsp), %r12
1800039af:     	movq	0x70(%rsp), %rsi
1800039b4:     	je	0x1800039ee <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x206e>
1800039b6:     	movq	0x60(%rsp), %rax
1800039bb:     	addq	%r9, %rax
1800039be:     	addq	%r9, %r10
1800039c1:     	movq	%r10, %rdx
1800039c4:     	sarq	$0x3f, %rdx
1800039c8:     	andq	%r14, %rdx
1800039cb:     	addq	%rdi, %rdx
1800039ce:     	movq	(%rdx,%r10,8), %rdx
1800039d2:     	movq	%rax, %r9
1800039d5:     	sarq	$0x3f, %r9
1800039d9:     	andq	%r14, %r9
1800039dc:     	addq	%rdi, %r9
1800039df:     	movq	%rdx, (%r9,%rax,8)
1800039e3:     	incq	%rax
1800039e6:     	incq	%r10
1800039e9:     	decq	%rbp
1800039ec:     	jne	0x1800039c1 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2041>
1800039ee:     	movq	0x98(%rsp), %rbp
1800039f6:     	movq	0xc0(%rsp), %rax
1800039fe:     	movq	%r12, 0x8(%rbp,%rax,8)
180003a03:     	movq	0xa0(%rsp), %rax
180003a0b:     	movq	0x60(%rsp), %rdx
180003a10:     	movq	%rdx, 0x10(%rbp,%rax,8)
180003a15:     	movq	0xf0(%rsp), %r14
180003a1d:     	movq	0xb8(%rsp), %r10
180003a25:     	leaq	0x1(%r10), %rax
180003a29:     	movq	%rax, (%rbp,%r11,8)
180003a2e:     	cmpb	$0x0, (%rsi)
180003a31:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
180003a37:     	movq	(%rbx), %rax
180003a3a:     	leaq	0x4(%rax), %rdx
180003a3e:     	cmpq	%r15, %rdx
180003a41:     	jg	0x180003c44 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x22c4>
180003a47:     	movq	0xa0(%rsp), %r9
180003a4f:     	addq	0x10(%rbp,%r9,8), %r10
180003a54:     	movq	%rdx, (%rbx)
180003a57:     	cmpb	$0x0, (%rsi)
180003a5a:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
180003a60:     	movq	%r11, %rbp
180003a63:     	movq	0x100(%rsp), %r11
180003a6b:     	incq	%r11
180003a6e:     	movq	%rax, %rdx
180003a71:     	sarq	$0x3f, %rdx
180003a75:     	andq	%r15, %rdx
180003a78:     	leaq	(%rdi,%rax,8), %r9
180003a7c:     	movq	%r13, (%r9,%rdx,8)
180003a80:     	cmpq	$-0x1, %rax
180003a84:     	movl	$0x0, %edx
180003a89:     	cmovlq	%r15, %rdx
180003a8d:     	movq	%r10, %r12
180003a90:     	leaq	(%r14,%rax,8), %r10
180003a94:     	movsd	%xmm3, 0x8(%r10,%rdx,8)
180003a9b:     	movq	0xc0(%rsp), %r10
180003aa3:     	cmpq	$-0x2, %rax
180003aa7:     	movl	$0x0, %edx
180003aac:     	cmovlq	%r15, %rdx
180003ab0:     	movq	0x78(%rsp), %r13
180003ab5:     	movq	%r13, 0x10(%r9,%rdx,8)
180003aba:     	cmpq	$-0x3, %rax
180003abe:     	movl	$0x0, %edx
180003ac3:     	cmovlq	%r15, %rdx
180003ac7:     	movq	0xf8(%rsp), %r13
180003acf:     	movq	%r13, 0x18(%r9,%rdx,8)
180003ad4:     	leaq	(%rdi,%r12,8), %rdx
180003ad8:     	sarq	$0x3f, %r12
180003adc:     	andq	%r15, %r12
180003adf:     	movq	%rax, (%rdx,%r12,8)
180003ae3:     	movq	%r11, %rdx
180003ae6:     	movq	%rbp, %r11
180003ae9:     	movq	0x98(%rsp), %rbp
180003af1:     	movq	0x68(%rsp), %rax
180003af6:     	cmpq	(%rdi,%rax,8), %rdx
180003afa:     	jl	0x18000324d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x18cd>
180003b00:     	movq	(%rbp), %r9
180003b04:     	testq	%r9, %r9
180003b07:     	jle	0x18000540e <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3a8e>
180003b0d:     	movq	0x90(%rsp), %rax
180003b15:     	movq	0x10(%rdi,%rax,8), %rax
180003b1a:     	leaq	(%rdi,%rax,8), %r10
180003b1e:     	xorpd	%xmm0, %xmm0
180003b22:     	movq	$-0x1, 0x88(%rsp)
180003b2e:     	xorl	%r12d, %r12d
180003b31:     	movsd	0x58e7(%rip), %xmm1     # 0x180009420
180003b39:     	movq	$0x0, 0x60(%rsp)
180003b42:     	movq	$-0x1, 0x80(%rsp)
180003b4e:     	jmp	0x180003ef0 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2570>
180003b53:     	movq	0x10(%rax), %rdx
180003b57:     	xorl	%eax, %eax
180003b59:     	cmpq	$-0x2, %rdx
180003b5d:     	movl	$0x0, %r9d
180003b63:     	cmovlq	%r15, %r9
180003b67:     	cmpq	$-0x4, %rdx
180003b6b:     	cmovlq	%r15, %rax
180003b6f:     	cmpb	$0x0, (%rsi)
180003b72:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
180003b78:     	leaq	(%r14,%rdx,8), %r10
180003b7c:     	sarq	$0x3f, %rdx
180003b80:     	andq	%r15, %rdx
180003b83:     	movsd	(%r10,%rdx,8), %xmm8
180003b89:     	movsd	0x10(%r10,%r9,8), %xmm7
180003b90:     	movsd	0x20(%r10,%rax,8), %xmm6
180003b97:     	jmp	0x180003bde <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x225e>
180003b99:     	movb	$0x1, (%rsi)
180003b9c:     	movq	$0x1406f42, 0x18(%rbx)  # imm = 0x1406F42
180003ba4:     	jmp	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
180003ba9:     	movb	$0x1, (%rsi)
180003bac:     	movq	$0xf4243, 0x18(%rbx)    # imm = 0xF4243
180003bb4:     	movzbl	(%rsi), %r9d
180003bb8:     	movq	$-0x1, %rdx
180003bbf:     	xorpd	%xmm6, %xmm6
180003bc3:     	testb	%r9b, %r9b
180003bc6:     	je	0x180003dc1 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2441>
180003bcc:     	xorpd	%xmm7, %xmm7
180003bd0:     	xorpd	%xmm8, %xmm8
180003bd5:     	cmpb	$0x0, (%rsi)
180003bd8:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
180003bde:     	movq	0x320(%rsp), %rdx
180003be6:     	movq	0x308(%rsp), %r11
180003bee:     	movsd	0x20(%r14,%r12,8), %xmm1
180003bf5:     	xorpd	%xmm0, %xmm0
180003bf9:     	ucomisd	%xmm0, %xmm1
180003bfd:     	setbe	%bpl
180003c01:     	ja	0x180003c4c <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x22cc>
180003c03:     	shlq	$0x3, %r12
180003c07:     	xorpd	%xmm1, %xmm1
180003c0b:     	xorpd	%xmm2, %xmm2
180003c0f:     	movsd	0x18(%r14,%r12), %xmm4
180003c16:     	xorpd	%xmm3, %xmm3
180003c1a:     	ucomisd	%xmm3, %xmm4
180003c1e:     	jbe	0x18000554a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3bca>
180003c24:     	movq	(%rbx), %rax
180003c27:     	cmpq	%r15, %rax
180003c2a:     	movq	%rax, %rdx
180003c2d:     	jle	0x180003c37 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x22b7>
180003c2f:     	movb	$0x2, (%rsi)
180003c32:     	movq	(%rbx), %rax
180003c35:     	xorl	%edx, %edx
180003c37:     	leaq	0x3(%rax), %r8
180003c3b:     	cmpq	%r15, %r8
180003c3e:     	jle	0x180003f74 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x25f4>
180003c44:     	movb	$0x2, (%rsi)
180003c47:     	jmp	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
180003c4c:     	movq	0x310(%rsp), %rax
180003c54:     	movq	0x8(%rdi,%rax,8), %rax
180003c59:     	movsd	(%r14,%rax,8), %xmm0
180003c5f:     	mulsd	(%r14,%rdx,8), %xmm0
180003c65:     	movapd	0x5763(%rip), %xmm1     # 0x1800093d0
180003c6d:     	andpd	%xmm0, %xmm1
180003c71:     	ucomisd	0x5767(%rip), %xmm1     # 0x1800093e0
180003c79:     	jae	0x180003cf7 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2377>
180003c7b:     	movsd	0x10(%r14,%rax,8), %xmm1
180003c82:     	mulsd	0x10(%r14,%rdx,8), %xmm1
180003c89:     	movapd	0x573f(%rip), %xmm2     # 0x1800093d0
180003c91:     	andpd	%xmm1, %xmm2
180003c95:     	ucomisd	0x5743(%rip), %xmm2     # 0x1800093e0
180003c9d:     	jae	0x180003cf7 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2377>
180003c9f:     	addsd	%xmm1, %xmm0
180003ca3:     	movapd	0x5725(%rip), %xmm1     # 0x1800093d0
180003cab:     	andpd	%xmm0, %xmm1
180003caf:     	ucomisd	0x5729(%rip), %xmm1     # 0x1800093e0
180003cb7:     	jae	0x180003cf7 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2377>
180003cb9:     	movsd	0x20(%r14,%rax,8), %xmm1
180003cc0:     	mulsd	0x20(%r14,%rdx,8), %xmm1
180003cc7:     	movapd	0x5701(%rip), %xmm2     # 0x1800093d0
180003ccf:     	andpd	%xmm1, %xmm2
180003cd3:     	ucomisd	0x5705(%rip), %xmm2     # 0x1800093e0
180003cdb:     	jae	0x180003cf7 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2377>
180003cdd:     	addsd	%xmm1, %xmm0
180003ce1:     	movapd	0x56e7(%rip), %xmm1     # 0x1800093d0
180003ce9:     	andpd	%xmm0, %xmm1
180003ced:     	ucomisd	0x56eb(%rip), %xmm1     # 0x1800093e0
180003cf5:     	jb	0x180003d0f <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x238f>
180003cf7:     	movb	$0x1, (%rsi)
180003cfa:     	movq	$0x14fb183, 0x18(%rbx)  # imm = 0x14FB183
180003d02:     	cmpb	$0x0, (%rsi)
180003d05:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
180003d0b:     	xorpd	%xmm0, %xmm0
180003d0f:     	movsd	(%r14,%rdx,8), %xmm1
180003d15:     	mulsd	%xmm0, %xmm1
180003d19:     	movapd	0x56af(%rip), %xmm2     # 0x1800093d0
180003d21:     	andpd	%xmm1, %xmm2
180003d25:     	ucomisd	0x56b3(%rip), %xmm2     # 0x1800093e0
180003d2d:     	jae	0x180003de9 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2469>
180003d33:     	movsd	0x10(%r14,%rdx,8), %xmm2
180003d3a:     	mulsd	%xmm0, %xmm2
180003d3e:     	movapd	0x568a(%rip), %xmm3     # 0x1800093d0
180003d46:     	andpd	%xmm2, %xmm3
180003d4a:     	ucomisd	0x568e(%rip), %xmm3     # 0x1800093e0
180003d52:     	jae	0x180003de9 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2469>
180003d58:     	mulsd	0x20(%r14,%rdx,8), %xmm0
180003d5f:     	movapd	0x5669(%rip), %xmm3     # 0x1800093d0
180003d67:     	andpd	%xmm0, %xmm3
180003d6b:     	ucomisd	0x566d(%rip), %xmm3     # 0x1800093e0
180003d73:     	jae	0x180003de9 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2469>
180003d75:     	movq	(%rbx), %r9
180003d78:     	leaq	0x6(%r9), %rdx
180003d7c:     	cmpq	%r15, %rdx
180003d7f:     	jg	0x180003c44 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x22c4>
180003d85:     	movq	%rdx, (%rbx)
180003d88:     	cmpb	$0x0, (%rsi)
180003d8b:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
180003d91:     	movsd	%xmm1, (%r14,%r9,8)
180003d97:     	movsd	%xmm2, 0x10(%r14,%r9,8)
180003d9e:     	movsd	%xmm0, 0x20(%r14,%r9,8)
180003da5:     	movzbl	(%rsi), %r10d
180003da9:     	xorl	%edx, %edx
180003dab:     	movl	%r10d, %r11d
180003dae:     	negb	%r11b
180003db1:     	movq	0x308(%rsp), %r11
180003db9:     	sbbq	%rdx, %rdx
180003dbc:     	orq	%r9, %rdx
180003dbf:     	jmp	0x180003dff <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x247f>
180003dc1:     	movq	0x28(%rax), %r11
180003dc5:     	testq	%r11, %r11
180003dc8:     	je	0x180004eab <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x352b>
180003dce:     	movq	(%rbx), %r10
180003dd1:     	leaq	0x6(%r10), %rbp
180003dd5:     	movb	$0x2, %r9b
180003dd8:     	cmpq	%r15, %rbp
180003ddb:     	jle	0x180004ebb <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x353b>
180003de1:     	movb	%r9b, (%rsi)
180003de4:     	jmp	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
180003de9:     	movb	$0x1, (%rsi)
180003dec:     	movq	$0x1d905c2, 0x18(%rbx)  # imm = 0x1D905C2
180003df4:     	movzbl	(%rsi), %r10d
180003df8:     	movq	$-0x1, %rdx
180003dff:     	testb	%r10b, %r10b
180003e02:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
180003e08:     	movsd	(%r14,%rdx,8), %xmm0
180003e0e:     	addsd	%xmm0, %xmm0
180003e12:     	movapd	0x55b6(%rip), %xmm1     # 0x1800093d0
180003e1a:     	andpd	%xmm0, %xmm1
180003e1e:     	ucomisd	0x55ba(%rip), %xmm1     # 0x1800093e0
180003e26:     	jae	0x180005026 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x36a6>
180003e2c:     	movsd	0x10(%r14,%rdx,8), %xmm1
180003e33:     	addsd	%xmm1, %xmm1
180003e37:     	movapd	0x5591(%rip), %xmm2     # 0x1800093d0
180003e3f:     	andpd	%xmm1, %xmm2
180003e43:     	ucomisd	0x5595(%rip), %xmm2     # 0x1800093e0
180003e4b:     	jae	0x180005026 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x36a6>
180003e51:     	movsd	0x20(%r14,%rdx,8), %xmm2
180003e58:     	addsd	%xmm2, %xmm2
180003e5c:     	movapd	0x556c(%rip), %xmm3     # 0x1800093d0
180003e64:     	andpd	%xmm2, %xmm3
180003e68:     	ucomisd	0x5570(%rip), %xmm3     # 0x1800093e0
180003e70:     	jae	0x180005026 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x36a6>
180003e76:     	movq	(%rbx), %r9
180003e79:     	leaq	0x6(%r9), %rdx
180003e7d:     	cmpq	%r15, %rdx
180003e80:     	jg	0x180003c44 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x22c4>
180003e86:     	movq	%rdx, (%rbx)
180003e89:     	cmpb	$0x0, (%rsi)
180003e8c:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
180003e92:     	movsd	%xmm0, (%r14,%r9,8)
180003e98:     	movsd	%xmm1, 0x10(%r14,%r9,8)
180003e9f:     	movsd	%xmm2, 0x20(%r14,%r9,8)
180003ea6:     	movzbl	(%rsi), %r10d
180003eaa:     	xorl	%edx, %edx
180003eac:     	movl	%r10d, %r11d
180003eaf:     	negb	%r11b
180003eb2:     	movq	0x308(%rsp), %r11
180003eba:     	sbbq	%rdx, %rdx
180003ebd:     	orq	%r9, %rdx
180003ec0:     	jmp	0x18000503c <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x36bc>
180003ec5:     	movq	%rdx, 0x80(%rsp)
180003ecd:     	movapd	%xmm2, %xmm0
180003ed1:     	movb	$0x1, %al
180003ed3:     	movq	%rax, 0x60(%rsp)
180003ed8:     	movq	%r13, 0x88(%rsp)
180003ee0:     	movb	$0x1, %r12b
180003ee3:     	addq	$0x8, %r10
180003ee7:     	decq	%r9
180003eea:     	je	0x1800053ae <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3a2e>
180003ef0:     	movq	(%r10), %r13
180003ef3:     	leaq	(%rdi,%r13,8), %rbp
180003ef7:     	cmpq	$-0x1, %r13
180003efb:     	movl	$0x0, %edx
180003f00:     	cmovlq	%r15, %rdx
180003f04:     	cmpq	$-0x2, %r13
180003f08:     	movl	$0x0, %r11d
180003f0e:     	cmovlq	%r15, %r11
180003f12:     	cmpq	$-0x3, %r13
180003f16:     	movl	$0x0, %eax
180003f1b:     	cmovlq	%r15, %rax
180003f1f:     	cmpq	$0x0, 0x10(%rbp,%r11,8)
180003f25:     	je	0x180003ee3 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2563>
180003f27:     	leaq	(%r14,%r13,8), %r11
180003f2b:     	movsd	0x8(%r11,%rdx,8), %xmm2
180003f32:     	ucomisd	%xmm1, %xmm2
180003f36:     	jbe	0x180003ee3 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2563>
180003f38:     	sarq	$0x3f, %r13
180003f3c:     	andq	%r15, %r13
180003f3f:     	movq	(%rbp,%r13,8), %rdx
180003f44:     	movq	0x18(%rbp,%rax,8), %r13
180003f49:     	testb	$0x1, %r12b
180003f4d:     	je	0x180003ec5 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2545>
180003f53:     	testb	$0x1, 0x60(%rsp)
180003f58:     	je	0x180005403 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3a83>
180003f5e:     	ucomisd	%xmm2, %xmm0
180003f62:     	ja	0x180003ec5 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2545>
180003f68:     	movb	$0x1, %al
180003f6a:     	movq	%rax, 0x60(%rsp)
180003f6f:     	jmp	0x180003ee0 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2560>
180003f74:     	movq	%r8, (%rbx)
180003f77:     	cmpb	$0x0, (%rsi)
180003f7a:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
180003f80:     	movq	%rax, %r8
180003f83:     	sarq	$0x3f, %r8
180003f87:     	andq	%r15, %r8
180003f8a:     	leaq	(%rdi,%rax,8), %r9
180003f8e:     	movq	$0x0, (%r9,%r8,8)
180003f96:     	xorl	%r10d, %r10d
180003f99:     	cmpq	$-0x1, %rax
180003f9d:     	movl	$0x0, %r11d
180003fa3:     	cmovlq	%r15, %r11
180003fa7:     	movq	%r11, 0xd8(%rsp)
180003faf:     	movq	$0x0, 0x8(%r9,%r11,8)
180003fb8:     	cmpq	$-0x2, %rax
180003fbc:     	cmovlq	%r15, %r10
180003fc0:     	movq	%r10, 0xa8(%rsp)
180003fc8:     	movq	%rdx, 0x10(%r9,%r10,8)
180003fcd:     	cmpb	$0x0, (%rsi)
180003fd0:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
180003fd6:     	movq	0x308(%rsp), %rdx
180003fde:     	movq	0x8(%rdi,%rdx,8), %rdx
180003fe3:     	movq	%rdx, 0xd0(%rsp)
180003feb:     	cmpq	$0x0, (%rdi,%rdx,8)
180003ff0:     	jle	0x180004b70 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x31f0>
180003ff6:     	xorl	%r9d, %r9d
180003ff9:     	movapd	0x53cf(%rip), %xmm4     # 0x1800093d0
180004001:     	movsd	0x53d7(%rip), %xmm5     # 0x1800093e0
180004009:     	xorpd	%xmm9, %xmm9
18000400e:     	movq	0xd0(%rsp), %rdx
180004016:     	movq	0x10(%rdi,%rdx,8), %rdx
18000401b:     	leaq	(%rdi,%rdx,8), %rdx
18000401f:     	movq	(%rdx,%r9,8), %rdx
180004023:     	movq	%rdx, 0x88(%rsp)
18000402b:     	incq	%r9
18000402e:     	movq	%r9, 0x110(%rsp)
180004036:     	movq	0x308(%rsp), %rdx
18000403e:     	movq	0x18(%rdi,%rdx,8), %rdx
180004043:     	movq	%rdx, 0x80(%rsp)
18000404b:     	movq	$0x0, 0x60(%rsp)
180004054:     	movq	0x80(%rsp), %rdx
18000405c:     	movq	0x60(%rsp), %r9
180004061:     	cmpq	(%rdi,%rdx,8), %r9
180004065:     	jge	0x180004705 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2d85>
18000406b:     	cmpb	$0x0, (%rsi)
18000406e:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
180004074:     	movq	0x80(%rsp), %rdx
18000407c:     	movq	0x10(%rdi,%rdx,8), %rdx
180004081:     	leaq	(%rdi,%rdx,8), %rdx
180004085:     	movq	0x60(%rsp), %r9
18000408a:     	movq	(%rdx,%r9,8), %rdx
18000408e:     	leaq	(%rdi,%rdx,8), %r9
180004092:     	sarq	$0x3f, %rdx
180004096:     	andq	%r15, %rdx
180004099:     	movq	(%r9,%rdx,8), %rbp
18000409d:     	movq	0x88(%rsp), %rdx
1800040a5:     	movsd	(%r14,%rdx,8), %xmm11
1800040ab:     	subsd	(%r14,%r13,8), %xmm11
1800040b1:     	movapd	%xmm11, %xmm12
1800040b6:     	andpd	%xmm4, %xmm12
1800040bb:     	ucomisd	%xmm5, %xmm12
1800040c0:     	jae	0x18000414b <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x27cb>
1800040c6:     	movsd	0x10(%r14,%rdx,8), %xmm13
1800040cd:     	subsd	0x10(%r14,%r13,8), %xmm13
1800040d4:     	movapd	%xmm13, %xmm12
1800040d9:     	andpd	%xmm4, %xmm12
1800040de:     	ucomisd	%xmm5, %xmm12
1800040e3:     	jae	0x18000414b <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x27cb>
1800040e5:     	movsd	0x20(%r14,%rdx,8), %xmm14
1800040ec:     	subsd	0x20(%r14,%r13,8), %xmm14
1800040f3:     	movapd	%xmm14, %xmm12
1800040f8:     	andpd	%xmm4, %xmm12
1800040fd:     	ucomisd	%xmm5, %xmm12
180004102:     	jae	0x18000414b <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x27cb>
180004104:     	movq	(%rbx), %r10
180004107:     	leaq	0x6(%r10), %rdx
18000410b:     	cmpq	%r15, %rdx
18000410e:     	jg	0x180003c44 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x22c4>
180004114:     	movq	%rdx, (%rbx)
180004117:     	cmpb	$0x0, (%rsi)
18000411a:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
180004120:     	movsd	%xmm11, (%r14,%r10,8)
180004126:     	movsd	%xmm13, 0x10(%r14,%r10,8)
18000412d:     	movsd	%xmm14, 0x20(%r14,%r10,8)
180004134:     	movzbl	(%rsi), %edx
180004137:     	movl	%edx, %r9d
18000413a:     	negb	%r9b
18000413d:     	movl	$0x0, %r9d
180004143:     	sbbq	%r9, %r9
180004146:     	orq	%r10, %r9
180004149:     	jmp	0x180004160 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x27e0>
18000414b:     	movb	$0x1, (%rsi)
18000414e:     	movq	$0xf4243, 0x18(%rbx)    # imm = 0xF4243
180004156:     	movzbl	(%rsi), %edx
180004159:     	movq	$-0x1, %r9
180004160:     	testb	%dl, %dl
180004162:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
180004168:     	movq	(%rbx), %r11
18000416b:     	leaq	0x2(%r11), %rdx
18000416f:     	cmpq	%r15, %rdx
180004172:     	jg	0x180003c44 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x22c4>
180004178:     	movq	%rdx, (%rbx)
18000417b:     	cmpb	$0x0, (%rsi)
18000417e:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
180004184:     	movq	%r13, (%rdi,%r11,8)
180004188:     	cmpb	$0x0, (%rsi)
18000418b:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
180004191:     	movsd	(%r14,%r9,8), %xmm11
180004197:     	mulsd	%xmm11, %xmm11
18000419c:     	movapd	%xmm11, %xmm12
1800041a1:     	andpd	%xmm4, %xmm12
1800041a6:     	ucomisd	%xmm5, %xmm12
1800041ab:     	jae	0x180004213 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2893>
1800041ad:     	movsd	0x10(%r14,%r9,8), %xmm13
1800041b4:     	mulsd	%xmm13, %xmm13
1800041b9:     	movapd	%xmm13, %xmm12
1800041be:     	andpd	%xmm4, %xmm12
1800041c3:     	ucomisd	%xmm5, %xmm12
1800041c8:     	jae	0x180004213 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2893>
1800041ca:     	addsd	%xmm13, %xmm11
1800041cf:     	movapd	%xmm11, %xmm12
1800041d4:     	andpd	%xmm4, %xmm12
1800041d9:     	ucomisd	%xmm5, %xmm12
1800041de:     	jae	0x180004213 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2893>
1800041e0:     	movsd	0x20(%r14,%r9,8), %xmm13
1800041e7:     	mulsd	%xmm13, %xmm13
1800041ec:     	movapd	%xmm13, %xmm12
1800041f1:     	andpd	%xmm4, %xmm12
1800041f6:     	ucomisd	%xmm5, %xmm12
1800041fb:     	jae	0x180004213 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2893>
1800041fd:     	addsd	%xmm13, %xmm11
180004202:     	movapd	%xmm11, %xmm12
180004207:     	andpd	%xmm4, %xmm12
18000420c:     	ucomisd	%xmm5, %xmm12
180004211:     	jb	0x18000422c <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x28ac>
180004213:     	movb	$0x1, (%rsi)
180004216:     	movq	$0x14fb183, 0x18(%rbx)  # imm = 0x14FB183
18000421e:     	xorpd	%xmm11, %xmm11
180004223:     	cmpb	$0x0, (%rsi)
180004226:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
18000422c:     	sqrtsd	%xmm11, %xmm11
180004231:     	ucomisd	%xmm9, %xmm11
180004236:     	jne	0x180004251 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x28d1>
180004238:     	jp	0x180004251 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x28d1>
18000423a:     	movb	$0x1, (%rsi)
18000423d:     	movq	$0x3d0902, 0x18(%rbx)   # imm = 0x3D0902
180004245:     	movzbl	(%rsi), %edx
180004248:     	movq	$-0x1, %r9
18000424f:     	jmp	0x1800042c7 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2947>
180004251:     	movq	(%rbx), %r10
180004254:     	leaq	0x6(%r10), %rdx
180004258:     	cmpq	%r15, %rdx
18000425b:     	jg	0x180003c44 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x22c4>
180004261:     	movsd	(%r14,%r9,8), %xmm13
180004267:     	movsd	0x10(%r14,%r9,8), %xmm14
18000426e:     	movsd	0x20(%r14,%r9,8), %xmm15
180004275:     	movq	%rdx, (%rbx)
180004278:     	cmpb	$0x0, (%rsi)
18000427b:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
180004281:     	movsd	0x515e(%rip), %xmm12    # 0x1800093e8
18000428a:     	divsd	%xmm11, %xmm12
18000428f:     	mulsd	%xmm12, %xmm13
180004294:     	mulsd	%xmm12, %xmm14
180004299:     	mulsd	%xmm15, %xmm12
18000429e:     	movsd	%xmm13, (%r14,%r10,8)
1800042a4:     	movsd	%xmm14, 0x10(%r14,%r10,8)
1800042ab:     	movsd	%xmm12, 0x20(%r14,%r10,8)
1800042b2:     	movzbl	(%rsi), %edx
1800042b5:     	movl	%edx, %r9d
1800042b8:     	negb	%r9b
1800042bb:     	movl	$0x0, %r9d
1800042c1:     	sbbq	%r9, %r9
1800042c4:     	orq	%r10, %r9
1800042c7:     	testb	%dl, %dl
1800042c9:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
1800042cf:     	movq	%r9, 0x8(%rdi,%r11,8)
1800042d4:     	cmpb	$0x0, (%rsi)
1800042d7:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
1800042dd:     	movq	%rbp, %r10
1800042e0:     	sarq	$0x3f, %r10
1800042e4:     	andq	%r15, %r10
1800042e7:     	leaq	(%rdi,%rbp,8), %rdx
1800042eb:     	movq	(%rdx,%r10,8), %r10
1800042ef:     	testq	%r10, %r10
1800042f2:     	je	0x1800043d7 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2a57>
1800042f8:     	cmpq	$0x1, %r10
1800042fc:     	jne	0x1800047d9 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2e59>
180004302:     	movq	0x20(%rdx), %r10
180004306:     	movsd	(%r14,%r9,8), %xmm11
18000430c:     	mulsd	(%r14,%r10,8), %xmm11
180004312:     	movapd	%xmm11, %xmm10
180004317:     	andpd	%xmm4, %xmm10
18000431c:     	ucomisd	%xmm5, %xmm10
180004321:     	jae	0x180004489 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2b09>
180004327:     	movsd	0x10(%r14,%r9,8), %xmm12
18000432e:     	mulsd	0x10(%r14,%r10,8), %xmm12
180004335:     	movapd	%xmm12, %xmm10
18000433a:     	andpd	%xmm4, %xmm10
18000433f:     	ucomisd	%xmm5, %xmm10
180004344:     	jae	0x180004489 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2b09>
18000434a:     	addsd	%xmm12, %xmm11
18000434f:     	movapd	%xmm11, %xmm10
180004354:     	andpd	%xmm4, %xmm10
180004359:     	ucomisd	%xmm5, %xmm10
18000435e:     	jae	0x180004489 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2b09>
180004364:     	movsd	0x20(%r14,%r9,8), %xmm12
18000436b:     	mulsd	0x20(%r14,%r10,8), %xmm12
180004372:     	movapd	%xmm12, %xmm10
180004377:     	andpd	%xmm4, %xmm10
18000437c:     	ucomisd	%xmm5, %xmm10
180004381:     	jae	0x180004489 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2b09>
180004387:     	addsd	%xmm12, %xmm11
18000438c:     	movapd	%xmm11, %xmm10
180004391:     	andpd	%xmm4, %xmm10
180004396:     	ucomisd	%xmm5, %xmm10
18000439b:     	jae	0x180004489 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2b09>
1800043a1:     	xorpd	%xmm13, %xmm13
1800043a6:     	ucomisd	%xmm13, %xmm11
1800043ab:     	jne	0x1800043b3 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2a33>
1800043ad:     	jnp	0x1800046f3 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2d73>
1800043b3:     	movsd	0x5054(%rip), %xmm13    # 0x180009410
1800043bc:     	divsd	%xmm11, %xmm13
1800043c1:     	movb	$0x1, %r9b
1800043c4:     	incq	0x60(%rsp)
1800043c9:     	testb	%r9b, %r9b
1800043cc:     	jne	0x1800046df <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2d5f>
1800043d2:     	jmp	0x180004054 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x26d4>
1800043d7:     	movq	0x8(%rdx), %r10
1800043db:     	movq	(%rdi,%r11,8), %r9
1800043df:     	movsd	(%r14,%r10,8), %xmm11
1800043e5:     	subsd	(%r14,%r9,8), %xmm11
1800043eb:     	movapd	%xmm11, %xmm10
1800043f0:     	andpd	%xmm4, %xmm10
1800043f5:     	ucomisd	%xmm5, %xmm10
1800043fa:     	jae	0x1800044b8 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2b38>
180004400:     	movsd	0x10(%r14,%r10,8), %xmm13
180004407:     	subsd	0x10(%r14,%r9,8), %xmm13
18000440e:     	movapd	%xmm13, %xmm12
180004413:     	andpd	%xmm4, %xmm12
180004418:     	ucomisd	%xmm5, %xmm12
18000441d:     	jae	0x1800044b8 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2b38>
180004423:     	movsd	0x20(%r14,%r10,8), %xmm14
18000442a:     	subsd	0x20(%r14,%r9,8), %xmm14
180004431:     	movapd	%xmm14, %xmm12
180004436:     	andpd	%xmm4, %xmm12
18000443b:     	ucomisd	%xmm5, %xmm12
180004440:     	jae	0x1800044b8 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2b38>
180004442:     	movq	(%rbx), %r10
180004445:     	leaq	0x6(%r10), %rdx
180004449:     	cmpq	%r15, %rdx
18000444c:     	jg	0x180003c44 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x22c4>
180004452:     	movq	%rdx, (%rbx)
180004455:     	cmpb	$0x0, (%rsi)
180004458:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
18000445e:     	movsd	%xmm11, (%r14,%r10,8)
180004464:     	movsd	%xmm13, 0x10(%r14,%r10,8)
18000446b:     	movsd	%xmm14, 0x20(%r14,%r10,8)
180004472:     	movzbl	(%rsi), %edx
180004475:     	movl	%edx, %r9d
180004478:     	negb	%r9b
18000447b:     	movl	$0x0, %r9d
180004481:     	sbbq	%r9, %r9
180004484:     	orq	%r10, %r9
180004487:     	jmp	0x1800044cd <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2b4d>
180004489:     	movb	$0x1, (%rsi)
18000448c:     	movq	$0x14fb183, 0x18(%rbx)  # imm = 0x14FB183
180004494:     	cmpb	$0x0, (%rsi)
180004497:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
18000449d:     	xorpd	%xmm13, %xmm13
1800044a2:     	xorl	%r9d, %r9d
1800044a5:     	incq	0x60(%rsp)
1800044aa:     	testb	%r9b, %r9b
1800044ad:     	jne	0x1800046df <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2d5f>
1800044b3:     	jmp	0x180004054 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x26d4>
1800044b8:     	movb	$0x1, (%rsi)
1800044bb:     	movq	$0xf4243, 0x18(%rbx)    # imm = 0xF4243
1800044c3:     	movzbl	(%rsi), %edx
1800044c6:     	movq	$-0x1, %r9
1800044cd:     	xorpd	%xmm13, %xmm13
1800044d2:     	testb	%dl, %dl
1800044d4:     	je	0x1800044e7 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2b67>
1800044d6:     	xorl	%r9d, %r9d
1800044d9:     	cmpb	$0x0, (%rsi)
1800044dc:     	je	0x1800046d1 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2d51>
1800044e2:     	jmp	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
1800044e7:     	movq	0x8(%rdi,%r11,8), %r10
1800044ec:     	movsd	(%r14,%r9,8), %xmm14
1800044f2:     	mulsd	(%r14,%r10,8), %xmm14
1800044f8:     	movapd	%xmm14, %xmm11
1800044fd:     	andpd	%xmm4, %xmm11
180004502:     	ucomisd	%xmm5, %xmm11
180004507:     	jae	0x180004573 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2bf3>
180004509:     	movsd	0x10(%r14,%r9,8), %xmm11
180004510:     	mulsd	0x10(%r14,%r10,8), %xmm11
180004517:     	movapd	%xmm11, %xmm12
18000451c:     	andpd	%xmm4, %xmm12
180004521:     	ucomisd	%xmm5, %xmm12
180004526:     	jae	0x180004573 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2bf3>
180004528:     	addsd	%xmm11, %xmm14
18000452d:     	movapd	%xmm14, %xmm11
180004532:     	andpd	%xmm4, %xmm11
180004537:     	ucomisd	%xmm5, %xmm11
18000453c:     	jae	0x180004573 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2bf3>
18000453e:     	movsd	0x20(%r14,%r9,8), %xmm11
180004545:     	mulsd	0x20(%r14,%r10,8), %xmm11
18000454c:     	movapd	%xmm11, %xmm12
180004551:     	andpd	%xmm4, %xmm12
180004556:     	ucomisd	%xmm5, %xmm12
18000455b:     	jae	0x180004573 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2bf3>
18000455d:     	addsd	%xmm11, %xmm14
180004562:     	movapd	%xmm14, %xmm11
180004567:     	andpd	%xmm4, %xmm11
18000456c:     	ucomisd	%xmm5, %xmm11
180004571:     	jb	0x18000458c <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2c0c>
180004573:     	movb	$0x1, (%rsi)
180004576:     	movq	$0x14fb183, 0x18(%rbx)  # imm = 0x14FB183
18000457e:     	xorpd	%xmm14, %xmm14
180004583:     	cmpb	$0x0, (%rsi)
180004586:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
18000458c:     	movsd	0x10(%r14,%rbp,8), %xmm15
180004593:     	mulsd	%xmm15, %xmm15
180004598:     	movapd	%xmm15, %xmm11
18000459d:     	andpd	%xmm4, %xmm11
1800045a2:     	ucomisd	%xmm5, %xmm11
1800045a7:     	jae	0x1800046ba <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2d3a>
1800045ad:     	movsd	(%r14,%r9,8), %xmm11
1800045b3:     	mulsd	%xmm11, %xmm11
1800045b8:     	movapd	%xmm11, %xmm10
1800045bd:     	andpd	%xmm4, %xmm10
1800045c2:     	ucomisd	%xmm5, %xmm10
1800045c7:     	jae	0x18000462f <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2caf>
1800045c9:     	movsd	0x10(%r14,%r9,8), %xmm10
1800045d0:     	mulsd	%xmm10, %xmm10
1800045d5:     	movapd	%xmm10, %xmm12
1800045da:     	andpd	%xmm4, %xmm12
1800045df:     	ucomisd	%xmm5, %xmm12
1800045e4:     	jae	0x18000462f <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2caf>
1800045e6:     	addsd	%xmm10, %xmm11
1800045eb:     	movapd	%xmm11, %xmm10
1800045f0:     	andpd	%xmm4, %xmm10
1800045f5:     	ucomisd	%xmm5, %xmm10
1800045fa:     	jae	0x18000462f <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2caf>
1800045fc:     	movsd	0x20(%r14,%r9,8), %xmm12
180004603:     	mulsd	%xmm12, %xmm12
180004608:     	movapd	%xmm12, %xmm10
18000460d:     	andpd	%xmm4, %xmm10
180004612:     	ucomisd	%xmm5, %xmm10
180004617:     	jae	0x18000462f <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2caf>
180004619:     	addsd	%xmm12, %xmm11
18000461e:     	movapd	%xmm11, %xmm10
180004623:     	andpd	%xmm4, %xmm10
180004628:     	ucomisd	%xmm5, %xmm10
18000462d:     	jb	0x180004648 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2cc8>
18000462f:     	movb	$0x1, (%rsi)
180004632:     	movq	$0x14fb183, 0x18(%rbx)  # imm = 0x14FB183
18000463a:     	xorpd	%xmm11, %xmm11
18000463f:     	cmpb	$0x0, (%rsi)
180004642:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
180004648:     	movapd	%xmm14, %xmm12
18000464d:     	mulsd	%xmm14, %xmm12
180004652:     	movapd	%xmm12, %xmm10
180004657:     	andpd	%xmm4, %xmm10
18000465c:     	ucomisd	%xmm5, %xmm10
180004661:     	jae	0x1800046ba <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2d3a>
180004663:     	subsd	%xmm12, %xmm11
180004668:     	movapd	%xmm11, %xmm10
18000466d:     	andpd	%xmm4, %xmm10
180004672:     	ucomisd	%xmm5, %xmm10
180004677:     	jae	0x1800046ba <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2d3a>
180004679:     	subsd	%xmm11, %xmm15
18000467e:     	movapd	%xmm15, %xmm10
180004683:     	andpd	%xmm4, %xmm10
180004688:     	ucomisd	%xmm5, %xmm10
18000468d:     	jae	0x1800046ba <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2d3a>
18000468f:     	ucomisd	%xmm15, %xmm13
180004694:     	ja	0x1800044d6 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2b56>
18000469a:     	xorps	%xmm10, %xmm10
18000469e:     	sqrtsd	%xmm15, %xmm10
1800046a3:     	subsd	%xmm10, %xmm14
1800046a8:     	movb	$0x1, %r9b
1800046ab:     	movapd	%xmm14, %xmm13
1800046b0:     	cmpb	$0x0, (%rsi)
1800046b3:     	je	0x1800046d1 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2d51>
1800046b5:     	jmp	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
1800046ba:     	movb	$0x1, (%rsi)
1800046bd:     	movq	$0xe4e1c4, 0x18(%rbx)   # imm = 0xE4E1C4
1800046c5:     	xorl	%r9d, %r9d
1800046c8:     	cmpb	$0x0, (%rsi)
1800046cb:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
1800046d1:     	incq	0x60(%rsp)
1800046d6:     	testb	%r9b, %r9b
1800046d9:     	je	0x180004054 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x26d4>
1800046df:     	ucomisd	0x4d30(%rip), %xmm13    # 0x180009418
1800046e8:     	jbe	0x180004054 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x26d4>
1800046ee:     	jmp	0x180004b4d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x31cd>
1800046f3:     	xorl	%r9d, %r9d
1800046f6:     	incq	0x60(%rsp)
1800046fb:     	testb	%r9b, %r9b
1800046fe:     	jne	0x1800046df <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2d5f>
180004700:     	jmp	0x180004054 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x26d4>
180004705:     	cmpb	$0x0, (%rsi)
180004708:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
18000470e:     	leaq	(%rdi,%rax,8), %rdx
180004712:     	movq	(%rdx,%r8,8), %r10
180004716:     	movq	0xd8(%rsp), %r9
18000471e:     	cmpq	0x8(%rdx,%r9,8), %r10
180004723:     	jne	0x180004b0d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x318d>
180004729:     	leaq	(%r10,%r10), %r9
18000472d:     	movq	%r10, 0x90(%rsp)
180004735:     	testq	%r10, %r10
180004738:     	movl	$0x4, %edx
18000473d:     	cmoveq	%rdx, %r9
180004741:     	movq	(%rbx), %r10
180004744:     	movq	%r9, 0xe0(%rsp)
18000474c:     	movq	%r10, 0x60(%rsp)
180004751:     	leaq	(%r10,%r9), %rdx
180004755:     	cmpq	%r15, %rdx
180004758:     	jg	0x180003c44 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x22c4>
18000475e:     	movq	%rdx, (%rbx)
180004761:     	cmpb	$0x0, (%rsi)
180004764:     	movq	0x90(%rsp), %rdx
18000476c:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
180004772:     	movq	%rsi, 0x70(%rsp)
180004777:     	movq	%r14, 0xf0(%rsp)
18000477f:     	movq	%rbx, 0xe8(%rsp)
180004787:     	movq	%rcx, 0x68(%rsp)
18000478c:     	testq	%rdx, %rdx
18000478f:     	jle	0x180004ac0 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3140>
180004795:     	leaq	(%rdi,%rax,8), %rcx
180004799:     	movq	0xa8(%rsp), %rdx
1800047a1:     	movq	0x10(%rcx,%rdx,8), %r11
1800047a6:     	movq	0x90(%rsp), %rcx
1800047ae:     	movl	%ecx, %edx
1800047b0:     	andl	$0x7, %edx
1800047b3:     	movq	%rdx, 0xb0(%rsp)
1800047bb:     	cmpq	$0x8, %rcx
1800047bf:     	jae	0x1800047f2 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2e72>
1800047c1:     	xorl	%r14d, %r14d
1800047c4:     	leaq	(,%r15,8), %rbx
1800047cc:     	movq	0xb0(%rsp), %rdx
1800047d4:     	jmp	0x180004a88 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3108>
1800047d9:     	movb	$0x1, (%rsi)
1800047dc:     	movq	$0x206cc83, 0x18(%rbx)  # imm = 0x206CC83
1800047e4:     	cmpb	$0x0, (%rsi)
1800047e7:     	je	0x180004b4d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x31cd>
1800047ed:     	jmp	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
1800047f2:     	movq	0x90(%rsp), %r9
1800047fa:     	movabsq	$0x7ffffffffffffff8, %rcx # imm = 0x7FFFFFFFFFFFFFF8
180004804:     	andq	%rcx, %r9
180004807:     	movq	%r9, 0x80(%rsp)
18000480f:     	movq	0x60(%rsp), %rcx
180004814:     	leaq	(%rdi,%rcx,8), %rcx
180004818:     	movq	%rcx, 0x108(%rsp)
180004820:     	xorl	%ecx, %ecx
180004822:     	leaq	(,%r15,8), %r9
18000482a:     	movq	%r9, 0xc8(%rsp)
180004832:     	leaq	0x8(,%r15,8), %rdx
18000483a:     	movq	%rdx, 0xa0(%rsp)
180004842:     	leaq	0x10(,%r15,8), %rdx
18000484a:     	movq	%rdx, 0x100(%rsp)
180004852:     	leaq	0x18(,%r15,8), %rdx
18000485a:     	movq	%rdx, 0xf8(%rsp)
180004862:     	leaq	0x20(,%r15,8), %rdx
18000486a:     	movq	%rdx, 0x78(%rsp)
18000486f:     	leaq	0x28(,%r15,8), %rdx
180004877:     	movq	%rdx, 0x98(%rsp)
18000487f:     	leaq	0x30(,%r15,8), %rdx
180004887:     	movq	%rdx, 0xc0(%rsp)
18000488f:     	leaq	0x38(,%r15,8), %rdx
180004897:     	movq	%rdx, 0xb8(%rsp)
18000489f:     	leaq	(%r11,%rcx), %r9
1800048a3:     	movq	%r9, %r10
1800048a6:     	sarq	$0x3f, %r10
1800048aa:     	movq	0xc8(%rsp), %rdx
1800048b2:     	andq	%rdx, %r10
1800048b5:     	leaq	(%rdi,%r11,8), %rsi
1800048b9:     	addq	%rsi, %r10
1800048bc:     	movq	(%r10,%rcx,8), %r10
1800048c0:     	movq	0x60(%rsp), %rbx
1800048c5:     	leaq	(%rbx,%rcx), %rbp
1800048c9:     	movq	%rbp, %rbx
1800048cc:     	sarq	$0x3f, %rbx
1800048d0:     	andq	%rdx, %rbx
1800048d3:     	movq	0x108(%rsp), %rdx
1800048db:     	addq	%rdx, %rbx
1800048de:     	movq	%r10, (%rbx,%rcx,8)
1800048e2:     	movq	%r9, %r10
1800048e5:     	incq	%r10
1800048e8:     	movl	$0x8, %r10d
1800048ee:     	movq	0xa0(%rsp), %r14
1800048f6:     	cmovsq	%r14, %r10
1800048fa:     	addq	%rsi, %r10
1800048fd:     	movq	(%r10,%rcx,8), %r10
180004901:     	movq	%rbp, %rbx
180004904:     	incq	%rbx
180004907:     	movl	$0x8, %ebx
18000490c:     	cmovsq	%r14, %rbx
180004910:     	addq	%rdx, %rbx
180004913:     	movq	%r10, (%rbx,%rcx,8)
180004917:     	movq	%r9, %r10
18000491a:     	addq	$0x2, %r10
18000491e:     	movl	$0x10, %r10d
180004924:     	movq	0x100(%rsp), %r14
18000492c:     	cmovsq	%r14, %r10
180004930:     	addq	%rsi, %r10
180004933:     	movq	(%r10,%rcx,8), %r10
180004937:     	movq	%rbp, %rbx
18000493a:     	addq	$0x2, %rbx
18000493e:     	movl	$0x10, %ebx
180004943:     	cmovsq	%r14, %rbx
180004947:     	addq	%rdx, %rbx
18000494a:     	movq	%r10, (%rbx,%rcx,8)
18000494e:     	movq	%r9, %r10
180004951:     	addq	$0x3, %r10
180004955:     	movl	$0x18, %r10d
18000495b:     	movq	0xf8(%rsp), %r14
180004963:     	cmovsq	%r14, %r10
180004967:     	addq	%rsi, %r10
18000496a:     	movq	(%r10,%rcx,8), %r10
18000496e:     	movq	%rbp, %rbx
180004971:     	addq	$0x3, %rbx
180004975:     	movl	$0x18, %ebx
18000497a:     	cmovsq	%r14, %rbx
18000497e:     	addq	%rdx, %rbx
180004981:     	movq	%r10, (%rbx,%rcx,8)
180004985:     	movq	%r9, %r10
180004988:     	addq	$0x4, %r10
18000498c:     	movl	$0x20, %r10d
180004992:     	movq	0x78(%rsp), %r14
180004997:     	cmovsq	%r14, %r10
18000499b:     	addq	%rsi, %r10
18000499e:     	movq	(%r10,%rcx,8), %r10
1800049a2:     	movq	%rbp, %rbx
1800049a5:     	addq	$0x4, %rbx
1800049a9:     	movl	$0x20, %ebx
1800049ae:     	cmovsq	%r14, %rbx
1800049b2:     	addq	%rdx, %rbx
1800049b5:     	movq	%r10, (%rbx,%rcx,8)
1800049b9:     	movq	%r9, %r10
1800049bc:     	addq	$0x5, %r10
1800049c0:     	movl	$0x28, %r10d
1800049c6:     	movq	0x98(%rsp), %r14
1800049ce:     	cmovsq	%r14, %r10
1800049d2:     	addq	%rsi, %r10
1800049d5:     	movq	(%r10,%rcx,8), %r10
1800049d9:     	movq	%rbp, %rbx
1800049dc:     	addq	$0x5, %rbx
1800049e0:     	movl	$0x28, %ebx
1800049e5:     	cmovsq	%r14, %rbx
1800049e9:     	addq	%rdx, %rbx
1800049ec:     	movq	%r10, (%rbx,%rcx,8)
1800049f0:     	movq	%r9, %r10
1800049f3:     	addq	$0x6, %r10
1800049f7:     	movl	$0x30, %r10d
1800049fd:     	movq	0xc0(%rsp), %r14
180004a05:     	cmovsq	%r14, %r10
180004a09:     	addq	%rsi, %r10
180004a0c:     	movq	(%r10,%rcx,8), %r10
180004a10:     	movq	%rbp, %rbx
180004a13:     	addq	$0x6, %rbx
180004a17:     	movl	$0x30, %ebx
180004a1c:     	cmovsq	%r14, %rbx
180004a20:     	addq	%rdx, %rbx
180004a23:     	movq	%r10, (%rbx,%rcx,8)
180004a27:     	addq	$0x7, %r9
180004a2b:     	movl	$0x38, %r9d
180004a31:     	movq	0xb8(%rsp), %rbx
180004a39:     	cmovsq	%rbx, %r9
180004a3d:     	addq	%rsi, %r9
180004a40:     	movq	(%r9,%rcx,8), %r9
180004a44:     	addq	$0x7, %rbp
180004a48:     	movl	$0x38, %r10d
180004a4e:     	cmovsq	%rbx, %r10
180004a52:     	addq	%rdx, %r10
180004a55:     	movq	%r9, (%r10,%rcx,8)
180004a59:     	addq	$0x8, %rcx
180004a5d:     	cmpq	%rcx, 0x80(%rsp)
180004a65:     	jne	0x18000489f <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2f1f>
180004a6b:     	movq	0x80(%rsp), %r14
180004a73:     	movq	0xb0(%rsp), %rdx
180004a7b:     	testq	%rdx, %rdx
180004a7e:     	movq	0xc8(%rsp), %rbx
180004a86:     	je	0x180004ac0 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3140>
180004a88:     	movq	0x60(%rsp), %rcx
180004a8d:     	addq	%r14, %rcx
180004a90:     	addq	%r14, %r11
180004a93:     	movq	%r11, %r9
180004a96:     	sarq	$0x3f, %r9
180004a9a:     	andq	%rbx, %r9
180004a9d:     	addq	%rdi, %r9
180004aa0:     	movq	(%r9,%r11,8), %r9
180004aa4:     	movq	%rcx, %r10
180004aa7:     	sarq	$0x3f, %r10
180004aab:     	andq	%rbx, %r10
180004aae:     	addq	%rdi, %r10
180004ab1:     	movq	%r9, (%r10,%rcx,8)
180004ab5:     	incq	%rcx
180004ab8:     	incq	%r11
180004abb:     	decq	%rdx
180004abe:     	jne	0x180004a93 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3113>
180004ac0:     	leaq	(%rdi,%rax,8), %rcx
180004ac4:     	movq	0xd8(%rsp), %rdx
180004acc:     	movq	0xe0(%rsp), %r9
180004ad4:     	movq	%r9, 0x8(%rcx,%rdx,8)
180004ad9:     	movq	0xa8(%rsp), %rdx
180004ae1:     	movq	0x60(%rsp), %r9
180004ae6:     	movq	%r9, 0x10(%rcx,%rdx,8)
180004aeb:     	movq	0x68(%rsp), %rcx
180004af0:     	movq	0xe8(%rsp), %rbx
180004af8:     	movq	0xf0(%rsp), %r14
180004b00:     	movq	0x90(%rsp), %r10
180004b08:     	movq	0x70(%rsp), %rsi
180004b0d:     	leaq	0x1(%r10), %rdx
180004b11:     	leaq	(%rdi,%rax,8), %r9
180004b15:     	movq	%rdx, (%r9,%r8,8)
180004b19:     	cmpb	$0x0, (%rsi)
180004b1c:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
180004b22:     	leaq	(%rdi,%rax,8), %rdx
180004b26:     	movq	0xa8(%rsp), %r9
180004b2e:     	addq	0x10(%rdx,%r9,8), %r10
180004b33:     	movq	%r10, %rdx
180004b36:     	sarq	$0x3f, %rdx
180004b3a:     	andq	%r15, %rdx
180004b3d:     	leaq	(%rdi,%r10,8), %r9
180004b41:     	movq	0x88(%rsp), %r10
180004b49:     	movq	%r10, (%r9,%rdx,8)
180004b4d:     	movq	0xd0(%rsp), %rdx
180004b55:     	movq	0x110(%rsp), %r9
180004b5d:     	cmpq	(%rdi,%rdx,8), %r9
180004b61:     	jl	0x18000400e <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x268e>
180004b67:     	cmpb	$0x0, (%rsi)
180004b6a:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
180004b70:     	leaq	(%rdi,%rax,8), %rdx
180004b74:     	cmpq	$0x0, (%rdx)
180004b78:     	jle	0x180005514 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3b94>
180004b7e:     	xorpd	%xmm5, %xmm5
180004b82:     	xorl	%edx, %edx
180004b84:     	movapd	0x4843(%rip), %xmm9     # 0x1800093d0
180004b8d:     	movsd	0x484a(%rip), %xmm10    # 0x1800093e0
180004b96:     	xorpd	%xmm4, %xmm4
180004b9a:     	movq	0x320(%rsp), %r11
180004ba2:     	movq	0x10(%rdi,%rax,8), %r8
180004ba7:     	leaq	(%rdi,%r8,8), %r8
180004bab:     	movq	(%r8,%rdx,8), %r8
180004baf:     	movsd	(%r14,%r8,8), %xmm12
180004bb5:     	subsd	(%r14,%r13,8), %xmm12
180004bbb:     	movapd	%xmm12, %xmm13
180004bc0:     	andpd	%xmm9, %xmm13
180004bc5:     	ucomisd	%xmm10, %xmm13
180004bca:     	jae	0x180004c56 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x32d6>
180004bd0:     	movsd	0x10(%r14,%r8,8), %xmm13
180004bd7:     	subsd	0x10(%r14,%r13,8), %xmm13
180004bde:     	movapd	%xmm13, %xmm14
180004be3:     	andpd	%xmm9, %xmm14
180004be8:     	ucomisd	%xmm10, %xmm14
180004bed:     	jae	0x180004c56 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x32d6>
180004bef:     	movsd	0x20(%r14,%r8,8), %xmm14
180004bf6:     	subsd	0x20(%r14,%r13,8), %xmm14
180004bfd:     	movapd	%xmm14, %xmm15
180004c02:     	andpd	%xmm9, %xmm15
180004c07:     	ucomisd	%xmm10, %xmm15
180004c0c:     	jae	0x180004c56 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x32d6>
180004c0e:     	movq	(%rbx), %r9
180004c11:     	leaq	0x6(%r9), %r8
180004c15:     	cmpq	%r15, %r8
180004c18:     	jg	0x180003c44 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x22c4>
180004c1e:     	movq	%r8, (%rbx)
180004c21:     	cmpb	$0x0, (%rsi)
180004c24:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
180004c2a:     	movsd	%xmm12, (%r14,%r9,8)
180004c30:     	movsd	%xmm13, 0x10(%r14,%r9,8)
180004c37:     	movsd	%xmm14, 0x20(%r14,%r9,8)
180004c3e:     	movzbl	(%rsi), %r10d
180004c42:     	movl	%r10d, %r8d
180004c45:     	negb	%r8b
180004c48:     	movl	$0x0, %r8d
180004c4e:     	sbbq	%r8, %r8
180004c51:     	orq	%r9, %r8
180004c54:     	jmp	0x180004c6c <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x32ec>
180004c56:     	movb	$0x1, (%rsi)
180004c59:     	movq	$0xf4243, 0x18(%rbx)    # imm = 0xF4243
180004c61:     	movzbl	(%rsi), %r10d
180004c65:     	movq	$-0x1, %r8
180004c6c:     	testb	%r10b, %r10b
180004c6f:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
180004c75:     	movsd	(%r14,%r8,8), %xmm12
180004c7b:     	mulsd	%xmm12, %xmm12
180004c80:     	movapd	%xmm12, %xmm13
180004c85:     	andpd	%xmm9, %xmm13
180004c8a:     	ucomisd	%xmm10, %xmm13
180004c8f:     	jae	0x180004cf7 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3377>
180004c91:     	movsd	0x10(%r14,%r8,8), %xmm13
180004c98:     	mulsd	%xmm13, %xmm13
180004c9d:     	movapd	%xmm13, %xmm14
180004ca2:     	andpd	%xmm9, %xmm14
180004ca7:     	ucomisd	%xmm10, %xmm14
180004cac:     	jae	0x180004cf7 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3377>
180004cae:     	addsd	%xmm13, %xmm12
180004cb3:     	movapd	%xmm12, %xmm13
180004cb8:     	andpd	%xmm9, %xmm13
180004cbd:     	ucomisd	%xmm10, %xmm13
180004cc2:     	jae	0x180004cf7 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3377>
180004cc4:     	movsd	0x20(%r14,%r8,8), %xmm13
180004ccb:     	mulsd	%xmm13, %xmm13
180004cd0:     	movapd	%xmm13, %xmm14
180004cd5:     	andpd	%xmm9, %xmm14
180004cda:     	ucomisd	%xmm10, %xmm14
180004cdf:     	jae	0x180004cf7 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3377>
180004ce1:     	addsd	%xmm13, %xmm12
180004ce6:     	movapd	%xmm12, %xmm13
180004ceb:     	andpd	%xmm9, %xmm13
180004cf0:     	ucomisd	%xmm10, %xmm13
180004cf5:     	jb	0x180004d10 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3390>
180004cf7:     	movb	$0x1, (%rsi)
180004cfa:     	movq	$0x14fb183, 0x18(%rbx)  # imm = 0x14FB183
180004d02:     	xorpd	%xmm12, %xmm12
180004d07:     	cmpb	$0x0, (%rsi)
180004d0a:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
180004d10:     	sqrtsd	%xmm12, %xmm12
180004d15:     	ucomisd	%xmm5, %xmm12
180004d1a:     	jne	0x180004d36 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x33b6>
180004d1c:     	jp	0x180004d36 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x33b6>
180004d1e:     	movb	$0x1, (%rsi)
180004d21:     	movq	$0x3d0902, 0x18(%rbx)   # imm = 0x3D0902
180004d29:     	movzbl	(%rsi), %r10d
180004d2d:     	movq	$-0x1, %r8
180004d34:     	jmp	0x180004dad <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x342d>
180004d36:     	movq	(%rbx), %r9
180004d39:     	leaq	0x6(%r9), %r10
180004d3d:     	cmpq	%r15, %r10
180004d40:     	jg	0x180003c44 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x22c4>
180004d46:     	movsd	(%r14,%r8,8), %xmm13
180004d4c:     	movsd	0x10(%r14,%r8,8), %xmm14
180004d53:     	movsd	0x20(%r14,%r8,8), %xmm15
180004d5a:     	movq	%r10, (%rbx)
180004d5d:     	cmpb	$0x0, (%rsi)
180004d60:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
180004d66:     	movsd	0x4679(%rip), %xmm11    # 0x1800093e8
180004d6f:     	divsd	%xmm12, %xmm11
180004d74:     	mulsd	%xmm11, %xmm13
180004d79:     	mulsd	%xmm11, %xmm14
180004d7e:     	mulsd	%xmm15, %xmm11
180004d83:     	movsd	%xmm13, (%r14,%r9,8)
180004d89:     	movsd	%xmm14, 0x10(%r14,%r9,8)
180004d90:     	movsd	%xmm11, 0x20(%r14,%r9,8)
180004d97:     	movzbl	(%rsi), %r10d
180004d9b:     	movl	%r10d, %r8d
180004d9e:     	negb	%r8b
180004da1:     	movl	$0x0, %r8d
180004da7:     	sbbq	%r8, %r8
180004daa:     	orq	%r9, %r8
180004dad:     	testb	%r10b, %r10b
180004db0:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
180004db6:     	movsd	(%r14,%r8,8), %xmm12
180004dbc:     	mulsd	(%r14,%r11,8), %xmm12
180004dc2:     	movapd	%xmm12, %xmm11
180004dc7:     	andpd	%xmm9, %xmm11
180004dcc:     	ucomisd	%xmm10, %xmm11
180004dd1:     	jae	0x180004e6b <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x34eb>
180004dd7:     	movsd	0x10(%r14,%r8,8), %xmm13
180004dde:     	mulsd	0x10(%r14,%r11,8), %xmm13
180004de5:     	movapd	%xmm13, %xmm11
180004dea:     	andpd	%xmm9, %xmm11
180004def:     	ucomisd	%xmm10, %xmm11
180004df4:     	jae	0x180004e6b <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x34eb>
180004df6:     	addsd	%xmm13, %xmm12
180004dfb:     	movapd	%xmm12, %xmm11
180004e00:     	andpd	%xmm9, %xmm11
180004e05:     	ucomisd	%xmm10, %xmm11
180004e0a:     	jae	0x180004e6b <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x34eb>
180004e0c:     	movsd	0x20(%r14,%r8,8), %xmm13
180004e13:     	mulsd	0x20(%r14,%r11,8), %xmm13
180004e1a:     	movapd	%xmm13, %xmm11
180004e1f:     	andpd	%xmm9, %xmm11
180004e24:     	ucomisd	%xmm10, %xmm11
180004e29:     	jae	0x180004e6b <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x34eb>
180004e2b:     	addsd	%xmm13, %xmm12
180004e30:     	movapd	%xmm12, %xmm11
180004e35:     	andpd	%xmm9, %xmm11
180004e3a:     	ucomisd	%xmm10, %xmm11
180004e3f:     	jae	0x180004e6b <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x34eb>
180004e41:     	ucomisd	%xmm5, %xmm12
180004e46:     	jbe	0x180004e91 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3511>
180004e48:     	addsd	%xmm12, %xmm4
180004e4d:     	movapd	%xmm4, %xmm11
180004e52:     	andpd	%xmm9, %xmm11
180004e57:     	ucomisd	%xmm10, %xmm11
180004e5c:     	movq	0x320(%rsp), %r11
180004e64:     	jb	0x180004e7f <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x34ff>
180004e66:     	jmp	0x180005c35 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x42b5>
180004e6b:     	movb	$0x1, (%rsi)
180004e6e:     	movq	$0x14fb183, 0x18(%rbx)  # imm = 0x14FB183
180004e76:     	cmpb	$0x0, (%rsi)
180004e79:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
180004e7f:     	incq	%rdx
180004e82:     	cmpq	(%rdi,%rax,8), %rdx
180004e86:     	jl	0x180004ba2 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3222>
180004e8c:     	jmp	0x180005518 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3b98>
180004e91:     	movq	0x320(%rsp), %r11
180004e99:     	incq	%rdx
180004e9c:     	cmpq	(%rdi,%rax,8), %rdx
180004ea0:     	jl	0x180004ba2 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3222>
180004ea6:     	jmp	0x180005518 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3b98>
180004eab:     	movb	$0x1, (%rsi)
180004eae:     	movq	$0x18cba83, 0x18(%rbx)  # imm = 0x18CBA83
180004eb6:     	jmp	0x180003bcc <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x224c>
180004ebb:     	movsd	(%r14,%rdx,8), %xmm0
180004ec1:     	movsd	0x10(%r14,%rdx,8), %xmm1
180004ec8:     	movsd	0x20(%r14,%rdx,8), %xmm2
180004ecf:     	movq	%rbp, (%rbx)
180004ed2:     	cmpb	$0x0, (%rsi)
180004ed5:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
180004edb:     	xorps	%xmm3, %xmm3
180004ede:     	cvtsi2sd	%r11, %xmm3
180004ee3:     	movsd	0x44fd(%rip), %xmm4     # 0x1800093e8
180004eeb:     	divsd	%xmm3, %xmm4
180004eef:     	mulsd	%xmm4, %xmm0
180004ef3:     	mulsd	%xmm4, %xmm1
180004ef7:     	mulsd	%xmm2, %xmm4
180004efb:     	movsd	%xmm0, (%r14,%r10,8)
180004f01:     	movsd	%xmm1, 0x10(%r14,%r10,8)
180004f08:     	movsd	%xmm4, 0x20(%r14,%r10,8)
180004f0f:     	cmpb	$0x0, (%rsi)
180004f12:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
180004f18:     	movsd	(%r14,%rdx,8), %xmm2
180004f1e:     	movapd	0x44aa(%rip), %xmm0     # 0x1800093d0
180004f26:     	andpd	%xmm0, %xmm2
180004f2a:     	addsd	0x447e(%rip), %xmm2     # 0x1800093b0
180004f32:     	movapd	%xmm2, %xmm3
180004f36:     	andpd	%xmm0, %xmm3
180004f3a:     	movsd	0x44c6(%rip), %xmm1     # 0x180009408
180004f42:     	ucomisd	%xmm3, %xmm1
180004f46:     	jbe	0x1800053f3 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3a73>
180004f4c:     	movsd	0x10(%r14,%rdx,8), %xmm3
180004f53:     	andpd	%xmm0, %xmm3
180004f57:     	addsd	0x4451(%rip), %xmm3     # 0x1800093b0
180004f5f:     	movapd	%xmm3, %xmm4
180004f63:     	andpd	%xmm0, %xmm4
180004f67:     	ucomisd	%xmm4, %xmm1
180004f6b:     	jbe	0x1800053f3 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3a73>
180004f71:     	movq	%rbx, %rbp
180004f74:     	cvttsd2si	%xmm2, %r11
180004f79:     	cvttsd2si	%xmm3, %rbx
180004f7e:     	leaq	(%rbx,%r11), %r10
180004f82:     	xorq	%r10, %r11
180004f85:     	xorq	%r10, %rbx
180004f88:     	movb	$0x1, %r9b
180004f8b:     	testq	%rbx, %r11
180004f8e:     	js	0x180003de1 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2461>
180004f94:     	movsd	0x20(%r14,%rdx,8), %xmm2
180004f9b:     	andpd	%xmm0, %xmm2
180004f9f:     	addsd	0x4409(%rip), %xmm2     # 0x1800093b0
180004fa7:     	andpd	%xmm2, %xmm0
180004fab:     	ucomisd	%xmm0, %xmm1
180004faf:     	jbe	0x1800056a4 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3d24>
180004fb5:     	cvttsd2si	%xmm2, %r11
180004fba:     	leaq	(%r10,%r11), %rdx
180004fbe:     	xorq	%rdx, %r10
180004fc1:     	xorq	%rdx, %r11
180004fc4:     	testq	%r11, %r10
180004fc7:     	js	0x180003de1 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2461>
180004fcd:     	movq	%rcx, 0x68(%rsp)
180004fd2:     	testb	$0x1, %dl
180004fd5:     	jne	0x1800057a8 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3e28>
180004fdb:     	movq	0x10(%rax), %rax
180004fdf:     	movq	%rax, %rdx
180004fe2:     	sarq	$0x3f, %rdx
180004fe6:     	andq	%r15, %rdx
180004fe9:     	leaq	(%r14,%rax,8), %r9
180004fed:     	movsd	(%r9,%rdx,8), %xmm8
180004ff3:     	xorl	%edx, %edx
180004ff5:     	cmpq	$-0x2, %rax
180004ff9:     	movl	$0x0, %r10d
180004fff:     	cmovlq	%r15, %r10
180005003:     	movsd	0x10(%r9,%r10,8), %xmm7
18000500a:     	cmpq	$-0x4, %rax
18000500e:     	cmovlq	%r15, %rdx
180005012:     	movsd	0x20(%r9,%rdx,8), %xmm6
180005019:     	movq	0x68(%rsp), %rcx
18000501e:     	movq	%rbp, %rbx
180005021:     	jmp	0x180003bd5 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2255>
180005026:     	movb	$0x1, (%rsi)
180005029:     	movq	$0x1e84802, 0x18(%rbx)  # imm = 0x1E84802
180005031:     	movzbl	(%rsi), %r10d
180005035:     	movq	$-0x1, %rdx
18000503c:     	testb	%r10b, %r10b
18000503f:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
180005045:     	movsd	(%r14,%rax,8), %xmm0
18000504b:     	subsd	(%r14,%rdx,8), %xmm0
180005051:     	movapd	0x4377(%rip), %xmm1     # 0x1800093d0
180005059:     	andpd	%xmm0, %xmm1
18000505d:     	ucomisd	0x437b(%rip), %xmm1     # 0x1800093e0
180005065:     	jae	0x1800050f7 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3777>
18000506b:     	movsd	0x10(%r14,%rax,8), %xmm1
180005072:     	subsd	0x10(%r14,%rdx,8), %xmm1
180005079:     	movapd	0x434f(%rip), %xmm2     # 0x1800093d0
180005081:     	andpd	%xmm1, %xmm2
180005085:     	ucomisd	0x4353(%rip), %xmm2     # 0x1800093e0
18000508d:     	jae	0x1800050f7 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3777>
18000508f:     	movsd	0x20(%r14,%rax,8), %xmm2
180005096:     	subsd	0x20(%r14,%rdx,8), %xmm2
18000509d:     	movapd	0x432b(%rip), %xmm3     # 0x1800093d0
1800050a5:     	andpd	%xmm2, %xmm3
1800050a9:     	ucomisd	0x432f(%rip), %xmm3     # 0x1800093e0
1800050b1:     	jae	0x1800050f7 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3777>
1800050b3:     	movq	(%rbx), %rax
1800050b6:     	leaq	0x6(%rax), %rdx
1800050ba:     	cmpq	%r15, %rdx
1800050bd:     	jg	0x180003c44 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x22c4>
1800050c3:     	movq	%rdx, (%rbx)
1800050c6:     	cmpb	$0x0, (%rsi)
1800050c9:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
1800050cf:     	movsd	%xmm0, (%r14,%rax,8)
1800050d5:     	movsd	%xmm1, 0x10(%r14,%rax,8)
1800050dc:     	movsd	%xmm2, 0x20(%r14,%rax,8)
1800050e3:     	movzbl	(%rsi), %r9d
1800050e7:     	xorl	%edx, %edx
1800050e9:     	movl	%r9d, %r10d
1800050ec:     	negb	%r10b
1800050ef:     	sbbq	%rdx, %rdx
1800050f2:     	orq	%rax, %rdx
1800050f5:     	jmp	0x18000510d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x378d>
1800050f7:     	movb	$0x1, (%rsi)
1800050fa:     	movq	$0x1f78a43, 0x18(%rbx)  # imm = 0x1F78A43
180005102:     	movzbl	(%rsi), %r9d
180005106:     	movq	$-0x1, %rdx
18000510d:     	testb	%r9b, %r9b
180005110:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
180005116:     	movq	(%rbx), %rax
180005119:     	leaq	0x2(%rax), %r9
18000511d:     	cmpq	%r15, %r9
180005120:     	jg	0x180003c44 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x22c4>
180005126:     	movq	%r9, (%rbx)
180005129:     	cmpb	$0x0, (%rsi)
18000512c:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
180005132:     	movq	%r13, (%rdi,%rax,8)
180005136:     	movq	%rsi, 0x70(%rsp)
18000513b:     	cmpb	$0x0, (%rsi)
18000513e:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
180005144:     	movq	%rcx, 0x68(%rsp)
180005149:     	movsd	(%r14,%rdx,8), %xmm0
18000514f:     	mulsd	%xmm0, %xmm0
180005153:     	movapd	0x4275(%rip), %xmm1     # 0x1800093d0
18000515b:     	andpd	%xmm0, %xmm1
18000515f:     	ucomisd	0x4279(%rip), %xmm1     # 0x1800093e0
180005167:     	jae	0x1800051df <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x385f>
180005169:     	movsd	0x10(%r14,%rdx,8), %xmm1
180005170:     	mulsd	%xmm1, %xmm1
180005174:     	movapd	0x4254(%rip), %xmm2     # 0x1800093d0
18000517c:     	andpd	%xmm1, %xmm2
180005180:     	ucomisd	0x4258(%rip), %xmm2     # 0x1800093e0
180005188:     	jae	0x1800051df <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x385f>
18000518a:     	addsd	%xmm1, %xmm0
18000518e:     	movapd	0x423a(%rip), %xmm1     # 0x1800093d0
180005196:     	andpd	%xmm0, %xmm1
18000519a:     	ucomisd	0x423e(%rip), %xmm1     # 0x1800093e0
1800051a2:     	jae	0x1800051df <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x385f>
1800051a4:     	movsd	0x20(%r14,%rdx,8), %xmm1
1800051ab:     	mulsd	%xmm1, %xmm1
1800051af:     	movapd	0x4219(%rip), %xmm2     # 0x1800093d0
1800051b7:     	andpd	%xmm1, %xmm2
1800051bb:     	ucomisd	0x421d(%rip), %xmm2     # 0x1800093e0
1800051c3:     	jae	0x1800051df <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x385f>
1800051c5:     	addsd	%xmm1, %xmm0
1800051c9:     	movapd	0x41ff(%rip), %xmm1     # 0x1800093d0
1800051d1:     	andpd	%xmm0, %xmm1
1800051d5:     	ucomisd	0x4203(%rip), %xmm1     # 0x1800093e0
1800051dd:     	jb	0x180005201 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3881>
1800051df:     	movq	0x70(%rsp), %rcx
1800051e4:     	movb	$0x1, (%rcx)
1800051e7:     	movq	$0x14fb183, 0x18(%rbx)  # imm = 0x14FB183
1800051ef:     	cmpb	$0x0, (%rcx)
1800051f2:     	movq	0x68(%rsp), %rcx
1800051f7:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
1800051fd:     	xorpd	%xmm0, %xmm0
180005201:     	sqrtsd	%xmm0, %xmm0
180005205:     	xorpd	%xmm1, %xmm1
180005209:     	ucomisd	%xmm1, %xmm0
18000520d:     	jne	0x18000592c <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3fac>
180005213:     	jp	0x18000592c <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3fac>
180005219:     	movq	0x70(%rsp), %rcx
18000521e:     	movb	$0x1, (%rcx)
180005221:     	movq	$0x3d0902, 0x18(%rbx)   # imm = 0x3D0902
180005229:     	movzbl	(%rcx), %ecx
18000522c:     	movq	$-0x1, %rdx
180005233:     	testb	%cl, %cl
180005235:     	movq	0x68(%rsp), %rcx
18000523a:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
180005240:     	movq	%rdx, 0x8(%rdi,%rax,8)
180005245:     	movq	0x70(%rsp), %rdx
18000524a:     	cmpb	$0x0, (%rdx)
18000524d:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
180005253:     	movq	0x8(%rbx), %rcx
180005257:     	leaq	0x1(%rcx), %rdx
18000525b:     	movq	%rdx, 0x8(%rbx)
18000525f:     	cmpq	0x10(%rbx), %rcx
180005263:     	jge	0x180005c45 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x42c5>
180005269:     	movq	$0x0, 0x118(%rsp)
180005275:     	movb	$0x0, 0x120(%rsp)
18000527d:     	movq	$0x0, 0x128(%rsp)
180005289:     	movb	$0x0, 0x130(%rsp)
180005291:     	movq	$0x0, 0x138(%rsp)
18000529d:     	movb	$0x0, 0x140(%rsp)
1800052a5:     	movq	$0x0, 0x148(%rsp)
1800052b1:     	movb	$0x0, 0x150(%rsp)
1800052b9:     	movq	$0x0, 0x158(%rsp)
1800052c5:     	movb	$0x0, 0x160(%rsp)
1800052cd:     	movq	$0x0, 0x168(%rsp)
1800052d9:     	movb	$0x0, 0x170(%rsp)
1800052e1:     	movq	%rax, 0x28(%rsp)
1800052e6:     	movq	%r11, 0x20(%rsp)
1800052eb:     	movq	$-0x1, 0x50(%rsp)
1800052f4:     	movq	$-0x1, 0x48(%rsp)
1800052fd:     	movq	$-0x1, 0x40(%rsp)
180005306:     	movq	$-0x1, 0x38(%rsp)
18000530f:     	movq	$-0x1, 0x30(%rsp)
180005318:     	leaq	0x118(%rsp), %rcx
180005320:     	xorl	%r9d, %r9d
180005323:     	callq	0x180002e80 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1500>
180005328:     	movq	0x70(%rsp), %rax
18000532d:     	cmpb	$0x0, (%rax)
180005330:     	jne	0x180005c55 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x42d5>
180005336:     	movsd	0x138(%rsp), %xmm2
18000533f:     	movsd	0x118(%rsp), %xmm0
180005348:     	movsd	0x128(%rsp), %xmm1
180005351:     	decq	0x8(%rbx)
180005355:     	movq	0x70(%rsp), %rax
18000535a:     	cmpb	$0x0, (%rax)
18000535d:     	jne	0x180005c55 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x42d5>
180005363:     	movsd	0x20(%r14,%r12,8), %xmm3
18000536a:     	shlq	$0x3, %r12
18000536e:     	mulsd	%xmm3, %xmm0
180005372:     	xorpd	%xmm4, %xmm4
180005376:     	addsd	%xmm4, %xmm0
18000537a:     	mulsd	%xmm3, %xmm1
18000537e:     	addsd	%xmm4, %xmm1
180005382:     	mulsd	%xmm3, %xmm2
180005386:     	addsd	%xmm4, %xmm2
18000538a:     	movq	0x68(%rsp), %rcx
18000538f:     	movq	0x70(%rsp), %rsi
180005394:     	movsd	0x18(%r14,%r12), %xmm4
18000539b:     	xorpd	%xmm3, %xmm3
18000539f:     	ucomisd	%xmm3, %xmm4
1800053a3:     	ja	0x180003c24 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x22a4>
1800053a9:     	jmp	0x18000554a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3bca>
1800053ae:     	cmpb	$0x0, (%rsi)
1800053b1:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
1800053b7:     	testb	$0x1, %r12b
1800053bb:     	je	0x180005413 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3a93>
1800053bd:     	movq	%rcx, %r13
1800053c0:     	movq	0x2f8(%rsp), %rax
1800053c8:     	movq	(%rdi,%rax,8), %rcx
1800053cc:     	testb	$0x1, 0x60(%rsp)
1800053d1:     	je	0x1800055bf <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3c3f>
1800053d7:     	movq	%rsi, %rbp
1800053da:     	movq	(%rbx), %r10
1800053dd:     	leaq	0x6(%r10), %rax
1800053e1:     	cmpq	%r15, %rax
1800053e4:     	jle	0x1800056b7 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3d37>
1800053ea:     	movb	$0x2, (%rbp)
1800053ee:     	jmp	0x180005743 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3dc3>
1800053f3:     	movb	$0x1, (%rsi)
1800053f6:     	movq	$0x18cba84, 0x18(%rbx)  # imm = 0x18CBA84
1800053fe:     	jmp	0x180003bcc <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x224c>
180005403:     	movb	$0x1, (%rsi)
180005406:     	movq	$0x1036646, 0x18(%rbx)  # imm = 0x1036646
18000540e:     	cmpb	$0x0, (%rsi)
180005411:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
180005413:     	movq	0x2f0(%rsp), %r8
18000541b:     	movq	0x28(%rdi,%r8,8), %rax
180005420:     	movabsq	$0x7ffffffffffffff8, %rdx # imm = 0x7FFFFFFFFFFFFFF8
18000542a:     	addq	$0x8, %rdx
18000542e:     	cmpq	%rdx, %rax
180005431:     	jne	0x180005507 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3b87>
180005437:     	movb	$0x1, (%rsi)
18000543a:     	movq	$0x0, 0x58(%rcx)
180005442:     	movq	$0x0, 0x50(%rcx)
18000544a:     	movq	$0x0, 0x48(%rcx)
180005452:     	movq	$0x0, 0x40(%rcx)
18000545a:     	movq	$0x0, 0x38(%rcx)
180005462:     	movq	$0x0, 0x30(%rcx)
18000546a:     	movq	$0x0, 0x28(%rcx)
180005472:     	movq	$0x0, 0x20(%rcx)
18000547a:     	movq	$0x0, 0x18(%rcx)
180005482:     	movq	$0x0, 0x10(%rcx)
18000548a:     	movq	$0x0, 0x8(%rcx)
180005492:     	movq	$0x0, (%rcx)
180005499:     	xorl	%eax, %eax
18000549b:     	movaps	0x1e0(%rsp), %xmm6
1800054a3:     	movaps	0x1f0(%rsp), %xmm7
1800054ab:     	movaps	0x200(%rsp), %xmm8
1800054b4:     	movaps	0x210(%rsp), %xmm9
1800054bd:     	movaps	0x220(%rsp), %xmm10
1800054c6:     	movaps	0x230(%rsp), %xmm11
1800054cf:     	movaps	0x240(%rsp), %xmm12
1800054d8:     	movaps	0x250(%rsp), %xmm13
1800054e1:     	movaps	0x260(%rsp), %xmm14
1800054ea:     	movaps	0x270(%rsp), %xmm15
1800054f3:     	addq	$0x288, %rsp            # imm = 0x288
1800054fa:     	popq	%rbx
1800054fb:     	popq	%rbp
1800054fc:     	popq	%rdi
1800054fd:     	popq	%rsi
1800054fe:     	popq	%r12
180005500:     	popq	%r13
180005502:     	popq	%r14
180005504:     	popq	%r15
180005506:     	retq
180005507:     	decq	%rax
18000550a:     	movq	%rax, 0x28(%rdi,%r8,8)
18000550f:     	jmp	0x18000301e <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x169e>
180005514:     	xorpd	%xmm4, %xmm4
180005518:     	minsd	0x3ec8(%rip), %xmm4     # 0x1800093e8
180005520:     	mulsd	0x18(%r14,%r12), %xmm4
180005527:     	movapd	%xmm8, %xmm5
18000552c:     	mulsd	%xmm4, %xmm5
180005530:     	addsd	%xmm5, %xmm0
180005534:     	movapd	%xmm7, %xmm5
180005538:     	mulsd	%xmm4, %xmm5
18000553c:     	addsd	%xmm5, %xmm1
180005540:     	mulsd	%xmm6, %xmm4
180005544:     	addsd	%xmm4, %xmm2
180005548:     	xorl	%ebp, %ebp
18000554a:     	movsd	0x8(%r14,%r12), %xmm4
180005551:     	ucomisd	%xmm3, %xmm4
180005555:     	jbe	0x180005573 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3bf3>
180005557:     	mulsd	%xmm4, %xmm8
18000555c:     	addsd	%xmm8, %xmm0
180005561:     	mulsd	%xmm4, %xmm7
180005565:     	addsd	%xmm7, %xmm1
180005569:     	mulsd	%xmm4, %xmm6
18000556d:     	addsd	%xmm6, %xmm2
180005571:     	xorl	%ebp, %ebp
180005573:     	movb	%bpl, 0x58(%rcx)
180005577:     	movsd	%xmm2, 0x50(%rcx)
18000557c:     	movb	%bpl, 0x48(%rcx)
180005580:     	movsd	%xmm1, 0x40(%rcx)
180005585:     	movb	%bpl, 0x38(%rcx)
180005589:     	movsd	%xmm0, 0x30(%rcx)
18000558e:     	movb	$0x0, 0x28(%rcx)
180005592:     	movq	$0x0, 0x20(%rcx)
18000559a:     	movb	$0x0, 0x18(%rcx)
18000559e:     	movq	$0x0, 0x10(%rcx)
1800055a6:     	movb	$0x0, 0x8(%rcx)
1800055aa:     	jmp	0x180005492 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3b12>
1800055af:     	movb	$0x1, (%rsi)
1800055b2:     	movq	$0x6acfc6, 0x18(%rbx)   # imm = 0x6ACFC6
1800055ba:     	jmp	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
1800055bf:     	movb	$0x1, (%rsi)
1800055c2:     	movq	%rbx, %r12
1800055c5:     	movq	$0x15ef3c2, 0x18(%rbx)  # imm = 0x15EF3C2
1800055cd:     	movq	%rsi, %rbp
1800055d0:     	movzbl	(%rsi), %r11d
1800055d4:     	movq	$-0x1, %r9
1800055db:     	testb	%r11b, %r11b
1800055de:     	jne	0x180005743 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3dc3>
1800055e4:     	movsd	(%r14,%rcx,8), %xmm0
1800055ea:     	addsd	(%r14,%r9,8), %xmm0
1800055f0:     	movapd	0x3dd8(%rip), %xmm1     # 0x1800093d0
1800055f8:     	andpd	%xmm0, %xmm1
1800055fc:     	ucomisd	0x3ddc(%rip), %xmm1     # 0x1800093e0
180005604:     	jae	0x180005721 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3da1>
18000560a:     	movsd	0x10(%r14,%rcx,8), %xmm1
180005611:     	addsd	0x10(%r14,%r9,8), %xmm1
180005618:     	movapd	0x3db0(%rip), %xmm2     # 0x1800093d0
180005620:     	andpd	%xmm1, %xmm2
180005624:     	ucomisd	0x3db4(%rip), %xmm2     # 0x1800093e0
18000562c:     	jae	0x180005721 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3da1>
180005632:     	movsd	0x20(%r14,%rcx,8), %xmm2
180005639:     	addsd	0x20(%r14,%r9,8), %xmm2
180005640:     	movapd	0x3d88(%rip), %xmm3     # 0x1800093d0
180005648:     	andpd	%xmm2, %xmm3
18000564c:     	ucomisd	0x3d8c(%rip), %xmm3     # 0x1800093e0
180005654:     	jae	0x180005721 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3da1>
18000565a:     	movq	(%r12), %r9
18000565e:     	leaq	0x6(%r9), %rax
180005662:     	cmpq	%r15, %rax
180005665:     	jg	0x1800053ea <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3a6a>
18000566b:     	movq	%rax, (%r12)
18000566f:     	cmpb	$0x0, (%rbp)
180005673:     	jne	0x180005743 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3dc3>
180005679:     	movsd	%xmm0, (%r14,%r9,8)
18000567f:     	movsd	%xmm1, 0x10(%r14,%r9,8)
180005686:     	movsd	%xmm2, 0x20(%r14,%r9,8)
18000568d:     	movzbl	(%rbp), %r10d
180005692:     	xorl	%ecx, %ecx
180005694:     	movl	%r10d, %eax
180005697:     	negb	%al
180005699:     	sbbq	%rcx, %rcx
18000569c:     	orq	%r9, %rcx
18000569f:     	jmp	0x18000573a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3dba>
1800056a4:     	movb	$0x1, (%rsi)
1800056a7:     	movq	%rbp, %rbx
1800056aa:     	movq	$0x18cba84, 0x18(%rbp)  # imm = 0x18CBA84
1800056b2:     	jmp	0x180003bcc <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x224c>
1800056b7:     	movq	%rbx, %r12
1800056ba:     	movq	0x2f8(%rsp), %rdx
1800056c2:     	movq	0x8(%rdi,%rdx,8), %rdx
1800056c7:     	movsd	(%r14,%rdx,8), %xmm1
1800056cd:     	movsd	0x10(%r14,%rdx,8), %xmm2
1800056d4:     	movsd	0x20(%r14,%rdx,8), %xmm3
1800056db:     	movq	%rax, (%rbx)
1800056de:     	cmpb	$0x0, (%rbp)
1800056e2:     	jne	0x180005743 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3dc3>
1800056e4:     	mulsd	%xmm0, %xmm1
1800056e8:     	mulsd	%xmm0, %xmm2
1800056ec:     	mulsd	%xmm0, %xmm3
1800056f0:     	movsd	%xmm1, (%r14,%r10,8)
1800056f6:     	movsd	%xmm2, 0x10(%r14,%r10,8)
1800056fd:     	movsd	%xmm3, 0x20(%r14,%r10,8)
180005704:     	movzbl	(%rbp), %r11d
180005709:     	xorl	%r9d, %r9d
18000570c:     	movl	%r11d, %eax
18000570f:     	negb	%al
180005711:     	sbbq	%r9, %r9
180005714:     	orq	%r10, %r9
180005717:     	testb	%r11b, %r11b
18000571a:     	jne	0x180005743 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3dc3>
18000571c:     	jmp	0x1800055e4 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3c64>
180005721:     	movb	$0x1, (%rbp)
180005725:     	movq	$0x16e3603, 0x18(%r12)  # imm = 0x16E3603
18000572e:     	movzbl	(%rbp), %r10d
180005733:     	movq	$-0x1, %rcx
18000573a:     	testb	%r10b, %r10b
18000573d:     	je	0x18000583e <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3ebe>
180005743:     	movq	$0x0, 0x58(%r13)
18000574b:     	movq	$0x0, 0x50(%r13)
180005753:     	movq	$0x0, 0x48(%r13)
18000575b:     	movq	$0x0, 0x40(%r13)
180005763:     	movq	$0x0, 0x38(%r13)
18000576b:     	movq	$0x0, 0x30(%r13)
180005773:     	movq	$0x0, 0x28(%r13)
18000577b:     	movq	$0x0, 0x20(%r13)
180005783:     	movq	$0x0, 0x18(%r13)
18000578b:     	movq	$0x0, 0x10(%r13)
180005793:     	movq	$0x0, 0x8(%r13)
18000579b:     	movq	$0x0, (%r13)
1800057a3:     	jmp	0x180005499 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3b19>
1800057a8:     	movabsq	$-0x20000000000001, %rdx # imm = 0xFFDFFFFFFFFFFFFF
1800057b2:     	movq	0x30(%rax), %rbx
1800057b6:     	movq	%rbx, %rax
1800057b9:     	sarq	$0x3f, %rax
1800057bd:     	andq	%r15, %rax
1800057c0:     	leaq	(%rdi,%rbx,8), %r10
1800057c4:     	movq	(%r10,%rax,8), %rcx
1800057c8:     	xorl	%r11d, %r11d
1800057cb:     	cmpq	$-0x1, %rbx
1800057cf:     	movl	$0x0, %r9d
1800057d5:     	cmovlq	%r15, %r9
1800057d9:     	cmpq	$-0x2, %rbx
1800057dd:     	cmovlq	%r15, %r11
1800057e1:     	leaq	(%rcx,%rdx), %rbx
1800057e5:     	movabsq	$-0x40000000000001, %rax # imm = 0xFFBFFFFFFFFFFFFF
1800057ef:     	cmpq	%rax, %rbx
1800057f2:     	jb	0x18000581d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3e9d>
1800057f4:     	movq	0x8(%r10,%r9,8), %rax
1800057f9:     	leaq	(%rax,%rdx), %rbx
1800057fd:     	movabsq	$-0x40000000000001, %r9 # imm = 0xFFBFFFFFFFFFFFFF
180005807:     	cmpq	%r9, %rbx
18000580a:     	jb	0x18000581d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3e9d>
18000580c:     	movq	0x10(%r10,%r11,8), %r10
180005811:     	addq	%r10, %rdx
180005814:     	cmpq	%r9, %rdx
180005817:     	jae	0x180005c10 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4290>
18000581d:     	movb	$0x1, (%rsi)
180005820:     	movq	%rbp, %rbx
180005823:     	movq	$0x18cba87, 0x18(%rbp)  # imm = 0x18CBA87
18000582b:     	xorpd	%xmm7, %xmm7
18000582f:     	xorpd	%xmm8, %xmm8
180005834:     	movq	0x68(%rsp), %rcx
180005839:     	jmp	0x180003bd5 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2255>
18000583e:     	movq	0x80(%rsp), %rax
180005846:     	leaq	(%rdi,%rax,8), %r9
18000584a:     	sarq	$0x3f, %rax
18000584e:     	andq	%r15, %rax
180005851:     	movq	(%r9,%rax,8), %rax
180005855:     	cmpq	$0x1, %rax
180005859:     	je	0x18000594e <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3fce>
18000585f:     	testq	%rax, %rax
180005862:     	jne	0x180005a6e <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x40ee>
180005868:     	movq	0x8(%r9), %rdx
18000586c:     	movsd	(%r14,%rcx,8), %xmm0
180005872:     	subsd	(%r14,%rdx,8), %xmm0
180005878:     	movapd	0x3b50(%rip), %xmm1     # 0x1800093d0
180005880:     	andpd	%xmm0, %xmm1
180005884:     	ucomisd	0x3b54(%rip), %xmm1     # 0x1800093e0
18000588c:     	jae	0x180005a80 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4100>
180005892:     	movsd	0x10(%r14,%rcx,8), %xmm1
180005899:     	subsd	0x10(%r14,%rdx,8), %xmm1
1800058a0:     	movapd	0x3b28(%rip), %xmm2     # 0x1800093d0
1800058a8:     	andpd	%xmm1, %xmm2
1800058ac:     	ucomisd	0x3b2c(%rip), %xmm2     # 0x1800093e0
1800058b4:     	jae	0x180005a80 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4100>
1800058ba:     	movsd	0x20(%r14,%rcx,8), %xmm2
1800058c1:     	subsd	0x20(%r14,%rdx,8), %xmm2
1800058c8:     	movapd	0x3b00(%rip), %xmm3     # 0x1800093d0
1800058d0:     	andpd	%xmm2, %xmm3
1800058d4:     	ucomisd	0x3b04(%rip), %xmm3     # 0x1800093e0
1800058dc:     	jae	0x180005a80 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4100>
1800058e2:     	movq	(%r12), %r9
1800058e6:     	leaq	0x6(%r9), %rax
1800058ea:     	cmpq	%r15, %rax
1800058ed:     	jg	0x1800053ea <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3a6a>
1800058f3:     	movq	%rax, (%r12)
1800058f7:     	cmpb	$0x0, (%rbp)
1800058fb:     	jne	0x180005743 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3dc3>
180005901:     	movsd	%xmm0, (%r14,%r9,8)
180005907:     	movsd	%xmm1, 0x10(%r14,%r9,8)
18000590e:     	movsd	%xmm2, 0x20(%r14,%r9,8)
180005915:     	movzbl	(%rbp), %r10d
18000591a:     	xorl	%edx, %edx
18000591c:     	movl	%r10d, %eax
18000591f:     	negb	%al
180005921:     	sbbq	%rdx, %rdx
180005924:     	orq	%r9, %rdx
180005927:     	jmp	0x180005a99 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4119>
18000592c:     	movq	(%rbx), %r9
18000592f:     	leaq	0x6(%r9), %rcx
180005933:     	cmpq	%r15, %rcx
180005936:     	jle	0x180005b92 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4212>
18000593c:     	movq	0x70(%rsp), %rax
180005941:     	movb	$0x2, (%rax)
180005944:     	movq	0x68(%rsp), %rcx
180005949:     	jmp	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
18000594e:     	movq	0x20(%r9), %rdx
180005952:     	movq	0x8(%r12), %rax
180005957:     	leaq	0x1(%rax), %r9
18000595b:     	movq	%r9, 0x8(%r12)
180005960:     	movq	%r12, %rbx
180005963:     	cmpq	0x10(%r12), %rax
180005968:     	jge	0x180005c24 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x42a4>
18000596e:     	movq	$0x0, 0x1a8(%rsp)
18000597a:     	movb	$0x0, 0x1b0(%rsp)
180005982:     	movq	$0x0, 0x1b8(%rsp)
18000598e:     	movb	$0x0, 0x1c0(%rsp)
180005996:     	movq	$0x0, 0x1c8(%rsp)
1800059a2:     	movb	$0x0, 0x1d0(%rsp)
1800059aa:     	movq	%rdx, 0x50(%rsp)
1800059af:     	movq	%rcx, 0x48(%rsp)
1800059b4:     	movq	0x2f8(%rsp), %rax
1800059bc:     	movq	%rax, 0x40(%rsp)
1800059c1:     	movq	0x2f0(%rsp), %rax
1800059c9:     	movq	%rax, 0x38(%rsp)
1800059ce:     	movq	0x88(%rsp), %rax
1800059d6:     	movq	%rax, 0x30(%rsp)
1800059db:     	movq	$-0x1, 0x28(%rsp)
1800059e4:     	movq	$-0x1, 0x20(%rsp)
1800059ed:     	leaq	0x178(%rsp), %rcx
1800059f5:     	movl	$0x1, %r9d
1800059fb:     	callq	0x180002e80 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1500>
180005a00:     	cmpb	$0x0, (%rbp)
180005a04:     	jne	0x180005743 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3dc3>
180005a0a:     	movsd	0x1a8(%rsp), %xmm0
180005a13:     	movzbl	0x1b0(%rsp), %eax
180005a1b:     	movsd	0x1b8(%rsp), %xmm1
180005a24:     	movzbl	0x1c0(%rsp), %edx
180005a2c:     	movsd	0x1c8(%rsp), %xmm2
180005a35:     	movzbl	0x1d0(%rsp), %ecx
180005a3d:     	decq	0x8(%rbx)
180005a41:     	movq	0x2f0(%rsp), %r8
180005a49:     	movq	0x28(%rdi,%r8,8), %r8
180005a4e:     	movabsq	$0x7ffffffffffffff8, %r9 # imm = 0x7FFFFFFFFFFFFFF8
180005a58:     	addq	$0x8, %r9
180005a5c:     	cmpq	%r9, %r8
180005a5f:     	jne	0x180005cbe <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x433e>
180005a65:     	movb	$0x1, (%rbp)
180005a69:     	jmp	0x180005743 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3dc3>
180005a6e:     	movb	$0x1, (%rbp)
180005a72:     	movq	$0x6acfce, 0x18(%r12)   # imm = 0x6ACFCE
180005a7b:     	jmp	0x180005743 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3dc3>
180005a80:     	movb	$0x1, (%rbp)
180005a84:     	movq	$0xf4243, 0x18(%r12)    # imm = 0xF4243
180005a8d:     	movzbl	(%rbp), %r10d
180005a92:     	movq	$-0x1, %rdx
180005a99:     	testb	%r10b, %r10b
180005a9c:     	jne	0x180005743 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3dc3>
180005aa2:     	movsd	(%r14,%rdx,8), %xmm0
180005aa8:     	mulsd	%xmm0, %xmm0
180005aac:     	movapd	0x391c(%rip), %xmm1     # 0x1800093d0
180005ab4:     	andpd	%xmm0, %xmm1
180005ab8:     	ucomisd	0x3920(%rip), %xmm1     # 0x1800093e0
180005ac0:     	jae	0x180005b38 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x41b8>
180005ac2:     	movsd	0x10(%r14,%rdx,8), %xmm1
180005ac9:     	mulsd	%xmm1, %xmm1
180005acd:     	movapd	0x38fb(%rip), %xmm2     # 0x1800093d0
180005ad5:     	andpd	%xmm1, %xmm2
180005ad9:     	ucomisd	0x38ff(%rip), %xmm2     # 0x1800093e0
180005ae1:     	jae	0x180005b38 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x41b8>
180005ae3:     	addsd	%xmm1, %xmm0
180005ae7:     	movapd	0x38e1(%rip), %xmm1     # 0x1800093d0
180005aef:     	andpd	%xmm0, %xmm1
180005af3:     	ucomisd	0x38e5(%rip), %xmm1     # 0x1800093e0
180005afb:     	jae	0x180005b38 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x41b8>
180005afd:     	movsd	0x20(%r14,%rdx,8), %xmm1
180005b04:     	mulsd	%xmm1, %xmm1
180005b08:     	movapd	0x38c0(%rip), %xmm2     # 0x1800093d0
180005b10:     	andpd	%xmm1, %xmm2
180005b14:     	ucomisd	0x38c4(%rip), %xmm2     # 0x1800093e0
180005b1c:     	jae	0x180005b38 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x41b8>
180005b1e:     	addsd	%xmm1, %xmm0
180005b22:     	movapd	0x38a6(%rip), %xmm1     # 0x1800093d0
180005b2a:     	andpd	%xmm0, %xmm1
180005b2e:     	ucomisd	0x38aa(%rip), %xmm1     # 0x1800093e0
180005b36:     	jb	0x180005b53 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x41d3>
180005b38:     	movb	$0x1, (%rbp)
180005b3c:     	movq	$0x14fb183, 0x18(%r12)  # imm = 0x14FB183
180005b45:     	cmpb	$0x0, (%rbp)
180005b49:     	jne	0x180005743 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3dc3>
180005b4f:     	xorpd	%xmm0, %xmm0
180005b53:     	sqrtsd	%xmm0, %xmm0
180005b57:     	xorpd	%xmm1, %xmm1
180005b5b:     	ucomisd	%xmm1, %xmm0
180005b5f:     	jne	0x180005d2b <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x43ab>
180005b65:     	jp	0x180005d2b <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x43ab>
180005b6b:     	movb	$0x1, (%rbp)
180005b6f:     	movq	$0x3d0902, 0x18(%r12)   # imm = 0x3D0902
180005b78:     	movzbl	(%rbp), %r10d
180005b7d:     	movq	$-0x1, %rdx
180005b84:     	testb	%r10b, %r10b
180005b87:     	jne	0x180005743 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3dc3>
180005b8d:     	jmp	0x180005952 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3fd2>
180005b92:     	movsd	(%r14,%rdx,8), %xmm1
180005b98:     	movsd	0x10(%r14,%rdx,8), %xmm2
180005b9f:     	movsd	0x20(%r14,%rdx,8), %xmm3
180005ba6:     	movq	%rcx, (%rbx)
180005ba9:     	movq	0x70(%rsp), %rcx
180005bae:     	cmpb	$0x0, (%rcx)
180005bb1:     	movq	0x68(%rsp), %rcx
180005bb6:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
180005bbc:     	movsd	0x3824(%rip), %xmm4     # 0x1800093e8
180005bc4:     	divsd	%xmm0, %xmm4
180005bc8:     	mulsd	%xmm4, %xmm1
180005bcc:     	mulsd	%xmm4, %xmm2
180005bd0:     	mulsd	%xmm3, %xmm4
180005bd4:     	movsd	%xmm1, (%r14,%r9,8)
180005bda:     	movsd	%xmm2, 0x10(%r14,%r9,8)
180005be1:     	movsd	%xmm4, 0x20(%r14,%r9,8)
180005be8:     	movq	0x70(%rsp), %rcx
180005bed:     	movzbl	(%rcx), %ecx
180005bf0:     	xorl	%edx, %edx
180005bf2:     	movl	%ecx, %r10d
180005bf5:     	negb	%r10b
180005bf8:     	sbbq	%rdx, %rdx
180005bfb:     	orq	%r9, %rdx
180005bfe:     	testb	%cl, %cl
180005c00:     	movq	0x68(%rsp), %rcx
180005c05:     	jne	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
180005c0b:     	jmp	0x180005240 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x38c0>
180005c10:     	cvtsi2sd	%rcx, %xmm8
180005c15:     	cvtsi2sd	%rax, %xmm7
180005c1a:     	cvtsi2sd	%r10, %xmm6
180005c1f:     	jmp	0x180005019 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3699>
180005c24:     	movb	$0x1, (%rbp)
180005c28:     	movq	$0x6acfce, 0x18(%rbx)   # imm = 0x6ACFCE
180005c30:     	jmp	0x180005743 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3dc3>
180005c35:     	movb	$0x1, (%rsi)
180005c38:     	movq	$0x1406f4f, 0x18(%rbx)  # imm = 0x1406F4F
180005c40:     	jmp	0x18000543a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3aba>
180005c45:     	movq	0x70(%rsp), %rax
180005c4a:     	movb	$0x1, (%rax)
180005c4d:     	movq	$0x1406f47, 0x18(%rbx)  # imm = 0x1406F47
180005c55:     	movq	0x68(%rsp), %rax
180005c5a:     	movq	$0x0, 0x58(%rax)
180005c62:     	movq	$0x0, 0x50(%rax)
180005c6a:     	movq	$0x0, 0x48(%rax)
180005c72:     	movq	$0x0, 0x40(%rax)
180005c7a:     	movq	$0x0, 0x38(%rax)
180005c82:     	movq	$0x0, 0x30(%rax)
180005c8a:     	movq	$0x0, 0x28(%rax)
180005c92:     	movq	$0x0, 0x20(%rax)
180005c9a:     	movq	$0x0, 0x18(%rax)
180005ca2:     	movq	$0x0, 0x10(%rax)
180005caa:     	movq	$0x0, 0x8(%rax)
180005cb2:     	movq	$0x0, (%rax)
180005cb9:     	jmp	0x180005499 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3b19>
180005cbe:     	cmpb	$0x0, (%rbp)
180005cc2:     	jne	0x180005743 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3dc3>
180005cc8:     	decq	%r8
180005ccb:     	testb	%dl, %dl
180005ccd:     	movq	0x2f0(%rsp), %rdx
180005cd5:     	movq	%r8, 0x28(%rdi,%rdx,8)
180005cda:     	setne	0x18(%r13)
180005cdf:     	testb	%cl, %cl
180005ce1:     	setne	0x28(%r13)
180005ce6:     	testb	%al, %al
180005ce8:     	movsd	%xmm2, 0x20(%r13)
180005cee:     	movsd	%xmm1, 0x10(%r13)
180005cf4:     	setne	0x8(%r13)
180005cf9:     	movsd	%xmm0, (%r13)
180005cff:     	movb	$0x0, 0x58(%r13)
180005d04:     	movq	$0x0, 0x50(%r13)
180005d0c:     	movb	$0x0, 0x48(%r13)
180005d11:     	movq	$0x0, 0x40(%r13)
180005d19:     	movb	$0x0, 0x38(%r13)
180005d1e:     	movq	$0x0, 0x30(%r13)
180005d26:     	jmp	0x180005499 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3b19>
180005d2b:     	movq	(%r12), %r9
180005d2f:     	leaq	0x6(%r9), %rax
180005d33:     	cmpq	%r15, %rax
180005d36:     	jg	0x1800053ea <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3a6a>
180005d3c:     	movsd	(%r14,%rdx,8), %xmm1
180005d42:     	movsd	0x10(%r14,%rdx,8), %xmm2
180005d49:     	movsd	0x20(%r14,%rdx,8), %xmm3
180005d50:     	movq	%rax, (%r12)
180005d54:     	cmpb	$0x0, (%rbp)
180005d58:     	jne	0x180005743 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3dc3>
180005d5e:     	movsd	0x3682(%rip), %xmm4     # 0x1800093e8
180005d66:     	divsd	%xmm0, %xmm4
180005d6a:     	mulsd	%xmm4, %xmm1
180005d6e:     	mulsd	%xmm4, %xmm2
180005d72:     	mulsd	%xmm3, %xmm4
180005d76:     	movsd	%xmm1, (%r14,%r9,8)
180005d7c:     	movsd	%xmm2, 0x10(%r14,%r9,8)
180005d83:     	movsd	%xmm4, 0x20(%r14,%r9,8)
180005d8a:     	movzbl	(%rbp), %r10d
180005d8f:     	xorl	%edx, %edx
180005d91:     	movl	%r10d, %eax
180005d94:     	negb	%al
180005d96:     	sbbq	%rdx, %rdx
180005d99:     	orq	%r9, %rdx
180005d9c:     	testb	%r10b, %r10b
180005d9f:     	jne	0x180005743 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3dc3>
180005da5:     	jmp	0x180005952 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3fd2>
180005daa:     	int3
180005dab:     	int3
180005dac:     	int3
180005dad:     	int3
180005dae:     	int3
180005daf:     	int3
180005db0:     	pushq	%rbx
180005db2:     	subq	$0x20, %rsp
180005db6:     	movq	%rcx, %rbx
180005db9:     	callq	*0x3331(%rip)           # 0x1800090f0
180005dbf:     	movl	%eax, (%rbx)
180005dc1:     	addq	$0x20, %rsp
180005dc5:     	popq	%rbx
180005dc6:     	retq
180005dc7:     	int3
180005dc8:     	int3
180005dc9:     	int3
180005dca:     	int3
180005dcb:     	int3
180005dcc:     	int3
180005dcd:     	int3
180005dce:     	int3
180005dcf:     	int3
180005dd0:     	movl	(%rcx), %ecx
180005dd2:     	jmpq	*0x3447(%rip)           # 0x180009220
180005dd9:     	int3
180005dda:     	int3
180005ddb:     	int3
180005ddc:     	int3
180005ddd:     	int3
180005dde:     	int3
180005ddf:     	int3
180005de0:     	pushq	%rbp
180005de2:     	pushq	%rbx
180005de3:     	pushq	%rsi
180005de4:     	pushq	%rdi
180005de5:     	pushq	%r14
180005de7:     	pushq	%r15
180005de9:     	movq	%rsp, %rbp
180005dec:     	subq	$0x48, %rsp
180005df0:     	movq	0x33f9(%rip), %rax      # 0x1800091f0
180005df7:     	xorl	%r15d, %r15d
180005dfa:     	movq	%rcx, %rsi
180005dfd:     	movq	%r15, 0x38(%rbp)
180005e01:     	movl	%r15d, %r14d
180005e04:     	movq	%r15, 0x50(%rbp)
180005e08:     	movq	%r15, 0x48(%rbp)
180005e0c:     	cmpq	%rax, 0x8(%rcx)
180005e10:     	jne	0x180005f7e <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x45fe>
180005e16:     	leaq	0x48(%rbp), %rax
180005e1a:     	leaq	0x50(%rbp), %r9
180005e1e:     	movq	%rax, 0x20(%rsp)
180005e23:     	leaq	0x38(%rbp), %r8
180005e27:     	leaq	0x3eb6(%rip), %rdx      # 0x180009ce4
180005e2e:     	callq	*0x32fc(%rip)           # 0x180009130
180005e34:     	testl	%eax, %eax
180005e36:     	jne	0x180005f74 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x45f4>
180005e3c:     	movq	0x48(%rbp), %rbx
180005e40:     	testq	%rbx, %rbx
180005e43:     	je	0x180005f65 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x45e5>
180005e49:     	cmpq	0x3490(%rip), %rbx      # 0x1800092e0
180005e50:     	je	0x180005f65 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x45e5>
180005e56:     	movq	0x8(%rbx), %rax
180005e5a:     	testl	$0x4000000, 0xa8(%rax)  # imm = 0x4000000
180005e64:     	je	0x180005f65 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x45e5>
180005e6a:     	movq	0x20(%rbx), %rcx
180005e6e:     	callq	*0x331c(%rip)           # 0x180009190
180005e74:     	movq	0x28(%rbx), %rcx
180005e78:     	movq	%rax, %rdi
180005e7b:     	callq	*0x330f(%rip)           # 0x180009190
180005e81:     	movq	0x30(%rbx), %rcx
180005e85:     	movq	%rax, %r14
180005e88:     	callq	*0x3312(%rip)           # 0x1800091a0
180005e8e:     	leaq	-0x10(%rbp), %r8
180005e92:     	movl	%eax, %ebx
180005e94:     	leaq	-0x18(%rbp), %rdx
180005e98:     	leaq	0x40(%rbp), %rcx
180005e9c:     	callq	*0x330e(%rip)           # 0x1800091b0
180005ea2:     	callq	*0x32c8(%rip)           # 0x180009170
180005ea8:     	movq	%rax, %rsi
180005eab:     	testq	%rax, %rax
180005eae:     	je	0x180005f5b <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x45db>
180005eb4:     	movl	%ebx, %r8d
180005eb7:     	movq	%rdi, %rdx
180005eba:     	movq	%r14, %rcx
180005ebd:     	callq	*0x33a5(%rip)           # 0x180009268
180005ec3:     	movq	%rax, %rdi
180005ec6:     	testq	%rax, %rax
180005ec9:     	je	0x180005f5b <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x45db>
180005ecf:     	callq	*0x33a3(%rip)           # 0x180009278
180005ed5:     	xorl	%r9d, %r9d
180005ed8:     	movq	%rsi, %r8
180005edb:     	movq	%rax, %rcx
180005ede:     	movq	%rdi, %rdx
180005ee1:     	callq	*0x3369(%rip)           # 0x180009250
180005ee7:     	movl	(%rsi), %ecx
180005ee9:     	movq	%rax, %rbx
180005eec:     	testl	%ecx, %ecx
180005eee:     	js	0x180005f00 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4580>
180005ef0:     	subl	$0x1, %ecx
180005ef3:     	movl	%ecx, (%rsi)
180005ef5:     	jne	0x180005f00 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4580>
180005ef7:     	movq	%rsi, %rcx
180005efa:     	callq	*0x32d8(%rip)           # 0x1800091d8
180005f00:     	movl	(%rdi), %eax
180005f02:     	testl	%eax, %eax
180005f04:     	js	0x180005f16 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4596>
180005f06:     	subl	$0x1, %eax
180005f09:     	movl	%eax, (%rdi)
180005f0b:     	jne	0x180005f16 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4596>
180005f0d:     	movq	%rdi, %rcx
180005f10:     	callq	*0x32c2(%rip)           # 0x1800091d8
180005f16:     	testq	%rbx, %rbx
180005f19:     	je	0x180005f5b <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x45db>
180005f1b:     	movq	-0x10(%rbp), %r8
180005f1f:     	movq	-0x18(%rbp), %rdx
180005f23:     	movq	0x40(%rbp), %rcx
180005f27:     	callq	*0x32b3(%rip)           # 0x1800091e0
180005f2d:     	movq	%rbx, %rcx
180005f30:     	callq	*0x3302(%rip)           # 0x180009238
180005f36:     	movl	(%rbx), %eax
180005f38:     	testl	%eax, %eax
180005f3a:     	js	0x180005f65 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x45e5>
180005f3c:     	subl	$0x1, %eax
180005f3f:     	movl	%eax, (%rbx)
180005f41:     	jne	0x180005f65 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x45e5>
180005f43:     	movq	%rbx, %rcx
180005f46:     	callq	*0x328c(%rip)           # 0x1800091d8
180005f4c:     	xorl	%eax, %eax
180005f4e:     	addq	$0x48, %rsp
180005f52:     	popq	%r15
180005f54:     	popq	%r14
180005f56:     	popq	%rdi
180005f57:     	popq	%rsi
180005f58:     	popq	%rbx
180005f59:     	popq	%rbp
180005f5a:     	retq
180005f5b:     	movq	0x40(%rbp), %rcx
180005f5f:     	callq	*0x32ab(%rip)           # 0x180009210
180005f65:     	xorl	%eax, %eax
180005f67:     	addq	$0x48, %rsp
180005f6b:     	popq	%r15
180005f6d:     	popq	%r14
180005f6f:     	popq	%rdi
180005f70:     	popq	%rsi
180005f71:     	popq	%rbx
180005f72:     	popq	%rbp
180005f73:     	retq
180005f74:     	movq	0x38(%rbp), %rbx
180005f78:     	movq	0x50(%rbp), %r14
180005f7c:     	jmp	0x180005f85 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4605>
180005f7e:     	movq	%rsi, %rbx
180005f81:     	movq	%rbx, 0x38(%rbp)
180005f85:     	cmpq	0x3354(%rip), %rbx      # 0x1800092e0
180005f8c:     	jne	0x180006024 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x46a4>
180005f92:     	leaq	-0x18(%rbp), %r8
180005f96:     	leaq	-0x10(%rbp), %rdx
180005f9a:     	leaq	0x40(%rbp), %rcx
180005f9e:     	callq	*0x317c(%rip)           # 0x180009120
180005fa4:     	movq	0x3335(%rip), %rax      # 0x1800092e0
180005fab:     	cmpq	%rax, 0x40(%rbp)
180005faf:     	jne	0x180005fc4 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4644>
180005fb1:     	movq	0x3308(%rip), %rcx      # 0x1800092c0
180005fb8:     	leaq	0x3cd9(%rip), %rdx      # 0x180009c98
180005fbf:     	jmp	0x1800060e5 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4765>
180005fc4:     	movq	0x40(%rbp), %rcx
180005fc8:     	testq	%rcx, %rcx
180005fcb:     	je	0x180005fda <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x465a>
180005fcd:     	movl	(%rcx), %eax
180005fcf:     	cmpl	$0xc0000000, %eax       # imm = 0xC0000000
180005fd4:     	jae	0x180005fda <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x465a>
180005fd6:     	incl	%eax
180005fd8:     	movl	%eax, (%rcx)
180005fda:     	movq	-0x10(%rbp), %rcx
180005fde:     	testq	%rcx, %rcx
180005fe1:     	je	0x180005ff0 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4670>
180005fe3:     	movl	(%rcx), %eax
180005fe5:     	cmpl	$0xc0000000, %eax       # imm = 0xC0000000
180005fea:     	jae	0x180005ff0 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4670>
180005fec:     	incl	%eax
180005fee:     	movl	%eax, (%rcx)
180005ff0:     	movq	-0x18(%rbp), %r8
180005ff4:     	testq	%r8, %r8
180005ff7:     	je	0x18000600c <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x468c>
180005ff9:     	movl	(%r8), %eax
180005ffc:     	cmpl	$0xc0000000, %eax       # imm = 0xC0000000
180006001:     	jae	0x18000600c <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x468c>
180006003:     	incl	%eax
180006005:     	movl	%eax, (%r8)
180006008:     	movq	-0x18(%rbp), %r8
18000600c:     	movq	-0x10(%rbp), %rdx
180006010:     	movq	0x40(%rbp), %rcx
180006014:     	callq	*0x31c6(%rip)           # 0x1800091e0
18000601a:     	movl	$0x1, %ebx
18000601f:     	jmp	0x1800060f1 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4771>
180006024:     	movq	0x8(%rbx), %rcx
180006028:     	movl	0xa8(%rcx), %eax
18000602e:     	testl	%eax, %eax
180006030:     	jns	0x1800060c6 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4746>
180006036:     	testl	$0x40000000, 0xa8(%rbx) # imm = 0x40000000
180006040:     	je	0x1800060c6 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4746>
180006046:     	movq	%r14, %rdx
180006049:     	movq	%rbx, %rcx
18000604c:     	callq	*0x30be(%rip)           # 0x180009110
180006052:     	movq	%rax, %rdi
180006055:     	testq	%rax, %rax
180006058:     	je	0x1800060ee <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x476e>
18000605e:     	movq	0x8(%rax), %rax
180006062:     	testl	$0x40000000, 0xa8(%rax) # imm = 0x40000000
18000606c:     	jne	0x18000609d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x471d>
18000606e:     	movq	0x323b(%rip), %rcx      # 0x1800092b0
180006075:     	leaq	0x3c3c(%rip), %rdx      # 0x180009cb8
18000607c:     	movq	(%rcx), %rcx
18000607f:     	callq	*0x3233(%rip)           # 0x1800092b8
180006085:     	movl	(%rdi), %eax
180006087:     	testl	%eax, %eax
180006089:     	js	0x1800060ee <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x476e>
18000608b:     	subl	$0x1, %eax
18000608e:     	movl	%eax, (%rdi)
180006090:     	jne	0x1800060ee <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x476e>
180006092:     	movq	%rdi, %rcx
180006095:     	callq	*0x313d(%rip)           # 0x1800091d8
18000609b:     	jmp	0x1800060ee <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x476e>
18000609d:     	movl	(%rdi), %eax
18000609f:     	testl	%eax, %eax
1800060a1:     	js	0x1800060b3 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4733>
1800060a3:     	subl	$0x1, %eax
1800060a6:     	movl	%eax, (%rdi)
1800060a8:     	jne	0x1800060b3 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4733>
1800060aa:     	movq	%rdi, %rcx
1800060ad:     	callq	*0x3125(%rip)           # 0x1800091d8
1800060b3:     	movq	%r14, %rdx
1800060b6:     	movq	%rbx, %rcx
1800060b9:     	callq	*0x31b1(%rip)           # 0x180009270
1800060bf:     	movl	$0x1, %ebx
1800060c4:     	jmp	0x1800060f1 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4771>
1800060c6:     	btl	$0x1e, %eax
1800060ca:     	jae	0x1800060d7 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4757>
1800060cc:     	movq	%rbx, %rdx
1800060cf:     	callq	*0x319b(%rip)           # 0x180009270
1800060d5:     	jmp	0x1800060ee <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x476e>
1800060d7:     	movq	0x31d2(%rip), %rcx      # 0x1800092b0
1800060de:     	leaq	0x3bd3(%rip), %rdx      # 0x180009cb8
1800060e5:     	movq	(%rcx), %rcx
1800060e8:     	callq	*0x31ca(%rip)           # 0x1800092b8
1800060ee:     	movl	%r15d, %ebx
1800060f1:     	movq	0x48(%rbp), %rdi
1800060f5:     	testq	%rdi, %rdi
1800060f8:     	je	0x18000621b <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x489b>
1800060fe:     	cmpq	0x31db(%rip), %rdi      # 0x1800092e0
180006105:     	je	0x18000621b <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x489b>
18000610b:     	movq	0x8(%rdi), %rax
18000610f:     	testl	$0x4000000, 0xa8(%rax)  # imm = 0x4000000
180006119:     	je	0x18000621b <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x489b>
18000611f:     	movq	0x20(%rdi), %rcx
180006123:     	movq	%r12, 0x40(%rsp)
180006128:     	callq	*0x3062(%rip)           # 0x180009190
18000612e:     	movq	0x28(%rdi), %rcx
180006132:     	movq	%rax, %r14
180006135:     	callq	*0x3055(%rip)           # 0x180009190
18000613b:     	movq	0x30(%rdi), %rcx
18000613f:     	movq	%rax, %r12
180006142:     	callq	*0x3058(%rip)           # 0x1800091a0
180006148:     	leaq	-0x10(%rbp), %r8
18000614c:     	movl	%eax, %edi
18000614e:     	leaq	-0x18(%rbp), %rdx
180006152:     	leaq	0x40(%rbp), %rcx
180006156:     	callq	*0x3054(%rip)           # 0x1800091b0
18000615c:     	callq	*0x300e(%rip)           # 0x180009170
180006162:     	movq	%rax, %r15
180006165:     	testq	%rax, %rax
180006168:     	je	0x18000620c <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x488c>
18000616e:     	movl	%edi, %r8d
180006171:     	movq	%r14, %rdx
180006174:     	movq	%r12, %rcx
180006177:     	callq	*0x30eb(%rip)           # 0x180009268
18000617d:     	movq	%rax, %r14
180006180:     	testq	%rax, %rax
180006183:     	je	0x18000620c <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x488c>
180006189:     	callq	*0x30e9(%rip)           # 0x180009278
18000618f:     	xorl	%r9d, %r9d
180006192:     	movq	%r15, %r8
180006195:     	movq	%rax, %rcx
180006198:     	movq	%r14, %rdx
18000619b:     	callq	*0x30af(%rip)           # 0x180009250
1800061a1:     	movl	(%r15), %ecx
1800061a4:     	movq	%rax, %rdi
1800061a7:     	testl	%ecx, %ecx
1800061a9:     	js	0x1800061bc <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x483c>
1800061ab:     	subl	$0x1, %ecx
1800061ae:     	movl	%ecx, (%r15)
1800061b1:     	jne	0x1800061bc <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x483c>
1800061b3:     	movq	%r15, %rcx
1800061b6:     	callq	*0x301c(%rip)           # 0x1800091d8
1800061bc:     	movl	(%r14), %eax
1800061bf:     	testl	%eax, %eax
1800061c1:     	js	0x1800061d4 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4854>
1800061c3:     	subl	$0x1, %eax
1800061c6:     	movl	%eax, (%r14)
1800061c9:     	jne	0x1800061d4 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4854>
1800061cb:     	movq	%r14, %rcx
1800061ce:     	callq	*0x3004(%rip)           # 0x1800091d8
1800061d4:     	testq	%rdi, %rdi
1800061d7:     	je	0x18000620c <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x488c>
1800061d9:     	movq	-0x10(%rbp), %r8
1800061dd:     	movq	-0x18(%rbp), %rdx
1800061e1:     	movq	0x40(%rbp), %rcx
1800061e5:     	callq	*0x2ff5(%rip)           # 0x1800091e0
1800061eb:     	movq	%rdi, %rcx
1800061ee:     	callq	*0x3044(%rip)           # 0x180009238
1800061f4:     	movl	(%rdi), %eax
1800061f6:     	testl	%eax, %eax
1800061f8:     	js	0x180006216 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4896>
1800061fa:     	subl	$0x1, %eax
1800061fd:     	movl	%eax, (%rdi)
1800061ff:     	jne	0x180006216 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4896>
180006201:     	movq	%rdi, %rcx
180006204:     	callq	*0x2fce(%rip)           # 0x1800091d8
18000620a:     	jmp	0x180006216 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4896>
18000620c:     	movq	0x40(%rbp), %rcx
180006210:     	callq	*0x2ffa(%rip)           # 0x180009210
180006216:     	movq	0x40(%rsp), %r12
18000621b:     	movl	(%rsi), %ecx
18000621d:     	testl	%ecx, %ecx
18000621f:     	js	0x180006231 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x48b1>
180006221:     	subl	$0x1, %ecx
180006224:     	movl	%ecx, (%rsi)
180006226:     	jne	0x180006231 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x48b1>
180006228:     	movq	%rsi, %rcx
18000622b:     	callq	*0x2fa7(%rip)           # 0x1800091d8
180006231:     	movl	%ebx, %eax
180006233:     	addq	$0x48, %rsp
180006237:     	popq	%r15
180006239:     	popq	%r14
18000623b:     	popq	%rdi
18000623c:     	popq	%rsi
18000623d:     	popq	%rbx
18000623e:     	popq	%rbp
18000623f:     	retq
180006240:     	movq	%rbx, 0x8(%rsp)
180006245:     	movq	%rsi, 0x10(%rsp)
18000624a:     	pushq	%rdi
18000624b:     	subq	$0x20, %rsp
18000624f:     	cmpq	$0x0, 0xaa01(%rip)      # 0x180010c58
180006257:     	movq	%rcx, %rsi
18000625a:     	movslq	%edx, %rdi
18000625d:     	jne	0x1800062ad <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x492d>
18000625f:     	leaq	0x3a82(%rip), %rcx      # 0x180009ce8
180006266:     	callq	*0x2fdc(%rip)           # 0x180009248
18000626c:     	movq	%rax, %rbx
18000626f:     	testq	%rax, %rax
180006272:     	je	0x1800062c1 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4941>
180006274:     	leaq	0x3a75(%rip), %rdx      # 0x180009cf0
18000627b:     	movq	%rax, %rcx
18000627e:     	callq	*0x2ef4(%rip)           # 0x180009178
180006284:     	movl	(%rbx), %ecx
180006286:     	movq	%rax, 0xa9cb(%rip)      # 0x180010c58
18000628d:     	testl	%ecx, %ecx
18000628f:     	js	0x1800062a8 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4928>
180006291:     	subl	$0x1, %ecx
180006294:     	movl	%ecx, (%rbx)
180006296:     	jne	0x1800062a8 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4928>
180006298:     	movq	%rbx, %rcx
18000629b:     	callq	*0x2f37(%rip)           # 0x1800091d8
1800062a1:     	movq	0xa9b0(%rip), %rax      # 0x180010c58
1800062a8:     	testq	%rax, %rax
1800062ab:     	je	0x1800062c1 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4941>
1800062ad:     	movq	%rdi, %rdx
1800062b0:     	movq	%rsi, %rcx
1800062b3:     	callq	*0x300f(%rip)           # 0x1800092c8
1800062b9:     	movq	%rax, %rbx
1800062bc:     	testq	%rax, %rax
1800062bf:     	jne	0x1800062d3 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4953>
1800062c1:     	xorl	%eax, %eax
1800062c3:     	movq	0x30(%rsp), %rbx
1800062c8:     	movq	0x38(%rsp), %rsi
1800062cd:     	addq	$0x20, %rsp
1800062d1:     	popq	%rdi
1800062d2:     	retq
1800062d3:     	movq	0xa97e(%rip), %rcx      # 0x180010c58
1800062da:     	xorl	%r8d, %r8d
1800062dd:     	movq	%rbx, %rdx
1800062e0:     	callq	*0x2ec2(%rip)           # 0x1800091a8
1800062e6:     	movl	(%rbx), %ecx
1800062e8:     	movq	%rax, %rdi
1800062eb:     	testl	%ecx, %ecx
1800062ed:     	js	0x1800062ff <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x497f>
1800062ef:     	subl	$0x1, %ecx
1800062f2:     	movl	%ecx, (%rbx)
1800062f4:     	jne	0x1800062ff <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x497f>
1800062f6:     	movq	%rbx, %rcx
1800062f9:     	callq	*0x2ed9(%rip)           # 0x1800091d8
1800062ff:     	movq	0x30(%rsp), %rbx
180006304:     	movq	%rdi, %rax
180006307:     	movq	0x38(%rsp), %rsi
18000630c:     	addq	$0x20, %rsp
180006310:     	popq	%rdi
180006311:     	retq
180006312:     	int3
180006313:     	int3
180006314:     	int3
180006315:     	int3
180006316:     	int3
180006317:     	int3
180006318:     	int3
180006319:     	int3
18000631a:     	int3
18000631b:     	int3
18000631c:     	int3
18000631d:     	int3
18000631e:     	int3
18000631f:     	int3
180006320:     	movq	%rbx, 0x8(%rsp)
180006325:     	movq	%rsi, 0x10(%rsp)
18000632a:     	pushq	%rdi
18000632b:     	subq	$0x20, %rsp
18000632f:     	movq	0xa91a(%rip), %rax      # 0x180010c50
180006336:     	movq	%rdx, %rdi
180006339:     	movq	%rcx, %rsi
18000633c:     	testq	%rax, %rax
18000633f:     	jne	0x1800063a1 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4a21>
180006341:     	leaq	0x39b0(%rip), %rcx      # 0x180009cf8
180006348:     	callq	*0x2efa(%rip)           # 0x180009248
18000634e:     	movq	%rax, %rbx
180006351:     	testq	%rax, %rax
180006354:     	je	0x18000638f <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4a0f>
180006356:     	leaq	0x39b3(%rip), %rdx      # 0x180009d10
18000635d:     	movq	%rax, %rcx
180006360:     	callq	*0x2e12(%rip)           # 0x180009178
180006366:     	movl	(%rbx), %ecx
180006368:     	movq	%rax, 0xa8e1(%rip)      # 0x180010c50
18000636f:     	testl	%ecx, %ecx
180006371:     	js	0x18000638a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4a0a>
180006373:     	subl	$0x1, %ecx
180006376:     	movl	%ecx, (%rbx)
180006378:     	jne	0x18000638a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4a0a>
18000637a:     	movq	%rbx, %rcx
18000637d:     	callq	*0x2e55(%rip)           # 0x1800091d8
180006383:     	movq	0xa8c6(%rip), %rax      # 0x180010c50
18000638a:     	testq	%rax, %rax
18000638d:     	jne	0x1800063a1 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4a21>
18000638f:     	xorl	%eax, %eax
180006391:     	movq	0x30(%rsp), %rbx
180006396:     	movq	0x38(%rsp), %rsi
18000639b:     	addq	$0x20, %rsp
18000639f:     	popq	%rdi
1800063a0:     	retq
1800063a1:     	xorl	%r9d, %r9d
1800063a4:     	movq	%rdi, %r8
1800063a7:     	movq	%rsi, %rdx
1800063aa:     	movq	%rax, %rcx
1800063ad:     	movq	0x30(%rsp), %rbx
1800063b2:     	movq	0x38(%rsp), %rsi
1800063b7:     	addq	$0x20, %rsp
1800063bb:     	popq	%rdi
1800063bc:     	jmpq	*0x2de5(%rip)           # 0x1800091a8
1800063c3:     	int3
1800063c4:     	int3
1800063c5:     	int3
1800063c6:     	int3
1800063c7:     	int3
1800063c8:     	int3
1800063c9:     	int3
1800063ca:     	int3
1800063cb:     	int3
1800063cc:     	int3
1800063cd:     	int3
1800063ce:     	int3
1800063cf:     	int3
1800063d0:     	movq	%rbx, 0x8(%rsp)
1800063d5:     	movq	%rsi, 0x10(%rsp)
1800063da:     	pushq	%rdi
1800063db:     	subq	$0x20, %rsp
1800063df:     	movq	%rcx, %rbx
1800063e2:     	movq	%r8, %rdi
1800063e5:     	movq	0x10(%rcx), %rcx
1800063e9:     	movq	%rdx, %rsi
1800063ec:     	testq	%rcx, %rcx
1800063ef:     	je	0x1800063fa <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4a7a>
1800063f1:     	movq	%r8, %rdx
1800063f4:     	callq	*%rsi
1800063f6:     	testl	%eax, %eax
1800063f8:     	jne	0x18000641d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4a9d>
1800063fa:     	movq	0x18(%rbx), %rcx
1800063fe:     	testq	%rcx, %rcx
180006401:     	je	0x18000641b <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4a9b>
180006403:     	movq	%rdi, %rdx
180006406:     	movq	%rsi, %rax
180006409:     	movq	0x30(%rsp), %rbx
18000640e:     	movq	0x38(%rsp), %rsi
180006413:     	addq	$0x20, %rsp
180006417:     	popq	%rdi
180006418:     	jmpq	*%rax
18000641b:     	xorl	%eax, %eax
18000641d:     	movq	0x30(%rsp), %rbx
180006422:     	movq	0x38(%rsp), %rsi
180006427:     	addq	$0x20, %rsp
18000642b:     	popq	%rdi
18000642c:     	retq
18000642d:     	int3
18000642e:     	int3
18000642f:     	int3
180006430:     	pushq	%rbx
180006432:     	subq	$0x20, %rsp
180006436:     	movq	%rcx, %rbx
180006439:     	movq	0x10(%rcx), %rcx
18000643d:     	testq	%rcx, %rcx
180006440:     	je	0x18000645d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4add>
180006442:     	movq	$0x0, 0x10(%rbx)
18000644a:     	movl	(%rcx), %eax
18000644c:     	testl	%eax, %eax
18000644e:     	js	0x18000645d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4add>
180006450:     	subl	$0x1, %eax
180006453:     	movl	%eax, (%rcx)
180006455:     	jne	0x18000645d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4add>
180006457:     	callq	*0x2d7b(%rip)           # 0x1800091d8
18000645d:     	movq	0x18(%rbx), %rcx
180006461:     	testq	%rcx, %rcx
180006464:     	je	0x180006481 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4b01>
180006466:     	movq	$0x0, 0x18(%rbx)
18000646e:     	movl	(%rcx), %eax
180006470:     	testl	%eax, %eax
180006472:     	js	0x180006481 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4b01>
180006474:     	subl	$0x1, %eax
180006477:     	movl	%eax, (%rcx)
180006479:     	jne	0x180006481 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4b01>
18000647b:     	callq	*0x2d57(%rip)           # 0x1800091d8
180006481:     	xorl	%eax, %eax
180006483:     	addq	$0x20, %rsp
180006487:     	popq	%rbx
180006488:     	retq
180006489:     	int3
18000648a:     	int3
18000648b:     	int3
18000648c:     	int3
18000648d:     	int3
18000648e:     	int3
18000648f:     	int3
180006490:     	pushq	%rbx
180006492:     	subq	$0x20, %rsp
180006496:     	movq	%rcx, %rbx
180006499:     	callq	*0x2d89(%rip)           # 0x180009228
18000649f:     	movq	0x10(%rbx), %rcx
1800064a3:     	testq	%rcx, %rcx
1800064a6:     	je	0x1800064c3 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4b43>
1800064a8:     	movq	$0x0, 0x10(%rbx)
1800064b0:     	movl	(%rcx), %eax
1800064b2:     	testl	%eax, %eax
1800064b4:     	js	0x1800064c3 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4b43>
1800064b6:     	subl	$0x1, %eax
1800064b9:     	movl	%eax, (%rcx)
1800064bb:     	jne	0x1800064c3 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4b43>
1800064bd:     	callq	*0x2d15(%rip)           # 0x1800091d8
1800064c3:     	movq	0x18(%rbx), %rcx
1800064c7:     	testq	%rcx, %rcx
1800064ca:     	je	0x1800064e7 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4b67>
1800064cc:     	movq	$0x0, 0x18(%rbx)
1800064d4:     	movl	(%rcx), %eax
1800064d6:     	testl	%eax, %eax
1800064d8:     	js	0x1800064e7 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4b67>
1800064da:     	subl	$0x1, %eax
1800064dd:     	movl	%eax, (%rcx)
1800064df:     	jne	0x1800064e7 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4b67>
1800064e1:     	callq	*0x2cf1(%rip)           # 0x1800091d8
1800064e7:     	movq	0x8(%rbx), %rax
1800064eb:     	movq	%rbx, %rcx
1800064ee:     	addq	$0x20, %rsp
1800064f2:     	popq	%rbx
1800064f3:     	jmpq	*0x140(%rax)
1800064fa:     	int3
1800064fb:     	int3
1800064fc:     	int3
1800064fd:     	int3
1800064fe:     	int3
1800064ff:     	int3
180006500:     	pushq	%rbx
180006502:     	subq	$0x30, %rsp
180006506:     	movq	%r8, %r10
180006509:     	leaq	0x58(%rsp), %rax
18000650e:     	movq	%rax, 0x28(%rsp)
180006513:     	leaq	0xa476(%rip), %r9       # 0x180010990
18000651a:     	movq	0x2cd7(%rip), %rax      # 0x1800091f8
180006521:     	leaq	0x3818(%rip), %r8       # 0x180009d40
180006528:     	movq	%rdx, %r11
18000652b:     	movq	%rax, 0x20(%rsp)
180006530:     	movq	%rcx, %rbx
180006533:     	movq	%r10, %rdx
180006536:     	movq	%r11, %rcx
180006539:     	callq	*0x2bb9(%rip)           # 0x1800090f8
18000653f:     	testl	%eax, %eax
180006541:     	je	0x18000659c <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4c1c>
180006543:     	xorl	%r8d, %r8d
180006546:     	xorl	%edx, %edx
180006548:     	movq	%rbx, %rcx
18000654b:     	callq	*0x2d07(%rip)           # 0x180009258
180006551:     	movq	%rax, %rbx
180006554:     	testq	%rax, %rax
180006557:     	je	0x18000659c <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4c1c>
180006559:     	movq	0x58(%rsp), %rax
18000655e:     	movl	(%rax), %ecx
180006560:     	cmpl	$0xc0000000, %ecx       # imm = 0xC0000000
180006566:     	jae	0x180006571 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4bf1>
180006568:     	incl	%ecx
18000656a:     	movl	%ecx, (%rax)
18000656c:     	movq	0x58(%rsp), %rax
180006571:     	xorl	%ecx, %ecx
180006573:     	movq	%rax, 0x10(%rbx)
180006577:     	callq	*0x2c0b(%rip)           # 0x180009188
18000657d:     	movq	%rax, 0x18(%rbx)
180006581:     	testq	%rax, %rax
180006584:     	jne	0x1800065a4 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4c24>
180006586:     	movl	(%rbx), %eax
180006588:     	testl	%eax, %eax
18000658a:     	js	0x18000659c <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4c1c>
18000658c:     	subl	$0x1, %eax
18000658f:     	movl	%eax, (%rbx)
180006591:     	jne	0x18000659c <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4c1c>
180006593:     	movq	%rbx, %rcx
180006596:     	callq	*0x2c3c(%rip)           # 0x1800091d8
18000659c:     	xorl	%eax, %eax
18000659e:     	addq	$0x30, %rsp
1800065a2:     	popq	%rbx
1800065a3:     	retq
1800065a4:     	movq	%rbx, %rax
1800065a7:     	addq	$0x30, %rsp
1800065ab:     	popq	%rbx
1800065ac:     	retq
1800065ad:     	int3
1800065ae:     	int3
1800065af:     	int3
1800065b0:     	movq	%rbx, 0x8(%rsp)
1800065b5:     	movq	%rsi, 0x10(%rsp)
1800065ba:     	pushq	%rdi
1800065bb:     	subq	$0x20, %rsp
1800065bf:     	movq	%rcx, %rbx
1800065c2:     	movq	%r8, %rdi
1800065c5:     	movq	0x18(%rcx), %rcx
1800065c9:     	movq	%rdx, %rsi
1800065cc:     	testq	%rcx, %rcx
1800065cf:     	je	0x1800065da <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4c5a>
1800065d1:     	movq	%r8, %rdx
1800065d4:     	callq	*%rsi
1800065d6:     	testl	%eax, %eax
1800065d8:     	jne	0x1800065fd <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4c7d>
1800065da:     	movq	0x40(%rbx), %rcx
1800065de:     	testq	%rcx, %rcx
1800065e1:     	je	0x1800065fb <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4c7b>
1800065e3:     	movq	%rdi, %rdx
1800065e6:     	movq	%rsi, %rax
1800065e9:     	movq	0x30(%rsp), %rbx
1800065ee:     	movq	0x38(%rsp), %rsi
1800065f3:     	addq	$0x20, %rsp
1800065f7:     	popq	%rdi
1800065f8:     	jmpq	*%rax
1800065fb:     	xorl	%eax, %eax
1800065fd:     	movq	0x30(%rsp), %rbx
180006602:     	movq	0x38(%rsp), %rsi
180006607:     	addq	$0x20, %rsp
18000660b:     	popq	%rdi
18000660c:     	retq
18000660d:     	int3
18000660e:     	int3
18000660f:     	int3
180006610:     	pushq	%rbx
180006612:     	subq	$0x20, %rsp
180006616:     	movq	%rcx, %rbx
180006619:     	callq	*0x2c09(%rip)           # 0x180009228
18000661f:     	cmpq	$0x0, 0x48(%rbx)
180006624:     	je	0x18000662f <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4caf>
180006626:     	movq	%rbx, %rcx
180006629:     	callq	*0x2b69(%rip)           # 0x180009198
18000662f:     	movq	0x20(%rbx), %rcx
180006633:     	callq	*0x2b8f(%rip)           # 0x1800091c8
180006639:     	movq	0x38(%rbx), %rcx
18000663d:     	callq	*0x2b85(%rip)           # 0x1800091c8
180006643:     	movq	0x18(%rbx), %rcx
180006647:     	testq	%rcx, %rcx
18000664a:     	je	0x18000665f <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4cdf>
18000664c:     	movl	(%rcx), %eax
18000664e:     	testl	%eax, %eax
180006650:     	js	0x18000665f <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4cdf>
180006652:     	subl	$0x1, %eax
180006655:     	movl	%eax, (%rcx)
180006657:     	jne	0x18000665f <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4cdf>
180006659:     	callq	*0x2b79(%rip)           # 0x1800091d8
18000665f:     	movq	0x40(%rbx), %rcx
180006663:     	testq	%rcx, %rcx
180006666:     	je	0x18000667b <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4cfb>
180006668:     	movl	(%rcx), %eax
18000666a:     	testl	%eax, %eax
18000666c:     	js	0x18000667b <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4cfb>
18000666e:     	subl	$0x1, %eax
180006671:     	movl	%eax, (%rcx)
180006673:     	jne	0x18000667b <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4cfb>
180006675:     	callq	*0x2b5d(%rip)           # 0x1800091d8
18000667b:     	movq	0x8(%rbx), %rax
18000667f:     	movq	%rbx, %rcx
180006682:     	addq	$0x20, %rsp
180006686:     	popq	%rbx
180006687:     	jmpq	*0x140(%rax)
18000668e:     	int3
18000668f:     	int3
180006690:     	pushq	%rbx
180006692:     	subq	$0x20, %rsp
180006696:     	callq	*0x2af4(%rip)           # 0x180009190
18000669c:     	movq	%rax, %rbx
18000669f:     	testq	%rax, %rax
1800066a2:     	jne	0x1800066aa <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4d2a>
1800066a4:     	addq	$0x20, %rsp
1800066a8:     	popq	%rbx
1800066a9:     	retq
1800066aa:     	movq	%rbx, %rcx
1800066ad:     	movq	%rdi, 0x30(%rsp)
1800066b2:     	callq	0x180008a0d <numba_list_iter_next+0xecd>
1800066b7:     	leaq	0x1(%rax), %rcx
1800066bb:     	callq	*0x2b9f(%rip)           # 0x180009260
1800066c1:     	movq	%rax, %rdi
1800066c4:     	testq	%rax, %rax
1800066c7:     	jne	0x1800066dc <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4d5c>
1800066c9:     	callq	*0x2a81(%rip)           # 0x180009150
1800066cf:     	movq	0x30(%rsp), %rdi
1800066d4:     	xorl	%eax, %eax
1800066d6:     	addq	$0x20, %rsp
1800066da:     	popq	%rbx
1800066db:     	retq
1800066dc:     	movq	%rbx, %rdx
1800066df:     	movq	%rdi, %rcx
1800066e2:     	callq	0x180008a07 <numba_list_iter_next+0xec7>
1800066e7:     	movq	%rdi, %rax
1800066ea:     	movq	0x30(%rsp), %rdi
1800066ef:     	addq	$0x20, %rsp
1800066f3:     	popq	%rbx
1800066f4:     	retq
1800066f5:     	int3
1800066f6:     	int3
1800066f7:     	int3
1800066f8:     	int3
1800066f9:     	int3
1800066fa:     	int3
1800066fb:     	int3
1800066fc:     	int3
1800066fd:     	int3
1800066fe:     	int3
1800066ff:     	int3
180006700:     	movq	0x18(%rcx), %rcx
180006704:     	movq	%rdx, %rax
180006707:     	testq	%rcx, %rcx
18000670a:     	je	0x180006712 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4d92>
18000670c:     	movq	%r8, %rdx
18000670f:     	jmpq	*%rax
180006712:     	xorl	%eax, %eax
180006714:     	retq
180006715:     	int3
180006716:     	int3
180006717:     	int3
180006718:     	int3
180006719:     	int3
18000671a:     	int3
18000671b:     	int3
18000671c:     	int3
18000671d:     	int3
18000671e:     	int3
18000671f:     	int3
180006720:     	movq	%rbx, 0x8(%rsp)
180006725:     	pushq	%rdi
180006726:     	subq	$0x20, %rsp
18000672a:     	movq	0x28(%rcx), %rax
18000672e:     	xorl	%edi, %edi
180006730:     	movq	%rcx, %rbx
180006733:     	testq	%rax, %rax
180006736:     	je	0x180006742 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4dc2>
180006738:     	addq	$0x38, %rcx
18000673c:     	callq	*%rax
18000673e:     	movq	%rdi, 0x28(%rbx)
180006742:     	movq	0x18(%rbx), %rcx
180006746:     	testq	%rcx, %rcx
180006749:     	je	0x180006762 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4de2>
18000674b:     	movq	%rdi, 0x18(%rbx)
18000674f:     	movl	(%rcx), %eax
180006751:     	testl	%eax, %eax
180006753:     	js	0x180006762 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4de2>
180006755:     	subl	$0x1, %eax
180006758:     	movl	%eax, (%rcx)
18000675a:     	jne	0x180006762 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4de2>
18000675c:     	callq	*0x2a76(%rip)           # 0x1800091d8
180006762:     	movq	%rdi, 0x20(%rbx)
180006766:     	xorl	%eax, %eax
180006768:     	movq	0x30(%rsp), %rbx
18000676d:     	addq	$0x20, %rsp
180006771:     	popq	%rdi
180006772:     	retq
180006773:     	int3
180006774:     	int3
180006775:     	int3
180006776:     	int3
180006777:     	int3
180006778:     	int3
180006779:     	int3
18000677a:     	int3
18000677b:     	int3
18000677c:     	int3
18000677d:     	int3
18000677e:     	int3
18000677f:     	int3
180006780:     	pushq	%rbx
180006782:     	subq	$0x20, %rsp
180006786:     	movq	%rcx, %rbx
180006789:     	callq	*0x2a99(%rip)           # 0x180009228
18000678f:     	cmpq	$0x0, 0x30(%rbx)
180006794:     	je	0x18000679f <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4e1f>
180006796:     	movq	%rbx, %rcx
180006799:     	callq	*0x29f9(%rip)           # 0x180009198
18000679f:     	callq	*0x29a3(%rip)           # 0x180009148
1800067a5:     	testl	%eax, %eax
1800067a7:     	jne	0x1800067b8 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4e38>
1800067a9:     	movq	0x28(%rbx), %rax
1800067ad:     	testq	%rax, %rax
1800067b0:     	je	0x1800067b8 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4e38>
1800067b2:     	leaq	0x38(%rbx), %rcx
1800067b6:     	callq	*%rax
1800067b8:     	movq	0x18(%rbx), %rcx
1800067bc:     	testq	%rcx, %rcx
1800067bf:     	je	0x1800067d4 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4e54>
1800067c1:     	movl	(%rcx), %eax
1800067c3:     	testl	%eax, %eax
1800067c5:     	js	0x1800067d4 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4e54>
1800067c7:     	subl	$0x1, %eax
1800067ca:     	movl	%eax, (%rcx)
1800067cc:     	jne	0x1800067d4 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4e54>
1800067ce:     	callq	*0x2a04(%rip)           # 0x1800091d8
1800067d4:     	movq	0x8(%rbx), %rax
1800067d8:     	movq	%rbx, %rcx
1800067db:     	addq	$0x20, %rsp
1800067df:     	popq	%rbx
1800067e0:     	jmpq	*0x140(%rax)
1800067e7:     	int3
1800067e8:     	int3
1800067e9:     	int3
1800067ea:     	int3
1800067eb:     	int3
1800067ec:     	int3
1800067ed:     	int3
1800067ee:     	int3
1800067ef:     	int3
1800067f0:     	pushq	%rdi
1800067f2:     	subq	$0x20, %rsp
1800067f6:     	cmpq	$0x0, 0x20(%rcx)
1800067fb:     	movq	%rcx, %rdi
1800067fe:     	jne	0x18000681f <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4e9f>
180006800:     	movq	0x2ab9(%rip), %rcx      # 0x1800092c0
180006807:     	leaq	0x3582(%rip), %rdx      # 0x180009d90
18000680e:     	movq	(%rcx), %rcx
180006811:     	callq	*0x2aa1(%rip)           # 0x1800092b8
180006817:     	xorl	%eax, %eax
180006819:     	addq	$0x20, %rsp
18000681d:     	popq	%rdi
18000681e:     	retq
18000681f:     	movq	%rdi, %rdx
180006822:     	movq	%rbx, 0x30(%rsp)
180006827:     	movl	$0x1, %ecx
18000682c:     	callq	*0x28d6(%rip)           # 0x180009108
180006832:     	movq	%rax, %rbx
180006835:     	testq	%rax, %rax
180006838:     	jne	0x180006845 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4ec5>
18000683a:     	movq	0x30(%rsp), %rbx
18000683f:     	addq	$0x20, %rsp
180006843:     	popq	%rdi
180006844:     	retq
180006845:     	xorl	%r8d, %r8d
180006848:     	movq	%rbx, %rdx
18000684b:     	movq	%rdi, %rcx
18000684e:     	callq	*0x20(%rdi)
180006851:     	movl	(%rbx), %ecx
180006853:     	movq	%rax, %rdi
180006856:     	testl	%ecx, %ecx
180006858:     	js	0x18000686a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4eea>
18000685a:     	subl	$0x1, %ecx
18000685d:     	movl	%ecx, (%rbx)
18000685f:     	jne	0x18000686a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4eea>
180006861:     	movq	%rbx, %rcx
180006864:     	callq	*0x296e(%rip)           # 0x1800091d8
18000686a:     	movq	0x30(%rsp), %rbx
18000686f:     	movq	%rdi, %rax
180006872:     	addq	$0x20, %rsp
180006876:     	popq	%rdi
180006877:     	retq
180006878:     	int3
180006879:     	int3
18000687a:     	int3
18000687b:     	int3
18000687c:     	int3
18000687d:     	int3
18000687e:     	int3
18000687f:     	int3
180006880:     	movq	%rbx, 0x8(%rsp)
180006885:     	pushq	%rdi
180006886:     	subq	$0x20, %rsp
18000688a:     	movq	%r8, %rbx
18000688d:     	callq	*0x285d(%rip)           # 0x1800090f0
180006893:     	movl	(%rbx), %ecx
180006895:     	movl	%eax, %edi
180006897:     	testl	%ecx, %ecx
180006899:     	js	0x1800068ab <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4f2b>
18000689b:     	subl	$0x1, %ecx
18000689e:     	movl	%ecx, (%rbx)
1800068a0:     	jne	0x1800068ab <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4f2b>
1800068a2:     	movq	%rbx, %rcx
1800068a5:     	callq	*0x292d(%rip)           # 0x1800091d8
1800068ab:     	movl	%edi, %ecx
1800068ad:     	movq	0x30(%rsp), %rbx
1800068b2:     	addq	$0x20, %rsp
1800068b6:     	popq	%rdi
1800068b7:     	jmpq	*0x2962(%rip)           # 0x180009220
1800068be:     	int3
1800068bf:     	int3
1800068c0:     	movq	%rbx, 0x8(%rsp)
1800068c5:     	pushq	%rdi
1800068c6:     	subq	$0x20, %rsp
1800068ca:     	movl	(%rdx), %eax
1800068cc:     	movq	%rdx, %rbx
1800068cf:     	movq	%rcx, %rdi
1800068d2:     	cmpl	$0xc0000000, %eax       # imm = 0xC0000000
1800068d7:     	jae	0x1800068dd <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4f5d>
1800068d9:     	incl	%eax
1800068db:     	movl	%eax, (%rdx)
1800068dd:     	movl	$0x30, %ecx
1800068e2:     	callq	*0xa340(%rip)           # 0x180010c28
1800068e8:     	cmpb	$0x0, 0xa311(%rip)      # 0x180010c00
1800068ef:     	je	0x1800068f9 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4f79>
1800068f1:     	lock
1800068f2:     	incq	0xa30f(%rip)            # 0x180010c08
1800068f9:     	testq	%rax, %rax
1800068fc:     	je	0x180006933 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4fb3>
1800068fe:     	movl	$0x1, %ecx
180006903:     	leaq	-0x8a(%rip), %rdx       # 0x180006880 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4f00>
18000690a:     	xchgq	%rcx, (%rax)
18000690d:     	xorl	%ecx, %ecx
18000690f:     	movq	%rdx, 0x8(%rax)
180006913:     	movq	%rcx, 0x20(%rax)
180006917:     	movq	%rcx, 0x28(%rax)
18000691b:     	movq	%rbx, 0x10(%rax)
18000691f:     	movq	%rdi, 0x18(%rax)
180006923:     	cmpb	%cl, 0xa2d7(%rip)       # 0x180010c00
180006929:     	je	0x180006933 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4fb3>
18000692b:     	lock
18000692c:     	incq	0xa2e5(%rip)            # 0x180010c18
180006933:     	movq	0x30(%rsp), %rbx
180006938:     	addq	$0x20, %rsp
18000693c:     	popq	%rdi
18000693d:     	retq
18000693e:     	int3
18000693f:     	int3
180006940:     	movq	%rbx, 0x8(%rsp)
180006945:     	pushq	%rdi
180006946:     	subq	$0x30, %rsp
18000694a:     	movq	%rcx, %rdi
18000694d:     	leaq	0xa02c(%rip), %r9       # 0x180010980
180006954:     	movq	%r8, %rax
180006957:     	leaq	0x58(%rsp), %rcx
18000695c:     	movq	%rdx, %r10
18000695f:     	movq	%rcx, 0x20(%rsp)
180006964:     	movq	%r10, %rcx
180006967:     	leaq	0x346a(%rip), %r8       # 0x180009dd8
18000696e:     	movq	%rax, %rdx
180006971:     	callq	*0x2781(%rip)           # 0x1800090f8
180006977:     	testl	%eax, %eax
180006979:     	je	0x1800069a3 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5023>
18000697b:     	movq	0x58(%rsp), %rcx
180006980:     	callq	*0x27ba(%rip)           # 0x180009140
180006986:     	movq	%rax, %rbx
180006989:     	callq	*0x2959(%rip)           # 0x1800092e8
18000698f:     	testq	%rax, %rax
180006992:     	jne	0x1800069a3 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5023>
180006994:     	movq	%rbx, 0x10(%rdi)
180006998:     	movq	0x40(%rsp), %rbx
18000699d:     	addq	$0x30, %rsp
1800069a1:     	popq	%rdi
1800069a2:     	retq
1800069a3:     	movq	0x40(%rsp), %rbx
1800069a8:     	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
1800069ad:     	addq	$0x30, %rsp
1800069b1:     	popq	%rdi
1800069b2:     	retq
1800069b3:     	int3
1800069b4:     	int3
1800069b5:     	int3
1800069b6:     	int3
1800069b7:     	int3
1800069b8:     	int3
1800069b9:     	int3
1800069ba:     	int3
1800069bb:     	int3
1800069bc:     	int3
1800069bd:     	int3
1800069be:     	int3
1800069bf:     	int3
1800069c0:     	subq	$0x38, %rsp
1800069c4:     	movl	%r8d, %eax
1800069c7:     	movq	%rdx, %r10
1800069ca:     	movq	0x10(%rcx), %r8
1800069ce:     	movq	%rcx, %rdx
1800069d1:     	movl	%eax, 0x28(%rsp)
1800069d5:     	movq	%r10, %rcx
1800069d8:     	movl	$0x0, 0x20(%rsp)
1800069e0:     	movq	0x20(%r8), %r9
1800069e4:     	movq	0x18(%r8), %r8
1800069e8:     	callq	*0x282a(%rip)           # 0x180009218
1800069ee:     	addq	$0x38, %rsp
1800069f2:     	retq
1800069f3:     	int3
1800069f4:     	int3
1800069f5:     	int3
1800069f6:     	int3
1800069f7:     	int3
1800069f8:     	int3
1800069f9:     	int3
1800069fa:     	int3
1800069fb:     	int3
1800069fc:     	int3
1800069fd:     	int3
1800069fe:     	int3
1800069ff:     	int3
180006a00:     	movq	0x10(%rcx), %rax
180006a04:     	lock
180006a05:     	incq	(%rax)
180006a08:     	movq	0x28d1(%rip), %rax      # 0x1800092e0
180006a0f:     	retq
180006a10:     	subq	$0x28, %rsp
180006a14:     	movq	0x10(%rcx), %rcx
180006a18:     	callq	0x180007d10 <numba_list_iter_next+0x1d0>
180006a1d:     	movq	0x28bc(%rip), %rax      # 0x1800092e0
180006a24:     	addq	$0x28, %rsp
180006a28:     	retq
180006a29:     	int3
180006a2a:     	int3
180006a2b:     	int3
180006a2c:     	int3
180006a2d:     	int3
180006a2e:     	int3
180006a2f:     	int3
180006a30:     	movq	0x10(%rcx), %rcx
180006a34:     	movq	0x18(%rcx), %rcx
180006a38:     	jmpq	*0x2729(%rip)           # 0x180009168
180006a3f:     	int3
180006a40:     	subq	$0x28, %rsp
180006a44:     	movq	0x10(%rcx), %rax
180006a48:     	testq	%rax, %rax
180006a4b:     	je	0x180006a69 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x50e9>
180006a4d:     	cmpq	$0x0, 0x18(%rax)
180006a52:     	je	0x180006a69 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x50e9>
180006a54:     	movq	(%rax), %rcx
180006a57:     	nop
180006a58:     	cmpq	$-0x1, %rcx
180006a5c:     	je	0x180006a69 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x50e9>
180006a5e:     	addq	$0x28, %rsp
180006a62:     	jmpq	*0x26bf(%rip)           # 0x180009128
180006a69:     	movq	0x2798(%rip), %rcx      # 0x180009208
180006a70:     	leaq	0x3369(%rip), %rdx      # 0x180009de0
180006a77:     	movq	(%rcx), %rcx
180006a7a:     	callq	*0x2838(%rip)           # 0x1800092b8
180006a80:     	xorl	%eax, %eax
180006a82:     	addq	$0x28, %rsp
180006a86:     	retq
180006a87:     	int3
180006a88:     	int3
180006a89:     	int3
180006a8a:     	int3
180006a8b:     	int3
180006a8c:     	int3
180006a8d:     	int3
180006a8e:     	int3
180006a8f:     	int3
180006a90:     	movq	0x10(%rcx), %rcx
180006a94:     	movq	0x28(%rcx), %rcx
180006a98:     	jmpq	*0x26c9(%rip)           # 0x180009168
180006a9f:     	int3
180006aa0:     	movq	0x10(%rcx), %rax
180006aa4:     	movq	0x10(%rax), %rax
180006aa8:     	testq	%rax, %rax
180006aab:     	je	0x180006abc <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x513c>
180006aad:     	movl	(%rax), %ecx
180006aaf:     	cmpl	$0xc0000000, %ecx       # imm = 0xC0000000
180006ab5:     	jae	0x180006ada <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x515a>
180006ab7:     	incl	%ecx
180006ab9:     	movl	%ecx, (%rax)
180006abb:     	retq
180006abc:     	movq	0x281d(%rip), %rcx      # 0x1800092e0
180006ac3:     	movl	(%rcx), %eax
180006ac5:     	cmpl	$0xc0000000, %eax       # imm = 0xC0000000
180006aca:     	jae	0x180006ad7 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5157>
180006acc:     	incl	%eax
180006ace:     	movl	%eax, (%rcx)
180006ad0:     	movq	0x2809(%rip), %rcx      # 0x1800092e0
180006ad7:     	movq	%rcx, %rax
180006ada:     	retq
180006adb:     	int3
180006adc:     	int3
180006add:     	int3
180006ade:     	int3
180006adf:     	int3
180006ae0:     	pushq	%rbx
180006ae2:     	subq	$0x20, %rsp
180006ae6:     	movq	%rcx, %rbx
180006ae9:     	movq	0x10(%rcx), %rcx
180006aed:     	callq	0x180007d10 <numba_list_iter_next+0x1d0>
180006af2:     	movq	0x8(%rbx), %rax
180006af6:     	movq	%rbx, %rcx
180006af9:     	addq	$0x20, %rsp
180006afd:     	popq	%rbx
180006afe:     	jmpq	*0x140(%rax)
180006b05:     	int3
180006b06:     	int3
180006b07:     	int3
180006b08:     	int3
180006b09:     	int3
180006b0a:     	int3
180006b0b:     	int3
180006b0c:     	int3
180006b0d:     	int3
180006b0e:     	int3
180006b0f:     	int3
180006b10:     	movq	%rdi, 0x18(%rsp)
180006b15:     	pushq	%r14
180006b17:     	subq	$0x20, %rsp
180006b1b:     	movq	0xa11e(%rip), %rax      # 0x180010c40
180006b22:     	movq	%rdx, %r14
180006b25:     	movq	%rcx, %rdi
180006b28:     	movq	0x8(%rcx), %rcx
180006b2c:     	movq	0x10(%rax), %rdx
180006b30:     	cmpq	%rdx, %rcx
180006b33:     	je	0x180006b50 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x51d0>
180006b35:     	callq	*0x26ad(%rip)           # 0x1800091e8
180006b3b:     	testl	%eax, %eax
180006b3d:     	jne	0x180006b50 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x51d0>
180006b3f:     	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
180006b44:     	movq	0x40(%rsp), %rdi
180006b49:     	addq	$0x20, %rsp
180006b4d:     	popq	%r14
180006b4f:     	retq
180006b50:     	movq	%rbx, 0x30(%rsp)
180006b55:     	movq	%rdi, %rdx
180006b58:     	movq	0x10(%rdi), %rbx
180006b5c:     	movq	%rbx, %rcx
180006b5f:     	movq	%rsi, 0x38(%rsp)
180006b64:     	movl	0x18(%rdi), %esi
180006b67:     	callq	0x1800068c0 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4f40>
180006b6c:     	movq	%rax, (%r14)
180006b6f:     	movq	0xa0ca(%rip), %rax      # 0x180010c40
180006b76:     	movq	%rbx, 0x20(%r14)
180006b7a:     	movl	0x18(%rdi), %edx
180006b7d:     	movq	0x20(%rdi), %rcx
180006b81:     	callq	*0x4f0(%rax)
180006b87:     	cmpl	$0x12, 0xa0be(%rip)     # 0x180010c4c
180006b8e:     	movq	0x30(%rsp), %rbx
180006b93:     	movq	%rax, 0x10(%r14)
180006b97:     	movq	0x38(%rdi), %rax
180006b9b:     	jl	0x180006ba3 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5223>
180006b9d:     	movq	0x28(%rax), %rax
180006ba1:     	jmp	0x180006ba7 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5227>
180006ba3:     	movslq	0x20(%rax), %rax
180006ba7:     	xorl	%r8d, %r8d
180006baa:     	movq	%rax, 0x18(%r14)
180006bae:     	movq	%rdi, 0x8(%r14)
180006bb2:     	leaq	0x28(%r14), %rax
180006bb6:     	testl	%esi, %esi
180006bb8:     	jle	0x180006bfb <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x527b>
180006bba:     	nopw	(%rax,%rax)
180006bc0:     	movq	0x20(%rdi), %rcx
180006bc4:     	movq	(%rcx,%r8,8), %rdx
180006bc8:     	incl	%r8d
180006bcb:     	movq	%rdx, (%rax)
180006bce:     	addq	$0x8, %rax
180006bd2:     	cmpl	%esi, %r8d
180006bd5:     	jl	0x180006bc0 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5240>
180006bd7:     	xorl	%r8d, %r8d
180006bda:     	nopw	(%rax,%rax)
180006be0:     	movq	0x28(%rdi), %rcx
180006be4:     	leaq	0x8(%rax), %rax
180006be8:     	movslq	%r8d, %rdx
180006beb:     	incl	%r8d
180006bee:     	movq	(%rcx,%rdx,8), %rdx
180006bf2:     	movq	%rdx, -0x8(%rax)
180006bf6:     	cmpl	%esi, %r8d
180006bf9:     	jl	0x180006be0 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5260>
180006bfb:     	movq	0x38(%rsp), %rsi
180006c00:     	xorl	%eax, %eax
180006c02:     	movq	0x40(%rsp), %rdi
180006c07:     	addq	$0x20, %rsp
180006c0b:     	popq	%r14
180006c0d:     	retq
180006c0e:     	int3
180006c0f:     	int3
180006c10:     	pushq	%rbx
180006c12:     	pushq	%rbp
180006c13:     	pushq	%rsi
180006c14:     	pushq	%rdi
180006c15:     	subq	$0x28, %rsp
180006c19:     	cmpq	$0x0, 0xa037(%rip)      # 0x180010c58
180006c21:     	movq	%rcx, %rbp
180006c24:     	movslq	0x8(%rdx), %rdi
180006c28:     	movq	(%rdx), %rsi
180006c2b:     	jne	0x180006c83 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5303>
180006c2d:     	leaq	0x30b4(%rip), %rcx      # 0x180009ce8
180006c34:     	callq	*0x260e(%rip)           # 0x180009248
180006c3a:     	movq	%rax, %rbx
180006c3d:     	testq	%rax, %rax
180006c40:     	je	0x180006d0a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x538a>
180006c46:     	leaq	0x30a3(%rip), %rdx      # 0x180009cf0
180006c4d:     	movq	%rax, %rcx
180006c50:     	callq	*0x2522(%rip)           # 0x180009178
180006c56:     	movl	(%rbx), %edx
180006c58:     	movq	%rax, 0x9ff9(%rip)      # 0x180010c58
180006c5f:     	testl	%edx, %edx
180006c61:     	js	0x180006c7a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x52fa>
180006c63:     	subl	$0x1, %edx
180006c66:     	movl	%edx, (%rbx)
180006c68:     	jne	0x180006c7a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x52fa>
180006c6a:     	movq	%rbx, %rcx
180006c6d:     	callq	*0x2565(%rip)           # 0x1800091d8
180006c73:     	movq	0x9fde(%rip), %rax      # 0x180010c58
180006c7a:     	testq	%rax, %rax
180006c7d:     	je	0x180006d0a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x538a>
180006c83:     	movq	%rdi, %rdx
180006c86:     	movq	%rsi, %rcx
180006c89:     	callq	*0x2639(%rip)           # 0x1800092c8
180006c8f:     	movq	%rax, %rdi
180006c92:     	testq	%rax, %rax
180006c95:     	je	0x180006d0a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x538a>
180006c97:     	movq	0x9fba(%rip), %rcx      # 0x180010c58
180006c9e:     	xorl	%r8d, %r8d
180006ca1:     	movq	%rax, %rdx
180006ca4:     	callq	*0x24fe(%rip)           # 0x1800091a8
180006caa:     	movl	(%rdi), %ecx
180006cac:     	movq	%rax, %rbx
180006caf:     	testl	%ecx, %ecx
180006cb1:     	js	0x180006cc3 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5343>
180006cb3:     	subl	$0x1, %ecx
180006cb6:     	movl	%ecx, (%rdi)
180006cb8:     	jne	0x180006cc3 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5343>
180006cba:     	movq	%rdi, %rcx
180006cbd:     	callq	*0x2515(%rip)           # 0x1800091d8
180006cc3:     	testq	%rbx, %rbx
180006cc6:     	je	0x180006d0a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x538a>
180006cc8:     	movq	0x8(%rbx), %r8
180006ccc:     	testl	$0x2000000, 0xa8(%r8)   # imm = 0x2000000
180006cd7:     	jne	0x180006d15 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5395>
180006cd9:     	movq	0x25d0(%rip), %rcx      # 0x1800092b0
180006ce0:     	leaq	0x3201(%rip), %rdx      # 0x180009ee8
180006ce7:     	movq	0x18(%r8), %r8
180006ceb:     	movq	(%rcx), %rcx
180006cee:     	callq	*0x250c(%rip)           # 0x180009200
180006cf4:     	movl	(%rbx), %eax
180006cf6:     	testl	%eax, %eax
180006cf8:     	js	0x180006d0a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x538a>
180006cfa:     	subl	$0x1, %eax
180006cfd:     	movl	%eax, (%rbx)
180006cff:     	jne	0x180006d0a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x538a>
180006d01:     	movq	%rbx, %rcx
180006d04:     	callq	*0x24ce(%rip)           # 0x1800091d8
180006d0a:     	xorl	%eax, %eax
180006d0c:     	addq	$0x28, %rsp
180006d10:     	popq	%rdi
180006d11:     	popq	%rsi
180006d12:     	popq	%rbp
180006d13:     	popq	%rbx
180006d14:     	retq
180006d15:     	xorl	%r8d, %r8d
180006d18:     	leaq	0x95e1(%rip), %rcx      # 0x180010300
180006d1f:     	xorl	%edx, %edx
180006d21:     	callq	*0x2531(%rip)           # 0x180009258
180006d27:     	movq	%rax, %rdi
180006d2a:     	testq	%rax, %rax
180006d2d:     	je	0x180006cf4 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5374>
180006d2f:     	movq	%rbp, %rcx
180006d32:     	movq	%rbx, 0x18(%rax)
180006d36:     	callq	*0x2494(%rip)           # 0x1800091d0
180006d3c:     	movq	%rax, 0x10(%rdi)
180006d40:     	movq	%rax, %rcx
180006d43:     	testq	%rax, %rax
180006d46:     	jne	0x180006d5a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x53da>
180006d48:     	movl	(%rdi), %eax
180006d4a:     	testl	%eax, %eax
180006d4c:     	js	0x180006d0a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x538a>
180006d4e:     	subl	$0x1, %eax
180006d51:     	movl	%eax, (%rdi)
180006d53:     	jne	0x180006d0a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x538a>
180006d55:     	movq	%rdi, %rcx
180006d58:     	jmp	0x180006d04 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5384>
180006d5a:     	movl	(%rax), %eax
180006d5c:     	cmpl	$0xc0000000, %eax       # imm = 0xC0000000
180006d61:     	jae	0x180006d67 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x53e7>
180006d63:     	incl	%eax
180006d65:     	movl	%eax, (%rcx)
180006d67:     	movq	%rdi, %rax
180006d6a:     	addq	$0x28, %rsp
180006d6e:     	popq	%rdi
180006d6f:     	popq	%rsi
180006d70:     	popq	%rbp
180006d71:     	popq	%rbx
180006d72:     	retq
180006d73:     	int3
180006d74:     	int3
180006d75:     	int3
180006d76:     	int3
180006d77:     	int3
180006d78:     	int3
180006d79:     	int3
180006d7a:     	int3
180006d7b:     	int3
180006d7c:     	int3
180006d7d:     	int3
180006d7e:     	int3
180006d7f:     	int3
180006d80:     	movq	%r9, 0x20(%rsp)
180006d85:     	movq	%r8, 0x18(%rsp)
180006d8a:     	movq	%rdx, 0x10(%rsp)
180006d8f:     	movq	%rcx, 0x8(%rsp)
180006d94:     	pushq	%rbx
180006d95:     	pushq	%rbp
180006d96:     	pushq	%rsi
180006d97:     	pushq	%rdi
180006d98:     	pushq	%r12
180006d9a:     	pushq	%r13
180006d9c:     	pushq	%r14
180006d9e:     	pushq	%r15
180006da0:     	subq	$0x68, %rsp
180006da4:     	movq	%rcx, %r14
180006da7:     	movq	%r9, %r15
180006daa:     	leaq	0x2bef(%rip), %rcx      # 0x1800099a0
180006db1:     	movq	%r8, %r13
180006db4:     	movq	%rdx, %rsi
180006db7:     	callq	*0x248b(%rip)           # 0x180009248
180006dbd:     	movq	%rax, %rdi
180006dc0:     	testq	%rax, %rax
180006dc3:     	jne	0x180006dfc <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x547c>
180006dc5:     	movq	0x236c(%rip), %rcx      # 0x180009138
180006dcc:     	movq	(%rcx), %rcx
180006dcf:     	callq	*0x23eb(%rip)           # 0x1800091c0
180006dd5:     	testl	%eax, %eax
180006dd7:     	je	0x180006ef7 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5577>
180006ddd:     	callq	*0x24ed(%rip)           # 0x1800092d0
180006de3:     	leaq	0x2bd6(%rip), %rcx      # 0x1800099c0
180006dea:     	callq	*0x2458(%rip)           # 0x180009248
180006df0:     	movq	%rax, %rdi
180006df3:     	testq	%rax, %rax
180006df6:     	je	0x180006ef7 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5577>
180006dfc:     	leaq	0x2bdd(%rip), %rdx      # 0x1800099e0
180006e03:     	movq	%rdi, %rcx
180006e06:     	callq	*0x236c(%rip)           # 0x180009178
180006e0c:     	movl	(%rdi), %ecx
180006e0e:     	movq	%rax, %rbx
180006e11:     	testl	%ecx, %ecx
180006e13:     	js	0x180006e25 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x54a5>
180006e15:     	subl	$0x1, %ecx
180006e18:     	movl	%ecx, (%rdi)
180006e1a:     	jne	0x180006e25 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x54a5>
180006e1c:     	movq	%rdi, %rcx
180006e1f:     	callq	*0x23b3(%rip)           # 0x1800091d8
180006e25:     	testq	%rbx, %rbx
180006e28:     	je	0x180006ef7 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5577>
180006e2e:     	movq	0x22cb(%rip), %rax      # 0x180009100
180006e35:     	cmpq	%rax, 0x8(%rbx)
180006e39:     	je	0x180006e75 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x54f5>
180006e3b:     	movq	0x247e(%rip), %rcx      # 0x1800092c0
180006e42:     	leaq	0x2ba7(%rip), %rdx      # 0x1800099f0
180006e49:     	movq	(%rcx), %rcx
180006e4c:     	callq	*0x2466(%rip)           # 0x1800092b8
180006e52:     	movl	(%rbx), %eax
180006e54:     	testl	%eax, %eax
180006e56:     	js	0x180006ef7 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5577>
180006e5c:     	subl	$0x1, %eax
180006e5f:     	movl	%eax, (%rbx)
180006e61:     	jne	0x180006ef7 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5577>
180006e67:     	movq	%rbx, %rcx
180006e6a:     	callq	*0x2368(%rip)           # 0x1800091d8
180006e70:     	jmp	0x180006ef7 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5577>
180006e75:     	xorl	%edx, %edx
180006e77:     	movq	%rbx, %rcx
180006e7a:     	callq	*0x2338(%rip)           # 0x1800091b8
180006e80:     	movl	(%rbx), %ecx
180006e82:     	movq	%rax, 0x9db7(%rip)      # 0x180010c40
180006e89:     	testl	%ecx, %ecx
180006e8b:     	js	0x180006ea4 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5524>
180006e8d:     	subl	$0x1, %ecx
180006e90:     	movl	%ecx, (%rbx)
180006e92:     	jne	0x180006ea4 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5524>
180006e94:     	movq	%rbx, %rcx
180006e97:     	callq	*0x233b(%rip)           # 0x1800091d8
180006e9d:     	movq	0x9d9c(%rip), %rax      # 0x180010c40
180006ea4:     	testq	%rax, %rax
180006ea7:     	jne	0x180006ec2 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5542>
180006ea9:     	leaq	0x2b68(%rip), %rdx      # 0x180009a18
180006eb0:     	movq	0x2409(%rip), %rcx      # 0x1800092c0
180006eb7:     	movq	(%rcx), %rcx
180006eba:     	callq	*0x23f8(%rip)           # 0x1800092b8
180006ec0:     	jmp	0x180006ef7 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5577>
180006ec2:     	callq	*(%rax)
180006ec4:     	cmpl	$0x2000000, %eax        # imm = 0x2000000
180006ec9:     	jbe	0x180006f2a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x55aa>
180006ecb:     	movq	0x23ee(%rip), %rax      # 0x1800092c0
180006ed2:     	movq	(%rax), %rbx
180006ed5:     	movq	0x9d64(%rip), %rax      # 0x180010c40
180006edc:     	callq	*(%rax)
180006ede:     	movl	$0x2000000, %r8d        # imm = 0x2000000
180006ee4:     	leaq	0x2b55(%rip), %rdx      # 0x180009a40
180006eeb:     	movl	%eax, %r9d
180006eee:     	movq	%rbx, %rcx
180006ef1:     	callq	*0x2309(%rip)           # 0x180009200
180006ef7:     	callq	*0x221b(%rip)           # 0x180009118
180006efd:     	movq	0x2404(%rip), %rcx      # 0x180009308
180006f04:     	leaq	0x2d5d(%rip), %rdx      # 0x180009c68
180006f0b:     	movq	(%rcx), %rcx
180006f0e:     	callq	*0x23a4(%rip)           # 0x1800092b8
180006f14:     	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
180006f19:     	addq	$0x68, %rsp
180006f1d:     	popq	%r15
180006f1f:     	popq	%r14
180006f21:     	popq	%r13
180006f23:     	popq	%r12
180006f25:     	popq	%rdi
180006f26:     	popq	%rsi
180006f27:     	popq	%rbp
180006f28:     	popq	%rbx
180006f29:     	retq
180006f2a:     	movq	0x9d0f(%rip), %rax      # 0x180010c40
180006f31:     	callq	*0x698(%rax)
180006f37:     	movl	%eax, 0x9d0f(%rip)      # 0x180010c4c
180006f3d:     	cmpl	$0x10, %eax
180006f40:     	jge	0x180006f5e <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x55de>
180006f42:     	movq	0x2377(%rip), %rcx      # 0x1800092c0
180006f49:     	leaq	0x2b40(%rip), %rdx      # 0x180009a90
180006f50:     	movl	%eax, %r9d
180006f53:     	movl	$0x10, %r8d
180006f59:     	movq	(%rcx), %rcx
180006f5c:     	jmp	0x180006ef1 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5571>
180006f5e:     	movq	0x9cdb(%rip), %rax      # 0x180010c40
180006f65:     	callq	*0x690(%rax)
180006f6b:     	testl	%eax, %eax
180006f6d:     	jne	0x180006f7b <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x55fb>
180006f6f:     	leaq	0x2c6a(%rip), %rdx      # 0x180009be0
180006f76:     	jmp	0x180006eb0 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5530>
180006f7b:     	cmpl	$0x1, %eax
180006f7e:     	je	0x180006f8c <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x560c>
180006f80:     	leaq	0x2c89(%rip), %rdx      # 0x180009c10
180006f87:     	jmp	0x180006eb0 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5530>
180006f8c:     	leaq	0x984d(%rip), %rcx      # 0x1800107e0
180006f93:     	callq	*0x21e7(%rip)           # 0x180009180
180006f99:     	testl	%eax, %eax
180006f9b:     	jne	0x180006f14 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5594>
180006fa1:     	leaq	0x9358(%rip), %rcx      # 0x180010300
180006fa8:     	callq	*0x21d2(%rip)           # 0x180009180
180006fae:     	testl	%eax, %eax
180006fb0:     	jne	0x180006f14 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5594>
180006fb6:     	leaq	0x9683(%rip), %rcx      # 0x180010640
180006fbd:     	callq	*0x21bd(%rip)           # 0x180009180
180006fc3:     	testl	%eax, %eax
180006fc5:     	jne	0x180006f14 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5594>
180006fcb:     	xorl	%ebx, %ebx
180006fcd:     	cmpl	%ebx, 0x9c75(%rip)      # 0x180010c48
180006fd3:     	jne	0x180007016 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5696>
180006fd5:     	movq	%gs:0x58, %rax
180006fde:     	movl	0x9c7c(%rip), %ecx      # 0x180010c60
180006fe4:     	movl	$0x1, 0x9c5a(%rip)      # 0x180010c48
180006fee:     	movq	(%rax,%rcx,8), %rdx
180006ff2:     	movl	$0x10, %eax
180006ff7:     	movl	%ebx, 0x9d0(%rax,%rdx)
180006ffe:     	movl	$0x9f0, %eax            # imm = 0x9F0
180007003:     	movl	%ebx, 0x9d0(%rax,%rdx)
18000700a:     	movl	$0x13d0, %eax           # imm = 0x13D0
18000700f:     	movl	%ebx, 0x9d0(%rax,%rdx)
180007016:     	movl	%ebx, 0x9bdc(%rip)      # 0x180010bf8
18000701c:     	movq	%rbx, %rax
18000701f:     	movb	%bl, 0x9bdb(%rip)       # 0x180010c00
180007025:     	movq	%rbx, %rcx
180007028:     	xchgq	%rax, 0x9bd9(%rip)      # 0x180010c08
18000702f:     	xchgq	%rcx, 0x9bda(%rip)      # 0x180010c10
180007036:     	movq	%rbx, %rax
180007039:     	movq	%rbx, %rcx
18000703c:     	xchgq	%rax, 0x9bd5(%rip)      # 0x180010c18
180007043:     	xchgq	%rcx, 0x9bd6(%rip)      # 0x180010c20
18000704a:     	movq	0x2017(%rip), %rax      # 0x180009068
180007051:     	leaq	0x9448(%rip), %rcx      # 0x1800104a0
180007058:     	movq	%rax, 0x9bc9(%rip)      # 0x180010c28
18000705f:     	movq	0x1ffa(%rip), %rax      # 0x180009060
180007066:     	movq	%rax, 0x9bc3(%rip)      # 0x180010c30
18000706d:     	movq	0x1ffc(%rip), %rax      # 0x180009070
180007074:     	movq	%rax, 0x9bbd(%rip)      # 0x180010c38
18000707b:     	movq	0x21d6(%rip), %rax      # 0x180009258
180007082:     	movq	%rax, 0x954f(%rip)      # 0x1800105d8
180007089:     	callq	*0x20f1(%rip)           # 0x180009180
18000708f:     	testl	%eax, %eax
180007091:     	jne	0x180006f14 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5594>
180007097:     	leaq	0x2ce2(%rip), %rdx      # 0x180009d80
18000709e:     	movq	%r14, %rcx
1800070a1:     	callq	*0x20d1(%rip)           # 0x180009178
1800070a7:     	movq	%rax, 0x28(%rsp)
1800070ac:     	movq	%rax, %rdi
1800070af:     	testq	%rax, %rax
1800070b2:     	je	0x180006f14 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5594>
1800070b8:     	leaq	0x2e5a(%rip), %rcx      # 0x180009f19
1800070bf:     	callq	*0x21cb(%rip)           # 0x180009290
1800070c5:     	movq	%rax, 0x20(%rsp)
1800070ca:     	movq	%rax, %r12
1800070cd:     	testq	%rax, %rax
1800070d0:     	je	0x180007414 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5a94>
1800070d6:     	movl	%ebx, %ebp
1800070d8:     	cmpq	%rbx, (%rsi)
1800070db:     	je	0x180007284 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5904>
1800070e1:     	movslq	%ebp, %rbx
1800070e4:     	leaq	0x30(%rsp), %rdx
1800070e9:     	movq	%r14, %rcx
1800070ec:     	leaq	(%rbx,%rbx,4), %rax
1800070f0:     	movups	(%r13,%rax,8), %xmm0
1800070f6:     	movups	0x10(%r13,%rax,8), %xmm1
1800070fc:     	movaps	%xmm0, 0x30(%rsp)
180007101:     	movsd	0x20(%r13,%rax,8), %xmm0
180007108:     	movsd	%xmm0, 0x50(%rsp)
18000710e:     	movaps	%xmm1, 0x40(%rsp)
180007113:     	callq	0x180006c10 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5290>
180007118:     	movq	%rax, %r14
18000711b:     	testq	%rax, %rax
18000711e:     	je	0x1800073f0 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5a70>
180007124:     	movq	(%rsi), %rcx
180007127:     	callq	*0x2163(%rip)           # 0x180009290
18000712d:     	movq	%rax, %r13
180007130:     	testq	%rax, %rax
180007133:     	je	0x180007437 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5ab7>
180007139:     	movq	(%r15,%rbx,8), %rcx
18000713d:     	xorl	%edx, %edx
18000713f:     	movq	%r14, (%rcx)
180007142:     	leaq	0x9697(%rip), %rcx      # 0x1800107e0
180007149:     	movq	0x8(%rsi), %r12
18000714d:     	callq	*0x200d(%rip)           # 0x180009160
180007153:     	movq	%rax, %rbx
180007156:     	testq	%rax, %rax
180007159:     	je	0x1800071d6 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5856>
18000715b:     	movq	%r13, %rcx
18000715e:     	callq	*0x202c(%rip)           # 0x180009190
180007164:     	movq	%rax, %rdi
180007167:     	testq	%rax, %rax
18000716a:     	je	0x18000718c <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x580c>
18000716c:     	movq	%rax, %rcx
18000716f:     	callq	0x180008a0d <numba_list_iter_next+0xecd>
180007174:     	leaq	0x1(%rax), %rcx
180007178:     	callq	*0x20e2(%rip)           # 0x180009260
18000717e:     	movq	%rax, %rsi
180007181:     	testq	%rax, %rax
180007184:     	jne	0x180007194 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5814>
180007186:     	callq	*0x1fc4(%rip)           # 0x180009150
18000718c:     	xorl	%eax, %eax
18000718e:     	movq	%rax, 0x20(%rbx)
180007192:     	jmp	0x1800071c5 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5845>
180007194:     	movq	%rdi, %rdx
180007197:     	movq	%rsi, %rcx
18000719a:     	callq	0x180008a07 <numba_list_iter_next+0xec7>
18000719f:     	movq	0x20(%rsp), %rcx
1800071a4:     	movq	%rsi, 0x20(%rbx)
1800071a8:     	movq	%r12, 0x28(%rbx)
1800071ac:     	movl	$0x3, 0x30(%rbx)
1800071b3:     	callq	0x180006690 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4d10>
1800071b8:     	movq	%rax, 0x38(%rbx)
1800071bc:     	testq	%rax, %rax
1800071bf:     	jne	0x180007330 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x59b0>
1800071c5:     	movl	(%rbx), %eax
1800071c7:     	testl	%eax, %eax
1800071c9:     	js	0x1800071d6 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5856>
1800071cb:     	subl	$0x1, %eax
1800071ce:     	movl	%eax, (%rbx)
1800071d0:     	je	0x18000737d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x59fd>
1800071d6:     	xorl	%edi, %edi
1800071d8:     	movl	(%r14), %eax
1800071db:     	testl	%eax, %eax
1800071dd:     	js	0x1800071f0 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5870>
1800071df:     	subl	$0x1, %eax
1800071e2:     	movl	%eax, (%r14)
1800071e5:     	jne	0x1800071f0 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5870>
1800071e7:     	movq	%r14, %rcx
1800071ea:     	callq	*0x1fe8(%rip)           # 0x1800091d8
1800071f0:     	movl	(%r13), %eax
1800071f4:     	testl	%eax, %eax
1800071f6:     	js	0x18000720a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x588a>
1800071f8:     	subl	$0x1, %eax
1800071fb:     	movl	%eax, (%r13)
1800071ff:     	jne	0x18000720a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x588a>
180007201:     	movq	%r13, %rcx
180007204:     	callq	*0x1fce(%rip)           # 0x1800091d8
18000720a:     	testq	%rdi, %rdi
18000720d:     	je	0x1800073f0 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5a70>
180007213:     	movq	0xb8(%rsp), %rsi
18000721b:     	movq	%rdi, %r8
18000721e:     	movq	0xb0(%rsp), %r14
180007226:     	movq	%r14, %rcx
180007229:     	movq	(%rsi), %rdx
18000722c:     	callq	*0x1ffe(%rip)           # 0x180009230
180007232:     	movl	(%rdi), %ecx
180007234:     	testl	%eax, %eax
180007236:     	jne	0x1800073da <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5a5a>
18000723c:     	testl	%ecx, %ecx
18000723e:     	js	0x180007252 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x58d2>
180007240:     	leal	-0x1(%rcx), %eax
180007243:     	movl	%eax, (%rdi)
180007245:     	testl	%eax, %eax
180007247:     	jne	0x180007252 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x58d2>
180007249:     	movq	%rdi, %rcx
18000724c:     	callq	*0x1f86(%rip)           # 0x1800091d8
180007252:     	movq	0xc8(%rsp), %r15
18000725a:     	addq	$0x20, %rsi
18000725e:     	movq	0xc0(%rsp), %r13
180007266:     	incl	%ebp
180007268:     	movq	%rsi, 0xb8(%rsp)
180007270:     	cmpq	$0x0, (%rsi)
180007274:     	jne	0x1800070e1 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5761>
18000727a:     	movq	0x20(%rsp), %r12
18000727f:     	movq	0x28(%rsp), %rdi
180007284:     	movslq	%ebp, %rax
180007287:     	cmpq	$0x0, (%r15,%rax,8)
18000728c:     	je	0x1800072f9 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5979>
18000728e:     	nop
180007290:     	movslq	%ebp, %rbx
180007293:     	leaq	0x30(%rsp), %rdx
180007298:     	movq	%r14, %rcx
18000729b:     	leaq	(%rbx,%rbx,4), %rax
18000729f:     	movups	(%r13,%rax,8), %xmm0
1800072a5:     	movups	0x10(%r13,%rax,8), %xmm1
1800072ab:     	movaps	%xmm0, 0x30(%rsp)
1800072b0:     	movsd	0x20(%r13,%rax,8), %xmm0
1800072b7:     	movsd	%xmm0, 0x50(%rsp)
1800072bd:     	movaps	%xmm1, 0x40(%rsp)
1800072c2:     	callq	0x180006c10 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5290>
1800072c7:     	testq	%rax, %rax
1800072ca:     	je	0x1800073f5 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5a75>
1800072d0:     	movq	(%r15,%rbx,8), %rcx
1800072d4:     	movq	%rax, (%rcx)
1800072d7:     	movl	(%rax), %ecx
1800072d9:     	testl	%ecx, %ecx
1800072db:     	js	0x1800072ed <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x596d>
1800072dd:     	subl	$0x1, %ecx
1800072e0:     	movl	%ecx, (%rax)
1800072e2:     	jne	0x1800072ed <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x596d>
1800072e4:     	movq	%rax, %rcx
1800072e7:     	callq	*0x1eeb(%rip)           # 0x1800091d8
1800072ed:     	incl	%ebp
1800072ef:     	movslq	%ebp, %rax
1800072f2:     	cmpq	$0x0, (%r15,%rax,8)
1800072f7:     	jne	0x180007290 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5910>
1800072f9:     	movl	(%r12), %eax
1800072fd:     	testl	%eax, %eax
1800072ff:     	js	0x180007313 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5993>
180007301:     	subl	$0x1, %eax
180007304:     	movl	%eax, (%r12)
180007308:     	jne	0x180007313 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5993>
18000730a:     	movq	%r12, %rcx
18000730d:     	callq	*0x1ec5(%rip)           # 0x1800091d8
180007313:     	movl	(%rdi), %eax
180007315:     	testl	%eax, %eax
180007317:     	js	0x180007329 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x59a9>
180007319:     	subl	$0x1, %eax
18000731c:     	movl	%eax, (%rdi)
18000731e:     	jne	0x180007329 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x59a9>
180007320:     	movq	%rdi, %rcx
180007323:     	callq	*0x1eaf(%rip)           # 0x1800091d8
180007329:     	xorl	%eax, %eax
18000732b:     	jmp	0x180006f19 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5599>
180007330:     	movl	(%r14), %eax
180007333:     	cmpl	$0xc0000000, %eax       # imm = 0xC0000000
180007338:     	jae	0x18000733f <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x59bf>
18000733a:     	incl	%eax
18000733c:     	movl	%eax, (%r14)
18000733f:     	movq	0xb0(%rsp), %rcx
180007347:     	leaq	0x2a32(%rip), %rdx      # 0x180009d80
18000734e:     	movq	%r14, 0x18(%rbx)
180007352:     	movq	$0x0, 0x40(%rbx)
18000735a:     	callq	*0x1e18(%rip)           # 0x180009178
180007360:     	movq	%rax, %rsi
180007363:     	testq	%rax, %rax
180007366:     	jne	0x18000738b <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5a0b>
180007368:     	movl	(%rbx), %eax
18000736a:     	testl	%eax, %eax
18000736c:     	js	0x1800071d6 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5856>
180007372:     	subl	$0x1, %eax
180007375:     	movl	%eax, (%rbx)
180007377:     	jne	0x1800071d6 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5856>
18000737d:     	movq	%rbx, %rcx
180007380:     	callq	*0x1e52(%rip)           # 0x1800091d8
180007386:     	jmp	0x1800071d6 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5856>
18000738b:     	xorl	%r9d, %r9d
18000738e:     	leaq	0x20(%rbx), %rcx
180007392:     	movq	%rsi, %r8
180007395:     	movq	%rbx, %rdx
180007398:     	callq	*0x1dba(%rip)           # 0x180009158
18000739e:     	movq	%rax, %rdi
1800073a1:     	movl	(%rbx), %eax
1800073a3:     	testl	%eax, %eax
1800073a5:     	js	0x1800073b7 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5a37>
1800073a7:     	subl	$0x1, %eax
1800073aa:     	movl	%eax, (%rbx)
1800073ac:     	jne	0x1800073b7 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5a37>
1800073ae:     	movq	%rbx, %rcx
1800073b1:     	callq	*0x1e21(%rip)           # 0x1800091d8
1800073b7:     	movl	(%rsi), %eax
1800073b9:     	testl	%eax, %eax
1800073bb:     	js	0x1800071d8 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5858>
1800073c1:     	subl	$0x1, %eax
1800073c4:     	movl	%eax, (%rsi)
1800073c6:     	jne	0x1800071d8 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5858>
1800073cc:     	movq	%rsi, %rcx
1800073cf:     	callq	*0x1e03(%rip)           # 0x1800091d8
1800073d5:     	jmp	0x1800071d8 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5858>
1800073da:     	testl	%ecx, %ecx
1800073dc:     	js	0x1800073f0 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5a70>
1800073de:     	leal	-0x1(%rcx), %eax
1800073e1:     	movl	%eax, (%rdi)
1800073e3:     	testl	%eax, %eax
1800073e5:     	jne	0x1800073f0 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5a70>
1800073e7:     	movq	%rdi, %rcx
1800073ea:     	callq	*0x1de8(%rip)           # 0x1800091d8
1800073f0:     	movq	0x20(%rsp), %r12
1800073f5:     	movl	(%r12), %eax
1800073f9:     	testl	%eax, %eax
1800073fb:     	js	0x18000740f <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5a8f>
1800073fd:     	subl	$0x1, %eax
180007400:     	movl	%eax, (%r12)
180007404:     	jne	0x18000740f <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5a8f>
180007406:     	movq	%r12, %rcx
180007409:     	callq	*0x1dc9(%rip)           # 0x1800091d8
18000740f:     	movq	0x28(%rsp), %rdi
180007414:     	movl	(%rdi), %eax
180007416:     	testl	%eax, %eax
180007418:     	js	0x180006f14 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5594>
18000741e:     	subl	$0x1, %eax
180007421:     	movl	%eax, (%rdi)
180007423:     	jne	0x180006f14 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5594>
180007429:     	movq	%rdi, %rcx
18000742c:     	callq	*0x1da6(%rip)           # 0x1800091d8
180007432:     	jmp	0x180006f14 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5594>
180007437:     	movl	(%r14), %eax
18000743a:     	testl	%eax, %eax
18000743c:     	js	0x1800073f0 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5a70>
18000743e:     	subl	$0x1, %eax
180007441:     	movl	%eax, (%r14)
180007444:     	jne	0x1800073f0 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5a70>
180007446:     	movq	%r14, %rcx
180007449:     	jmp	0x1800073ea <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5a6a>
18000744b:     	int3
18000744c:     	int3
18000744d:     	int3
18000744e:     	int3
18000744f:     	int3
180007450:     	leaq	0x9849(%rip), %rax      # 0x180010ca0
180007457:     	retq
180007458:     	int3
180007459:     	int3
18000745a:     	int3
18000745b:     	int3
18000745c:     	int3
18000745d:     	int3
18000745e:     	int3
18000745f:     	int3

0000000180007460 <numba_list_set_method_table>:
180007460:     	movups	(%rdx), %xmm0
180007463:     	movups	%xmm0, 0x20(%rcx)
180007467:     	retq
180007468:     	int3
180007469:     	int3
18000746a:     	int3
18000746b:     	int3
18000746c:     	int3
18000746d:     	int3
18000746e:     	int3
18000746f:     	int3

0000000180007470 <numba_list_new>:
180007470:     	pushq	%rbx
180007472:     	pushq	%rbp
180007473:     	pushq	%rsi
180007474:     	pushq	%rdi
180007475:     	subq	$0x28, %rsp
180007479:     	movq	%rcx, %rsi
18000747c:     	movq	%r8, %rdi
18000747f:     	movl	$0x38, %ecx
180007484:     	movq	%rdx, %rbp
180007487:     	callq	*0x1bdb(%rip)           # 0x180009068
18000748d:     	movq	%rax, %rbx
180007490:     	testq	%rax, %rax
180007493:     	je	0x1800074fd <numba_list_new+0x8d>
180007495:     	movq	$0x0, (%rax)
18000749c:     	xorps	%xmm0, %xmm0
18000749f:     	movq	%rbp, 0x8(%rax)
1800074a3:     	movq	%rdi, 0x10(%rax)
1800074a7:     	movl	$0x1, 0x18(%rax)
1800074ae:     	movups	%xmm0, 0x20(%rax)
1800074b2:     	testq	%rdi, %rdi
1800074b5:     	je	0x18000750b <numba_list_new+0x9b>
1800074b7:     	imulq	%rbp, %rdi
1800074bb:     	movl	$0x8, %ecx
1800074c0:     	movq	%rdi, %rax
1800074c3:     	cqto
1800074c5:     	andl	$0x7, %edx
1800074c8:     	addq	%rdx, %rax
1800074cb:     	andl	$0x7, %eax
1800074ce:     	subq	%rdx, %rax
1800074d1:     	subq	%rax, %rcx
1800074d4:     	movq	%rcx, %rax
1800074d7:     	cqto
1800074d9:     	andl	$0x7, %edx
1800074dc:     	leaq	(%rdx,%rax), %rcx
1800074e0:     	andl	$0x7, %ecx
1800074e3:     	subq	%rdx, %rcx
1800074e6:     	addq	%rdi, %rcx
1800074e9:     	callq	*0x1b79(%rip)           # 0x180009068
1800074ef:     	testq	%rax, %rax
1800074f2:     	jne	0x18000750d <numba_list_new+0x9d>
1800074f4:     	movq	%rbx, %rcx
1800074f7:     	callq	*0x1b73(%rip)           # 0x180009070
1800074fd:     	movl	$0xfffffffe, %eax       # imm = 0xFFFFFFFE
180007502:     	addq	$0x28, %rsp
180007506:     	popq	%rdi
180007507:     	popq	%rsi
180007508:     	popq	%rbp
180007509:     	popq	%rbx
18000750a:     	retq
18000750b:     	xorl	%eax, %eax
18000750d:     	movq	%rax, 0x30(%rbx)
180007511:     	xorl	%eax, %eax
180007513:     	movq	%rbx, (%rsi)
180007516:     	addq	$0x28, %rsp
18000751a:     	popq	%rdi
18000751b:     	popq	%rsi
18000751c:     	popq	%rbp
18000751d:     	popq	%rbx
18000751e:     	retq
18000751f:     	int3

0000000180007520 <numba_list_free>:
180007520:     	pushq	%rbx
180007522:     	subq	$0x20, %rsp
180007526:     	cmpq	$0x0, 0x28(%rcx)
18000752b:     	movq	%rcx, %rbx
18000752e:     	je	0x180007564 <numba_list_free+0x44>
180007530:     	movq	%rdi, 0x30(%rsp)
180007535:     	xorl	%edi, %edi
180007537:     	cmpq	%rdi, (%rcx)
18000753a:     	jle	0x18000755f <numba_list_free+0x3f>
18000753c:     	nopl	(%rax)
180007540:     	movq	0x28(%rbx), %rax
180007544:     	testq	%rax, %rax
180007547:     	je	0x180007557 <numba_list_free+0x37>
180007549:     	movq	%rdi, %rcx
18000754c:     	imulq	0x8(%rbx), %rcx
180007551:     	addq	0x30(%rbx), %rcx
180007555:     	callq	*%rax
180007557:     	incq	%rdi
18000755a:     	cmpq	(%rbx), %rdi
18000755d:     	jl	0x180007540 <numba_list_free+0x20>
18000755f:     	movq	0x30(%rsp), %rdi
180007564:     	movq	0x30(%rbx), %rcx
180007568:     	testq	%rcx, %rcx
18000756b:     	je	0x180007573 <numba_list_free+0x53>
18000756d:     	callq	*0x1afd(%rip)           # 0x180009070
180007573:     	movq	%rbx, %rcx
180007576:     	addq	$0x20, %rsp
18000757a:     	popq	%rbx
18000757b:     	jmpq	*0x1aee(%rip)           # 0x180009070
180007582:     	int3
180007583:     	int3
180007584:     	int3
180007585:     	int3
180007586:     	int3
180007587:     	int3
180007588:     	int3
180007589:     	int3
18000758a:     	int3
18000758b:     	int3
18000758c:     	int3
18000758d:     	int3
18000758e:     	int3
18000758f:     	int3

0000000180007590 <numba_list_base_ptr>:
180007590:     	movq	0x30(%rcx), %rax
180007594:     	retq
180007595:     	int3
180007596:     	int3
180007597:     	int3
180007598:     	int3
180007599:     	int3
18000759a:     	int3
18000759b:     	int3
18000759c:     	int3
18000759d:     	int3
18000759e:     	int3
18000759f:     	int3

00000001800075a0 <numba_list_size_address>:
1800075a0:     	movq	%rcx, %rax
1800075a3:     	retq
1800075a4:     	int3
1800075a5:     	int3
1800075a6:     	int3
1800075a7:     	int3
1800075a8:     	int3
1800075a9:     	int3
1800075aa:     	int3
1800075ab:     	int3
1800075ac:     	int3
1800075ad:     	int3
1800075ae:     	int3
1800075af:     	int3

00000001800075b0 <numba_list_length>:
1800075b0:     	movq	(%rcx), %rax
1800075b3:     	retq
1800075b4:     	int3
1800075b5:     	int3
1800075b6:     	int3
1800075b7:     	int3
1800075b8:     	int3
1800075b9:     	int3
1800075ba:     	int3
1800075bb:     	int3
1800075bc:     	int3
1800075bd:     	int3
1800075be:     	int3
1800075bf:     	int3

00000001800075c0 <numba_list_allocated>:
1800075c0:     	movq	0x10(%rcx), %rax
1800075c4:     	retq
1800075c5:     	int3
1800075c6:     	int3
1800075c7:     	int3
1800075c8:     	int3
1800075c9:     	int3
1800075ca:     	int3
1800075cb:     	int3
1800075cc:     	int3
1800075cd:     	int3
1800075ce:     	int3
1800075cf:     	int3

00000001800075d0 <numba_list_is_mutable>:
1800075d0:     	movl	0x18(%rcx), %eax
1800075d3:     	retq
1800075d4:     	int3
1800075d5:     	int3
1800075d6:     	int3
1800075d7:     	int3
1800075d8:     	int3
1800075d9:     	int3
1800075da:     	int3
1800075db:     	int3
1800075dc:     	int3
1800075dd:     	int3
1800075de:     	int3
1800075df:     	int3

00000001800075e0 <numba_list_set_is_mutable>:
1800075e0:     	movl	%edx, 0x18(%rcx)
1800075e3:     	retq
1800075e4:     	int3
1800075e5:     	int3
1800075e6:     	int3
1800075e7:     	int3
1800075e8:     	int3
1800075e9:     	int3
1800075ea:     	int3
1800075eb:     	int3
1800075ec:     	int3
1800075ed:     	int3
1800075ee:     	int3
1800075ef:     	int3

00000001800075f0 <numba_list_setitem>:
1800075f0:     	movq	%rbx, 0x10(%rsp)
1800075f5:     	pushq	%rsi
1800075f6:     	subq	$0x20, %rsp
1800075fa:     	cmpl	$0x0, 0x18(%rcx)
1800075fe:     	movq	%r8, %rsi
180007601:     	movq	%rcx, %rbx
180007604:     	jne	0x180007616 <numba_list_setitem+0x26>
180007606:     	movl	$0xfffffffb, %eax       # imm = 0xFFFFFFFB
18000760b:     	movq	0x38(%rsp), %rbx
180007610:     	addq	$0x20, %rsp
180007614:     	popq	%rsi
180007615:     	retq
180007616:     	cmpq	(%rcx), %rdx
180007619:     	jb	0x18000762b <numba_list_setitem+0x3b>
18000761b:     	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
180007620:     	movq	0x38(%rsp), %rbx
180007625:     	addq	$0x20, %rsp
180007629:     	popq	%rsi
18000762a:     	retq
18000762b:     	imulq	0x8(%rcx), %rdx
180007630:     	movq	0x28(%rcx), %rax
180007634:     	movq	%rdi, 0x30(%rsp)
180007639:     	movq	0x30(%rcx), %rdi
18000763d:     	addq	%rdx, %rdi
180007640:     	testq	%rax, %rax
180007643:     	je	0x18000764a <numba_list_setitem+0x5a>
180007645:     	movq	%rdi, %rcx
180007648:     	callq	*%rax
18000764a:     	movq	0x8(%rbx), %r8
18000764e:     	movq	%rsi, %rdx
180007651:     	movq	%rdi, %rcx
180007654:     	callq	0x1800089fb <numba_list_iter_next+0xebb>
180007659:     	movq	0x20(%rbx), %rax
18000765d:     	testq	%rax, %rax
180007660:     	je	0x180007667 <numba_list_setitem+0x77>
180007662:     	movq	%rdi, %rcx
180007665:     	callq	*%rax
180007667:     	movq	0x30(%rsp), %rdi
18000766c:     	xorl	%eax, %eax
18000766e:     	movq	0x38(%rsp), %rbx
180007673:     	addq	$0x20, %rsp
180007677:     	popq	%rsi
180007678:     	retq
180007679:     	int3
18000767a:     	int3
18000767b:     	int3
18000767c:     	int3
18000767d:     	int3
18000767e:     	int3
18000767f:     	int3

0000000180007680 <numba_list_getitem>:
180007680:     	subq	$0x28, %rsp
180007684:     	movq	%r8, %r9
180007687:     	movq	%rdx, %rax
18000768a:     	cmpq	(%rcx), %rdx
18000768d:     	jb	0x180007699 <numba_list_getitem+0x19>
18000768f:     	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
180007694:     	addq	$0x28, %rsp
180007698:     	retq
180007699:     	movq	0x8(%rcx), %r8
18000769d:     	movq	%r8, %rdx
1800076a0:     	imulq	%rax, %rdx
1800076a4:     	addq	0x30(%rcx), %rdx
1800076a8:     	movq	%r9, %rcx
1800076ab:     	callq	0x1800089fb <numba_list_iter_next+0xebb>
1800076b0:     	xorl	%eax, %eax
1800076b2:     	addq	$0x28, %rsp
1800076b6:     	retq
1800076b7:     	int3
1800076b8:     	int3
1800076b9:     	int3
1800076ba:     	int3
1800076bb:     	int3
1800076bc:     	int3
1800076bd:     	int3
1800076be:     	int3
1800076bf:     	int3

00000001800076c0 <numba_list_append>:
1800076c0:     	movq	%rbx, 0x10(%rsp)
1800076c5:     	pushq	%rsi
1800076c6:     	subq	$0x20, %rsp
1800076ca:     	cmpl	$0x0, 0x18(%rcx)
1800076ce:     	movq	%rdx, %rsi
1800076d1:     	movq	%rcx, %rbx
1800076d4:     	jne	0x1800076e6 <numba_list_append+0x26>
1800076d6:     	movl	$0xfffffffb, %eax       # imm = 0xFFFFFFFB
1800076db:     	movq	0x38(%rsp), %rbx
1800076e0:     	addq	$0x20, %rsp
1800076e4:     	popq	%rsi
1800076e5:     	retq
1800076e6:     	movq	(%rcx), %rdx
1800076e9:     	incq	%rdx
1800076ec:     	callq	0x180007740 <numba_list_resize>
1800076f1:     	testl	%eax, %eax
1800076f3:     	js	0x18000772c <numba_list_append+0x6c>
1800076f5:     	movq	0x8(%rbx), %r8
1800076f9:     	movq	%rsi, %rdx
1800076fc:     	movq	%rdi, 0x30(%rsp)
180007701:     	movq	(%rbx), %rdi
180007704:     	decq	%rdi
180007707:     	imulq	%r8, %rdi
18000770b:     	addq	0x30(%rbx), %rdi
18000770f:     	movq	%rdi, %rcx
180007712:     	callq	0x1800089fb <numba_list_iter_next+0xebb>
180007717:     	movq	0x20(%rbx), %rax
18000771b:     	testq	%rax, %rax
18000771e:     	je	0x180007725 <numba_list_append+0x65>
180007720:     	movq	%rdi, %rcx
180007723:     	callq	*%rax
180007725:     	movq	0x30(%rsp), %rdi
18000772a:     	xorl	%eax, %eax
18000772c:     	movq	0x38(%rsp), %rbx
180007731:     	addq	$0x20, %rsp
180007735:     	popq	%rsi
180007736:     	retq
180007737:     	int3
180007738:     	int3
180007739:     	int3
18000773a:     	int3
18000773b:     	int3
18000773c:     	int3
18000773d:     	int3
18000773e:     	int3
18000773f:     	int3

0000000180007740 <numba_list_resize>:
180007740:     	movq	%rsi, 0x18(%rsp)
180007745:     	pushq	%rdi
180007746:     	subq	$0x20, %rsp
18000774a:     	cmpl	$0x0, 0x18(%rcx)
18000774e:     	movq	%rdx, %rsi
180007751:     	movq	%rcx, %rdi
180007754:     	jne	0x180007766 <numba_list_resize+0x26>
180007756:     	movl	$0xfffffffb, %eax       # imm = 0xFFFFFFFB
18000775b:     	movq	0x40(%rsp), %rsi
180007760:     	addq	$0x20, %rsp
180007764:     	popq	%rdi
180007765:     	retq
180007766:     	movq	0x10(%rcx), %rax
18000776a:     	cmpq	%rsi, %rax
18000776d:     	jl	0x180007787 <numba_list_resize+0x47>
18000776f:     	sarq	%rax
180007772:     	cmpq	%rax, %rsi
180007775:     	jl	0x180007787 <numba_list_resize+0x47>
180007777:     	movq	%rsi, (%rcx)
18000777a:     	xorl	%eax, %eax
18000777c:     	movq	0x40(%rsp), %rsi
180007781:     	addq	$0x20, %rsp
180007785:     	popq	%rdi
180007786:     	retq
180007787:     	cmpq	$0x9, %rsi
18000778b:     	movq	%rbp, 0x38(%rsp)
180007790:     	movl	$0x3, %ecx
180007795:     	movl	$0x6, %eax
18000779a:     	cmovll	%ecx, %eax
18000779d:     	movq	%rsi, %r8
1800077a0:     	movq	0x8(%rdi), %rcx
1800077a4:     	addq	%rsi, %rax
1800077a7:     	sarq	$0x3, %r8
1800077ab:     	xorl	%edx, %edx
1800077ad:     	addq	%rax, %r8
1800077b0:     	movabsq	$0x7fffffffffffffff, %rax # imm = 0x7FFFFFFFFFFFFFFF
1800077ba:     	divq	%rcx
1800077bd:     	cmpq	%rax, %r8
1800077c0:     	ja	0x18000783b <numba_list_resize+0xfb>
1800077c2:     	xorl	%ebp, %ebp
1800077c4:     	movq	%rbx, 0x30(%rsp)
1800077c9:     	testq	%rsi, %rsi
1800077cc:     	cmovneq	%r8, %rbp
1800077d0:     	movq	%rbp, %rbx
1800077d3:     	imulq	%rcx, %rbx
1800077d7:     	movl	$0x8, %ecx
1800077dc:     	movq	%rbx, %rax
1800077df:     	cqto
1800077e1:     	andl	$0x7, %edx
1800077e4:     	addq	%rdx, %rax
1800077e7:     	andl	$0x7, %eax
1800077ea:     	subq	%rdx, %rax
1800077ed:     	subq	%rax, %rcx
1800077f0:     	movq	%rcx, %rax
1800077f3:     	movq	0x30(%rdi), %rcx
1800077f7:     	cqto
1800077f9:     	andl	$0x7, %edx
1800077fc:     	addq	%rdx, %rax
1800077ff:     	andl	$0x7, %eax
180007802:     	subq	%rdx, %rax
180007805:     	leaq	(%rbx,%rax), %rdx
180007809:     	callq	*0x1851(%rip)           # 0x180009060
18000780f:     	testq	%rbx, %rbx
180007812:     	movq	0x30(%rsp), %rbx
180007817:     	je	0x18000781e <numba_list_resize+0xde>
180007819:     	testq	%rax, %rax
18000781c:     	je	0x18000783b <numba_list_resize+0xfb>
18000781e:     	movq	%rax, 0x30(%rdi)
180007822:     	xorl	%eax, %eax
180007824:     	movq	%rbp, 0x10(%rdi)
180007828:     	movq	0x38(%rsp), %rbp
18000782d:     	movq	%rsi, (%rdi)
180007830:     	movq	0x40(%rsp), %rsi
180007835:     	addq	$0x20, %rsp
180007839:     	popq	%rdi
18000783a:     	retq
18000783b:     	movq	0x38(%rsp), %rbp
180007840:     	movl	$0xfffffffe, %eax       # imm = 0xFFFFFFFE
180007845:     	movq	0x40(%rsp), %rsi
18000784a:     	addq	$0x20, %rsp
18000784e:     	popq	%rdi
18000784f:     	retq

0000000180007850 <numba_list_delitem>:
180007850:     	movq	%rbx, 0x10(%rsp)
180007855:     	pushq	%rdi
180007856:     	subq	$0x20, %rsp
18000785a:     	cmpl	$0x0, 0x18(%rcx)
18000785e:     	movq	%rdx, %rdi
180007861:     	movq	%rcx, %rbx
180007864:     	jne	0x180007876 <numba_list_delitem+0x26>
180007866:     	movl	$0xfffffffb, %eax       # imm = 0xFFFFFFFB
18000786b:     	movq	0x38(%rsp), %rbx
180007870:     	addq	$0x20, %rsp
180007874:     	popq	%rdi
180007875:     	retq
180007876:     	cmpq	(%rcx), %rdi
180007879:     	jb	0x18000788b <numba_list_delitem+0x3b>
18000787b:     	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
180007880:     	movq	0x38(%rsp), %rbx
180007885:     	addq	$0x20, %rsp
180007889:     	popq	%rdi
18000788a:     	retq
18000788b:     	movq	0x28(%rcx), %rax
18000788f:     	movq	%rsi, 0x30(%rsp)
180007894:     	movq	%rdi, %rsi
180007897:     	imulq	0x8(%rcx), %rsi
18000789c:     	addq	0x30(%rcx), %rsi
1800078a0:     	testq	%rax, %rax
1800078a3:     	je	0x1800078aa <numba_list_delitem+0x5a>
1800078a5:     	movq	%rsi, %rcx
1800078a8:     	callq	*%rax
1800078aa:     	movq	(%rbx), %r8
1800078ad:     	leaq	-0x1(%r8), %rax
1800078b1:     	cmpq	%rax, %rdi
1800078b4:     	je	0x1800078d6 <numba_list_delitem+0x86>
1800078b6:     	subq	%rdi, %r8
1800078b9:     	leaq	0x1(%rdi), %rdx
1800078bd:     	imulq	0x8(%rbx), %rdx
1800078c2:     	decq	%r8
1800078c5:     	movq	%rsi, %rcx
1800078c8:     	imulq	0x8(%rbx), %r8
1800078cd:     	addq	0x30(%rbx), %rdx
1800078d1:     	callq	0x180008a01 <numba_list_iter_next+0xec1>
1800078d6:     	movq	(%rbx), %rdx
1800078d9:     	movq	%rbx, %rcx
1800078dc:     	decq	%rdx
1800078df:     	callq	0x180007740 <numba_list_resize>
1800078e4:     	movq	0x30(%rsp), %rsi
1800078e9:     	xorl	%ecx, %ecx
1800078eb:     	movq	0x38(%rsp), %rbx
1800078f0:     	testl	%eax, %eax
1800078f2:     	cmovsl	%eax, %ecx
1800078f5:     	movl	%ecx, %eax
1800078f7:     	addq	$0x20, %rsp
1800078fb:     	popq	%rdi
1800078fc:     	retq
1800078fd:     	int3
1800078fe:     	int3
1800078ff:     	int3

0000000180007900 <numba_list_delete_slice>:
180007900:     	pushq	%rbx
180007902:     	pushq	%rbp
180007903:     	pushq	%rdi
180007904:     	pushq	%r15
180007906:     	subq	$0x38, %rsp
18000790a:     	cmpl	$0x0, 0x18(%rcx)
18000790e:     	movq	%r9, %rdi
180007911:     	movq	%r8, %rbp
180007914:     	movq	%rdx, %r15
180007917:     	movq	%rcx, %rbx
18000791a:     	jne	0x18000792b <numba_list_delete_slice+0x2b>
18000791c:     	movl	$0xfffffffb, %eax       # imm = 0xFFFFFFFB
180007921:     	addq	$0x38, %rsp
180007925:     	popq	%r15
180007927:     	popq	%rdi
180007928:     	popq	%rbp
180007929:     	popq	%rbx
18000792a:     	retq
18000792b:     	movq	%r13, 0x78(%rsp)
180007930:     	testq	%rdi, %rdi
180007933:     	jle	0x180007952 <numba_list_delete_slice+0x52>
180007935:     	cmpq	%r8, %r15
180007938:     	jge	0x180007af1 <numba_list_delete_slice+0x1f1>
18000793e:     	movq	%r8, %rax
180007941:     	subq	%r15, %rax
180007944:     	decq	%rax
180007947:     	cqto
180007949:     	idivq	%rdi
18000794c:     	leal	0x1(%rax), %r13d
180007950:     	jmp	0x180007972 <numba_list_delete_slice+0x72>
180007952:     	cmpq	%r15, %r8
180007955:     	jge	0x180007af1 <numba_list_delete_slice+0x1f1>
18000795b:     	movq	%r15, %rax
18000795e:     	movl	$0x1, %r13d
180007964:     	subq	%r8, %rax
180007967:     	decq	%rax
18000796a:     	cqto
18000796c:     	idivq	%rdi
18000796f:     	subl	%eax, %r13d
180007972:     	testl	%r13d, %r13d
180007975:     	jle	0x180007af1 <numba_list_delete_slice+0x1f1>
18000797b:     	movq	%rsi, 0x68(%rsp)
180007980:     	movl	(%rcx), %esi
180007982:     	subl	%r13d, %esi
180007985:     	movl	%esi, 0x20(%rsp)
180007989:     	testq	%rdi, %rdi
18000798c:     	jns	0x1800079a7 <numba_list_delete_slice+0xa7>
18000798e:     	leaq	0x1(%r15), %rbp
180007992:     	leal	-0x1(%r13), %eax
180007996:     	movslq	%eax, %rcx
180007999:     	leaq	-0x1(%rbp), %r15
18000799d:     	imulq	%rdi, %rcx
1800079a1:     	addq	%rcx, %r15
1800079a4:     	negq	%rdi
1800079a7:     	cmpq	$0x1, %rdi
1800079ab:     	jne	0x1800079f7 <numba_list_delete_slice+0xf7>
1800079ad:     	cmpq	$0x0, 0x28(%rbx)
1800079b2:     	je	0x1800079d9 <numba_list_delete_slice+0xd9>
1800079b4:     	movslq	%r15d, %rdi
1800079b7:     	cmpq	%rbp, %rdi
1800079ba:     	jge	0x1800079d9 <numba_list_delete_slice+0xd9>
1800079bc:     	nopl	(%rax)
1800079c0:     	movslq	%edi, %rcx
1800079c3:     	imulq	0x8(%rbx), %rcx
1800079c8:     	addq	0x30(%rbx), %rcx
1800079cc:     	callq	*0x28(%rbx)
1800079cf:     	incl	%edi
1800079d1:     	movslq	%edi, %rax
1800079d4:     	cmpq	%rbp, %rax
1800079d7:     	jl	0x1800079c0 <numba_list_delete_slice+0xc0>
1800079d9:     	movq	0x8(%rbx), %rcx
1800079dd:     	movq	(%rbx), %r8
1800079e0:     	movq	%rcx, %rdx
1800079e3:     	subq	%rbp, %r8
1800079e6:     	imulq	%rcx, %r8
1800079ea:     	imulq	%rbp, %rdx
1800079ee:     	imulq	%r15, %rcx
1800079f2:     	jmp	0x180007abc <numba_list_delete_slice+0x1bc>
1800079f7:     	movq	%r14, 0x30(%rsp)
1800079fc:     	movq	%r15, %r14
1800079ff:     	movl	$0x0, 0x60(%rsp)
180007a07:     	cmpq	%rbp, %r15
180007a0a:     	jge	0x180007a89 <numba_list_delete_slice+0x189>
180007a0c:     	movq	%r12, 0x70(%rsp)
180007a11:     	movq	(%rbx), %rax
180007a14:     	leaq	(%r14,%rdi), %r12
180007a18:     	cmpq	%rax, %r12
180007a1b:     	jl	0x180007a28 <numba_list_delete_slice+0x128>
180007a1d:     	movq	%r14, %rsi
180007a20:     	notq	%rsi
180007a23:     	addq	%rax, %rsi
180007a26:     	jmp	0x180007a2c <numba_list_delete_slice+0x12c>
180007a28:     	leaq	-0x1(%rdi), %rsi
180007a2c:     	movq	0x28(%rbx), %rax
180007a30:     	testq	%rax, %rax
180007a33:     	je	0x180007a43 <numba_list_delete_slice+0x143>
180007a35:     	movq	%r14, %rcx
180007a38:     	imulq	0x8(%rbx), %rcx
180007a3d:     	addq	0x30(%rbx), %rcx
180007a41:     	callq	*%rax
180007a43:     	movq	0x8(%rbx), %r9
180007a47:     	leaq	0x1(%r14), %rdx
180007a4b:     	movq	0x30(%rbx), %r10
180007a4f:     	movq	%r9, %r8
180007a52:     	imulq	%rsi, %r8
180007a56:     	imulq	%r9, %rdx
180007a5a:     	movslq	0x60(%rsp), %rsi
180007a5f:     	subq	%rsi, %r14
180007a62:     	imulq	%r9, %r14
180007a66:     	addq	%r10, %rdx
180007a69:     	leaq	(%r10,%r14), %rcx
180007a6d:     	callq	0x180008a01 <numba_list_iter_next+0xec1>
180007a72:     	incl	%esi
180007a74:     	movq	%r12, %r14
180007a77:     	movl	%esi, 0x60(%rsp)
180007a7b:     	cmpq	%rbp, %r12
180007a7e:     	jl	0x180007a11 <numba_list_delete_slice+0x111>
180007a80:     	movq	0x70(%rsp), %r12
180007a85:     	movl	0x20(%rsp), %esi
180007a89:     	movq	(%rbx), %r8
180007a8c:     	movq	0x30(%rsp), %r14
180007a91:     	movslq	%r13d, %r10
180007a94:     	movq	%r10, %rcx
180007a97:     	imulq	%rdi, %rcx
180007a9b:     	addq	%r15, %rcx
180007a9e:     	cmpq	%r8, %rcx
180007aa1:     	jge	0x180007ac9 <numba_list_delete_slice+0x1c9>
180007aa3:     	movq	0x8(%rbx), %rax
180007aa7:     	subq	%rcx, %r8
180007aaa:     	movq	%rax, %rdx
180007aad:     	imulq	%rcx, %rdx
180007ab1:     	imulq	%rax, %r8
180007ab5:     	subq	%r10, %rcx
180007ab8:     	imulq	%rax, %rcx
180007abc:     	addq	0x30(%rbx), %rdx
180007ac0:     	addq	0x30(%rbx), %rcx
180007ac4:     	callq	0x180008a01 <numba_list_iter_next+0xec1>
180007ac9:     	movslq	%esi, %rdx
180007acc:     	movq	%rbx, %rcx
180007acf:     	callq	0x180007740 <numba_list_resize>
180007ad4:     	movq	0x68(%rsp), %rsi
180007ad9:     	xorl	%ecx, %ecx
180007adb:     	movq	0x78(%rsp), %r13
180007ae0:     	testl	%eax, %eax
180007ae2:     	cmovsl	%eax, %ecx
180007ae5:     	movl	%ecx, %eax
180007ae7:     	addq	$0x38, %rsp
180007aeb:     	popq	%r15
180007aed:     	popq	%rdi
180007aee:     	popq	%rbp
180007aef:     	popq	%rbx
180007af0:     	retq
180007af1:     	movq	0x78(%rsp), %r13
180007af6:     	xorl	%eax, %eax
180007af8:     	addq	$0x38, %rsp
180007afc:     	popq	%r15
180007afe:     	popq	%rdi
180007aff:     	popq	%rbp
180007b00:     	popq	%rbx
180007b01:     	retq
180007b02:     	int3
180007b03:     	int3
180007b04:     	int3
180007b05:     	int3
180007b06:     	int3
180007b07:     	int3
180007b08:     	int3
180007b09:     	int3
180007b0a:     	int3
180007b0b:     	int3
180007b0c:     	int3
180007b0d:     	int3
180007b0e:     	int3
180007b0f:     	int3

0000000180007b10 <numba_list_iter_sizeof>:
180007b10:     	movl	$0x18, %eax
180007b15:     	retq
180007b16:     	int3
180007b17:     	int3
180007b18:     	int3
180007b19:     	int3
180007b1a:     	int3
180007b1b:     	int3
180007b1c:     	int3
180007b1d:     	int3
180007b1e:     	int3
180007b1f:     	int3

0000000180007b20 <numba_list_iter>:
180007b20:     	movq	%rdx, (%rcx)
180007b23:     	movq	(%rdx), %rax
180007b26:     	movq	%rax, 0x8(%rcx)
180007b2a:     	movq	$0x0, 0x10(%rcx)
180007b32:     	retq
180007b33:     	int3
180007b34:     	int3
180007b35:     	int3
180007b36:     	int3
180007b37:     	int3
180007b38:     	int3
180007b39:     	int3
180007b3a:     	int3
180007b3b:     	int3
180007b3c:     	int3
180007b3d:     	int3
180007b3e:     	int3
180007b3f:     	int3

0000000180007b40 <numba_list_iter_next>:
180007b40:     	movq	(%rcx), %r8
180007b43:     	movq	(%r8), %r9
180007b46:     	cmpq	0x8(%rcx), %r9
180007b4a:     	je	0x180007b52 <numba_list_iter_next+0x12>
180007b4c:     	movl	$0xfffffffd, %eax       # imm = 0xFFFFFFFD
180007b51:     	retq
180007b52:     	movq	0x10(%rcx), %rax
180007b56:     	cmpq	%r9, %rax
180007b59:     	jge	0x180007b6e <numba_list_iter_next+0x2e>
180007b5b:     	imulq	0x8(%r8), %rax
180007b60:     	addq	0x30(%r8), %rax
180007b64:     	movq	%rax, (%rdx)
180007b67:     	incq	0x10(%rcx)
180007b6b:     	xorl	%eax, %eax
180007b6d:     	retq
180007b6e:     	movl	$0xfffffffc, %eax       # imm = 0xFFFFFFFC
180007b73:     	retq
180007b74:     	int3
180007b75:     	int3
180007b76:     	int3
180007b77:     	int3
180007b78:     	int3
180007b79:     	int3
180007b7a:     	int3
180007b7b:     	int3
180007b7c:     	int3
180007b7d:     	int3
180007b7e:     	int3
180007b7f:     	int3
180007b80:     	pushq	%rbx
180007b82:     	subq	$0x20, %rsp
180007b86:     	movq	%rcx, %rbx
180007b89:     	addq	$0x30, %rcx
180007b8d:     	callq	*0x9095(%rip)           # 0x180010c28
180007b93:     	cmpb	$0x0, 0x9066(%rip)      # 0x180010c00
180007b9a:     	je	0x180007ba4 <numba_list_iter_next+0x64>
180007b9c:     	lock
180007b9d:     	incq	0x9064(%rip)            # 0x180010c08
180007ba4:     	testq	%rax, %rax
180007ba7:     	je	0x180007be8 <numba_list_iter_next+0xa8>
180007ba9:     	leaq	0x30(%rax), %rdx
180007bad:     	testq	%rdx, %rdx
180007bb0:     	je	0x180007be8 <numba_list_iter_next+0xa8>
180007bb2:     	xorl	%r8d, %r8d
180007bb5:     	movl	$0x1, %ecx
180007bba:     	xchgq	%rcx, (%rax)
180007bbd:     	movq	%r8, 0x8(%rax)
180007bc1:     	movq	%r8, 0x10(%rax)
180007bc5:     	movq	%rdx, 0x18(%rax)
180007bc9:     	movq	%rbx, 0x20(%rax)
180007bcd:     	movq	%r8, 0x28(%rax)
180007bd1:     	cmpb	%r8b, 0x9028(%rip)      # 0x180010c00
180007bd8:     	je	0x180007bea <numba_list_iter_next+0xaa>
180007bda:     	lock
180007bdb:     	incq	0x9036(%rip)            # 0x180010c18
180007be2:     	addq	$0x20, %rsp
180007be6:     	popq	%rbx
180007be7:     	retq
180007be8:     	xorl	%eax, %eax
180007bea:     	addq	$0x20, %rsp
180007bee:     	popq	%rbx
180007bef:     	retq
180007bf0:     	movq	%rbx, 0x8(%rsp)
180007bf5:     	pushq	%rdi
180007bf6:     	subq	$0x20, %rsp
180007bfa:     	movq	%rcx, %rdi
180007bfd:     	movq	%rdx, %rbx
180007c00:     	addq	$0x30, %rcx
180007c04:     	testq	%rdx, %rdx
180007c07:     	je	0x180007c11 <numba_list_iter_next+0xd1>
180007c09:     	movq	0x18(%rdx), %rdx
180007c0d:     	callq	*(%rbx)
180007c0f:     	jmp	0x180007c17 <numba_list_iter_next+0xd7>
180007c11:     	callq	*0x9011(%rip)           # 0x180010c28
180007c17:     	cmpb	$0x0, 0x8fe2(%rip)      # 0x180010c00
180007c1e:     	movq	%rax, %r8
180007c21:     	je	0x180007c2b <numba_list_iter_next+0xeb>
180007c23:     	lock
180007c24:     	incq	0x8fdd(%rip)            # 0x180010c08
180007c2b:     	xorl	%edx, %edx
180007c2d:     	leaq	0x30(%r8), %rax
180007c31:     	testq	%r8, %r8
180007c34:     	movl	%edx, %ecx
180007c36:     	cmovneq	%rax, %rcx
180007c3a:     	testq	%rcx, %rcx
180007c3d:     	jne	0x180007c4c <numba_list_iter_next+0x10c>
180007c3f:     	xorl	%eax, %eax
180007c41:     	movq	0x30(%rsp), %rbx
180007c46:     	addq	$0x20, %rsp
180007c4a:     	popq	%rdi
180007c4b:     	retq
180007c4c:     	movl	$0x1, %eax
180007c51:     	xchgq	%rax, (%r8)
180007c54:     	movq	%rdx, 0x8(%r8)
180007c58:     	movq	%rdx, 0x10(%r8)
180007c5c:     	movq	%rcx, 0x18(%r8)
180007c60:     	movq	%rdi, 0x20(%r8)
180007c64:     	movq	%rbx, 0x28(%r8)
180007c68:     	cmpb	%dl, 0x8f92(%rip)       # 0x180010c00
180007c6e:     	je	0x180007c78 <numba_list_iter_next+0x138>
180007c70:     	lock
180007c71:     	incq	0x8fa0(%rip)            # 0x180010c18
180007c78:     	movq	0x30(%rsp), %rbx
180007c7d:     	movq	%r8, %rax
180007c80:     	addq	$0x20, %rsp
180007c84:     	popq	%rdi
180007c85:     	retq
180007c86:     	int3
180007c87:     	int3
180007c88:     	int3
180007c89:     	int3
180007c8a:     	int3
180007c8b:     	int3
180007c8c:     	int3
180007c8d:     	int3
180007c8e:     	int3
180007c8f:     	int3
180007c90:     	lock
180007c91:     	incq	(%rcx)
180007c94:     	retq
180007c95:     	int3
180007c96:     	int3
180007c97:     	int3
180007c98:     	int3
180007c99:     	int3
180007c9a:     	int3
180007c9b:     	int3
180007c9c:     	int3
180007c9d:     	int3
180007c9e:     	int3
180007c9f:     	int3
180007ca0:     	pushq	%rbx
180007ca2:     	subq	$0x20, %rsp
180007ca6:     	movq	0x8(%rcx), %rax
180007caa:     	movq	%rcx, %rbx
180007cad:     	testq	%rax, %rax
180007cb0:     	je	0x180007cc9 <numba_list_iter_next+0x189>
180007cb2:     	cmpl	$0x0, 0x8f3f(%rip)      # 0x180010bf8
180007cb9:     	jne	0x180007cc9 <numba_list_iter_next+0x189>
180007cbb:     	movq	0x10(%rcx), %r8
180007cbf:     	movq	0x20(%rcx), %rdx
180007cc3:     	movq	0x18(%rcx), %rcx
180007cc7:     	callq	*%rax
180007cc9:     	movq	0x28(%rbx), %rax
180007ccd:     	movq	%rbx, %rcx
180007cd0:     	testq	%rax, %rax
180007cd3:     	je	0x180007cde <numba_list_iter_next+0x19e>
180007cd5:     	movq	0x18(%rax), %rdx
180007cd9:     	callq	*0x10(%rax)
180007cdc:     	jmp	0x180007ce4 <numba_list_iter_next+0x1a4>
180007cde:     	callq	*0x8f54(%rip)           # 0x180010c38
180007ce4:     	cmpb	$0x0, 0x8f15(%rip)      # 0x180010c00
180007ceb:     	je	0x180007d09 <numba_list_iter_next+0x1c9>
180007ced:     	leaq	0x8f1c(%rip), %rax      # 0x180010c10
180007cf4:     	lock
180007cf5:     	incq	(%rax)
180007cf8:     	cmpb	$0x0, 0x8f01(%rip)      # 0x180010c00
180007cff:     	je	0x180007d09 <numba_list_iter_next+0x1c9>
180007d01:     	lock
180007d02:     	incq	0x8f17(%rip)            # 0x180010c20
180007d09:     	addq	$0x20, %rsp
180007d0d:     	popq	%rbx
180007d0e:     	retq
180007d0f:     	int3
180007d10:     	pushq	%rbx
180007d12:     	subq	$0x20, %rsp
180007d16:     	movq	%rcx, %rbx
180007d19:     	movq	$-0x1, %rax
180007d20:     	lock
180007d21:     	xaddq	%rax, (%rcx)
180007d25:     	cmpq	$0x1, %rax
180007d29:     	jne	0x180007d8b <numba_list_iter_next+0x24b>
180007d2b:     	movq	0x8(%rcx), %rax
180007d2f:     	testq	%rax, %rax
180007d32:     	je	0x180007d4b <numba_list_iter_next+0x20b>
180007d34:     	cmpl	$0x0, 0x8ebd(%rip)      # 0x180010bf8
180007d3b:     	jne	0x180007d4b <numba_list_iter_next+0x20b>
180007d3d:     	movq	0x10(%rcx), %r8
180007d41:     	movq	0x20(%rcx), %rdx
180007d45:     	movq	0x18(%rcx), %rcx
180007d49:     	callq	*%rax
180007d4b:     	movq	0x28(%rbx), %rax
180007d4f:     	movq	%rbx, %rcx
180007d52:     	testq	%rax, %rax
180007d55:     	je	0x180007d60 <numba_list_iter_next+0x220>
180007d57:     	movq	0x18(%rax), %rdx
180007d5b:     	callq	*0x10(%rax)
180007d5e:     	jmp	0x180007d66 <numba_list_iter_next+0x226>
180007d60:     	callq	*0x8ed2(%rip)           # 0x180010c38
180007d66:     	cmpb	$0x0, 0x8e93(%rip)      # 0x180010c00
180007d6d:     	je	0x180007d8b <numba_list_iter_next+0x24b>
180007d6f:     	leaq	0x8e9a(%rip), %rax      # 0x180010c10
180007d76:     	lock
180007d77:     	incq	(%rax)
180007d7a:     	cmpb	$0x0, 0x8e7f(%rip)      # 0x180010c00
180007d81:     	je	0x180007d8b <numba_list_iter_next+0x24b>
180007d83:     	lock
180007d84:     	incq	0x8e95(%rip)            # 0x180010c20
180007d8b:     	addq	$0x20, %rsp
180007d8f:     	popq	%rbx
180007d90:     	retq
180007d91:     	int3
180007d92:     	int3
180007d93:     	int3
180007d94:     	int3
180007d95:     	int3
180007d96:     	int3
180007d97:     	int3
180007d98:     	int3
180007d99:     	int3
180007d9a:     	int3
180007d9b:     	int3
180007d9c:     	int3
180007d9d:     	int3
180007d9e:     	int3
180007d9f:     	int3
180007da0:     	movq	0x18(%rcx), %rax
180007da4:     	retq
180007da5:     	int3
180007da6:     	int3
180007da7:     	int3
180007da8:     	int3
180007da9:     	int3
180007daa:     	int3
180007dab:     	int3
180007dac:     	int3
180007dad:     	int3
180007dae:     	int3
180007daf:     	int3
180007db0:     	subq	$0x28, %rsp
180007db4:     	callq	*0x8e7e(%rip)           # 0x180010c38
180007dba:     	cmpb	$0x0, 0x8e3f(%rip)      # 0x180010c00
180007dc1:     	je	0x180007dcb <numba_list_iter_next+0x28b>
180007dc3:     	lock
180007dc4:     	incq	0x8e45(%rip)            # 0x180010c10
180007dcb:     	addq	$0x28, %rsp
180007dcf:     	retq
180007dd0:     	jmpq	*%r8
180007dd3:     	int3
180007dd4:     	int3
180007dd5:     	int3
180007dd6:     	int3
180007dd7:     	int3
180007dd8:     	int3
180007dd9:     	int3
180007dda:     	int3
180007ddb:     	int3
180007ddc:     	int3
180007ddd:     	int3
180007dde:     	int3
180007ddf:     	int3
180007de0:     	movq	%rbx, 0x8(%rsp)
180007de5:     	pushq	%rdi
180007de6:     	subq	$0x20, %rsp
180007dea:     	movq	%rcx, %rdi
180007ded:     	movq	%rdx, %rbx
180007df0:     	movl	$0x30, %ecx
180007df5:     	callq	*0x8e2d(%rip)           # 0x180010c28
180007dfb:     	cmpb	$0x0, 0x8dfe(%rip)      # 0x180010c00
180007e02:     	je	0x180007e0c <numba_list_iter_next+0x2cc>
180007e04:     	lock
180007e05:     	incq	0x8dfc(%rip)            # 0x180010c08
180007e0c:     	testq	%rax, %rax
180007e0f:     	je	0x180007e46 <numba_list_iter_next+0x306>
180007e11:     	leaq	-0x48(%rip), %rcx       # 0x180007dd0 <numba_list_iter_next+0x290>
180007e18:     	movl	$0x1, %edx
180007e1d:     	xchgq	%rdx, (%rax)
180007e20:     	movq	%rcx, 0x8(%rax)
180007e24:     	xorl	%ecx, %ecx
180007e26:     	movq	%rcx, 0x20(%rax)
180007e2a:     	movq	%rcx, 0x28(%rax)
180007e2e:     	movq	%rbx, 0x10(%rax)
180007e32:     	movq	%rdi, 0x18(%rax)
180007e36:     	cmpb	%cl, 0x8dc4(%rip)       # 0x180010c00
180007e3c:     	je	0x180007e46 <numba_list_iter_next+0x306>
180007e3e:     	lock
180007e3f:     	incq	0x8dd2(%rip)            # 0x180010c18
180007e46:     	movq	0x30(%rsp), %rbx
180007e4b:     	addq	$0x20, %rsp
180007e4f:     	popq	%rdi
180007e50:     	retq
180007e51:     	jmpq	*0x14b9(%rip)           # 0x180009310
180007e57:     	jmpq	*0x14a3(%rip)           # 0x180009300
180007e5d:     	jmpq	*0x1495(%rip)           # 0x1800092f8
180007e63:     	jmpq	*0x1487(%rip)           # 0x1800092f0
180007e69:     	jmpq	*0x1479(%rip)           # 0x1800092e8
180007e6f:     	jmpq	*0x1463(%rip)           # 0x1800092d8
180007e75:     	jmpq	*0x1455(%rip)           # 0x1800092d0
180007e7b:     	jmpq	*0x1447(%rip)           # 0x1800092c8
180007e81:     	jmpq	*0x1431(%rip)           # 0x1800092b8
180007e87:     	jmpq	*0x140b(%rip)           # 0x180009298
180007e8d:     	jmpq	*0x13fd(%rip)           # 0x180009290
180007e93:     	jmpq	*0x13ef(%rip)           # 0x180009288
180007e99:     	jmpq	*0x13e1(%rip)           # 0x180009280
180007e9f:     	jmpq	*0x139b(%rip)           # 0x180009240
180007ea5:     	int3
180007ea6:     	int3
180007ea7:     	int3
180007ea8:     	int3
180007ea9:     	int3
180007eaa:     	int3
180007eab:     	int3
180007eac:     	int3
180007ead:     	int3
180007eae:     	int3
180007eaf:     	int3
180007eb0:     	int3
180007eb1:     	int3
180007eb2:     	int3
180007eb3:     	int3
180007eb4:     	int3
180007eb5:     	int3
180007eb6:     	nopw	(%rax,%rax)
180007ec0:     	cmpq	0x81f9(%rip), %rcx      # 0x1800100c0
180007ec7:     	jne	0x180007ed9 <numba_list_iter_next+0x399>
180007ec9:     	rolq	$0x10, %rcx
180007ecd:     	testw	$0xffff, %cx            # imm = 0xFFFF
180007ed2:     	jne	0x180007ed5 <numba_list_iter_next+0x395>
180007ed4:     	retq
180007ed5:     	rorq	$0x10, %rcx
180007ed9:     	jmp	0x180008234 <numba_list_iter_next+0x6f4>
180007ede:     	int3
180007edf:     	int3
180007ee0:     	subq	$0x28, %rsp
180007ee4:     	testl	%edx, %edx
180007ee6:     	je	0x180007f21 <numba_list_iter_next+0x3e1>
180007ee8:     	subl	$0x1, %edx
180007eeb:     	je	0x180007f15 <numba_list_iter_next+0x3d5>
180007eed:     	subl	$0x1, %edx
180007ef0:     	je	0x180007f08 <numba_list_iter_next+0x3c8>
180007ef2:     	cmpl	$0x1, %edx
180007ef5:     	je	0x180007f01 <numba_list_iter_next+0x3c1>
180007ef7:     	movl	$0x1, %eax
180007efc:     	addq	$0x28, %rsp
180007f00:     	retq
180007f01:     	callq	0x180008400 <numba_list_iter_next+0x8c0>
180007f06:     	jmp	0x180007f0d <numba_list_iter_next+0x3cd>
180007f08:     	callq	0x1800083d8 <numba_list_iter_next+0x898>
180007f0d:     	movzbl	%al, %eax
180007f10:     	addq	$0x28, %rsp
180007f14:     	retq
180007f15:     	movq	%r8, %rdx
180007f18:     	addq	$0x28, %rsp
180007f1c:     	jmp	0x180007f30 <numba_list_iter_next+0x3f0>
180007f21:     	testq	%r8, %r8
180007f24:     	setne	%cl
180007f27:     	addq	$0x28, %rsp
180007f2b:     	jmp	0x180008048 <numba_list_iter_next+0x508>
180007f30:     	movq	%rbx, 0x8(%rsp)
180007f35:     	movq	%rsi, 0x10(%rsp)
180007f3a:     	movq	%rdi, 0x20(%rsp)
180007f3f:     	pushq	%r14
180007f41:     	subq	$0x20, %rsp
180007f45:     	movq	%rdx, %rsi
180007f48:     	movq	%rcx, %r14
180007f4b:     	xorl	%ecx, %ecx
180007f4d:     	callq	0x1800084bc <numba_list_iter_next+0x97c>
180007f52:     	testb	%al, %al
180007f54:     	je	0x180008022 <numba_list_iter_next+0x4e2>
180007f5a:     	callq	0x180008350 <numba_list_iter_next+0x810>
180007f5f:     	movb	%al, %bl
180007f61:     	movb	%al, 0x40(%rsp)
180007f65:     	movb	$0x1, %dil
180007f68:     	cmpl	$0x0, 0x8a59(%rip)      # 0x1800109c8
180007f6f:     	jne	0x18000803a <numba_list_iter_next+0x4fa>
180007f75:     	movl	$0x1, 0x8a49(%rip)      # 0x1800109c8
180007f7f:     	callq	0x1800083c0 <numba_list_iter_next+0x880>
180007f84:     	testb	%al, %al
180007f86:     	je	0x180007fd7 <numba_list_iter_next+0x497>
180007f88:     	callq	0x18000867c <numba_list_iter_next+0xb3c>
180007f8d:     	callq	0x180008310 <numba_list_iter_next+0x7d0>
180007f92:     	callq	0x180008334 <numba_list_iter_next+0x7f4>
180007f97:     	leaq	0x13d2(%rip), %rdx      # 0x180009370
180007f9e:     	leaq	0x13c3(%rip), %rcx      # 0x180009368
180007fa5:     	callq	0x1800089c8 <numba_list_iter_next+0xe88>
180007faa:     	testl	%eax, %eax
180007fac:     	jne	0x180007fd7 <numba_list_iter_next+0x497>
180007fae:     	callq	0x18000838c <numba_list_iter_next+0x84c>
180007fb3:     	testb	%al, %al
180007fb5:     	je	0x180007fd7 <numba_list_iter_next+0x497>
180007fb7:     	leaq	0x13a2(%rip), %rdx      # 0x180009360
180007fbe:     	leaq	0x1393(%rip), %rcx      # 0x180009358
180007fc5:     	callq	0x1800089c2 <numba_list_iter_next+0xe82>
180007fca:     	movl	$0x2, 0x89f4(%rip)      # 0x1800109c8
180007fd4:     	xorb	%dil, %dil
180007fd7:     	movb	%bl, %cl
180007fd9:     	callq	0x18000861c <numba_list_iter_next+0xadc>
180007fde:     	testb	%dil, %dil
180007fe1:     	jne	0x180008022 <numba_list_iter_next+0x4e2>
180007fe3:     	callq	0x18000866c <numba_list_iter_next+0xb2c>
180007fe8:     	movq	%rax, %rbx
180007feb:     	cmpq	$0x0, (%rax)
180007fef:     	je	0x180008015 <numba_list_iter_next+0x4d5>
180007ff1:     	movq	%rax, %rcx
180007ff4:     	callq	0x180008584 <numba_list_iter_next+0xa44>
180007ff9:     	testb	%al, %al
180007ffb:     	je	0x180008015 <numba_list_iter_next+0x4d5>
180007ffd:     	movq	%rsi, %r8
180008000:     	movl	$0x2, %edx
180008005:     	movq	%r14, %rcx
180008008:     	movq	(%rbx), %rax
18000800b:     	movq	0x131e(%rip), %r9       # 0x180009330
180008012:     	callq	*%r9
180008015:     	incl	0x8985(%rip)            # 0x1800109a0
18000801b:     	movl	$0x1, %eax
180008020:     	jmp	0x180008024 <numba_list_iter_next+0x4e4>
180008022:     	xorl	%eax, %eax
180008024:     	movq	0x30(%rsp), %rbx
180008029:     	movq	0x38(%rsp), %rsi
18000802e:     	movq	0x48(%rsp), %rdi
180008033:     	addq	$0x20, %rsp
180008037:     	popq	%r14
180008039:     	retq
18000803a:     	movl	$0x7, %ecx
18000803f:     	callq	0x180008674 <numba_list_iter_next+0xb34>
180008044:     	nop
180008045:     	int3
180008046:     	int3
180008047:     	int3
180008048:     	movq	%rbx, 0x8(%rsp)
18000804d:     	pushq	%rdi
18000804e:     	subq	$0x30, %rsp
180008052:     	movb	%cl, %dil
180008055:     	movl	0x8945(%rip), %eax      # 0x1800109a0
18000805b:     	testl	%eax, %eax
18000805d:     	jg	0x18000806c <numba_list_iter_next+0x52c>
18000805f:     	xorl	%eax, %eax
180008061:     	movq	0x40(%rsp), %rbx
180008066:     	addq	$0x30, %rsp
18000806a:     	popq	%rdi
18000806b:     	retq
18000806c:     	decl	%eax
18000806e:     	movl	%eax, 0x892c(%rip)      # 0x1800109a0
180008074:     	callq	0x180008350 <numba_list_iter_next+0x810>
180008079:     	movb	%al, %bl
18000807b:     	movb	%al, 0x20(%rsp)
18000807f:     	cmpl	$0x2, 0x8942(%rip)      # 0x1800109c8
180008086:     	jne	0x1800080be <numba_list_iter_next+0x57e>
180008088:     	callq	0x180008478 <numba_list_iter_next+0x938>
18000808d:     	callq	0x180008320 <numba_list_iter_next+0x7e0>
180008092:     	callq	0x1800086b8 <numba_list_iter_next+0xb78>
180008097:     	movl	$0x0, 0x8927(%rip)      # 0x1800109c8
1800080a1:     	movb	%bl, %cl
1800080a3:     	callq	0x18000861c <numba_list_iter_next+0xadc>
1800080a8:     	xorl	%edx, %edx
1800080aa:     	movb	%dil, %cl
1800080ad:     	callq	0x180008640 <numba_list_iter_next+0xb00>
1800080b2:     	movzbl	%al, %ebx
1800080b5:     	callq	0x1800084a8 <numba_list_iter_next+0x968>
1800080ba:     	movl	%ebx, %eax
1800080bc:     	jmp	0x180008061 <numba_list_iter_next+0x521>
1800080be:     	movl	$0x7, %ecx
1800080c3:     	callq	0x180008674 <numba_list_iter_next+0xb34>
1800080c8:     	nop
1800080c9:     	nop
1800080ca:     	int3
1800080cb:     	int3
1800080cc:     	movq	%rsp, %rax
1800080cf:     	movq	%rbx, 0x20(%rax)
1800080d3:     	movq	%r8, 0x18(%rax)
1800080d7:     	movl	%edx, 0x10(%rax)
1800080da:     	movq	%rcx, 0x8(%rax)
1800080de:     	pushq	%rsi
1800080df:     	pushq	%rdi
1800080e0:     	pushq	%r14
1800080e2:     	subq	$0x40, %rsp
1800080e6:     	movq	%r8, %rsi
1800080e9:     	movl	%edx, %edi
1800080eb:     	movq	%rcx, %r14
1800080ee:     	testl	%edx, %edx
1800080f0:     	jne	0x180008101 <numba_list_iter_next+0x5c1>
1800080f2:     	cmpl	%edx, 0x88a8(%rip)      # 0x1800109a0
1800080f8:     	jg	0x180008101 <numba_list_iter_next+0x5c1>
1800080fa:     	xorl	%eax, %eax
1800080fc:     	jmp	0x1800081e6 <numba_list_iter_next+0x6a6>
180008101:     	leal	-0x1(%rdx), %eax
180008104:     	cmpl	$0x1, %eax
180008107:     	ja	0x180008149 <numba_list_iter_next+0x609>
180008109:     	movq	0x1878(%rip), %rax      # 0x180009988
180008110:     	testq	%rax, %rax
180008113:     	jne	0x18000811a <numba_list_iter_next+0x5da>
180008115:     	leal	0x1(%rax), %ebx
180008118:     	jmp	0x180008122 <numba_list_iter_next+0x5e2>
18000811a:     	callq	*0x1210(%rip)           # 0x180009330
180008120:     	movl	%eax, %ebx
180008122:     	movl	%ebx, 0x30(%rsp)
180008126:     	testl	%ebx, %ebx
180008128:     	je	0x1800081dc <numba_list_iter_next+0x69c>
18000812e:     	movq	%rsi, %r8
180008131:     	movl	%edi, %edx
180008133:     	movq	%r14, %rcx
180008136:     	callq	0x180007ee0 <numba_list_iter_next+0x3a0>
18000813b:     	movl	%eax, %ebx
18000813d:     	movl	%eax, 0x30(%rsp)
180008141:     	testl	%eax, %eax
180008143:     	je	0x1800081dc <numba_list_iter_next+0x69c>
180008149:     	movq	%rsi, %r8
18000814c:     	movl	%edi, %edx
18000814e:     	movq	%r14, %rcx
180008151:     	callq	0x1800082ec <numba_list_iter_next+0x7ac>
180008156:     	movl	%eax, %ebx
180008158:     	movl	%eax, 0x30(%rsp)
18000815c:     	cmpl	$0x1, %edi
18000815f:     	jne	0x180008197 <numba_list_iter_next+0x657>
180008161:     	testl	%eax, %eax
180008163:     	jne	0x180008197 <numba_list_iter_next+0x657>
180008165:     	movq	%rsi, %r8
180008168:     	xorl	%edx, %edx
18000816a:     	movq	%r14, %rcx
18000816d:     	callq	0x1800082ec <numba_list_iter_next+0x7ac>
180008172:     	testq	%rsi, %rsi
180008175:     	setne	%cl
180008178:     	callq	0x180008048 <numba_list_iter_next+0x508>
18000817d:     	movq	0x1804(%rip), %rax      # 0x180009988
180008184:     	testq	%rax, %rax
180008187:     	je	0x180008197 <numba_list_iter_next+0x657>
180008189:     	movq	%rsi, %r8
18000818c:     	xorl	%edx, %edx
18000818e:     	movq	%r14, %rcx
180008191:     	callq	*0x1199(%rip)           # 0x180009330
180008197:     	testl	%edi, %edi
180008199:     	je	0x1800081a0 <numba_list_iter_next+0x660>
18000819b:     	cmpl	$0x3, %edi
18000819e:     	jne	0x1800081dc <numba_list_iter_next+0x69c>
1800081a0:     	movq	%rsi, %r8
1800081a3:     	movl	%edi, %edx
1800081a5:     	movq	%r14, %rcx
1800081a8:     	callq	0x180007ee0 <numba_list_iter_next+0x3a0>
1800081ad:     	movl	%eax, %ebx
1800081af:     	movl	%eax, 0x30(%rsp)
1800081b3:     	testl	%eax, %eax
1800081b5:     	je	0x1800081dc <numba_list_iter_next+0x69c>
1800081b7:     	movq	0x17ca(%rip), %rax      # 0x180009988
1800081be:     	testq	%rax, %rax
1800081c1:     	jne	0x1800081c8 <numba_list_iter_next+0x688>
1800081c3:     	leal	0x1(%rax), %ebx
1800081c6:     	jmp	0x1800081d8 <numba_list_iter_next+0x698>
1800081c8:     	movq	%rsi, %r8
1800081cb:     	movl	%edi, %edx
1800081cd:     	movq	%r14, %rcx
1800081d0:     	callq	*0x115a(%rip)           # 0x180009330
1800081d6:     	movl	%eax, %ebx
1800081d8:     	movl	%ebx, 0x30(%rsp)
1800081dc:     	jmp	0x1800081e4 <numba_list_iter_next+0x6a4>
1800081de:     	xorl	%ebx, %ebx
1800081e0:     	movl	%ebx, 0x30(%rsp)
1800081e4:     	movl	%ebx, %eax
1800081e6:     	movq	0x78(%rsp), %rbx
1800081eb:     	addq	$0x40, %rsp
1800081ef:     	popq	%r14
1800081f1:     	popq	%rdi
1800081f2:     	popq	%rsi
1800081f3:     	retq
1800081f4:     	movq	%rbx, 0x8(%rsp)
1800081f9:     	movq	%rsi, 0x10(%rsp)
1800081fe:     	pushq	%rdi
1800081ff:     	subq	$0x20, %rsp
180008203:     	movq	%r8, %rdi
180008206:     	movl	%edx, %ebx
180008208:     	movq	%rcx, %rsi
18000820b:     	cmpl	$0x1, %edx
18000820e:     	jne	0x180008215 <numba_list_iter_next+0x6d5>
180008210:     	callq	0x18000823c <numba_list_iter_next+0x6fc>
180008215:     	movq	%rdi, %r8
180008218:     	movl	%ebx, %edx
18000821a:     	movq	%rsi, %rcx
18000821d:     	movq	0x30(%rsp), %rbx
180008222:     	movq	0x38(%rsp), %rsi
180008227:     	addq	$0x20, %rsp
18000822b:     	popq	%rdi
18000822c:     	jmp	0x1800080cc <numba_list_iter_next+0x58c>
180008231:     	int3
180008232:     	int3
180008233:     	int3
180008234:     	movl	$0x2, %ecx
180008239:     	int	$0x29
18000823b:     	retq
18000823c:     	movq	%rbx, 0x18(%rsp)
180008241:     	pushq	%rbp
180008242:     	movq	%rsp, %rbp
180008245:     	subq	$0x30, %rsp
180008249:     	movq	0x7e70(%rip), %rax      # 0x1800100c0
180008250:     	movabsq	$0x2b992ddfa232, %rbx   # imm = 0x2B992DDFA232
18000825a:     	cmpq	%rbx, %rax
18000825d:     	jne	0x1800082d6 <numba_list_iter_next+0x796>
18000825f:     	leaq	0x10(%rbp), %rcx
180008263:     	movq	$0x0, 0x10(%rbp)
18000826b:     	callq	*0xdb7(%rip)            # 0x180009028
180008271:     	movq	0x10(%rbp), %rax
180008275:     	movq	%rax, -0x10(%rbp)
180008279:     	callq	*0xd91(%rip)            # 0x180009010
18000827f:     	movl	%eax, %eax
180008281:     	xorq	%rax, -0x10(%rbp)
180008285:     	callq	*0xd7d(%rip)            # 0x180009008
18000828b:     	movl	%eax, %eax
18000828d:     	leaq	0x18(%rbp), %rcx
180008291:     	xorq	%rax, -0x10(%rbp)
180008295:     	callq	*0xd65(%rip)            # 0x180009000
18000829b:     	movl	0x18(%rbp), %eax
18000829e:     	leaq	-0x10(%rbp), %rcx
1800082a2:     	shlq	$0x20, %rax
1800082a6:     	xorq	0x18(%rbp), %rax
1800082aa:     	xorq	-0x10(%rbp), %rax
1800082ae:     	xorq	%rcx, %rax
1800082b1:     	movabsq	$0xffffffffffff, %rcx   # imm = 0xFFFFFFFFFFFF
1800082bb:     	andq	%rcx, %rax
1800082be:     	movabsq	$0x2b992ddfa233, %rcx   # imm = 0x2B992DDFA233
1800082c8:     	cmpq	%rbx, %rax
1800082cb:     	cmoveq	%rcx, %rax
1800082cf:     	movq	%rax, 0x7dea(%rip)      # 0x1800100c0
1800082d6:     	movq	0x50(%rsp), %rbx
1800082db:     	notq	%rax
1800082de:     	movq	%rax, 0x7e1b(%rip)      # 0x180010100
1800082e5:     	addq	$0x30, %rsp
1800082e9:     	popq	%rbp
1800082ea:     	retq
1800082eb:     	int3
1800082ec:     	subq	$0x28, %rsp
1800082f0:     	cmpl	$0x1, %edx
1800082f3:     	jne	0x180008305 <numba_list_iter_next+0x7c5>
1800082f5:     	cmpq	$0x0, 0x168b(%rip)      # 0x180009988
1800082fd:     	jne	0x180008305 <numba_list_iter_next+0x7c5>
1800082ff:     	callq	*0xd1b(%rip)            # 0x180009020
180008305:     	movl	$0x1, %eax
18000830a:     	addq	$0x28, %rsp
18000830e:     	retq
18000830f:     	int3
180008310:     	leaq	0x8699(%rip), %rcx      # 0x1800109b0
180008317:     	jmpq	*0xcfa(%rip)            # 0x180009018
18000831e:     	int3
18000831f:     	int3
180008320:     	leaq	0x8689(%rip), %rcx      # 0x1800109b0
180008327:     	jmp	0x1800089b6 <numba_list_iter_next+0xe76>
18000832c:     	leaq	0x868d(%rip), %rax      # 0x1800109c0
180008333:     	retq
180008334:     	subq	$0x28, %rsp
180008338:     	callq	0x180007450 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x5ad0>
18000833d:     	orq	$0x24, (%rax)
180008341:     	callq	0x18000832c <numba_list_iter_next+0x7ec>
180008346:     	orq	$0x2, (%rax)
18000834a:     	addq	$0x28, %rsp
18000834e:     	retq
18000834f:     	int3
180008350:     	subq	$0x28, %rsp
180008354:     	callq	0x18000899c <numba_list_iter_next+0xe5c>
180008359:     	testl	%eax, %eax
18000835b:     	je	0x18000837e <numba_list_iter_next+0x83e>
18000835d:     	movq	%gs:0x30, %rax
180008366:     	movq	0x8(%rax), %rcx
18000836a:     	jmp	0x180008371 <numba_list_iter_next+0x831>
18000836c:     	cmpq	%rax, %rcx
18000836f:     	je	0x180008385 <numba_list_iter_next+0x845>
180008371:     	xorl	%eax, %eax
180008373:     	lock
180008374:     	cmpxchgq	%rcx, 0x8654(%rip)      # 0x1800109d0
18000837c:     	jne	0x18000836c <numba_list_iter_next+0x82c>
18000837e:     	xorb	%al, %al
180008380:     	addq	$0x28, %rsp
180008384:     	retq
180008385:     	movb	$0x1, %al
180008387:     	jmp	0x180008380 <numba_list_iter_next+0x840>
180008389:     	int3
18000838a:     	int3
18000838b:     	int3
18000838c:     	subq	$0x28, %rsp
180008390:     	callq	0x18000899c <numba_list_iter_next+0xe5c>
180008395:     	testl	%eax, %eax
180008397:     	je	0x1800083a0 <numba_list_iter_next+0x860>
180008399:     	callq	0x1800086f8 <numba_list_iter_next+0xbb8>
18000839e:     	jmp	0x1800083b9 <numba_list_iter_next+0x879>
1800083a0:     	callq	0x180008994 <numba_list_iter_next+0xe54>
1800083a5:     	movl	%eax, %ecx
1800083a7:     	callq	0x1800089d4 <numba_list_iter_next+0xe94>
1800083ac:     	testl	%eax, %eax
1800083ae:     	je	0x1800083b4 <numba_list_iter_next+0x874>
1800083b0:     	xorb	%al, %al
1800083b2:     	jmp	0x1800083bb <numba_list_iter_next+0x87b>
1800083b4:     	callq	0x1800089da <numba_list_iter_next+0xe9a>
1800083b9:     	movb	$0x1, %al
1800083bb:     	addq	$0x28, %rsp
1800083bf:     	retq
1800083c0:     	subq	$0x28, %rsp
1800083c4:     	xorl	%ecx, %ecx
1800083c6:     	callq	0x1800084f8 <numba_list_iter_next+0x9b8>
1800083cb:     	testb	%al, %al
1800083cd:     	setne	%al
1800083d0:     	addq	$0x28, %rsp
1800083d4:     	retq
1800083d5:     	int3
1800083d6:     	int3
1800083d7:     	int3
1800083d8:     	subq	$0x28, %rsp
1800083dc:     	callq	0x1800089f4 <numba_list_iter_next+0xeb4>
1800083e1:     	testb	%al, %al
1800083e3:     	jne	0x1800083e9 <numba_list_iter_next+0x8a9>
1800083e5:     	xorb	%al, %al
1800083e7:     	jmp	0x1800083fb <numba_list_iter_next+0x8bb>
1800083e9:     	callq	0x1800089f4 <numba_list_iter_next+0xeb4>
1800083ee:     	testb	%al, %al
1800083f0:     	jne	0x1800083f9 <numba_list_iter_next+0x8b9>
1800083f2:     	callq	0x1800089f4 <numba_list_iter_next+0xeb4>
1800083f7:     	jmp	0x1800083e5 <numba_list_iter_next+0x8a5>
1800083f9:     	movb	$0x1, %al
1800083fb:     	addq	$0x28, %rsp
1800083ff:     	retq
180008400:     	subq	$0x28, %rsp
180008404:     	callq	0x1800089f4 <numba_list_iter_next+0xeb4>
180008409:     	callq	0x1800089f4 <numba_list_iter_next+0xeb4>
18000840e:     	movb	$0x1, %al
180008410:     	addq	$0x28, %rsp
180008414:     	retq
180008415:     	int3
180008416:     	int3
180008417:     	int3
180008418:     	movq	%rbx, 0x8(%rsp)
18000841d:     	movq	%rbp, 0x10(%rsp)
180008422:     	movq	%rsi, 0x18(%rsp)
180008427:     	pushq	%rdi
180008428:     	subq	$0x20, %rsp
18000842c:     	movq	%r9, %rdi
18000842f:     	movq	%r8, %rsi
180008432:     	movl	%edx, %ebx
180008434:     	movq	%rcx, %rbp
180008437:     	callq	0x18000899c <numba_list_iter_next+0xe5c>
18000843c:     	testl	%eax, %eax
18000843e:     	jne	0x180008456 <numba_list_iter_next+0x916>
180008440:     	cmpl	$0x1, %ebx
180008443:     	jne	0x180008456 <numba_list_iter_next+0x916>
180008445:     	movq	%rsi, %r8
180008448:     	xorl	%edx, %edx
18000844a:     	movq	%rbp, %rcx
18000844d:     	movq	%rdi, %rax
180008450:     	callq	*0xeda(%rip)            # 0x180009330
180008456:     	movq	0x58(%rsp), %rdx
18000845b:     	movl	0x50(%rsp), %ecx
18000845f:     	movq	0x30(%rsp), %rbx
180008464:     	movq	0x38(%rsp), %rbp
180008469:     	movq	0x40(%rsp), %rsi
18000846e:     	addq	$0x20, %rsp
180008472:     	popq	%rdi
180008473:     	jmp	0x1800089ce <numba_list_iter_next+0xe8e>
180008478:     	subq	$0x28, %rsp
18000847c:     	callq	0x18000899c <numba_list_iter_next+0xe5c>
180008481:     	testl	%eax, %eax
180008483:     	je	0x180008495 <numba_list_iter_next+0x955>
180008485:     	leaq	0x8554(%rip), %rcx      # 0x1800109e0
18000848c:     	addq	$0x28, %rsp
180008490:     	jmp	0x1800089e6 <numba_list_iter_next+0xea6>
180008495:     	callq	0x1800089f8 <numba_list_iter_next+0xeb8>
18000849a:     	testl	%eax, %eax
18000849c:     	jne	0x1800084a3 <numba_list_iter_next+0x963>
18000849e:     	callq	0x1800089ec <numba_list_iter_next+0xeac>
1800084a3:     	addq	$0x28, %rsp
1800084a7:     	retq
1800084a8:     	subq	$0x28, %rsp
1800084ac:     	xorl	%ecx, %ecx
1800084ae:     	callq	0x1800089f4 <numba_list_iter_next+0xeb4>
1800084b3:     	addq	$0x28, %rsp
1800084b7:     	jmp	0x1800089f4 <numba_list_iter_next+0xeb4>
1800084bc:     	subq	$0x28, %rsp
1800084c0:     	testl	%ecx, %ecx
1800084c2:     	jne	0x1800084cb <numba_list_iter_next+0x98b>
1800084c4:     	movb	$0x1, 0x850d(%rip)      # 0x1800109d8
1800084cb:     	callq	0x1800086f8 <numba_list_iter_next+0xbb8>
1800084d0:     	callq	0x1800089f4 <numba_list_iter_next+0xeb4>
1800084d5:     	testb	%al, %al
1800084d7:     	jne	0x1800084dd <numba_list_iter_next+0x99d>
1800084d9:     	xorb	%al, %al
1800084db:     	jmp	0x1800084f1 <numba_list_iter_next+0x9b1>
1800084dd:     	callq	0x1800089f4 <numba_list_iter_next+0xeb4>
1800084e2:     	testb	%al, %al
1800084e4:     	jne	0x1800084ef <numba_list_iter_next+0x9af>
1800084e6:     	xorl	%ecx, %ecx
1800084e8:     	callq	0x1800089f4 <numba_list_iter_next+0xeb4>
1800084ed:     	jmp	0x1800084d9 <numba_list_iter_next+0x999>
1800084ef:     	movb	$0x1, %al
1800084f1:     	addq	$0x28, %rsp
1800084f5:     	retq
1800084f6:     	int3
1800084f7:     	int3
1800084f8:     	pushq	%rbx
1800084fa:     	subq	$0x20, %rsp
1800084fe:     	cmpb	$0x0, 0x84d4(%rip)      # 0x1800109d9
180008505:     	movl	%ecx, %ebx
180008507:     	jne	0x180008570 <numba_list_iter_next+0xa30>
180008509:     	cmpl	$0x1, %ecx
18000850c:     	ja	0x180008578 <numba_list_iter_next+0xa38>
18000850e:     	callq	0x18000899c <numba_list_iter_next+0xe5c>
180008513:     	testl	%eax, %eax
180008515:     	je	0x18000853f <numba_list_iter_next+0x9ff>
180008517:     	testl	%ebx, %ebx
180008519:     	jne	0x18000853f <numba_list_iter_next+0x9ff>
18000851b:     	leaq	0x84be(%rip), %rcx      # 0x1800109e0
180008522:     	callq	0x1800089e0 <numba_list_iter_next+0xea0>
180008527:     	testl	%eax, %eax
180008529:     	jne	0x18000853b <numba_list_iter_next+0x9fb>
18000852b:     	leaq	0x84c6(%rip), %rcx      # 0x1800109f8
180008532:     	callq	0x1800089e0 <numba_list_iter_next+0xea0>
180008537:     	testl	%eax, %eax
180008539:     	je	0x180008569 <numba_list_iter_next+0xa29>
18000853b:     	xorb	%al, %al
18000853d:     	jmp	0x180008572 <numba_list_iter_next+0xa32>
18000853f:     	movdqa	0x1449(%rip), %xmm0     # 0x180009990
180008547:     	orq	$-0x1, %rax
18000854b:     	movdqu	%xmm0, 0x848d(%rip)     # 0x1800109e0
180008553:     	movq	%rax, 0x8496(%rip)      # 0x1800109f0
18000855a:     	movdqu	%xmm0, 0x8496(%rip)     # 0x1800109f8
180008562:     	movq	%rax, 0x849f(%rip)      # 0x180010a08
180008569:     	movb	$0x1, 0x8469(%rip)      # 0x1800109d9
180008570:     	movb	$0x1, %al
180008572:     	addq	$0x20, %rsp
180008576:     	popq	%rbx
180008577:     	retq
180008578:     	movl	$0x5, %ecx
18000857d:     	callq	0x180008674 <numba_list_iter_next+0xb34>
180008582:     	int3
180008583:     	int3
180008584:     	subq	$0x18, %rsp
180008588:     	movq	%rcx, %r8
18000858b:     	movl	$0x5a4d, %eax           # imm = 0x5A4D
180008590:     	cmpw	%ax, -0x8597(%rip)      # 0x180000000
180008597:     	jne	0x180008611 <numba_list_iter_next+0xad1>
180008599:     	movslq	-0x8564(%rip), %rcx     # 0x18000003c
1800085a0:     	leaq	-0x85a7(%rip), %rdx     # 0x180000000
1800085a7:     	addq	%rdx, %rcx
1800085aa:     	cmpl	$0x4550, (%rcx)         # imm = 0x4550
1800085b0:     	jne	0x180008611 <numba_list_iter_next+0xad1>
1800085b2:     	movl	$0x20b, %eax            # imm = 0x20B
1800085b7:     	cmpw	%ax, 0x18(%rcx)
1800085bb:     	jne	0x180008611 <numba_list_iter_next+0xad1>
1800085bd:     	subq	%rdx, %r8
1800085c0:     	movzwl	0x14(%rcx), %edx
1800085c4:     	addq	$0x18, %rdx
1800085c8:     	addq	%rcx, %rdx
1800085cb:     	movzwl	0x6(%rcx), %eax
1800085cf:     	leaq	(%rax,%rax,4), %rcx
1800085d3:     	leaq	(%rdx,%rcx,8), %r9
1800085d7:     	movq	%rdx, (%rsp)
1800085db:     	cmpq	%r9, %rdx
1800085de:     	je	0x1800085f8 <numba_list_iter_next+0xab8>
1800085e0:     	movl	0xc(%rdx), %ecx
1800085e3:     	cmpq	%rcx, %r8
1800085e6:     	jb	0x1800085f2 <numba_list_iter_next+0xab2>
1800085e8:     	movl	0x8(%rdx), %eax
1800085eb:     	addl	%ecx, %eax
1800085ed:     	cmpq	%rax, %r8
1800085f0:     	jb	0x1800085fa <numba_list_iter_next+0xaba>
1800085f2:     	addq	$0x28, %rdx
1800085f6:     	jmp	0x1800085d7 <numba_list_iter_next+0xa97>
1800085f8:     	xorl	%edx, %edx
1800085fa:     	testq	%rdx, %rdx
1800085fd:     	jne	0x180008603 <numba_list_iter_next+0xac3>
1800085ff:     	xorb	%al, %al
180008601:     	jmp	0x180008617 <numba_list_iter_next+0xad7>
180008603:     	cmpl	$0x0, 0x24(%rdx)
180008607:     	jge	0x18000860d <numba_list_iter_next+0xacd>
180008609:     	xorb	%al, %al
18000860b:     	jmp	0x180008617 <numba_list_iter_next+0xad7>
18000860d:     	movb	$0x1, %al
18000860f:     	jmp	0x180008617 <numba_list_iter_next+0xad7>
180008611:     	xorb	%al, %al
180008613:     	jmp	0x180008617 <numba_list_iter_next+0xad7>
180008615:     	xorb	%al, %al
180008617:     	addq	$0x18, %rsp
18000861b:     	retq
18000861c:     	pushq	%rbx
18000861e:     	subq	$0x20, %rsp
180008622:     	movb	%cl, %bl
180008624:     	callq	0x18000899c <numba_list_iter_next+0xe5c>
180008629:     	xorl	%edx, %edx
18000862b:     	testl	%eax, %eax
18000862d:     	je	0x18000863a <numba_list_iter_next+0xafa>
18000862f:     	testb	%bl, %bl
180008631:     	jne	0x18000863a <numba_list_iter_next+0xafa>
180008633:     	xchgq	%rdx, 0x8396(%rip)      # 0x1800109d0
18000863a:     	addq	$0x20, %rsp
18000863e:     	popq	%rbx
18000863f:     	retq
180008640:     	pushq	%rbx
180008642:     	subq	$0x20, %rsp
180008646:     	cmpb	$0x0, 0x838b(%rip)      # 0x1800109d8
18000864d:     	movb	%cl, %bl
18000864f:     	je	0x180008655 <numba_list_iter_next+0xb15>
180008651:     	testb	%dl, %dl
180008653:     	jne	0x180008661 <numba_list_iter_next+0xb21>
180008655:     	callq	0x1800089f4 <numba_list_iter_next+0xeb4>
18000865a:     	movb	%bl, %cl
18000865c:     	callq	0x1800089f4 <numba_list_iter_next+0xeb4>
180008661:     	movb	$0x1, %al
180008663:     	addq	$0x20, %rsp
180008667:     	popq	%rbx
180008668:     	retq
180008669:     	int3
18000866a:     	int3
18000866b:     	int3
18000866c:     	leaq	0x8625(%rip), %rax      # 0x180010c98
180008673:     	retq
180008674:     	movl	%ecx, %ecx
180008676:     	int	$0x29
180008678:     	retq
180008679:     	int3
18000867a:     	int3
18000867b:     	int3
18000867c:     	movq	%rbx, 0x8(%rsp)
180008681:     	pushq	%rdi
180008682:     	subq	$0x20, %rsp
180008686:     	leaq	0x3d3b(%rip), %rbx      # 0x18000c3c8
18000868d:     	leaq	0x3d34(%rip), %rdi      # 0x18000c3c8
180008694:     	jmp	0x1800086a8 <numba_list_iter_next+0xb68>
180008696:     	movq	(%rbx), %rax
180008699:     	testq	%rax, %rax
18000869c:     	je	0x1800086a4 <numba_list_iter_next+0xb64>
18000869e:     	callq	*0xc8c(%rip)            # 0x180009330
1800086a4:     	addq	$0x8, %rbx
1800086a8:     	cmpq	%rdi, %rbx
1800086ab:     	jb	0x180008696 <numba_list_iter_next+0xb56>
1800086ad:     	movq	0x30(%rsp), %rbx
1800086b2:     	addq	$0x20, %rsp
1800086b6:     	popq	%rdi
1800086b7:     	retq
1800086b8:     	movq	%rbx, 0x8(%rsp)
1800086bd:     	pushq	%rdi
1800086be:     	subq	$0x20, %rsp
1800086c2:     	leaq	0x3d0f(%rip), %rbx      # 0x18000c3d8
1800086c9:     	leaq	0x3d08(%rip), %rdi      # 0x18000c3d8
1800086d0:     	jmp	0x1800086e4 <numba_list_iter_next+0xba4>
1800086d2:     	movq	(%rbx), %rax
1800086d5:     	testq	%rax, %rax
1800086d8:     	je	0x1800086e0 <numba_list_iter_next+0xba0>
1800086da:     	callq	*0xc50(%rip)            # 0x180009330
1800086e0:     	addq	$0x8, %rbx
1800086e4:     	cmpq	%rdi, %rbx
1800086e7:     	jb	0x1800086d2 <numba_list_iter_next+0xb92>
1800086e9:     	movq	0x30(%rsp), %rbx
1800086ee:     	addq	$0x20, %rsp
1800086f2:     	popq	%rdi
1800086f3:     	retq
1800086f4:     	retq	$0x0
1800086f7:     	int3
1800086f8:     	movq	%rbx, 0x10(%rsp)
1800086fd:     	movq	%rbp, 0x18(%rsp)
180008702:     	movq	%rsi, 0x20(%rsp)
180008707:     	pushq	%rdi
180008708:     	subq	$0x10, %rsp
18000870c:     	xorl	%eax, %eax
18000870e:     	xorl	%ecx, %ecx
180008710:     	cpuid
180008712:     	xorl	$0x6c65746e, %ecx       # imm = 0x6C65746E
180008718:     	xorl	$0x49656e69, %edx       # imm = 0x49656E69
18000871e:     	orl	%ecx, %edx
180008720:     	movl	%eax, %ebp
180008722:     	movl	$0x1, %eax
180008727:     	xorl	$0x756e6547, %ebx       # imm = 0x756E6547
18000872d:     	orl	%ebx, %edx
18000872f:     	leal	-0x1(%rax), %ecx
180008732:     	cpuid
180008734:     	movl	%ecx, %edi
180008736:     	jne	0x180008796 <numba_list_iter_next+0xc56>
180008738:     	andl	$0xfff3ff0, %eax        # imm = 0xFFF3FF0
18000873d:     	movq	$0x8000, 0x79d0(%rip)   # imm = 0x8000
                                                # 0x180010118
180008748:     	movq	$-0x1, 0x79cd(%rip)     # 0x180010120
180008753:     	cmpl	$0x106c0, %eax          # imm = 0x106C0
180008758:     	je	0x180008782 <numba_list_iter_next+0xc42>
18000875a:     	cmpl	$0x20660, %eax          # imm = 0x20660
18000875f:     	je	0x180008782 <numba_list_iter_next+0xc42>
180008761:     	cmpl	$0x20670, %eax          # imm = 0x20670
180008766:     	je	0x180008782 <numba_list_iter_next+0xc42>
180008768:     	addl	$0xfffcf9b0, %eax       # imm = 0xFFFCF9B0
18000876d:     	cmpl	$0x20, %eax
180008770:     	ja	0x180008796 <numba_list_iter_next+0xc56>
180008772:     	movabsq	$0x100010001, %rcx      # imm = 0x100010001
18000877c:     	btq	%rax, %rcx
180008780:     	jae	0x180008796 <numba_list_iter_next+0xc56>
180008782:     	movl	0x828b(%rip), %r8d      # 0x180010a14
180008789:     	orl	$0x1, %r8d
18000878d:     	movl	%r8d, 0x8280(%rip)      # 0x180010a14
180008794:     	jmp	0x18000879d <numba_list_iter_next+0xc5d>
180008796:     	movl	0x8277(%rip), %r8d      # 0x180010a14
18000879d:     	xorl	%r9d, %r9d
1800087a0:     	movl	%r9d, %r11d
1800087a3:     	cmpl	$0x7, %ebp
1800087a6:     	jl	0x1800087ea <numba_list_iter_next+0xcaa>
1800087a8:     	xorl	%ecx, %ecx
1800087aa:     	leal	0x7(%r9), %eax
1800087ae:     	cpuid
1800087b0:     	movl	%edx, %esi
1800087b2:     	movl	%ebx, %r10d
1800087b5:     	btl	$0x9, %ebx
1800087b9:     	jae	0x1800087c6 <numba_list_iter_next+0xc86>
1800087bb:     	orl	$0x2, %r8d
1800087bf:     	movl	%r8d, 0x824e(%rip)      # 0x180010a14
1800087c6:     	cmpl	$0x1, %eax
1800087c9:     	jl	0x1800087d8 <numba_list_iter_next+0xc98>
1800087cb:     	movl	$0x7, %eax
1800087d0:     	leal	-0x6(%rax), %ecx
1800087d3:     	cpuid
1800087d5:     	movl	%edx, %r9d
1800087d8:     	movl	$0x24, %eax
1800087dd:     	cmpl	%eax, %ebp
1800087df:     	jl	0x1800087f0 <numba_list_iter_next+0xcb0>
1800087e1:     	xorl	%ecx, %ecx
1800087e3:     	cpuid
1800087e5:     	movl	%ebx, %r11d
1800087e8:     	jmp	0x1800087f0 <numba_list_iter_next+0xcb0>
1800087ea:     	movl	%r9d, %r10d
1800087ed:     	movl	%r9d, %esi
1800087f0:     	movq	0x7931(%rip), %rax      # 0x180010128
1800087f7:     	andq	$-0x2, %rax
1800087fb:     	movl	$0x1, 0x790b(%rip)      # 0x180010110
180008805:     	movl	$0x2, 0x7905(%rip)      # 0x180010114
18000880f:     	movq	%rax, 0x7912(%rip)      # 0x180010128
180008816:     	btl	$0x14, %edi
18000881a:     	jae	0x18000883b <numba_list_iter_next+0xcfb>
18000881c:     	andq	$-0x11, %rax
180008820:     	movl	$0x2, 0x78e6(%rip)      # 0x180010110
18000882a:     	movq	%rax, 0x78f7(%rip)      # 0x180010128
180008831:     	movl	$0x6, 0x78d9(%rip)      # 0x180010114
18000883b:     	btl	$0x1b, %edi
18000883f:     	jae	0x18000897c <numba_list_iter_next+0xe3c>
180008845:     	xorl	%ecx, %ecx
180008847:     	xgetbv
18000884a:     	shlq	$0x20, %rdx
18000884e:     	orq	%rax, %rdx
180008851:     	movq	%rdx, 0x20(%rsp)
180008856:     	btl	$0x1c, %edi
18000885a:     	jae	0x180008960 <numba_list_iter_next+0xe20>
180008860:     	movq	0x20(%rsp), %rax
180008865:     	andb	$0x6, %al
180008867:     	cmpb	$0x6, %al
180008869:     	jne	0x180008960 <numba_list_iter_next+0xe20>
18000886f:     	movl	0x789f(%rip), %eax      # 0x180010114
180008875:     	movb	$-0x20, %dl
180008877:     	orl	$0x8, %eax
18000887a:     	movl	$0x3, 0x788c(%rip)      # 0x180010110
180008884:     	movl	%eax, 0x788a(%rip)      # 0x180010114
18000888a:     	testb	$0x20, %r10b
18000888e:     	je	0x1800088f2 <numba_list_iter_next+0xdb2>
180008890:     	orl	$0x20, %eax
180008893:     	movl	$0x5, 0x7873(%rip)      # 0x180010110
18000889d:     	movl	%eax, 0x7871(%rip)      # 0x180010114
1800088a3:     	movl	$0xd0030000, %ecx       # imm = 0xD0030000
1800088a8:     	movq	0x7879(%rip), %rax      # 0x180010128
1800088af:     	andl	%ecx, %r10d
1800088b2:     	andq	$-0x3, %rax
1800088b6:     	movq	%rax, 0x786b(%rip)      # 0x180010128
1800088bd:     	cmpl	%ecx, %r10d
1800088c0:     	jne	0x1800088f9 <numba_list_iter_next+0xdb9>
1800088c2:     	movq	0x20(%rsp), %rax
1800088c7:     	andb	%dl, %al
1800088c9:     	cmpb	%dl, %al
1800088cb:     	jne	0x1800088f2 <numba_list_iter_next+0xdb2>
1800088cd:     	movq	0x7854(%rip), %rax      # 0x180010128
1800088d4:     	orl	$0x40, 0x7839(%rip)     # 0x180010114
1800088db:     	andq	$-0x25, %rax
1800088df:     	movl	$0x6, 0x7827(%rip)      # 0x180010110
1800088e9:     	movq	%rax, 0x7838(%rip)      # 0x180010128
1800088f0:     	jmp	0x1800088f9 <numba_list_iter_next+0xdb9>
1800088f2:     	movq	0x782f(%rip), %rax      # 0x180010128
1800088f9:     	btl	$0x17, %esi
1800088fd:     	jae	0x18000890b <numba_list_iter_next+0xdcb>
1800088ff:     	btrq	$0x18, %rax
180008904:     	movq	%rax, 0x781d(%rip)      # 0x180010128
18000890b:     	btl	$0x13, %r9d
180008910:     	jae	0x180008960 <numba_list_iter_next+0xe20>
180008912:     	movq	0x20(%rsp), %rax
180008917:     	andb	%dl, %al
180008919:     	cmpb	%dl, %al
18000891b:     	jne	0x180008960 <numba_list_iter_next+0xe20>
18000891d:     	movq	0x7804(%rip), %rdx      # 0x180010128
180008924:     	movl	%r11d, %eax
180008927:     	shrq	$0x10, %rax
18000892b:     	movl	%r11d, %ecx
18000892e:     	andl	$0x6, %eax
180008931:     	andl	$0x400ff, %ecx          # imm = 0x400FF
180008937:     	orq	$0x1000029, %rax        # imm = 0x1000029
18000893d:     	movl	%ecx, 0x80d5(%rip)      # 0x180010a18
180008943:     	notq	%rax
180008946:     	andq	%rax, %rdx
180008949:     	movq	%rdx, 0x77d8(%rip)      # 0x180010128
180008950:     	cmpb	$0x1, %cl
180008953:     	jbe	0x180008960 <numba_list_iter_next+0xe20>
180008955:     	andq	$-0x41, %rdx
180008959:     	movq	%rdx, 0x77c8(%rip)      # 0x180010128
180008960:     	btl	$0x15, %r9d
180008965:     	jae	0x18000897c <numba_list_iter_next+0xe3c>
180008967:     	movq	0x20(%rsp), %rax
18000896c:     	btq	$0x13, %rax
180008971:     	jae	0x18000897c <numba_list_iter_next+0xe3c>
180008973:     	btrq	$0x7, 0x77ac(%rip)      # 0x180010128
18000897c:     	movq	0x28(%rsp), %rbx
180008981:     	xorl	%eax, %eax
180008983:     	movq	0x30(%rsp), %rbp
180008988:     	movq	0x38(%rsp), %rsi
18000898d:     	addq	$0x10, %rsp
180008991:     	popq	%rdi
180008992:     	retq
180008993:     	int3
180008994:     	movl	$0x1, %eax
180008999:     	retq
18000899a:     	int3
18000899b:     	int3
18000899c:     	xorl	%eax, %eax
18000899e:     	cmpl	%eax, 0x778c(%rip)      # 0x180010130
1800089a4:     	setne	%al
1800089a7:     	retq
1800089a8:     	int3
1800089a9:     	int3
1800089aa:     	int3
1800089ab:     	int3
1800089ac:     	int3
1800089ad:     	int3
1800089ae:     	int3
1800089af:     	int3
1800089b0:     	jmpq	*0x692(%rip)            # 0x180009048
1800089b6:     	jmpq	*0x694(%rip)            # 0x180009050
1800089bc:     	jmpq	*0x6be(%rip)            # 0x180009080
1800089c2:     	jmpq	*0x6d0(%rip)            # 0x180009098
1800089c8:     	jmpq	*0x6d2(%rip)            # 0x1800090a0
1800089ce:     	jmpq	*0x6d4(%rip)            # 0x1800090a8
1800089d4:     	jmpq	*0x6d6(%rip)            # 0x1800090b0
1800089da:     	jmpq	*0x6d8(%rip)            # 0x1800090b8
1800089e0:     	jmpq	*0x6da(%rip)            # 0x1800090c0
1800089e6:     	jmpq	*0x6dc(%rip)            # 0x1800090c8
1800089ec:     	jmpq	*0x69e(%rip)            # 0x180009090
1800089f2:     	int3
1800089f3:     	int3
1800089f4:     	movb	$0x1, %al
1800089f6:     	retq
1800089f7:     	int3
1800089f8:     	xorl	%eax, %eax
1800089fa:     	retq
1800089fb:     	jmpq	*0x63f(%rip)            # 0x180009040
180008a01:     	jmpq	*0x631(%rip)            # 0x180009038
180008a07:     	jmpq	*0x6cb(%rip)            # 0x1800090d8
180008a0d:     	jmpq	*0x6cd(%rip)            # 0x1800090e0
180008a13:     	int3
180008a14:     	int3
180008a15:     	int3
180008a16:     	int3
180008a17:     	int3
180008a18:     	int3
180008a19:     	int3
180008a1a:     	int3
180008a1b:     	int3
180008a1c:     	int3
180008a1d:     	int3
180008a1e:     	int3
180008a1f:     	int3
180008a20:     	int3
180008a21:     	int3
180008a22:     	int3
180008a23:     	int3
180008a24:     	int3
180008a25:     	int3
180008a26:     	nopw	(%rax,%rax)
180008a30:     	jmpq	*%rax
180008a32:     	int3
180008a33:     	int3
180008a34:     	int3
180008a35:     	int3
180008a36:     	int3
180008a37:     	int3
180008a38:     	int3
180008a39:     	int3
180008a3a:     	int3
180008a3b:     	int3
180008a3c:     	int3
180008a3d:     	int3
180008a3e:     	int3
180008a3f:     	int3
180008a40:     	int3
180008a41:     	int3
180008a42:     	int3
180008a43:     	int3
180008a44:     	int3
180008a45:     	int3
180008a46:     	nopw	(%rax,%rax)
180008a50:     	jmpq	*0x8da(%rip)            # 0x180009330
180008a56:     	pushq	%rbp
180008a58:     	subq	$0x20, %rsp
180008a5c:     	movq	%rdx, %rbp
180008a5f:     	movb	0x40(%rbp), %cl
180008a62:     	addq	$0x20, %rsp
180008a66:     	popq	%rbp
180008a67:     	jmp	0x18000861c <numba_list_iter_next+0xadc>
180008a6c:     	int3
180008a6d:     	pushq	%rbp
180008a6f:     	subq	$0x20, %rsp
180008a73:     	movq	%rdx, %rbp
180008a76:     	movb	0x20(%rbp), %cl
180008a79:     	callq	0x18000861c <numba_list_iter_next+0xadc>
180008a7e:     	nop
180008a7f:     	addq	$0x20, %rsp
180008a83:     	popq	%rbp
180008a84:     	retq
180008a85:     	int3
180008a86:     	pushq	%rbp
180008a88:     	subq	$0x20, %rsp
180008a8c:     	movq	%rdx, %rbp
180008a8f:     	addq	$0x20, %rsp
180008a93:     	popq	%rbp
180008a94:     	jmp	0x1800084a8 <numba_list_iter_next+0x968>
180008a99:     	int3
180008a9a:     	pushq	%rbp
180008a9c:     	subq	$0x30, %rsp
180008aa0:     	movq	%rdx, %rbp
180008aa3:     	movq	(%rcx), %rax
180008aa6:     	movl	(%rax), %edx
180008aa8:     	movq	%rcx, 0x28(%rsp)
180008aad:     	movl	%edx, 0x20(%rsp)
180008ab1:     	leaq	-0xbd8(%rip), %r9       # 0x180007ee0 <numba_list_iter_next+0x3a0>
180008ab8:     	movq	0x70(%rbp), %r8
180008abc:     	movl	0x68(%rbp), %edx
180008abf:     	movq	0x60(%rbp), %rcx
180008ac3:     	callq	0x180008418 <numba_list_iter_next+0x8d8>
180008ac8:     	nop
180008ac9:     	addq	$0x30, %rsp
180008acd:     	popq	%rbp
180008ace:     	retq
180008acf:     	int3
180008ad0:     	pushq	%rbp
180008ad2:     	movq	%rdx, %rbp
180008ad5:     	movq	(%rcx), %rax
180008ad8:     	xorl	%ecx, %ecx
180008ada:     	cmpl	$0xc0000005, (%rax)     # imm = 0xC0000005
180008ae0:     	sete	%cl
180008ae3:     	movl	%ecx, %eax
180008ae5:     	popq	%rbp
180008ae6:     	retq
180008ae7:     	int3
