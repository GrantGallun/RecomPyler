# barnes-current force: [0x180002c30, 0x180003250)
# Source/call-target-bound static range; padding included; never cycles.
180002c30:     	pushq	%r15
180002c32:     	pushq	%r14
180002c34:     	pushq	%r13
180002c36:     	pushq	%r12
180002c38:     	pushq	%rsi
180002c39:     	pushq	%rdi
180002c3a:     	pushq	%rbp
180002c3b:     	pushq	%rbx
180002c3c:     	subq	$0x118, %rsp            # imm = 0x118
180002c43:     	movapd	%xmm8, 0x100(%rsp)
180002c4d:     	movapd	%xmm7, 0xf0(%rsp)
180002c56:     	movapd	%xmm6, 0xe0(%rsp)
180002c5f:     	movq	0x198(%rsp), %r14
180002c67:     	movq	$0x0, 0x60(%rsp)
180002c70:     	movb	$0x0, 0x68(%rsp)
180002c75:     	movq	$0x0, 0x70(%rsp)
180002c7e:     	movsd	0x48(%r8,%r14,8), %xmm0
180002c85:     	xorpd	%xmm1, %xmm1
180002c89:     	ucomisd	%xmm1, %xmm0
180002c8d:     	jne	0x180002ca6 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x736>
180002c8f:     	jp	0x180002ca6 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x736>
180002c91:     	movb	$0x1, 0x18(%rcx)
180002c95:     	movq	$0x0, 0x10(%rcx)
180002c9d:     	movb	$0x1, 0x8(%rcx)
180002ca1:     	jmp	0x180002e88 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x918>
180002ca6:     	movq	0x1a0(%rsp), %rbx
180002cae:     	movq	0x30(%r9,%r14,8), %rax
180002cb3:     	cmpq	$0x1, (%r9,%rax,8)
180002cb8:     	jne	0x180002cc5 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x755>
180002cba:     	movq	0x10(%r9,%rax,8), %rax
180002cbf:     	cmpq	%rbx, (%r9,%rax,8)
180002cc3:     	je	0x180002c91 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x721>
180002cc5:     	movq	0x188(%rsp), %rdi
180002ccd:     	movq	0x180(%rsp), %rsi
180002cd5:     	movq	0x10(%r9,%r14,8), %r10
180002cda:     	movsd	(%r8,%r10,8), %xmm1
180002ce0:     	cmpq	$0x0, 0x8(%r9,%r10,8)
180002ce6:     	setne	%r11b
180002cea:     	movq	0x10(%r9,%rbx,8), %rdx
180002cef:     	cmpq	$0x0, 0x8(%r9,%rdx,8)
180002cf5:     	setne	%al
180002cf8:     	subsd	(%r8,%rdx,8), %xmm1
180002cfe:     	andb	%r11b, %al
180002d01:     	cmpb	$0x1, %al
180002d03:     	jne	0x180002d27 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x7b7>
180002d05:     	movapd	0x76b3(%rip), %xmm2     # 0x18000a3c0
180002d0d:     	andpd	%xmm1, %xmm2
180002d11:     	ucomisd	0x76b7(%rip), %xmm2     # 0x18000a3d0
180002d19:     	jae	0x180002dce <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x85e>
180002d1f:     	xorpd	%xmm2, %xmm2
180002d23:     	addsd	%xmm2, %xmm1
180002d27:     	movsd	0x10(%r8,%r10,8), %xmm2
180002d2e:     	cmpq	$0x0, 0x18(%r9,%r10,8)
180002d34:     	subsd	0x10(%r8,%rdx,8), %xmm2
180002d3b:     	je	0x180002da5 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x835>
180002d3d:     	cmpq	$0x0, 0x18(%r9,%rdx,8)
180002d43:     	je	0x180002da5 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x835>
180002d45:     	movapd	0x7673(%rip), %xmm3     # 0x18000a3c0
180002d4d:     	andpd	%xmm2, %xmm3
180002d51:     	ucomisd	0x7677(%rip), %xmm3     # 0x18000a3d0
180002d59:     	jae	0x180002e12 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x8a2>
180002d5f:     	movapd	%xmm1, %xmm3
180002d63:     	mulsd	%xmm1, %xmm3
180002d67:     	ucomisd	0x7661(%rip), %xmm3     # 0x18000a3d0
180002d6f:     	setae	%dl
180002d72:     	testb	%dl, %al
180002d74:     	jne	0x180002dbe <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x84e>
180002d76:     	xorpd	%xmm4, %xmm4
180002d7a:     	addsd	%xmm4, %xmm2
180002d7e:     	movapd	%xmm2, %xmm4
180002d82:     	mulsd	%xmm2, %xmm4
180002d86:     	ucomisd	0x7642(%rip), %xmm4     # 0x18000a3d0
180002d8e:     	jae	0x180002dbe <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x84e>
180002d90:     	addsd	%xmm4, %xmm3
180002d94:     	ucomisd	0x7634(%rip), %xmm3     # 0x18000a3d0
180002d9c:     	setae	%dl
180002d9f:     	testb	%dl, %al
180002da1:     	jne	0x180002dbe <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x84e>
180002da3:     	jmp	0x180002dea <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x87a>
180002da5:     	movapd	%xmm1, %xmm3
180002da9:     	mulsd	%xmm1, %xmm3
180002dad:     	ucomisd	0x761b(%rip), %xmm3     # 0x18000a3d0
180002db5:     	setae	%dl
180002db8:     	andb	%dl, %al
180002dba:     	cmpb	$0x1, %al
180002dbc:     	jne	0x180002dde <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x86e>
180002dbe:     	movb	$0x1, (%rdi)
180002dc1:     	movq	$0x3d090c, 0x18(%rsi)   # imm = 0x3D090C
180002dc9:     	jmp	0x180002e70 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x900>
180002dce:     	movb	$0x1, (%rdi)
180002dd1:     	movq	$0x3d090a, 0x18(%rsi)   # imm = 0x3D090A
180002dd9:     	jmp	0x180002e70 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x900>
180002dde:     	movapd	%xmm2, %xmm4
180002de2:     	mulsd	%xmm2, %xmm4
180002de6:     	addsd	%xmm4, %xmm3
180002dea:     	xorps	%xmm4, %xmm4
180002ded:     	sqrtsd	%xmm3, %xmm4
180002df1:     	cmpq	$0x0, 0x18(%r9,%r14,8)
180002df7:     	je	0x180002e45 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x8d5>
180002df9:     	xorpd	%xmm5, %xmm5
180002dfd:     	ucomisd	%xmm5, %xmm3
180002e01:     	jne	0x180002e1f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x8af>
180002e03:     	jp	0x180002e1f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x8af>
180002e05:     	movb	$0x1, (%rdi)
180002e08:     	movq	$0x3d090f, 0x18(%rsi)   # imm = 0x3D090F
180002e10:     	jmp	0x180002e70 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x900>
180002e12:     	movb	$0x1, (%rdi)
180002e15:     	movq	$0x3d090b, 0x18(%rsi)   # imm = 0x3D090B
180002e1d:     	jmp	0x180002e70 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x900>
180002e1f:     	movsd	0x1a8(%rsp), %xmm6
180002e28:     	movq	(%r9,%r14,8), %rax
180002e2c:     	movsd	0x8(%r8,%rax,8), %xmm3
180002e33:     	addsd	%xmm3, %xmm3
180002e37:     	divsd	%xmm4, %xmm3
180002e3b:     	ucomisd	%xmm3, %xmm6
180002e3f:     	jbe	0x180002ef8 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x988>
180002e45:     	movsd	0x758b(%rip), %xmm3     # 0x18000a3d8
180002e4d:     	maxsd	%xmm4, %xmm3
180002e51:     	movapd	%xmm3, %xmm4
180002e55:     	mulsd	%xmm3, %xmm4
180002e59:     	xorpd	%xmm5, %xmm5
180002e5d:     	ucomisd	%xmm5, %xmm4
180002e61:     	jne	0x180002ebe <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x94e>
180002e63:     	jp	0x180002ebe <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x94e>
180002e65:     	movb	$0x1, (%rdi)
180002e68:     	movq	$0x3d0915, 0x18(%rsi)   # imm = 0x3D0915
180002e70:     	movq	$0x0, 0x18(%rcx)
180002e78:     	movq	$0x0, 0x10(%rcx)
180002e80:     	movq	$0x0, 0x8(%rcx)
180002e88:     	movq	$0x0, (%rcx)
180002e8f:     	xorl	%eax, %eax
180002e91:     	movaps	0xe0(%rsp), %xmm6
180002e99:     	movaps	0xf0(%rsp), %xmm7
180002ea1:     	movaps	0x100(%rsp), %xmm8
180002eaa:     	addq	$0x118, %rsp            # imm = 0x118
180002eb1:     	popq	%rbx
180002eb2:     	popq	%rbp
180002eb3:     	popq	%rdi
180002eb4:     	popq	%rsi
180002eb5:     	popq	%r12
180002eb7:     	popq	%r13
180002eb9:     	popq	%r14
180002ebb:     	popq	%r15
180002ebd:     	retq
180002ebe:     	movsd	0x8(%r8,%rbx,8), %xmm5
180002ec5:     	mulsd	0x7513(%rip), %xmm5     # 0x18000a3e0
180002ecd:     	mulsd	%xmm5, %xmm0
180002ed1:     	divsd	%xmm4, %xmm0
180002ed5:     	mulsd	%xmm0, %xmm1
180002ed9:     	divsd	%xmm3, %xmm1
180002edd:     	mulsd	%xmm0, %xmm2
180002ee1:     	divsd	%xmm3, %xmm2
180002ee5:     	movsd	%xmm2, 0x10(%rcx)
180002eea:     	movsd	%xmm1, (%rcx)
180002eee:     	movb	$0x0, 0x18(%rcx)
180002ef2:     	movb	$0x0, 0x8(%rcx)
180002ef6:     	jmp	0x180002e8f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x91f>
180002ef8:     	movq	0x190(%rsp), %r15
180002f00:     	movq	0x20(%r9,%r14,8), %rax
180002f05:     	testq	%rax, %rax
180002f08:     	js	0x180002faf <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xa3f>
180002f0e:     	movq	0x8(%rsi), %rdx
180002f12:     	leaq	0x1(%rdx), %r10
180002f16:     	movq	%r10, 0x8(%rsi)
180002f1a:     	cmpq	0x10(%rsi), %rdx
180002f1e:     	jge	0x180003100 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xb90>
180002f24:     	movq	%rcx, %r13
180002f27:     	movsd	%xmm6, 0x48(%rsp)
180002f2d:     	movq	%rbx, 0x40(%rsp)
180002f32:     	movq	%rax, 0x38(%rsp)
180002f37:     	movq	%r15, 0x30(%rsp)
180002f3c:     	movq	%rdi, 0x28(%rsp)
180002f41:     	movq	%rsi, 0x20(%rsp)
180002f46:     	leaq	0xc0(%rsp), %rcx
180002f4e:     	movq	%r15, %r12
180002f51:     	movq	%r8, %r15
180002f54:     	movq	%r9, %rbp
180002f57:     	callq	0x180002c30 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x6c0>
180002f5c:     	cmpb	$0x0, (%rdi)
180002f5f:     	jne	0x1800030db <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xb6b>
180002f65:     	cmpb	$0x0, 0xd8(%rsp)
180002f6d:     	movq	%r12, %rax
180002f70:     	setne	%r12b
180002f74:     	cmpb	$0x0, 0xc8(%rsp)
180002f7c:     	setne	%r11b
180002f80:     	xorpd	%xmm8, %xmm8
180002f85:     	movsd	0xc0(%rsp), %xmm7
180002f8e:     	addsd	%xmm8, %xmm7
180002f93:     	addsd	0xd0(%rsp), %xmm8
180002f9d:     	decq	0x8(%rsi)
180002fa1:     	movq	%r13, %rcx
180002fa4:     	movq	%r15, %r8
180002fa7:     	movq	%rbp, %r9
180002faa:     	movq	%rax, %r15
180002fad:     	jmp	0x180002fbe <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xa4e>
180002faf:     	movb	$0x1, %r11b
180002fb2:     	xorpd	%xmm7, %xmm7
180002fb6:     	xorpd	%xmm8, %xmm8
180002fbb:     	movb	$0x1, %r12b
180002fbe:     	movq	0x28(%r9,%r14,8), %rax
180002fc3:     	testq	%rax, %rax
180002fc6:     	js	0x180003075 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xb05>
180002fcc:     	movq	0x8(%rsi), %rdx
180002fd0:     	leaq	0x1(%rdx), %r10
180002fd4:     	movq	%r10, 0x8(%rsi)
180002fd8:     	cmpq	0x10(%rsi), %rdx
180002fdc:     	jge	0x180003110 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xba0>
180002fe2:     	movb	%r12b, 0x5f(%rsp)
180002fe7:     	movl	%r11d, %r12d
180002fea:     	movq	%rcx, %r13
180002fed:     	movsd	%xmm6, 0x48(%rsp)
180002ff3:     	movq	%rbx, 0x40(%rsp)
180002ff8:     	movq	%rax, 0x38(%rsp)
180002ffd:     	movq	%r15, 0x30(%rsp)
180003002:     	movq	%rdi, 0x28(%rsp)
180003007:     	movq	%rsi, 0x20(%rsp)
18000300c:     	leaq	0xa0(%rsp), %rcx
180003014:     	movq	%r8, %rbp
180003017:     	movq	%r9, %r15
18000301a:     	callq	0x180002c30 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x6c0>
18000301f:     	cmpb	$0x0, (%rdi)
180003022:     	jne	0x1800030db <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xb6b>
180003028:     	cmpb	$0x0, 0xb8(%rsp)
180003030:     	setne	%al
180003033:     	cmpb	$0x0, 0xa8(%rsp)
18000303b:     	setne	%cl
18000303e:     	addsd	0xa0(%rsp), %xmm7
180003047:     	addsd	0xb0(%rsp), %xmm8
180003051:     	decq	0x8(%rsi)
180003055:     	movl	%r12d, %r11d
180003058:     	andb	%cl, %r11b
18000305b:     	movzbl	0x5f(%rsp), %r12d
180003061:     	andb	%al, %r12b
180003064:     	movq	%r13, %rcx
180003067:     	movq	%rbp, %r8
18000306a:     	movq	%r15, %r9
18000306d:     	movq	0x190(%rsp), %r15
180003075:     	movq	0x38(%r9,%r14,8), %rax
18000307a:     	testq	%rax, %rax
18000307d:     	js	0x18000317d <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xc0d>
180003083:     	movq	0x8(%rsi), %rdx
180003087:     	leaq	0x1(%rdx), %r10
18000308b:     	movq	%r10, 0x8(%rsi)
18000308f:     	cmpq	0x10(%rsi), %rdx
180003093:     	jge	0x180003120 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xbb0>
180003099:     	movb	%r12b, 0x5f(%rsp)
18000309e:     	movl	%r11d, %r12d
1800030a1:     	movq	%rcx, %r13
1800030a4:     	movsd	%xmm6, 0x48(%rsp)
1800030aa:     	movq	%rbx, 0x40(%rsp)
1800030af:     	movq	%rax, 0x38(%rsp)
1800030b4:     	movq	%r15, 0x30(%rsp)
1800030b9:     	movq	%rdi, 0x28(%rsp)
1800030be:     	movq	%rsi, 0x20(%rsp)
1800030c3:     	leaq	0x80(%rsp), %rcx
1800030cb:     	movq	%r8, %rbp
1800030ce:     	movq	%r9, %r15
1800030d1:     	callq	0x180002c30 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x6c0>
1800030d6:     	cmpb	$0x0, (%rdi)
1800030d9:     	je	0x180003130 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xbc0>
1800030db:     	movq	$0x0, 0x18(%r13)
1800030e3:     	movq	$0x0, 0x10(%r13)
1800030eb:     	movq	$0x0, 0x8(%r13)
1800030f3:     	movq	$0x0, (%r13)
1800030fb:     	jmp	0x180002e8f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x91f>
180003100:     	movb	$0x1, (%rdi)
180003103:     	movq	$0x3d0921, 0x18(%rsi)   # imm = 0x3D0921
18000310b:     	jmp	0x180002e70 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x900>
180003110:     	movb	$0x1, (%rdi)
180003113:     	movq	$0x3d0926, 0x18(%rsi)   # imm = 0x3D0926
18000311b:     	jmp	0x180002e70 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x900>
180003120:     	movb	$0x1, (%rdi)
180003123:     	movq	$0x3d092b, 0x18(%rsi)   # imm = 0x3D092B
18000312b:     	jmp	0x180002e70 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x900>
180003130:     	cmpb	$0x0, 0x98(%rsp)
180003138:     	setne	%al
18000313b:     	cmpb	$0x0, 0x88(%rsp)
180003143:     	setne	%cl
180003146:     	addsd	0x80(%rsp), %xmm7
18000314f:     	addsd	0x90(%rsp), %xmm8
180003159:     	decq	0x8(%rsi)
18000315d:     	movl	%r12d, %r11d
180003160:     	andb	%cl, %r11b
180003163:     	movzbl	0x5f(%rsp), %r12d
180003169:     	andb	%al, %r12b
18000316c:     	movq	%r13, %rcx
18000316f:     	movq	%rbp, %r8
180003172:     	movq	%r15, %r9
180003175:     	movq	0x190(%rsp), %r15
18000317d:     	movq	0x40(%r9,%r14,8), %rax
180003182:     	testq	%rax, %rax
180003185:     	js	0x180003232 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xcc2>
18000318b:     	movq	0x8(%rsi), %rdx
18000318f:     	leaq	0x1(%rdx), %r10
180003193:     	movq	%r10, 0x8(%rsi)
180003197:     	cmpq	0x10(%rsi), %rdx
18000319b:     	jge	0x1800031f5 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xc85>
18000319d:     	movl	%r11d, %ebp
1800031a0:     	movq	%rcx, %r14
1800031a3:     	movsd	%xmm6, 0x48(%rsp)
1800031a9:     	movq	%rbx, 0x40(%rsp)
1800031ae:     	movq	%rax, 0x38(%rsp)
1800031b3:     	movq	%r15, 0x30(%rsp)
1800031b8:     	movq	%rdi, 0x28(%rsp)
1800031bd:     	movq	%rsi, 0x20(%rsp)
1800031c2:     	leaq	0x60(%rsp), %rcx
1800031c7:     	callq	0x180002c30 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x6c0>
1800031cc:     	cmpb	$0x0, (%rdi)
1800031cf:     	je	0x180003205 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0xc95>
1800031d1:     	movq	$0x0, 0x18(%r14)
1800031d9:     	movq	$0x0, 0x10(%r14)
1800031e1:     	movq	$0x0, 0x8(%r14)
1800031e9:     	movq	$0x0, (%r14)
1800031f0:     	jmp	0x180002e8f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x91f>
1800031f5:     	movb	$0x1, (%rdi)
1800031f8:     	movq	$0x3d0930, 0x18(%rsi)   # imm = 0x3D0930
180003200:     	jmp	0x180002e70 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x900>
180003205:     	cmpb	$0x0, 0x78(%rsp)
18000320a:     	setne	%al
18000320d:     	cmpb	$0x0, 0x68(%rsp)
180003212:     	setne	%cl
180003215:     	addsd	0x60(%rsp), %xmm7
18000321b:     	addsd	0x70(%rsp), %xmm8
180003222:     	decq	0x8(%rsi)
180003226:     	movl	%ebp, %r11d
180003229:     	andb	%cl, %r11b
18000322c:     	andb	%al, %r12b
18000322f:     	movq	%r14, %rcx
180003232:     	movb	%r12b, 0x18(%rcx)
180003236:     	movsd	%xmm8, 0x10(%rcx)
18000323c:     	movb	%r11b, 0x8(%rcx)
180003240:     	movsd	%xmm7, (%rcx)
180003244:     	jmp	0x180002e8f <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x91f>
180003249:     	nopl	(%rax)
