# raytrace-final first-intersection-list-item: [0x180003ef0, 0x180003ef3)
# Source/call-target-bound static range; padding included; never cycles.
180003ef0:     	movq	(%r10), %r13
