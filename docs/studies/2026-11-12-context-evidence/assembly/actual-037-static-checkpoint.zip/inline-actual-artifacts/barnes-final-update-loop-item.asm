# barnes-final update-loop-item: [0x180002a48, 0x180002a61)
# Source/call-target-bound static range; padding included; never cycles.
180002a48:     	cmpq	(%r13,%r14), %rcx
180002a4d:     	jge	0x180002b55 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x5c5>
180002a53:     	movq	0x10(%r13,%r14), %rdx
180002a58:     	leaq	(%r13,%rdx,8), %rdx
180002a5d:     	movq	(%rdx,%rcx,8), %rdx
