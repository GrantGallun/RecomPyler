# barnes-final descriptor-construction: [0x180001155, 0x18000116e)
# Source/call-target-bound static range; padding included; never cycles.
180001155:     	movq	%r8, 0x50(%rsp)
18000115a:     	movq	%rbx, 0x58(%rsp)
18000115f:     	movq	%r11, 0x60(%rsp)
180001164:     	movq	%r10, 0x68(%rsp)
180001169:     	movq	%r9, 0x70(%rsp)
