# raytrace-current first-intersection-list-item: [0x180005292, 0x1800052ab)
# Source/call-target-bound static range; padding included; never cycles.
180005292:     	movq	%r11, %rax
180005295:     	sarq	$0x3f, %rax
180005299:     	leaq	(,%r15,8), %rdx
1800052a1:     	andq	%rdx, %rax
1800052a4:     	addq	%r9, %rax
1800052a7:     	movq	(%rax,%r11,8), %r12
