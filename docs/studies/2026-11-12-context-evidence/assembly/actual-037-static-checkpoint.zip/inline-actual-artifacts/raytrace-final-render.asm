# raytrace-final render: [0x1800019e0, 0x180002e80)
# Source/call-target-bound static range; padding included; never cycles.
1800019e0:     	pushq	%r15
1800019e2:     	pushq	%r14
1800019e4:     	pushq	%r13
1800019e6:     	pushq	%r12
1800019e8:     	pushq	%rsi
1800019e9:     	pushq	%rdi
1800019ea:     	pushq	%rbp
1800019eb:     	pushq	%rbx
1800019ec:     	subq	$0x1b8, %rsp            # imm = 0x1B8
1800019f3:     	movapd	%xmm15, 0x1a0(%rsp)
1800019fd:     	movapd	%xmm14, 0x190(%rsp)
180001a07:     	movapd	%xmm13, 0x180(%rsp)
180001a11:     	movapd	%xmm12, 0x170(%rsp)
180001a1b:     	movapd	%xmm11, 0x160(%rsp)
180001a25:     	movapd	%xmm10, 0x150(%rsp)
180001a2f:     	movapd	%xmm9, 0x140(%rsp)
180001a39:     	movapd	%xmm8, 0x130(%rsp)
180001a43:     	movapd	%xmm7, 0x120(%rsp)
180001a4c:     	movaps	%xmm6, 0x110(%rsp)
180001a54:     	movq	%r9, %rbx
180001a57:     	movq	%r8, %r14
180001a5a:     	movq	%rdx, 0x100(%rsp)
180001a62:     	movq	%rcx, %rsi
180001a65:     	movq	$0x0, 0x88(%rsp)
180001a71:     	movb	$0x0, 0x90(%rsp)
180001a79:     	movq	$0x0, 0x98(%rsp)
180001a85:     	movb	$0x0, 0xa0(%rsp)
180001a8d:     	movq	$0x0, 0xa8(%rsp)
180001a99:     	movb	$0x0, 0xb0(%rsp)
180001aa1:     	movq	$0x0, 0xb8(%rsp)
180001aad:     	movb	$0x0, 0xc0(%rsp)
180001ab5:     	movq	$0x0, 0xc8(%rsp)
180001ac1:     	movb	$0x0, 0xd0(%rsp)
180001ac9:     	movq	$0x0, 0xd8(%rsp)
180001ad5:     	movb	$0x0, 0xe0(%rsp)
180001add:     	movq	$0x0, 0x108(%rsp)
180001ae9:     	movq	(%r8), %r15
180001aec:     	movq	0x8(%r8), %r12
180001af0:     	movq	0x10(%r8), %rbp
180001af4:     	movq	0x18(%r8), %r13
180001af8:     	movq	0x20(%r8), %rdi
180001afc:     	xorps	%xmm6, %xmm6
180001aff:     	cvtsi2sdq	(%r12,%r9,8), %xmm6
180001b05:     	mulsd	0x78a3(%rip), %xmm6     # 0x1800093b0
180001b0d:     	mulsd	0x78a3(%rip), %xmm6     # 0x1800093b8
180001b15:     	divsd	0x78a3(%rip), %xmm6     # 0x1800093c0
180001b1d:     	movapd	%xmm6, %xmm0
180001b21:     	callq	0x1800089bc <numba_list_iter_next+0xe7c>
180001b26:     	ucomisd	%xmm0, %xmm0
180001b2a:     	jp	0x180001b80 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x200>
180001b2c:     	movq	%xmm0, %rax
180001b31:     	movabsq	$0x7fffffffffffffff, %rcx # imm = 0x7FFFFFFFFFFFFFFF
180001b3b:     	andq	%rcx, %rax
180001b3e:     	movabsq	$0x7ff0000000000000, %rdx # imm = 0x7FF0000000000000
180001b48:     	cmpq	%rdx, %rax
180001b4b:     	setne	%al
180001b4e:     	movq	%xmm6, %r8
180001b53:     	andq	%rcx, %r8
180001b56:     	cmpq	%rdx, %r8
180001b59:     	sete	%cl
180001b5c:     	orb	%al, %cl
180001b5e:     	je	0x180001b80 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x200>
180001b60:     	movq	0x220(%rsp), %rdx
180001b68:     	movq	0x10(%r12,%rdx,8), %rcx
180001b6d:     	movq	%rcx, %rax
180001b70:     	negq	%rax
180001b73:     	jno	0x180001c02 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x282>
180001b79:     	movb	$0x1, (%r13)
180001b7e:     	jmp	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
180001b80:     	movb	$0x1, (%r13)
180001b85:     	movq	$0x3, 0x18(%rbp)
180001b8d:     	xorl	%eax, %eax
180001b8f:     	movq	$0x0, (%rsi)
180001b96:     	movaps	0x110(%rsp), %xmm6
180001b9e:     	movaps	0x120(%rsp), %xmm7
180001ba6:     	movaps	0x130(%rsp), %xmm8
180001baf:     	movaps	0x140(%rsp), %xmm9
180001bb8:     	movaps	0x150(%rsp), %xmm10
180001bc1:     	movaps	0x160(%rsp), %xmm11
180001bca:     	movaps	0x170(%rsp), %xmm12
180001bd3:     	movaps	0x180(%rsp), %xmm13
180001bdc:     	movaps	0x190(%rsp), %xmm14
180001be5:     	movaps	0x1a0(%rsp), %xmm15
180001bee:     	addq	$0x1b8, %rsp            # imm = 0x1B8
180001bf5:     	popq	%rbx
180001bf6:     	popq	%rbp
180001bf7:     	popq	%rdi
180001bf8:     	popq	%rsi
180001bf9:     	popq	%r12
180001bfb:     	popq	%r13
180001bfd:     	popq	%r14
180001bff:     	popq	%r15
180001c01:     	retq
180001c02:     	xorl	%eax, %eax
180001c04:     	cmpb	$0x0, (%r13)
180001c09:     	jne	0x180001b8f <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20f>
180001c0b:     	decq	%rcx
180001c0e:     	je	0x180001c2e <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2ae>
180001c10:     	movabsq	$-0x8000000000000000, %r8 # imm = 0x8000000000000000
180001c1a:     	movq	0x8(%r12,%rdx,8), %rdx
180001c1f:     	cmpq	%r8, %rdx
180001c22:     	jne	0x180001c40 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x2c0>
180001c24:     	movb	$0x1, (%r13)
180001c29:     	jmp	0x180001b8f <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20f>
180001c2e:     	movb	$0x1, (%r13)
180001c33:     	movq	$0x7, 0x18(%rbp)
180001c3b:     	jmp	0x180001b8f <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20f>
180001c40:     	decq	%rdx
180001c43:     	je	0x180001d50 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3d0>
180001c49:     	movq	0x10(%r12,%rbx,8), %r8
180001c4e:     	movq	0x20(%r12,%rbx,8), %r9
180001c53:     	movsd	(%r15,%r8,8), %xmm1
180001c59:     	subsd	(%r15,%r9,8), %xmm1
180001c5f:     	movapd	0x7769(%rip), %xmm2     # 0x1800093d0
180001c67:     	andpd	%xmm1, %xmm2
180001c6b:     	ucomisd	0x776d(%rip), %xmm2     # 0x1800093e0
180001c73:     	jae	0x180001d17 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x397>
180001c79:     	movsd	0x10(%r15,%r8,8), %xmm2
180001c80:     	subsd	0x10(%r15,%r9,8), %xmm2
180001c87:     	movapd	0x7741(%rip), %xmm3     # 0x1800093d0
180001c8f:     	andpd	%xmm2, %xmm3
180001c93:     	ucomisd	0x7745(%rip), %xmm3     # 0x1800093e0
180001c9b:     	jae	0x180001d17 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x397>
180001c9d:     	movsd	0x20(%r15,%r8,8), %xmm3
180001ca4:     	subsd	0x20(%r15,%r9,8), %xmm3
180001cab:     	movapd	0x771d(%rip), %xmm4     # 0x1800093d0
180001cb3:     	andpd	%xmm3, %xmm4
180001cb7:     	ucomisd	0x7721(%rip), %xmm4     # 0x1800093e0
180001cbf:     	jae	0x180001d17 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x397>
180001cc1:     	movq	(%rbp), %r10
180001cc5:     	leaq	0x6(%r10), %r8
180001cc9:     	cmpq	%rdi, %r8
180001ccc:     	jg	0x180001d46 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3c6>
180001cce:     	movq	%r8, (%rbp)
180001cd2:     	cmpb	$0x0, (%r13)
180001cd7:     	jne	0x180001b8f <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20f>
180001cdd:     	movsd	%xmm1, (%r15,%r10,8)
180001ce3:     	movsd	%xmm2, 0x10(%r15,%r10,8)
180001cea:     	movsd	%xmm3, 0x20(%r15,%r10,8)
180001cf1:     	movq	%r10, 0x58(%rsp)
180001cf6:     	movzbl	(%r13), %r10d
180001cfb:     	xorl	%r8d, %r8d
180001cfe:     	movl	%r10d, %r11d
180001d01:     	negb	%r11b
180001d04:     	sbbq	%r8, %r8
180001d07:     	orq	0x58(%rsp), %r8
180001d0c:     	testb	%r10b, %r10b
180001d0f:     	jne	0x180001b8f <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20f>
180001d15:     	jmp	0x180001d39 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3b9>
180001d17:     	movb	$0x1, (%r13)
180001d1c:     	movq	$0xf4243, 0x18(%rbp)    # imm = 0xF4243
180001d24:     	movzbl	(%r13), %r10d
180001d29:     	movq	$-0x1, %r8
180001d30:     	testb	%r10b, %r10b
180001d33:     	jne	0x180001b8f <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20f>
180001d39:     	movq	(%rbp), %r11
180001d3d:     	leaq	0x2(%r11), %r10
180001d41:     	cmpq	%rdi, %r10
180001d44:     	jle	0x180001d62 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x3e2>
180001d46:     	movb	$0x2, (%r13)
180001d4b:     	jmp	0x180001b8f <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20f>
180001d50:     	movb	$0x1, (%r13)
180001d55:     	movq	$0x8, 0x18(%rbp)
180001d5d:     	jmp	0x180001b8f <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20f>
180001d62:     	movq	%r10, (%rbp)
180001d66:     	cmpb	$0x0, (%r13)
180001d6b:     	jne	0x180001b8f <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20f>
180001d71:     	movq	%r9, (%r12,%r11,8)
180001d75:     	cmpb	$0x0, (%r13)
180001d7a:     	jne	0x180001b8f <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20f>
180001d80:     	movsd	(%r15,%r8,8), %xmm1
180001d86:     	mulsd	%xmm1, %xmm1
180001d8a:     	movapd	0x763e(%rip), %xmm2     # 0x1800093d0
180001d92:     	andpd	%xmm1, %xmm2
180001d96:     	ucomisd	0x7642(%rip), %xmm2     # 0x1800093e0
180001d9e:     	jae	0x180001e16 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x496>
180001da0:     	movsd	0x10(%r15,%r8,8), %xmm2
180001da7:     	mulsd	%xmm2, %xmm2
180001dab:     	movapd	0x761d(%rip), %xmm3     # 0x1800093d0
180001db3:     	andpd	%xmm2, %xmm3
180001db7:     	ucomisd	0x7621(%rip), %xmm3     # 0x1800093e0
180001dbf:     	jae	0x180001e16 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x496>
180001dc1:     	addsd	%xmm2, %xmm1
180001dc5:     	movapd	0x7603(%rip), %xmm2     # 0x1800093d0
180001dcd:     	andpd	%xmm1, %xmm2
180001dd1:     	ucomisd	0x7607(%rip), %xmm2     # 0x1800093e0
180001dd9:     	jae	0x180001e16 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x496>
180001ddb:     	movsd	0x20(%r15,%r8,8), %xmm2
180001de2:     	mulsd	%xmm2, %xmm2
180001de6:     	movapd	0x75e2(%rip), %xmm3     # 0x1800093d0
180001dee:     	andpd	%xmm2, %xmm3
180001df2:     	ucomisd	0x75e6(%rip), %xmm3     # 0x1800093e0
180001dfa:     	jae	0x180001e16 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x496>
180001dfc:     	addsd	%xmm2, %xmm1
180001e00:     	movapd	0x75c8(%rip), %xmm2     # 0x1800093d0
180001e08:     	andpd	%xmm1, %xmm2
180001e0c:     	ucomisd	0x75cc(%rip), %xmm2     # 0x1800093e0
180001e14:     	jb	0x180001e27 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4a7>
180001e16:     	movb	$0x1, (%r13)
180001e1b:     	movq	$0x14fb183, 0x18(%rbp)  # imm = 0x14FB183
180001e23:     	xorpd	%xmm1, %xmm1
180001e27:     	cmpb	$0x0, (%r13)
180001e2c:     	jne	0x180001b8f <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20f>
180001e32:     	sqrtsd	%xmm1, %xmm1
180001e36:     	xorpd	%xmm2, %xmm2
180001e3a:     	ucomisd	%xmm2, %xmm1
180001e3e:     	movq	%r11, 0x58(%rsp)
180001e43:     	jne	0x18000201d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x69d>
180001e49:     	jp	0x18000201d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x69d>
180001e4f:     	movb	$0x1, (%r13)
180001e54:     	movq	$0x3d0902, 0x18(%rbp)   # imm = 0x3D0902
180001e5c:     	movzbl	(%r13), %r8d
180001e61:     	movq	$-0x1, %r9
180001e68:     	testb	%r8b, %r8b
180001e6b:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
180001e71:     	movq	0x58(%rsp), %rax
180001e76:     	movq	%r9, 0x8(%r12,%rax,8)
180001e7b:     	cmpb	$0x0, (%r13)
180001e80:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
180001e86:     	movq	0x58(%rsp), %rax
180001e8b:     	movq	0x8(%r12,%rax,8), %rax
180001e90:     	movq	(%r12), %r8
180001e94:     	movsd	0x10(%r15,%rax,8), %xmm4
180001e9b:     	movsd	0x20(%r15,%r8,8), %xmm5
180001ea2:     	movapd	%xmm4, %xmm1
180001ea6:     	mulsd	%xmm5, %xmm1
180001eaa:     	movapd	0x751e(%rip), %xmm2     # 0x1800093d0
180001eb2:     	andpd	%xmm1, %xmm2
180001eb6:     	ucomisd	0x7522(%rip), %xmm2     # 0x1800093e0
180001ebe:     	jae	0x1800020a5 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x725>
180001ec4:     	movsd	0x20(%r15,%rax,8), %xmm2
180001ecb:     	movsd	0x10(%r15,%r8,8), %xmm3
180001ed2:     	movapd	%xmm2, %xmm6
180001ed6:     	mulsd	%xmm3, %xmm6
180001eda:     	movapd	0x74ee(%rip), %xmm7     # 0x1800093d0
180001ee2:     	andpd	%xmm6, %xmm7
180001ee6:     	ucomisd	0x74f2(%rip), %xmm7     # 0x1800093e0
180001eee:     	jae	0x1800020a5 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x725>
180001ef4:     	subsd	%xmm6, %xmm1
180001ef8:     	movapd	0x74d0(%rip), %xmm6     # 0x1800093d0
180001f00:     	andpd	%xmm1, %xmm6
180001f04:     	ucomisd	0x74d4(%rip), %xmm6     # 0x1800093e0
180001f0c:     	jae	0x1800020a5 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x725>
180001f12:     	movsd	(%r15,%r8,8), %xmm6
180001f18:     	mulsd	%xmm6, %xmm2
180001f1c:     	movapd	0x74ac(%rip), %xmm7     # 0x1800093d0
180001f24:     	andpd	%xmm2, %xmm7
180001f28:     	ucomisd	0x74b0(%rip), %xmm7     # 0x1800093e0
180001f30:     	jae	0x1800020a5 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x725>
180001f36:     	movsd	(%r15,%rax,8), %xmm7
180001f3c:     	mulsd	%xmm7, %xmm5
180001f40:     	movapd	0x7487(%rip), %xmm8     # 0x1800093d0
180001f49:     	andpd	%xmm5, %xmm8
180001f4e:     	ucomisd	0x7489(%rip), %xmm8     # 0x1800093e0
180001f57:     	jae	0x1800020a5 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x725>
180001f5d:     	subsd	%xmm5, %xmm2
180001f61:     	movapd	0x7467(%rip), %xmm5     # 0x1800093d0
180001f69:     	andpd	%xmm2, %xmm5
180001f6d:     	ucomisd	0x746b(%rip), %xmm5     # 0x1800093e0
180001f75:     	jae	0x1800020a5 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x725>
180001f7b:     	mulsd	%xmm7, %xmm3
180001f7f:     	movapd	0x7449(%rip), %xmm5     # 0x1800093d0
180001f87:     	andpd	%xmm3, %xmm5
180001f8b:     	ucomisd	0x744d(%rip), %xmm5     # 0x1800093e0
180001f93:     	jae	0x1800020a5 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x725>
180001f99:     	mulsd	%xmm6, %xmm4
180001f9d:     	movapd	0x742b(%rip), %xmm5     # 0x1800093d0
180001fa5:     	andpd	%xmm4, %xmm5
180001fa9:     	ucomisd	0x742f(%rip), %xmm5     # 0x1800093e0
180001fb1:     	jae	0x1800020a5 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x725>
180001fb7:     	subsd	%xmm4, %xmm3
180001fbb:     	movapd	0x740d(%rip), %xmm4     # 0x1800093d0
180001fc3:     	andpd	%xmm3, %xmm4
180001fc7:     	ucomisd	0x7411(%rip), %xmm4     # 0x1800093e0
180001fcf:     	jae	0x1800020a5 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x725>
180001fd5:     	movq	(%rbp), %r8
180001fd9:     	leaq	0x6(%r8), %rax
180001fdd:     	cmpq	%rdi, %rax
180001fe0:     	jg	0x18000202a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x6aa>
180001fe2:     	movq	%rax, (%rbp)
180001fe6:     	cmpb	$0x0, (%r13)
180001feb:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
180001ff1:     	movsd	%xmm1, (%r15,%r8,8)
180001ff7:     	movsd	%xmm2, 0x10(%r15,%r8,8)
180001ffe:     	movsd	%xmm3, 0x20(%r15,%r8,8)
180002005:     	movzbl	(%r13), %r9d
18000200a:     	xorl	%eax, %eax
18000200c:     	movl	%r9d, %r10d
18000200f:     	negb	%r10b
180002012:     	sbbq	%rax, %rax
180002015:     	orq	%r8, %rax
180002018:     	jmp	0x1800020be <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x73e>
18000201d:     	movq	(%rbp), %rax
180002021:     	leaq	0x6(%rax), %r9
180002025:     	cmpq	%rdi, %r9
180002028:     	jle	0x180002034 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x6b4>
18000202a:     	movb	$0x2, (%r13)
18000202f:     	jmp	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
180002034:     	movsd	(%r15,%r8,8), %xmm2
18000203a:     	movsd	0x10(%r15,%r8,8), %xmm3
180002041:     	movsd	0x20(%r15,%r8,8), %xmm4
180002048:     	movq	%r9, (%rbp)
18000204c:     	cmpb	$0x0, (%r13)
180002051:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
180002057:     	movsd	0x7389(%rip), %xmm5     # 0x1800093e8
18000205f:     	divsd	%xmm1, %xmm5
180002063:     	mulsd	%xmm5, %xmm2
180002067:     	mulsd	%xmm5, %xmm3
18000206b:     	mulsd	%xmm4, %xmm5
18000206f:     	movsd	%xmm2, (%r15,%rax,8)
180002075:     	movsd	%xmm3, 0x10(%r15,%rax,8)
18000207c:     	movsd	%xmm5, 0x20(%r15,%rax,8)
180002083:     	movzbl	(%r13), %r8d
180002088:     	xorl	%r9d, %r9d
18000208b:     	movl	%r8d, %r10d
18000208e:     	negb	%r10b
180002091:     	sbbq	%r9, %r9
180002094:     	orq	%rax, %r9
180002097:     	testb	%r8b, %r8b
18000209a:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
1800020a0:     	jmp	0x180001e71 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x4f1>
1800020a5:     	movb	$0x1, (%r13)
1800020aa:     	movq	$0x2dc6c3, 0x18(%rbp)   # imm = 0x2DC6C3
1800020b2:     	movzbl	(%r13), %r9d
1800020b7:     	movq	$-0x1, %rax
1800020be:     	testb	%r9b, %r9b
1800020c1:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
1800020c7:     	movsd	(%r15,%rax,8), %xmm1
1800020cd:     	mulsd	%xmm1, %xmm1
1800020d1:     	movapd	0x72f7(%rip), %xmm2     # 0x1800093d0
1800020d9:     	andpd	%xmm1, %xmm2
1800020dd:     	ucomisd	0x72fb(%rip), %xmm2     # 0x1800093e0
1800020e5:     	jae	0x18000215d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x7dd>
1800020e7:     	movsd	0x10(%r15,%rax,8), %xmm2
1800020ee:     	mulsd	%xmm2, %xmm2
1800020f2:     	movapd	0x72d6(%rip), %xmm3     # 0x1800093d0
1800020fa:     	andpd	%xmm2, %xmm3
1800020fe:     	ucomisd	0x72da(%rip), %xmm3     # 0x1800093e0
180002106:     	jae	0x18000215d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x7dd>
180002108:     	addsd	%xmm2, %xmm1
18000210c:     	movapd	0x72bc(%rip), %xmm2     # 0x1800093d0
180002114:     	andpd	%xmm1, %xmm2
180002118:     	ucomisd	0x72c0(%rip), %xmm2     # 0x1800093e0
180002120:     	jae	0x18000215d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x7dd>
180002122:     	movsd	0x20(%r15,%rax,8), %xmm2
180002129:     	mulsd	%xmm2, %xmm2
18000212d:     	movapd	0x729b(%rip), %xmm3     # 0x1800093d0
180002135:     	andpd	%xmm2, %xmm3
180002139:     	ucomisd	0x729f(%rip), %xmm3     # 0x1800093e0
180002141:     	jae	0x18000215d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x7dd>
180002143:     	addsd	%xmm2, %xmm1
180002147:     	movapd	0x7281(%rip), %xmm2     # 0x1800093d0
18000214f:     	andpd	%xmm1, %xmm2
180002153:     	ucomisd	0x7285(%rip), %xmm2     # 0x1800093e0
18000215b:     	jb	0x18000216e <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x7ee>
18000215d:     	movb	$0x1, (%r13)
180002162:     	movq	$0x14fb183, 0x18(%rbp)  # imm = 0x14FB183
18000216a:     	xorpd	%xmm1, %xmm1
18000216e:     	cmpb	$0x0, (%r13)
180002173:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
180002179:     	sqrtsd	%xmm1, %xmm1
18000217d:     	xorpd	%xmm2, %xmm2
180002181:     	ucomisd	%xmm2, %xmm1
180002185:     	jne	0x18000235a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x9da>
18000218b:     	jp	0x18000235a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x9da>
180002191:     	movb	$0x1, (%r13)
180002196:     	movq	$0x3d0902, 0x18(%rbp)   # imm = 0x3D0902
18000219e:     	movzbl	(%r13), %eax
1800021a3:     	movq	$-0x1, 0x60(%rsp)
1800021ac:     	testb	%al, %al
1800021ae:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
1800021b4:     	movq	0x58(%rsp), %rax
1800021b9:     	movq	0x8(%r12,%rax,8), %rax
1800021be:     	movq	0x60(%rsp), %r8
1800021c3:     	movsd	0x10(%r15,%r8,8), %xmm4
1800021ca:     	movsd	0x20(%r15,%rax,8), %xmm5
1800021d1:     	movapd	%xmm4, %xmm1
1800021d5:     	mulsd	%xmm5, %xmm1
1800021d9:     	movapd	0x71ef(%rip), %xmm2     # 0x1800093d0
1800021e1:     	andpd	%xmm1, %xmm2
1800021e5:     	ucomisd	0x71f3(%rip), %xmm2     # 0x1800093e0
1800021ed:     	jae	0x1800023e0 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xa60>
1800021f3:     	movq	0x60(%rsp), %r8
1800021f8:     	movsd	0x20(%r15,%r8,8), %xmm2
1800021ff:     	movsd	0x10(%r15,%rax,8), %xmm3
180002206:     	movapd	%xmm2, %xmm6
18000220a:     	mulsd	%xmm3, %xmm6
18000220e:     	movapd	0x71ba(%rip), %xmm7     # 0x1800093d0
180002216:     	andpd	%xmm6, %xmm7
18000221a:     	ucomisd	0x71be(%rip), %xmm7     # 0x1800093e0
180002222:     	jae	0x1800023e0 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xa60>
180002228:     	subsd	%xmm6, %xmm1
18000222c:     	movapd	0x719c(%rip), %xmm6     # 0x1800093d0
180002234:     	andpd	%xmm1, %xmm6
180002238:     	ucomisd	0x71a0(%rip), %xmm6     # 0x1800093e0
180002240:     	jae	0x1800023e0 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xa60>
180002246:     	movsd	(%r15,%rax,8), %xmm6
18000224c:     	mulsd	%xmm6, %xmm2
180002250:     	movapd	0x7178(%rip), %xmm7     # 0x1800093d0
180002258:     	andpd	%xmm2, %xmm7
18000225c:     	ucomisd	0x717c(%rip), %xmm7     # 0x1800093e0
180002264:     	jae	0x1800023e0 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xa60>
18000226a:     	movq	0x60(%rsp), %rax
18000226f:     	movsd	(%r15,%rax,8), %xmm7
180002275:     	mulsd	%xmm7, %xmm5
180002279:     	movapd	0x714e(%rip), %xmm8     # 0x1800093d0
180002282:     	andpd	%xmm5, %xmm8
180002287:     	ucomisd	0x7150(%rip), %xmm8     # 0x1800093e0
180002290:     	jae	0x1800023e0 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xa60>
180002296:     	subsd	%xmm5, %xmm2
18000229a:     	movapd	0x712e(%rip), %xmm5     # 0x1800093d0
1800022a2:     	andpd	%xmm2, %xmm5
1800022a6:     	ucomisd	0x7132(%rip), %xmm5     # 0x1800093e0
1800022ae:     	jae	0x1800023e0 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xa60>
1800022b4:     	mulsd	%xmm7, %xmm3
1800022b8:     	movapd	0x7110(%rip), %xmm5     # 0x1800093d0
1800022c0:     	andpd	%xmm3, %xmm5
1800022c4:     	ucomisd	0x7114(%rip), %xmm5     # 0x1800093e0
1800022cc:     	jae	0x1800023e0 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xa60>
1800022d2:     	mulsd	%xmm6, %xmm4
1800022d6:     	movapd	0x70f2(%rip), %xmm5     # 0x1800093d0
1800022de:     	andpd	%xmm4, %xmm5
1800022e2:     	ucomisd	0x70f6(%rip), %xmm5     # 0x1800093e0
1800022ea:     	jae	0x1800023e0 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xa60>
1800022f0:     	subsd	%xmm4, %xmm3
1800022f4:     	movapd	0x70d4(%rip), %xmm4     # 0x1800093d0
1800022fc:     	andpd	%xmm3, %xmm4
180002300:     	ucomisd	0x70d8(%rip), %xmm4     # 0x1800093e0
180002308:     	jae	0x1800023e0 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xa60>
18000230e:     	movq	(%rbp), %r8
180002312:     	leaq	0x6(%r8), %rax
180002316:     	cmpq	%rdi, %rax
180002319:     	jg	0x18000202a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x6aa>
18000231f:     	movq	%rax, (%rbp)
180002323:     	cmpb	$0x0, (%r13)
180002328:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
18000232e:     	movsd	%xmm1, (%r15,%r8,8)
180002334:     	movsd	%xmm2, 0x10(%r15,%r8,8)
18000233b:     	movsd	%xmm3, 0x20(%r15,%r8,8)
180002342:     	movzbl	(%r13), %r9d
180002347:     	xorl	%eax, %eax
180002349:     	movl	%r9d, %r10d
18000234c:     	negb	%r10b
18000234f:     	sbbq	%rax, %rax
180002352:     	orq	%r8, %rax
180002355:     	jmp	0x1800023f9 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xa79>
18000235a:     	movq	(%rbp), %r8
18000235e:     	leaq	0x6(%r8), %r9
180002362:     	cmpq	%rdi, %r9
180002365:     	jg	0x18000202a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x6aa>
18000236b:     	movsd	(%r15,%rax,8), %xmm2
180002371:     	movsd	0x10(%r15,%rax,8), %xmm3
180002378:     	movsd	0x20(%r15,%rax,8), %xmm4
18000237f:     	movq	%r9, (%rbp)
180002383:     	cmpb	$0x0, (%r13)
180002388:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
18000238e:     	movsd	0x7052(%rip), %xmm5     # 0x1800093e8
180002396:     	divsd	%xmm1, %xmm5
18000239a:     	mulsd	%xmm5, %xmm2
18000239e:     	mulsd	%xmm5, %xmm3
1800023a2:     	mulsd	%xmm4, %xmm5
1800023a6:     	movsd	%xmm2, (%r15,%r8,8)
1800023ac:     	movsd	%xmm3, 0x10(%r15,%r8,8)
1800023b3:     	movsd	%xmm5, 0x20(%r15,%r8,8)
1800023ba:     	movzbl	(%r13), %eax
1800023bf:     	xorl	%r10d, %r10d
1800023c2:     	movl	%eax, %r9d
1800023c5:     	negb	%r9b
1800023c8:     	sbbq	%r10, %r10
1800023cb:     	orq	%r8, %r10
1800023ce:     	movq	%r10, 0x60(%rsp)
1800023d3:     	testb	%al, %al
1800023d5:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
1800023db:     	jmp	0x1800021b4 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x834>
1800023e0:     	movb	$0x1, (%r13)
1800023e5:     	movq	$0x2dc6c3, 0x18(%rbp)   # imm = 0x2DC6C3
1800023ed:     	movzbl	(%r13), %r9d
1800023f2:     	movq	$-0x1, %rax
1800023f9:     	testb	%r9b, %r9b
1800023fc:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
180002402:     	movsd	(%r15,%rax,8), %xmm1
180002408:     	mulsd	%xmm1, %xmm1
18000240c:     	movapd	0x6fbc(%rip), %xmm2     # 0x1800093d0
180002414:     	andpd	%xmm1, %xmm2
180002418:     	ucomisd	0x6fc0(%rip), %xmm2     # 0x1800093e0
180002420:     	jae	0x180002498 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xb18>
180002422:     	movsd	0x10(%r15,%rax,8), %xmm2
180002429:     	mulsd	%xmm2, %xmm2
18000242d:     	movapd	0x6f9b(%rip), %xmm3     # 0x1800093d0
180002435:     	andpd	%xmm2, %xmm3
180002439:     	ucomisd	0x6f9f(%rip), %xmm3     # 0x1800093e0
180002441:     	jae	0x180002498 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xb18>
180002443:     	addsd	%xmm2, %xmm1
180002447:     	movapd	0x6f81(%rip), %xmm2     # 0x1800093d0
18000244f:     	andpd	%xmm1, %xmm2
180002453:     	ucomisd	0x6f85(%rip), %xmm2     # 0x1800093e0
18000245b:     	jae	0x180002498 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xb18>
18000245d:     	movsd	0x20(%r15,%rax,8), %xmm2
180002464:     	mulsd	%xmm2, %xmm2
180002468:     	movapd	0x6f60(%rip), %xmm3     # 0x1800093d0
180002470:     	andpd	%xmm2, %xmm3
180002474:     	ucomisd	0x6f64(%rip), %xmm3     # 0x1800093e0
18000247c:     	jae	0x180002498 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xb18>
18000247e:     	addsd	%xmm2, %xmm1
180002482:     	movapd	0x6f46(%rip), %xmm2     # 0x1800093d0
18000248a:     	andpd	%xmm1, %xmm2
18000248e:     	ucomisd	0x6f4a(%rip), %xmm2     # 0x1800093e0
180002496:     	jb	0x1800024a9 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xb29>
180002498:     	movb	$0x1, (%r13)
18000249d:     	movq	$0x14fb183, 0x18(%rbp)  # imm = 0x14FB183
1800024a5:     	xorpd	%xmm1, %xmm1
1800024a9:     	cmpb	$0x0, (%r13)
1800024ae:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
1800024b4:     	sqrtsd	%xmm1, %xmm1
1800024b8:     	xorpd	%xmm2, %xmm2
1800024bc:     	ucomisd	%xmm2, %xmm1
1800024c0:     	jne	0x180002dce <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x144e>
1800024c6:     	jp	0x180002dce <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x144e>
1800024cc:     	movb	$0x1, (%r13)
1800024d1:     	movq	$0x3d0902, 0x18(%rbp)   # imm = 0x3D0902
1800024d9:     	movzbl	(%r13), %eax
1800024de:     	movq	$-0x8, 0x80(%rsp)
1800024ea:     	testb	%al, %al
1800024ec:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
1800024f2:     	movq	0x220(%rsp), %rax
1800024fa:     	movq	0x8(%r12,%rax,8), %rax
1800024ff:     	movq	%rax, 0xe8(%rsp)
180002507:     	testq	%rax, %rax
18000250a:     	jle	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
180002510:     	movsd	0x6eb0(%rip), %xmm6     # 0x1800093c8
180002518:     	movapd	%xmm0, %xmm8
18000251d:     	mulsd	%xmm0, %xmm6
180002521:     	movapd	%xmm0, %xmm7
180002525:     	addsd	%xmm0, %xmm8
18000252a:     	cvtsi2sd	%rcx, %xmm0
18000252f:     	divsd	%xmm0, %xmm8
180002534:     	movapd	%xmm6, %xmm9
180002539:     	addsd	%xmm6, %xmm9
18000253e:     	xorps	%xmm0, %xmm0
180002541:     	cvtsi2sd	%rdx, %xmm0
180002546:     	divsd	%xmm0, %xmm9
18000254b:     	movq	$-0x1, 0x78(%rsp)
180002554:     	movapd	0x6e73(%rip), %xmm10    # 0x1800093d0
18000255d:     	movsd	0x6e7a(%rip), %xmm11    # 0x1800093e0
180002566:     	xorpd	%xmm12, %xmm12
18000256b:     	movsd	0x6e7c(%rip), %xmm13    # 0x1800093f0
180002574:     	movsd	0x6e83(%rip), %xmm15    # 0x180009400
18000257d:     	movq	$0x0, 0x70(%rsp)
180002586:     	movq	0x70(%rsp), %rcx
18000258b:     	leaq	0x1(%rcx), %rax
18000258f:     	movq	%rax, 0x70(%rsp)
180002594:     	movq	0x220(%rsp), %rax
18000259c:     	movq	0x10(%r12,%rax,8), %rdx
1800025a1:     	testq	%rdx, %rdx
1800025a4:     	movl	$0x0, %eax
1800025a9:     	cmovleq	%rax, %rdx
1800025ad:     	movq	%rdx, 0xf8(%rsp)
1800025b5:     	movq	%rcx, 0xf0(%rsp)
1800025bd:     	xorps	%xmm14, %xmm14
1800025c1:     	cvtsi2sd	%rcx, %xmm14
1800025c6:     	mulsd	%xmm9, %xmm14
1800025cb:     	subsd	%xmm6, %xmm14
1800025d0:     	movq	$0x0, 0x68(%rsp)
1800025d9:     	movq	0x68(%rsp), %rax
1800025de:     	cmpq	%rax, 0xf8(%rsp)
1800025e6:     	je	0x180002db1 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1431>
1800025ec:     	movq	(%rbp), %rdx
1800025f0:     	leaq	0x6(%rdx), %rax
1800025f4:     	cmpq	%rdi, %rax
1800025f7:     	jg	0x18000202a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x6aa>
1800025fd:     	movq	0x60(%rsp), %rcx
180002602:     	movsd	(%r15,%rcx,8), %xmm0
180002608:     	movsd	0x10(%r15,%rcx,8), %xmm1
18000260f:     	movsd	0x20(%r15,%rcx,8), %xmm2
180002616:     	movq	%rax, (%rbp)
18000261a:     	cmpb	$0x0, (%r13)
18000261f:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
180002625:     	xorps	%xmm3, %xmm3
180002628:     	cvtsi2sdq	0x68(%rsp), %xmm3
18000262f:     	mulsd	%xmm8, %xmm3
180002634:     	subsd	%xmm7, %xmm3
180002638:     	mulsd	%xmm3, %xmm0
18000263c:     	mulsd	%xmm3, %xmm1
180002640:     	mulsd	%xmm2, %xmm3
180002644:     	movsd	%xmm0, (%r15,%rdx,8)
18000264a:     	movsd	%xmm1, 0x10(%r15,%rdx,8)
180002651:     	movsd	%xmm3, 0x20(%r15,%rdx,8)
180002658:     	cmpb	$0x0, (%r13)
18000265d:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
180002663:     	movq	(%rbp), %rax
180002667:     	leaq	0x6(%rax), %rcx
18000266b:     	cmpq	%rdi, %rcx
18000266e:     	jg	0x18000202a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x6aa>
180002674:     	movq	0x80(%rsp), %r8
18000267c:     	movsd	(%r15,%r8), %xmm0
180002682:     	movsd	0x10(%r15,%r8), %xmm1
180002689:     	movsd	0x20(%r15,%r8), %xmm2
180002690:     	movq	%rcx, (%rbp)
180002694:     	cmpb	$0x0, (%r13)
180002699:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
18000269f:     	mulsd	%xmm14, %xmm0
1800026a4:     	mulsd	%xmm14, %xmm1
1800026a9:     	mulsd	%xmm14, %xmm2
1800026ae:     	movsd	%xmm0, (%r15,%rax,8)
1800026b4:     	movsd	%xmm1, 0x10(%r15,%rax,8)
1800026bb:     	movsd	%xmm2, 0x20(%r15,%rax,8)
1800026c2:     	cmpb	$0x0, (%r13)
1800026c7:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
1800026cd:     	movq	0x58(%rsp), %r8
1800026d2:     	movq	(%r12,%r8,8), %rcx
1800026d6:     	movq	0x8(%r12,%r8,8), %r8
1800026db:     	movsd	(%r15,%r8,8), %xmm0
1800026e1:     	addsd	(%r15,%rdx,8), %xmm0
1800026e7:     	movapd	%xmm0, %xmm1
1800026eb:     	andpd	%xmm10, %xmm1
1800026f0:     	ucomisd	%xmm11, %xmm1
1800026f5:     	jae	0x180002782 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xe02>
1800026fb:     	movsd	0x10(%r15,%r8,8), %xmm1
180002702:     	addsd	0x10(%r15,%rdx,8), %xmm1
180002709:     	movapd	%xmm1, %xmm2
18000270d:     	andpd	%xmm10, %xmm2
180002712:     	ucomisd	%xmm11, %xmm2
180002717:     	jae	0x180002782 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xe02>
180002719:     	movsd	0x20(%r15,%r8,8), %xmm2
180002720:     	addsd	0x20(%r15,%rdx,8), %xmm2
180002727:     	movapd	%xmm2, %xmm3
18000272b:     	andpd	%xmm10, %xmm3
180002730:     	ucomisd	%xmm11, %xmm3
180002735:     	jae	0x180002782 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xe02>
180002737:     	movq	(%rbp), %r8
18000273b:     	leaq	0x6(%r8), %rdx
18000273f:     	cmpq	%rdi, %rdx
180002742:     	jg	0x18000202a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x6aa>
180002748:     	movq	%rdx, (%rbp)
18000274c:     	cmpb	$0x0, (%r13)
180002751:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
180002757:     	movsd	%xmm0, (%r15,%r8,8)
18000275d:     	movsd	%xmm1, 0x10(%r15,%r8,8)
180002764:     	movsd	%xmm2, 0x20(%r15,%r8,8)
18000276b:     	movzbl	(%r13), %r9d
180002770:     	movl	%r9d, %edx
180002773:     	negb	%dl
180002775:     	movl	$0x0, %edx
18000277a:     	sbbq	%rdx, %rdx
18000277d:     	orq	%r8, %rdx
180002780:     	jmp	0x18000279b <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xe1b>
180002782:     	movb	$0x1, (%r13)
180002787:     	movq	$0x5b8d85, 0x18(%rbp)   # imm = 0x5B8D85
18000278f:     	movzbl	(%r13), %r9d
180002794:     	movq	$-0x1, %rdx
18000279b:     	testb	%r9b, %r9b
18000279e:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
1800027a4:     	movsd	(%r15,%rdx,8), %xmm0
1800027aa:     	addsd	(%r15,%rax,8), %xmm0
1800027b0:     	movapd	%xmm0, %xmm1
1800027b4:     	andpd	%xmm10, %xmm1
1800027b9:     	ucomisd	%xmm11, %xmm1
1800027be:     	jae	0x18000284b <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xecb>
1800027c4:     	movsd	0x10(%r15,%rdx,8), %xmm1
1800027cb:     	addsd	0x10(%r15,%rax,8), %xmm1
1800027d2:     	movapd	%xmm1, %xmm2
1800027d6:     	andpd	%xmm10, %xmm2
1800027db:     	ucomisd	%xmm11, %xmm2
1800027e0:     	jae	0x18000284b <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xecb>
1800027e2:     	movsd	0x20(%r15,%rdx,8), %xmm2
1800027e9:     	addsd	0x20(%r15,%rax,8), %xmm2
1800027f0:     	movapd	%xmm2, %xmm3
1800027f4:     	andpd	%xmm10, %xmm3
1800027f9:     	ucomisd	%xmm11, %xmm3
1800027fe:     	jae	0x18000284b <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xecb>
180002800:     	movq	(%rbp), %rax
180002804:     	leaq	0x6(%rax), %rdx
180002808:     	cmpq	%rdi, %rdx
18000280b:     	jg	0x18000202a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x6aa>
180002811:     	movq	%rdx, (%rbp)
180002815:     	cmpb	$0x0, (%r13)
18000281a:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
180002820:     	movsd	%xmm0, (%r15,%rax,8)
180002826:     	movsd	%xmm1, 0x10(%r15,%rax,8)
18000282d:     	movsd	%xmm2, 0x20(%r15,%rax,8)
180002834:     	movzbl	(%r13), %r8d
180002839:     	movl	%r8d, %edx
18000283c:     	negb	%dl
18000283e:     	movl	$0x0, %edx
180002843:     	sbbq	%rdx, %rdx
180002846:     	orq	%rax, %rdx
180002849:     	jmp	0x180002864 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xee4>
18000284b:     	movb	$0x1, (%r13)
180002850:     	movq	$0x5b8d85, 0x18(%rbp)   # imm = 0x5B8D85
180002858:     	movzbl	(%r13), %r8d
18000285d:     	movq	$-0x1, %rdx
180002864:     	testb	%r8b, %r8b
180002867:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
18000286d:     	movq	(%rbp), %rax
180002871:     	leaq	0x2(%rax), %r8
180002875:     	cmpq	%rdi, %r8
180002878:     	jg	0x18000202a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x6aa>
18000287e:     	movq	%r8, (%rbp)
180002882:     	cmpb	$0x0, (%r13)
180002887:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
18000288d:     	movq	%rcx, (%r12,%rax,8)
180002891:     	cmpb	$0x0, (%r13)
180002896:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
18000289c:     	movsd	(%r15,%rdx,8), %xmm0
1800028a2:     	mulsd	%xmm0, %xmm0
1800028a6:     	movapd	%xmm0, %xmm1
1800028aa:     	andpd	%xmm10, %xmm1
1800028af:     	ucomisd	%xmm11, %xmm1
1800028b4:     	jae	0x180002914 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xf94>
1800028b6:     	movsd	0x10(%r15,%rdx,8), %xmm1
1800028bd:     	mulsd	%xmm1, %xmm1
1800028c1:     	movapd	%xmm1, %xmm2
1800028c5:     	andpd	%xmm10, %xmm2
1800028ca:     	ucomisd	%xmm11, %xmm2
1800028cf:     	jae	0x180002914 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xf94>
1800028d1:     	addsd	%xmm1, %xmm0
1800028d5:     	movapd	%xmm0, %xmm1
1800028d9:     	andpd	%xmm10, %xmm1
1800028de:     	ucomisd	%xmm11, %xmm1
1800028e3:     	jae	0x180002914 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xf94>
1800028e5:     	movsd	0x20(%r15,%rdx,8), %xmm1
1800028ec:     	mulsd	%xmm1, %xmm1
1800028f0:     	movapd	%xmm1, %xmm2
1800028f4:     	andpd	%xmm10, %xmm2
1800028f9:     	ucomisd	%xmm11, %xmm2
1800028fe:     	jae	0x180002914 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xf94>
180002900:     	addsd	%xmm1, %xmm0
180002904:     	movapd	%xmm0, %xmm1
180002908:     	andpd	%xmm10, %xmm1
18000290d:     	ucomisd	%xmm11, %xmm1
180002912:     	jb	0x180002925 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xfa5>
180002914:     	movb	$0x1, (%r13)
180002919:     	movq	$0x14fb183, 0x18(%rbp)  # imm = 0x14FB183
180002921:     	xorpd	%xmm0, %xmm0
180002925:     	cmpb	$0x0, (%r13)
18000292a:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
180002930:     	sqrtsd	%xmm0, %xmm0
180002934:     	ucomisd	%xmm12, %xmm0
180002939:     	jne	0x180002958 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xfd8>
18000293b:     	jp	0x180002958 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xfd8>
18000293d:     	movb	$0x1, (%r13)
180002942:     	movq	$0x3d0902, 0x18(%rbp)   # imm = 0x3D0902
18000294a:     	movzbl	(%r13), %edx
18000294f:     	movq	$-0x1, %r8
180002956:     	jmp	0x1800029cf <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x104f>
180002958:     	movq	(%rbp), %rcx
18000295c:     	leaq	0x6(%rcx), %r8
180002960:     	cmpq	%rdi, %r8
180002963:     	jg	0x18000202a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x6aa>
180002969:     	movsd	(%r15,%rdx,8), %xmm1
18000296f:     	movsd	0x10(%r15,%rdx,8), %xmm2
180002976:     	movsd	0x20(%r15,%rdx,8), %xmm3
18000297d:     	movq	%r8, (%rbp)
180002981:     	cmpb	$0x0, (%r13)
180002986:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
18000298c:     	movsd	0x6a54(%rip), %xmm4     # 0x1800093e8
180002994:     	divsd	%xmm0, %xmm4
180002998:     	mulsd	%xmm4, %xmm1
18000299c:     	mulsd	%xmm4, %xmm2
1800029a0:     	mulsd	%xmm3, %xmm4
1800029a4:     	movsd	%xmm1, (%r15,%rcx,8)
1800029aa:     	movsd	%xmm2, 0x10(%r15,%rcx,8)
1800029b1:     	movsd	%xmm4, 0x20(%r15,%rcx,8)
1800029b8:     	movzbl	(%r13), %edx
1800029bd:     	movl	%edx, %r8d
1800029c0:     	negb	%r8b
1800029c3:     	movl	$0x0, %r8d
1800029c9:     	sbbq	%r8, %r8
1800029cc:     	orq	%rcx, %r8
1800029cf:     	testb	%dl, %dl
1800029d1:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
1800029d7:     	movq	%r8, 0x8(%r12,%rax,8)
1800029dc:     	cmpb	$0x0, (%r13)
1800029e1:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
1800029e7:     	movq	0x8(%rbp), %rcx
1800029eb:     	leaq	0x1(%rcx), %rdx
1800029ef:     	movq	%rdx, 0x8(%rbp)
1800029f3:     	cmpq	0x10(%rbp), %rcx
1800029f7:     	jge	0x180002e5d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x14dd>
1800029fd:     	movq	$0x0, 0x88(%rsp)
180002a09:     	movb	$0x0, 0x90(%rsp)
180002a11:     	movq	$0x0, 0x98(%rsp)
180002a1d:     	movb	$0x0, 0xa0(%rsp)
180002a25:     	movq	$0x0, 0xa8(%rsp)
180002a31:     	movb	$0x0, 0xb0(%rsp)
180002a39:     	movq	$0x0, 0xb8(%rsp)
180002a45:     	movb	$0x0, 0xc0(%rsp)
180002a4d:     	movq	$0x0, 0xc8(%rsp)
180002a59:     	movb	$0x0, 0xd0(%rsp)
180002a61:     	movq	$0x0, 0xd8(%rsp)
180002a6d:     	movb	$0x0, 0xe0(%rsp)
180002a75:     	movq	%rax, 0x28(%rsp)
180002a7a:     	movq	%rbx, 0x20(%rsp)
180002a7f:     	movq	$-0x1, 0x50(%rsp)
180002a88:     	movq	$-0x1, 0x48(%rsp)
180002a91:     	movq	$-0x1, 0x40(%rsp)
180002a9a:     	movq	$-0x1, 0x38(%rsp)
180002aa3:     	movq	$-0x1, 0x30(%rsp)
180002aac:     	leaq	0x88(%rsp), %rcx
180002ab4:     	leaq	0x108(%rsp), %rdx
180002abc:     	movq	%r14, %r8
180002abf:     	xorl	%r9d, %r9d
180002ac2:     	callq	0x180002e80 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1500>
180002ac7:     	testl	%eax, %eax
180002ac9:     	jne	0x180002e6f <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x14ef>
180002acf:     	cmpb	$0x0, (%r13)
180002ad4:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
180002ada:     	movsd	0x88(%rsp), %xmm2
180002ae3:     	movsd	0x98(%rsp), %xmm1
180002aec:     	movsd	0xa8(%rsp), %xmm0
180002af5:     	decq	0x8(%rbp)
180002af9:     	movq	0x220(%rsp), %rax
180002b01:     	movq	0x8(%r12,%rax,8), %rax
180002b06:     	movq	%rax, %rcx
180002b09:     	subq	0xf0(%rsp), %rcx
180002b11:     	movq	%rcx, %rdx
180002b14:     	notq	%rdx
180002b17:     	testq	%rdx, %rax
180002b1a:     	js	0x180001b79 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1f9>
180002b20:     	cmpb	$0x0, (%r13)
180002b25:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
180002b2b:     	movabsq	$-0x8000000000000000, %rdx # imm = 0x8000000000000000
180002b35:     	cmpq	%rdx, %rcx
180002b38:     	je	0x180001b79 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1f9>
180002b3e:     	decq	%rcx
180002b41:     	movq	0x220(%rsp), %rdx
180002b49:     	movq	0x10(%r12,%rdx,8), %rdx
180002b4e:     	cvtsi2sd	%rcx, %xmm3
180002b53:     	cvtsi2sd	%rdx, %xmm4
180002b58:     	mulsd	%xmm3, %xmm4
180002b5c:     	andpd	%xmm10, %xmm4
180002b61:     	ucomisd	%xmm13, %xmm4
180002b66:     	jae	0x180001b79 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1f9>
180002b6c:     	imulq	%rdx, %rcx
180002b70:     	addq	0x78(%rsp), %rax
180002b75:     	imulq	%rdx, %rax
180002b79:     	movq	0x68(%rsp), %r8
180002b7e:     	addq	%r8, %rax
180002b81:     	xorq	%rax, %rcx
180002b84:     	movq	%rax, %rdx
180002b87:     	xorq	%r8, %rdx
180002b8a:     	testq	%rdx, %rcx
180002b8d:     	js	0x180001b79 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1f9>
180002b93:     	xorps	%xmm3, %xmm3
180002b96:     	cvtsi2sd	%rax, %xmm3
180002b9b:     	mulsd	0x6855(%rip), %xmm3     # 0x1800093f8
180002ba3:     	andpd	%xmm10, %xmm3
180002ba8:     	ucomisd	%xmm13, %xmm3
180002bad:     	jae	0x180001b79 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1f9>
180002bb3:     	mulsd	%xmm15, %xmm2
180002bb8:     	movapd	%xmm2, %xmm3
180002bbc:     	andpd	%xmm10, %xmm3
180002bc1:     	ucomisd	%xmm11, %xmm3
180002bc6:     	jae	0x180002d71 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x13f1>
180002bcc:     	movsd	0x6834(%rip), %xmm4     # 0x180009408
180002bd4:     	ucomisd	%xmm3, %xmm4
180002bd8:     	jbe	0x180002d71 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x13f1>
180002bde:     	leaq	(%rax,%rax,2), %rcx
180002be2:     	cvttsd2si	%xmm2, %rdx
180002be7:     	testq	%rdx, %rdx
180002bea:     	movl	$0x0, %r8d
180002bf0:     	cmovleq	%r8, %rdx
180002bf4:     	cmpq	$0xff, %rdx
180002bfb:     	movl	$0xff, %r8d
180002c01:     	cmovgeq	%r8, %rdx
180002c05:     	movq	0x220(%rsp), %r8
180002c0d:     	movq	(%r12,%r8,8), %r8
180002c11:     	movq	(%r12,%r8,8), %r10
180002c15:     	testq	%rax, %rax
180002c18:     	movq	%rcx, %r9
180002c1b:     	jns	0x180002c29 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x12a9>
180002c1d:     	movq	%r10, %r9
180002c20:     	addq	%rcx, %r9
180002c23:     	js	0x180002d71 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x13f1>
180002c29:     	cmpq	%r10, %r9
180002c2c:     	jge	0x180002d71 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x13f1>
180002c32:     	movq	0x10(%r12,%r8,8), %r8
180002c37:     	leaq	(%r12,%r8,8), %r8
180002c3b:     	movq	%rdx, (%r8,%r9,8)
180002c3f:     	mulsd	%xmm15, %xmm1
180002c44:     	movapd	%xmm1, %xmm2
180002c48:     	andpd	%xmm10, %xmm2
180002c4d:     	ucomisd	%xmm11, %xmm2
180002c52:     	jae	0x180002d93 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1413>
180002c58:     	movsd	0x67a8(%rip), %xmm3     # 0x180009408
180002c60:     	ucomisd	%xmm2, %xmm3
180002c64:     	jbe	0x180002d93 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1413>
180002c6a:     	cvttsd2si	%xmm1, %r8
180002c6f:     	testq	%r8, %r8
180002c72:     	movl	$0x0, %edx
180002c77:     	cmovleq	%rdx, %r8
180002c7b:     	cmpq	$0xff, %r8
180002c82:     	movl	$0xff, %edx
180002c87:     	cmovgeq	%rdx, %r8
180002c8b:     	leaq	0x1(%rcx), %r9
180002c8f:     	movq	%rcx, %rdx
180002c92:     	notq	%rdx
180002c95:     	testq	%rdx, %r9
180002c98:     	js	0x180001b79 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1f9>
180002c9e:     	cmpb	$0x0, (%r13)
180002ca3:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
180002ca9:     	movq	0x220(%rsp), %r10
180002cb1:     	movq	(%r12,%r10,8), %r10
180002cb5:     	testq	%rax, %rax
180002cb8:     	movq	(%r12,%r10,8), %r11
180002cbc:     	jns	0x180002cc7 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1347>
180002cbe:     	addq	%r11, %r9
180002cc1:     	js	0x180002d93 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1413>
180002cc7:     	cmpq	%r11, %r9
180002cca:     	jge	0x180002d93 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1413>
180002cd0:     	movq	0x10(%r12,%r10,8), %r10
180002cd5:     	leaq	(%r12,%r10,8), %r10
180002cd9:     	movq	%r8, (%r10,%r9,8)
180002cdd:     	mulsd	%xmm15, %xmm0
180002ce2:     	movapd	%xmm0, %xmm1
180002ce6:     	andpd	%xmm10, %xmm1
180002ceb:     	ucomisd	%xmm11, %xmm1
180002cf0:     	jae	0x180002da2 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1422>
180002cf6:     	movsd	0x670a(%rip), %xmm2     # 0x180009408
180002cfe:     	ucomisd	%xmm1, %xmm2
180002d02:     	jbe	0x180002da2 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1422>
180002d08:     	cvttsd2si	%xmm0, %r8
180002d0d:     	testq	%r8, %r8
180002d10:     	movl	$0x0, %r9d
180002d16:     	cmovleq	%r9, %r8
180002d1a:     	cmpq	$0xff, %r8
180002d21:     	movl	$0xff, %r9d
180002d27:     	cmovgeq	%r9, %r8
180002d2b:     	addq	$0x2, %rcx
180002d2f:     	testq	%rdx, %rcx
180002d32:     	js	0x180001b79 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1f9>
180002d38:     	cmpb	$0x0, (%r13)
180002d3d:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
180002d43:     	movq	0x220(%rsp), %rdx
180002d4b:     	movq	(%r12,%rdx,8), %rdx
180002d4f:     	testq	%rax, %rax
180002d52:     	movq	(%r12,%rdx,8), %rax
180002d56:     	jns	0x180002d5d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x13dd>
180002d58:     	addq	%rax, %rcx
180002d5b:     	js	0x180002da2 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1422>
180002d5d:     	cmpq	%rax, %rcx
180002d60:     	jge	0x180002da2 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x1422>
180002d62:     	movq	0x10(%r12,%rdx,8), %rax
180002d67:     	leaq	(%r12,%rax,8), %rax
180002d6b:     	movq	%r8, (%rax,%rcx,8)
180002d6f:     	jmp	0x180002d7e <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x13fe>
180002d71:     	movb	$0x1, (%r13)
180002d76:     	movq	$0x7a1203, 0x18(%rbp)   # imm = 0x7A1203
180002d7e:     	incq	0x68(%rsp)
180002d83:     	cmpb	$0x0, (%r13)
180002d88:     	je	0x1800025d9 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xc59>
180002d8e:     	jmp	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
180002d93:     	movb	$0x1, (%r13)
180002d98:     	movq	$0x7a1204, 0x18(%rbp)   # imm = 0x7A1204
180002da0:     	jmp	0x180002d7e <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x13fe>
180002da2:     	movb	$0x1, (%r13)
180002da7:     	movq	$0x7a1205, 0x18(%rbp)   # imm = 0x7A1205
180002daf:     	jmp	0x180002d7e <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x13fe>
180002db1:     	decq	0x78(%rsp)
180002db6:     	movq	0x70(%rsp), %rax
180002dbb:     	cmpq	0xe8(%rsp), %rax
180002dc3:     	jne	0x180002586 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xc06>
180002dc9:     	jmp	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
180002dce:     	movq	(%rbp), %r8
180002dd2:     	leaq	0x6(%r8), %r9
180002dd6:     	cmpq	%rdi, %r9
180002dd9:     	jg	0x18000202a <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x6aa>
180002ddf:     	movsd	(%r15,%rax,8), %xmm2
180002de5:     	movsd	0x10(%r15,%rax,8), %xmm3
180002dec:     	movsd	0x20(%r15,%rax,8), %xmm4
180002df3:     	movq	%r9, (%rbp)
180002df7:     	cmpb	$0x0, (%r13)
180002dfc:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
180002e02:     	movsd	0x65de(%rip), %xmm5     # 0x1800093e8
180002e0a:     	divsd	%xmm1, %xmm5
180002e0e:     	mulsd	%xmm5, %xmm2
180002e12:     	mulsd	%xmm5, %xmm3
180002e16:     	mulsd	%xmm4, %xmm5
180002e1a:     	leaq	(,%r8,8), %r9
180002e22:     	movsd	%xmm2, (%r15,%r8,8)
180002e28:     	movsd	%xmm3, 0x10(%r15,%r8,8)
180002e2f:     	movsd	%xmm5, 0x20(%r15,%r8,8)
180002e36:     	movzbl	(%r13), %eax
180002e3b:     	testb	%al, %al
180002e3d:     	movq	$-0x8, %r8
180002e44:     	cmoveq	%r9, %r8
180002e48:     	movq	%r8, 0x80(%rsp)
180002e50:     	testb	%al, %al
180002e52:     	jne	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
180002e58:     	jmp	0x1800024f2 <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0xb72>
180002e5d:     	movb	$0x1, (%r13)
180002e62:     	movq	$0x13, 0x18(%rbp)
180002e6a:     	jmp	0x180001b8d <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20d>
180002e6f:     	movq	0x100(%rsp), %rsi
180002e77:     	jmp	0x180001b8f <PyInit_rcaotr_7508da57ea552f418d6e0f1d+0x20f>
180002e7c:     	nopl	(%rax)
