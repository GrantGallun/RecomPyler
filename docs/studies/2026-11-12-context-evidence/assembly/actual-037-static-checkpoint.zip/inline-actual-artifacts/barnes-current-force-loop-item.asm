# barnes-current force-loop-item: [0x1800029a2, 0x1800029d1)
# Source/call-target-bound static range; padding included; never cycles.
1800029a2:     	movq	0x78(%rsp), %rax
1800029a7:     	cmpq	(%rbp,%rax), %r14
1800029ac:     	jge	0x180002aef <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x57f>
1800029b2:     	movq	0x80(%rsp), %rax
1800029ba:     	movq	0x10(%rbp,%rax), %rax
1800029bf:     	addq	%r14, %rax
1800029c2:     	leaq	(%rdi,%rax,8), %rcx
1800029c6:     	sarq	$0x3f, %rax
1800029ca:     	andq	%r12, %rax
1800029cd:     	movq	(%rcx,%rax,8), %rsi
