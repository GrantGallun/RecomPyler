# barnes-current first-recursive-call: [0x180002f27, 0x180002f5c)
# Source/call-target-bound static range; padding included; never cycles.
180002f27:     	movsd	%xmm6, 0x48(%rsp)
180002f2d:     	movq	%rbx, 0x40(%rsp)
180002f32:     	movq	%rax, 0x38(%rsp)
180002f37:     	movq	%r15, 0x30(%rsp)
180002f3c:     	movq	%rdi, 0x28(%rsp)
180002f41:     	movq	%rsi, 0x20(%rsp)
180002f46:     	leaq	0xc0(%rsp), %rcx
180002f4e:     	movq	%r15, %r12
180002f51:     	movq	%r8, %r15
180002f54:     	movq	%r9, %rbp
180002f57:     	callq	0x180002c30 <PyInit_rcaotr_37d5bbedabb5b3cb6ca652c3+0x6c0>
