
D:\Code\Datathon\recompyler-codex-20261111\wave9-native\results-inline\cache\barnes_hut\final\recompyler\rcaotr_37bed947cdaa1333e55322a8.cp314-win_amd64.pyd:	file format coff-x86-64

Disassembly of section .text:

0000000180001000 <.text>:
180001000:     	movl	$0x1, %eax
180001005:     	lock
180001006:     	xaddq	%rax, (%rcx)
18000100a:     	incq	%rax
18000100d:     	retq
18000100e:     	nop
180001010:     	movq	$-0x1, %rax
180001017:     	lock
180001018:     	xaddq	%rax, (%rcx)
18000101c:     	decq	%rax
18000101f:     	retq
180001020:     	movq	%rdx, %rax
180001023:     	xorl	%edx, %edx
180001025:     	lock
180001026:     	cmpxchgq	%r8, (%rcx)
18000102a:     	sete	%dl
18000102d:     	movq	%rax, (%r9)
180001030:     	movl	%edx, %eax
180001032:     	retq
180001033:     	nopw	%cs:(%rax,%rax)
18000103d:     	nopl	(%rax)
180001040:     	movq	0x18(%rcx), %rax
180001044:     	retq
180001045:     	nopw	%cs:(%rax,%rax)
18000104f:     	nop
180001050:     	testq	%rcx, %rcx
180001053:     	je	0x180001059 <.text+0x59>
180001055:     	lock
180001056:     	incq	(%rcx)
180001059:     	retq
18000105a:     	nopw	(%rax,%rax)
180001060:     	testq	%rcx, %rcx
180001063:     	je	0x18000106b <.text+0x6b>
180001065:     	lock
180001066:     	decq	(%rcx)
180001069:     	je	0x18000106c <.text+0x6c>
18000106b:     	retq
18000106c:     	jmp	0x1800082e0 <numba_list_iter_next+0x160>
180001071:     	nopw	%cs:(%rax,%rax)
18000107b:     	nopl	(%rax,%rax)
180001080:     	leaq	0x93f9(%rip), %rax      # 0x18000a480
180001087:     	movq	%rax, (%rdx)
18000108a:     	movl	$0x1, %eax
18000108f:     	retq
180001090:     	pushq	%r14
180001092:     	pushq	%rsi
180001093:     	pushq	%rdi
180001094:     	pushq	%rbx
180001095:     	subq	$0x78, %rsp
180001099:     	movq	%rcx, %rsi
18000109c:     	movq	0x108(%rsp), %rax
1800010a4:     	movq	0xf0(%rsp), %rcx
1800010ac:     	movq	0xd8(%rsp), %r10
1800010b4:     	movq	0xc0(%rsp), %r11
1800010bc:     	movq	0x100(%rsp), %rdi
1800010c4:     	movq	0xe8(%rsp), %rbx
1800010cc:     	movq	$0x0, 0x40(%rsp)
1800010d5:     	movq	0xd0(%rsp), %r14
1800010dd:     	xorq	%r9, %r14
1800010e0:     	xorq	$0x4, %rbx
1800010e4:     	orq	%r14, %rbx
1800010e7:     	xorq	$0x1, %rdi
1800010eb:     	xorq	$0x8, %r11
1800010ef:     	orq	%rdi, %r11
1800010f2:     	orq	%rbx, %r11
1800010f5:     	xorq	$0x8, %r10
1800010f9:     	xorq	$0x8, %rcx
1800010fd:     	orq	%r10, %rcx
180001100:     	orq	%r11, %rcx
180001103:     	xorq	$0x1, %rax
180001107:     	orq	%rcx, %rax
18000110a:     	jne	0x1800011b4 <.text+0x1b4>
180001110:     	movq	%rdx, %rdi
180001113:     	movq	0x130(%rsp), %rcx
18000111b:     	movq	0x128(%rsp), %rdx
180001123:     	movsd	0x120(%rsp), %xmm0
18000112c:     	movsd	0x118(%rsp), %xmm1
180001135:     	movq	0x110(%rsp), %rax
18000113d:     	movq	0xf8(%rsp), %r10
180001145:     	movq	0xe0(%rsp), %r11
18000114d:     	movq	0xc8(%rsp), %rbx
180001155:     	movq	%r8, 0x50(%rsp)
18000115a:     	movq	%rbx, 0x58(%rsp)
18000115f:     	movq	%r11, 0x60(%rsp)
180001164:     	movq	%r10, 0x68(%rsp)
180001169:     	movq	%r9, 0x70(%rsp)
18000116e:     	movq	$0x0, 0x48(%rsp)
180001177:     	movq	%rcx, 0x38(%rsp)
18000117c:     	movq	%rdx, 0x30(%rsp)
180001181:     	movsd	%xmm0, 0x28(%rsp)
180001187:     	movsd	%xmm1, 0x20(%rsp)
18000118d:     	leaq	0x48(%rsp), %rcx
180001192:     	leaq	0x40(%rsp), %rdx
180001197:     	leaq	0x50(%rsp), %r8
18000119c:     	movq	%rax, %r9
18000119f:     	callq	0x1800025f0 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x60>
1800011a4:     	testl	%eax, %eax
1800011a6:     	jne	0x1800011cd <.text+0x1cd>
1800011a8:     	movq	0x48(%rsp), %rax
1800011ad:     	movq	%rax, (%rsi)
1800011b0:     	xorl	%eax, %eax
1800011b2:     	jmp	0x1800011c3 <.text+0x1c3>
1800011b4:     	leaq	0x9395(%rip), %rax      # 0x18000a550
1800011bb:     	movq	%rax, (%rdx)
1800011be:     	movl	$0x1, %eax
1800011c3:     	addq	$0x78, %rsp
1800011c7:     	popq	%rbx
1800011c8:     	popq	%rdi
1800011c9:     	popq	%rsi
1800011ca:     	popq	%r14
1800011cc:     	retq
1800011cd:     	movq	0x40(%rsp), %rcx
1800011d2:     	movq	%rcx, (%rdi)
1800011d5:     	jmp	0x1800011c3 <.text+0x1c3>
1800011d7:     	nopw	(%rax,%rax)
1800011e0:     	pushq	%r15
1800011e2:     	pushq	%r14
1800011e4:     	pushq	%r13
1800011e6:     	pushq	%r12
1800011e8:     	pushq	%rsi
1800011e9:     	pushq	%rdi
1800011ea:     	pushq	%rbp
1800011eb:     	pushq	%rbx
1800011ec:     	subq	$0x278, %rsp            # imm = 0x278
1800011f3:     	movaps	%xmm7, 0x260(%rsp)
1800011fb:     	movaps	%xmm6, 0x250(%rsp)
180001203:     	movq	%rdx, %rcx
180001206:     	leaq	0x108(%rsp), %rax
18000120e:     	movq	%rax, 0x60(%rsp)
180001213:     	leaq	0x110(%rsp), %rax
18000121b:     	movq	%rax, 0x58(%rsp)
180001220:     	leaq	0x118(%rsp), %rax
180001228:     	movq	%rax, 0x50(%rsp)
18000122d:     	leaq	0x120(%rsp), %rax
180001235:     	movq	%rax, 0x48(%rsp)
18000123a:     	leaq	0x128(%rsp), %rax
180001242:     	movq	%rax, 0x40(%rsp)
180001247:     	leaq	0x130(%rsp), %rax
18000124f:     	movq	%rax, 0x38(%rsp)
180001254:     	leaq	0x138(%rsp), %rax
18000125c:     	movq	%rax, 0x30(%rsp)
180001261:     	leaq	0x140(%rsp), %rax
180001269:     	movq	%rax, 0x28(%rsp)
18000126e:     	leaq	0x148(%rsp), %rax
180001276:     	movq	%rax, 0x20(%rsp)
18000127b:     	leaq	0x92fe(%rip), %rdx      # 0x18000a580
180001282:     	movl	$0x9, %r8d
180001288:     	movl	$0x9, %r9d
18000128e:     	callq	0x180008491 <numba_list_iter_next+0x311>
180001293:     	testl	%eax, %eax
180001295:     	movq	$0x0, 0xb8(%rsp)
1800012a1:     	je	0x18000184b <.text+0x84b>
1800012a7:     	cmpq	$0x0, 0x10a49(%rip)     # 0x180011cf8
1800012af:     	je	0x180001783 <.text+0x783>
1800012b5:     	movq	0x148(%rsp), %rcx
1800012bd:     	xorps	%xmm0, %xmm0
1800012c0:     	movaps	%xmm0, 0x210(%rsp)
1800012c8:     	movaps	%xmm0, 0x220(%rsp)
1800012d0:     	movaps	%xmm0, 0x230(%rsp)
1800012d8:     	movq	$0x0, 0x240(%rsp)
1800012e4:     	leaq	0x210(%rsp), %rdx
1800012ec:     	callq	0x180007150 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4bc0>
1800012f1:     	testl	%eax, %eax
1800012f3:     	jne	0x18000179b <.text+0x79b>
1800012f9:     	cmpq	$0x8, 0x228(%rsp)
180001302:     	jne	0x18000179b <.text+0x79b>
180001308:     	movq	0x210(%rsp), %rdi
180001310:     	movq	0x230(%rsp), %r14
180001318:     	movq	0x238(%rsp), %r12
180001320:     	movq	0x240(%rsp), %rbx
180001328:     	movq	0x140(%rsp), %rcx
180001330:     	xorps	%xmm0, %xmm0
180001333:     	movaps	%xmm0, 0x1d0(%rsp)
18000133b:     	movaps	%xmm0, 0x1e0(%rsp)
180001343:     	movaps	%xmm0, 0x1f0(%rsp)
18000134b:     	movq	$0x0, 0x200(%rsp)
180001357:     	leaq	0x1d0(%rsp), %rdx
18000135f:     	callq	0x180007150 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4bc0>
180001364:     	testl	%eax, %eax
180001366:     	jne	0x1800017b3 <.text+0x7b3>
18000136c:     	cmpq	$0x8, 0x1e8(%rsp)
180001375:     	jne	0x1800017b3 <.text+0x7b3>
18000137b:     	movq	0x1d0(%rsp), %r15
180001383:     	movq	0x1f0(%rsp), %rbp
18000138b:     	movq	0x1f8(%rsp), %rsi
180001393:     	movq	0x200(%rsp), %r13
18000139b:     	movq	0x138(%rsp), %rcx
1800013a3:     	xorps	%xmm0, %xmm0
1800013a6:     	movaps	%xmm0, 0x190(%rsp)
1800013ae:     	movaps	%xmm0, 0x1a0(%rsp)
1800013b6:     	movaps	%xmm0, 0x1b0(%rsp)
1800013be:     	movq	$0x0, 0x1c0(%rsp)
1800013ca:     	leaq	0x190(%rsp), %rdx
1800013d2:     	callq	0x180007150 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4bc0>
1800013d7:     	testl	%eax, %eax
1800013d9:     	jne	0x1800017c8 <.text+0x7c8>
1800013df:     	cmpq	$0x8, 0x1a8(%rsp)
1800013e8:     	jne	0x1800017c8 <.text+0x7c8>
1800013ee:     	movq	%r13, 0x100(%rsp)
1800013f6:     	movq	0x190(%rsp), %r13
1800013fe:     	movq	0x1b0(%rsp), %rax
180001406:     	movq	%rax, 0xf8(%rsp)
18000140e:     	movq	0x1b8(%rsp), %rax
180001416:     	movq	%rax, 0xf0(%rsp)
18000141e:     	movq	0x1c0(%rsp), %rax
180001426:     	movq	%rax, 0xe8(%rsp)
18000142e:     	movq	0x130(%rsp), %rcx
180001436:     	xorps	%xmm0, %xmm0
180001439:     	movaps	%xmm0, 0x150(%rsp)
180001441:     	movaps	%xmm0, 0x160(%rsp)
180001449:     	movaps	%xmm0, 0x170(%rsp)
180001451:     	movq	$0x0, 0x180(%rsp)
18000145d:     	leaq	0x150(%rsp), %rdx
180001465:     	callq	0x180007150 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4bc0>
18000146a:     	testl	%eax, %eax
18000146c:     	jne	0x1800017dd <.text+0x7dd>
180001472:     	cmpq	$0x1, 0x168(%rsp)
18000147b:     	jne	0x1800017dd <.text+0x7dd>
180001481:     	movq	%rsi, 0xd8(%rsp)
180001489:     	movq	0x150(%rsp), %rax
180001491:     	movq	%rax, 0xa8(%rsp)
180001499:     	movq	0x170(%rsp), %rax
1800014a1:     	movq	%rax, 0xd0(%rsp)
1800014a9:     	movq	0x178(%rsp), %rax
1800014b1:     	movq	%rax, 0xc8(%rsp)
1800014b9:     	movq	0x180(%rsp), %rax
1800014c1:     	movq	%rax, 0xc0(%rsp)
1800014c9:     	movq	0x128(%rsp), %rcx
1800014d1:     	callq	0x180008497 <numba_list_iter_next+0x317>
1800014d6:     	testq	%rax, %rax
1800014d9:     	movq	%r13, 0xb0(%rsp)
1800014e1:     	movq	%rbp, 0xe0(%rsp)
1800014e9:     	je	0x1800017f2 <.text+0x7f2>
1800014ef:     	movq	%rax, %rsi
1800014f2:     	movq	%rax, %rcx
1800014f5:     	callq	0x18000849d <numba_list_iter_next+0x31d>
1800014fa:     	movq	%rax, 0xa0(%rsp)
180001502:     	movq	%rsi, %rcx
180001505:     	callq	0x1800084a3 <numba_list_iter_next+0x323>
18000150a:     	callq	0x1800084a9 <numba_list_iter_next+0x329>
18000150f:     	testq	%rax, %rax
180001512:     	jne	0x18000181e <.text+0x81e>
180001518:     	movq	0x120(%rsp), %rcx
180001520:     	callq	0x1800084af <numba_list_iter_next+0x32f>
180001525:     	movq	%rax, %rsi
180001528:     	movq	%rax, %rcx
18000152b:     	callq	0x1800084b5 <numba_list_iter_next+0x335>
180001530:     	movaps	%xmm0, %xmm6
180001533:     	movq	%rsi, %rcx
180001536:     	callq	0x1800084a3 <numba_list_iter_next+0x323>
18000153b:     	callq	0x1800084a9 <numba_list_iter_next+0x329>
180001540:     	testq	%rax, %rax
180001543:     	jne	0x18000181e <.text+0x81e>
180001549:     	movq	0x118(%rsp), %rcx
180001551:     	callq	0x1800084af <numba_list_iter_next+0x32f>
180001556:     	movq	%rax, %rsi
180001559:     	movq	%rax, %rcx
18000155c:     	callq	0x1800084b5 <numba_list_iter_next+0x335>
180001561:     	movaps	%xmm0, %xmm7
180001564:     	movq	%rsi, %rcx
180001567:     	callq	0x1800084a3 <numba_list_iter_next+0x323>
18000156c:     	callq	0x1800084a9 <numba_list_iter_next+0x329>
180001571:     	testq	%rax, %rax
180001574:     	jne	0x18000181e <.text+0x81e>
18000157a:     	movq	0x110(%rsp), %rcx
180001582:     	callq	0x180008497 <numba_list_iter_next+0x317>
180001587:     	testq	%rax, %rax
18000158a:     	je	0x18000180e <.text+0x80e>
180001590:     	movq	%rax, %rsi
180001593:     	movq	%rax, %rcx
180001596:     	callq	0x18000849d <numba_list_iter_next+0x31d>
18000159b:     	movq	%rax, %rbp
18000159e:     	movq	%rsi, %rcx
1800015a1:     	callq	0x1800084a3 <numba_list_iter_next+0x323>
1800015a6:     	callq	0x1800084a9 <numba_list_iter_next+0x329>
1800015ab:     	testq	%rax, %rax
1800015ae:     	jne	0x18000181e <.text+0x81e>
1800015b4:     	movq	%rbx, %r13
1800015b7:     	movq	%r12, %rbx
1800015ba:     	movq	%r14, %r12
1800015bd:     	movq	%r15, %r14
1800015c0:     	movq	%rdi, %r15
1800015c3:     	movq	0x108(%rsp), %rcx
1800015cb:     	callq	0x180008497 <numba_list_iter_next+0x317>
1800015d0:     	testq	%rax, %rax
1800015d3:     	je	0x180001852 <.text+0x852>
1800015d9:     	movq	%rax, %rdi
1800015dc:     	movq	%rax, %rcx
1800015df:     	callq	0x18000849d <numba_list_iter_next+0x31d>
1800015e4:     	movq	%rax, %rsi
1800015e7:     	movq	%rdi, %rcx
1800015ea:     	callq	0x1800084a3 <numba_list_iter_next+0x323>
1800015ef:     	callq	0x1800084a9 <numba_list_iter_next+0x329>
1800015f4:     	testq	%rax, %rax
1800015f7:     	movq	%r15, %rdi
1800015fa:     	movq	%r14, %r15
1800015fd:     	jne	0x18000181e <.text+0x81e>
180001603:     	movq	%rsi, 0x90(%rsp)
18000160b:     	movq	%rbp, 0x88(%rsp)
180001613:     	movsd	%xmm7, 0x80(%rsp)
18000161c:     	movsd	%xmm6, 0x78(%rsp)
180001622:     	movq	0xa0(%rsp), %rax
18000162a:     	movq	%rax, 0x70(%rsp)
18000162f:     	movq	0xc0(%rsp), %rax
180001637:     	movq	%rax, 0x68(%rsp)
18000163c:     	movq	0xc8(%rsp), %rax
180001644:     	movq	%rax, 0x60(%rsp)
180001649:     	movq	0xd0(%rsp), %rax
180001651:     	movq	%rax, 0x58(%rsp)
180001656:     	movq	0xe8(%rsp), %rax
18000165e:     	movq	%rax, 0x50(%rsp)
180001663:     	movq	0xf0(%rsp), %rax
18000166b:     	movq	%rax, 0x48(%rsp)
180001670:     	movq	0xf8(%rsp), %rax
180001678:     	movq	%rax, 0x40(%rsp)
18000167d:     	movq	0x100(%rsp), %rax
180001685:     	movq	%rax, 0x38(%rsp)
18000168a:     	movq	0xd8(%rsp), %rax
180001692:     	movq	%rax, 0x30(%rsp)
180001697:     	movq	0xe0(%rsp), %rax
18000169f:     	movq	%rax, 0x28(%rsp)
1800016a4:     	movq	%r13, 0x20(%rsp)
1800016a9:     	leaq	0x248(%rsp), %rcx
1800016b1:     	leaq	0xb8(%rsp), %rdx
1800016b9:     	movq	%r12, %r8
1800016bc:     	movq	%rbx, %r9
1800016bf:     	callq	0x180001090 <.text+0x90>
1800016c4:     	movl	%eax, %ebp
1800016c6:     	movq	0xb8(%rsp), %rbx
1800016ce:     	movq	%rdi, %rcx
1800016d1:     	callq	0x180001060 <.text+0x60>
1800016d6:     	movq	%r15, %rcx
1800016d9:     	callq	0x180001060 <.text+0x60>
1800016de:     	movq	0xb0(%rsp), %rcx
1800016e6:     	callq	0x180001060 <.text+0x60>
1800016eb:     	movq	0xa8(%rsp), %rcx
1800016f3:     	callq	0x180001060 <.text+0x60>
1800016f8:     	testl	%ebp, %ebp
1800016fa:     	jne	0x180001732 <.text+0x732>
1800016fc:     	movq	0x8bcd(%rip), %rsi      # 0x18000a2d0
180001703:     	movq	%rsi, %rcx
180001706:     	callq	0x1800084bb <numba_list_iter_next+0x33b>
18000170b:     	movq	%rsi, %rax
18000170e:     	movaps	0x250(%rsp), %xmm6
180001716:     	movaps	0x260(%rsp), %xmm7
18000171e:     	addq	$0x278, %rsp            # imm = 0x278
180001725:     	popq	%rbx
180001726:     	popq	%rbp
180001727:     	popq	%rdi
180001728:     	popq	%rsi
180001729:     	popq	%r12
18000172b:     	popq	%r13
18000172d:     	popq	%r14
18000172f:     	popq	%r15
180001731:     	retq
180001732:     	jle	0x180001859 <.text+0x859>
180001738:     	callq	0x1800084c1 <numba_list_iter_next+0x341>
18000173d:     	movl	0x8(%rbx), %edx
180001740:     	movq	(%rbx), %rcx
180001743:     	cmpl	$0x0, 0x20(%rbx)
180001747:     	jle	0x180001878 <.text+0x878>
18000174d:     	movslq	%edx, %rdx
180001750:     	callq	0x1800084c7 <numba_list_iter_next+0x347>
180001755:     	movq	%rax, %rsi
180001758:     	movq	0x10(%rbx), %rcx
18000175c:     	callq	*0x18(%rbx)
18000175f:     	testq	%rax, %rax
180001762:     	je	0x1800018a1 <.text+0x8a1>
180001768:     	movq	%rsi, %rcx
18000176b:     	movq	%rax, %rdx
18000176e:     	callq	0x180006960 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x43d0>
180001773:     	movq	%rax, %rsi
180001776:     	movq	%rbx, %rcx
180001779:     	callq	0x1800083f0 <numba_list_iter_next+0x270>
18000177e:     	jmp	0x180001884 <.text+0x884>
180001783:     	movq	0x8b26(%rip), %rcx      # 0x18000a2b0
18000178a:     	leaq	0x8e0f(%rip), %rdx      # 0x18000a5a0
180001791:     	callq	0x1800084cd <numba_list_iter_next+0x34d>
180001796:     	jmp	0x18000184b <.text+0x84b>
18000179b:     	movq	0x8afe(%rip), %rcx      # 0x18000a2a0
1800017a2:     	leaq	0x8ef7(%rip), %rdx      # 0x18000a6a0
1800017a9:     	callq	0x1800084cd <numba_list_iter_next+0x34d>
1800017ae:     	jmp	0x18000184b <.text+0x84b>
1800017b3:     	movq	0x8ae6(%rip), %rcx      # 0x18000a2a0
1800017ba:     	leaq	0x8edf(%rip), %rdx      # 0x18000a6a0
1800017c1:     	callq	0x1800084cd <numba_list_iter_next+0x34d>
1800017c6:     	jmp	0x180001843 <.text+0x843>
1800017c8:     	movq	0x8ad1(%rip), %rcx      # 0x18000a2a0
1800017cf:     	leaq	0x8eca(%rip), %rdx      # 0x18000a6a0
1800017d6:     	callq	0x1800084cd <numba_list_iter_next+0x34d>
1800017db:     	jmp	0x18000183b <.text+0x83b>
1800017dd:     	movq	0x8abc(%rip), %rcx      # 0x18000a2a0
1800017e4:     	leaq	0x8eb5(%rip), %rdx      # 0x18000a6a0
1800017eb:     	callq	0x1800084cd <numba_list_iter_next+0x34d>
1800017f0:     	jmp	0x180001833 <.text+0x833>
1800017f2:     	movq	$0x0, 0xa0(%rsp)
1800017fe:     	callq	0x1800084a9 <numba_list_iter_next+0x329>
180001803:     	testq	%rax, %rax
180001806:     	je	0x180001518 <.text+0x518>
18000180c:     	jmp	0x18000181e <.text+0x81e>
18000180e:     	xorl	%ebp, %ebp
180001810:     	callq	0x1800084a9 <numba_list_iter_next+0x329>
180001815:     	testq	%rax, %rax
180001818:     	je	0x1800015b4 <.text+0x5b4>
18000181e:     	movq	0xa8(%rsp), %rcx
180001826:     	callq	0x180001060 <.text+0x60>
18000182b:     	movq	0xb0(%rsp), %r13
180001833:     	movq	%r13, %rcx
180001836:     	callq	0x180001060 <.text+0x60>
18000183b:     	movq	%r15, %rcx
18000183e:     	callq	0x180001060 <.text+0x60>
180001843:     	movq	%rdi, %rcx
180001846:     	callq	0x180001060 <.text+0x60>
18000184b:     	xorl	%esi, %esi
18000184d:     	jmp	0x18000170b <.text+0x70b>
180001852:     	xorl	%esi, %esi
180001854:     	jmp	0x1800015ef <.text+0x5ef>
180001859:     	cmpl	$-0x3, %ebp
18000185c:     	je	0x180001893 <.text+0x893>
18000185e:     	cmpl	$-0x1, %ebp
180001861:     	je	0x18000184b <.text+0x84b>
180001863:     	movq	0x8a2e(%rip), %rcx      # 0x18000a298
18000186a:     	leaq	0x8ecf(%rip), %rdx      # 0x18000a740
180001871:     	callq	0x1800084cd <numba_list_iter_next+0x34d>
180001876:     	jmp	0x18000184b <.text+0x84b>
180001878:     	movq	0x10(%rbx), %r8
18000187c:     	callq	0x180006880 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x42f0>
180001881:     	movq	%rax, %rsi
180001884:     	testq	%rsi, %rsi
180001887:     	je	0x18000184b <.text+0x84b>
180001889:     	movq	%rsi, %rcx
18000188c:     	callq	0x180006420 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3e90>
180001891:     	jmp	0x18000184b <.text+0x84b>
180001893:     	movq	0x89f6(%rip), %rcx      # 0x18000a290
18000189a:     	callq	0x1800084d3 <numba_list_iter_next+0x353>
18000189f:     	jmp	0x18000184b <.text+0x84b>
1800018a1:     	movq	0x8a08(%rip), %rcx      # 0x18000a2b0
1800018a8:     	leaq	0x8e51(%rip), %rdx      # 0x18000a700
1800018af:     	callq	0x1800084cd <numba_list_iter_next+0x34d>
1800018b4:     	jmp	0x18000184b <.text+0x84b>
1800018b6:     	nopw	%cs:(%rax,%rax)
1800018c0:     	pushq	%r15
1800018c2:     	pushq	%r14
1800018c4:     	pushq	%r13
1800018c6:     	pushq	%r12
1800018c8:     	pushq	%rsi
1800018c9:     	pushq	%rdi
1800018ca:     	pushq	%rbp
1800018cb:     	pushq	%rbx
1800018cc:     	subq	$0xb8, %rsp
1800018d3:     	movq	0x120(%rsp), %r8
1800018db:     	movq	0x128(%rsp), %r9
1800018e3:     	movq	0x130(%rsp), %rax
1800018eb:     	movq	0x158(%rsp), %rcx
1800018f3:     	movq	0x160(%rsp), %rdx
1800018fb:     	movq	0x168(%rsp), %r10
180001903:     	movq	0x190(%rsp), %r11
18000190b:     	movq	0x198(%rsp), %rsi
180001913:     	movq	0x1a0(%rsp), %rdi
18000191b:     	movq	0x1c8(%rsp), %rbx
180001923:     	movq	0x1d0(%rsp), %r14
18000192b:     	movq	0x1d8(%rsp), %r15
180001933:     	movq	0x1e0(%rsp), %r12
18000193b:     	movsd	0x1e8(%rsp), %xmm0
180001944:     	movsd	0x1f0(%rsp), %xmm1
18000194d:     	movq	0x1f8(%rsp), %r13
180001955:     	movq	0x200(%rsp), %rbp
18000195d:     	movq	$0x0, 0xb0(%rsp)
180001969:     	movq	$0x0, 0xa8(%rsp)
180001975:     	movq	%rbp, 0x90(%rsp)
18000197d:     	movq	%r13, 0x88(%rsp)
180001985:     	movsd	%xmm1, 0x80(%rsp)
18000198e:     	movsd	%xmm0, 0x78(%rsp)
180001994:     	movq	%r12, 0x70(%rsp)
180001999:     	movq	%r15, 0x68(%rsp)
18000199e:     	movq	%r14, 0x60(%rsp)
1800019a3:     	movq	%rbx, 0x58(%rsp)
1800019a8:     	movq	%rdi, 0x50(%rsp)
1800019ad:     	movq	%rsi, 0x48(%rsp)
1800019b2:     	movq	%r11, 0x40(%rsp)
1800019b7:     	movq	%r10, 0x38(%rsp)
1800019bc:     	movq	%rdx, 0x30(%rsp)
1800019c1:     	movq	%rcx, 0x28(%rsp)
1800019c6:     	movq	%rax, 0x20(%rsp)
1800019cb:     	leaq	0xb0(%rsp), %rcx
1800019d3:     	leaq	0xa8(%rsp), %rdx
1800019db:     	callq	0x180001090 <.text+0x90>
1800019e0:     	movl	%eax, %edx
1800019e2:     	movq	0xa8(%rsp), %rsi
1800019ea:     	movq	0xb0(%rsp), %rax
1800019f2:     	movl	$0x0, 0xa4(%rsp)
1800019fd:     	testl	%edx, %edx
1800019ff:     	jne	0x180001a15 <.text+0xa15>
180001a01:     	addq	$0xb8, %rsp
180001a08:     	popq	%rbx
180001a09:     	popq	%rbp
180001a0a:     	popq	%rdi
180001a0b:     	popq	%rsi
180001a0c:     	popq	%r12
180001a0e:     	popq	%r13
180001a10:     	popq	%r14
180001a12:     	popq	%r15
180001a14:     	retq
180001a15:     	movq	%rax, %rbx
180001a18:     	leaq	0xa4(%rsp), %rcx
180001a20:     	movl	%edx, %edi
180001a22:     	callq	0x1800063f0 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3e60>
180001a27:     	testl	%edi, %edi
180001a29:     	jle	0x180001a6f <.text+0xa6f>
180001a2b:     	callq	0x1800084c1 <numba_list_iter_next+0x341>
180001a30:     	movl	0x8(%rsi), %edx
180001a33:     	movq	(%rsi), %rcx
180001a36:     	cmpl	$0x0, 0x20(%rsi)
180001a3a:     	jle	0x180001a90 <.text+0xa90>
180001a3c:     	movslq	%edx, %rdx
180001a3f:     	callq	0x1800084c7 <numba_list_iter_next+0x347>
180001a44:     	movq	%rax, %rdi
180001a47:     	movq	0x10(%rsi), %rcx
180001a4b:     	callq	*0x18(%rsi)
180001a4e:     	testq	%rax, %rax
180001a51:     	je	0x180001aeb <.text+0xaeb>
180001a57:     	movq	%rdi, %rcx
180001a5a:     	movq	%rax, %rdx
180001a5d:     	callq	0x180006960 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x43d0>
180001a62:     	movq	%rax, %rdi
180001a65:     	movq	%rsi, %rcx
180001a68:     	callq	0x1800083f0 <numba_list_iter_next+0x270>
180001a6d:     	jmp	0x180001a9c <.text+0xa9c>
180001a6f:     	movl	%edi, %eax
180001a71:     	cmpl	$-0x3, %edi
180001a74:     	je	0x180001add <.text+0xadd>
180001a76:     	cmpl	$-0x1, %eax
180001a79:     	je	0x180001aa9 <.text+0xaa9>
180001a7b:     	movq	0x8816(%rip), %rcx      # 0x18000a298
180001a82:     	leaq	0x8d27(%rip), %rdx      # 0x18000a7b0
180001a89:     	callq	0x1800084cd <numba_list_iter_next+0x34d>
180001a8e:     	jmp	0x180001aa9 <.text+0xaa9>
180001a90:     	movq	0x10(%rsi), %r8
180001a94:     	callq	0x180006880 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x42f0>
180001a99:     	movq	%rax, %rdi
180001a9c:     	testq	%rdi, %rdi
180001a9f:     	je	0x180001aa9 <.text+0xaa9>
180001aa1:     	movq	%rdi, %rcx
180001aa4:     	callq	0x180006420 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3e90>
180001aa9:     	leaq	0x8d30(%rip), %rcx      # 0x18000a7e0
180001ab0:     	callq	0x1800084d9 <numba_list_iter_next+0x359>
180001ab5:     	movq	%rax, %rsi
180001ab8:     	movq	%rax, %rcx
180001abb:     	callq	0x1800084df <numba_list_iter_next+0x35f>
180001ac0:     	movq	%rsi, %rcx
180001ac3:     	callq	0x1800084a3 <numba_list_iter_next+0x323>
180001ac8:     	leaq	0xa4(%rsp), %rcx
180001ad0:     	callq	0x180006410 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3e80>
180001ad5:     	movq	%rbx, %rax
180001ad8:     	jmp	0x180001a01 <.text+0xa01>
180001add:     	movq	0x87ac(%rip), %rcx      # 0x18000a290
180001ae4:     	callq	0x1800084d3 <numba_list_iter_next+0x353>
180001ae9:     	jmp	0x180001aa9 <.text+0xaa9>
180001aeb:     	movq	0x87be(%rip), %rcx      # 0x18000a2b0
180001af2:     	leaq	0x8c77(%rip), %rdx      # 0x18000a770
180001af9:     	callq	0x1800084cd <numba_list_iter_next+0x34d>
180001afe:     	xorl	%eax, %eax
180001b00:     	jmp	0x180001a01 <.text+0xa01>
180001b05:     	nopw	%cs:(%rax,%rax)
180001b0f:     	nop
180001b10:     	pushq	%r14
180001b12:     	pushq	%rsi
180001b13:     	pushq	%rdi
180001b14:     	pushq	%rbx
180001b15:     	subq	$0x78, %rsp
180001b19:     	movq	%rcx, %rsi
180001b1c:     	movq	0x108(%rsp), %rax
180001b24:     	movq	0xf0(%rsp), %rcx
180001b2c:     	movq	0xd8(%rsp), %r10
180001b34:     	movq	0xc0(%rsp), %r11
180001b3c:     	movq	0x100(%rsp), %rdi
180001b44:     	movq	0xe8(%rsp), %rbx
180001b4c:     	movq	$0x0, 0x40(%rsp)
180001b55:     	movq	0xd0(%rsp), %r14
180001b5d:     	xorq	%r9, %r14
180001b60:     	xorq	$0x4, %rbx
180001b64:     	orq	%r14, %rbx
180001b67:     	xorq	$0x1, %rdi
180001b6b:     	xorq	$0x8, %r11
180001b6f:     	orq	%rdi, %r11
180001b72:     	orq	%rbx, %r11
180001b75:     	xorq	$0x8, %r10
180001b79:     	xorq	$0x8, %rcx
180001b7d:     	orq	%r10, %rcx
180001b80:     	orq	%r11, %rcx
180001b83:     	xorq	$0x1, %rax
180001b87:     	orq	%rcx, %rax
180001b8a:     	jne	0x180001c34 <.text+0xc34>
180001b90:     	movq	%rdx, %rdi
180001b93:     	movq	0x130(%rsp), %rcx
180001b9b:     	movq	0x128(%rsp), %rdx
180001ba3:     	movsd	0x120(%rsp), %xmm0
180001bac:     	movsd	0x118(%rsp), %xmm1
180001bb5:     	movq	0x110(%rsp), %rax
180001bbd:     	movq	0xf8(%rsp), %r10
180001bc5:     	movq	0xe0(%rsp), %r11
180001bcd:     	movq	0xc8(%rsp), %rbx
180001bd5:     	movq	%r8, 0x50(%rsp)
180001bda:     	movq	%rbx, 0x58(%rsp)
180001bdf:     	movq	%r11, 0x60(%rsp)
180001be4:     	movq	%r10, 0x68(%rsp)
180001be9:     	movq	%r9, 0x70(%rsp)
180001bee:     	movq	$0x0, 0x48(%rsp)
180001bf7:     	movq	%rcx, 0x38(%rsp)
180001bfc:     	movq	%rdx, 0x30(%rsp)
180001c01:     	movsd	%xmm0, 0x28(%rsp)
180001c07:     	movsd	%xmm1, 0x20(%rsp)
180001c0d:     	leaq	0x48(%rsp), %rcx
180001c12:     	leaq	0x40(%rsp), %rdx
180001c17:     	leaq	0x50(%rsp), %r8
180001c1c:     	movq	%rax, %r9
180001c1f:     	callq	0x180004360 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1dd0>
180001c24:     	testl	%eax, %eax
180001c26:     	jne	0x180001c4d <.text+0xc4d>
180001c28:     	movq	0x48(%rsp), %rax
180001c2d:     	movq	%rax, (%rsi)
180001c30:     	xorl	%eax, %eax
180001c32:     	jmp	0x180001c43 <.text+0xc43>
180001c34:     	leaq	0x8c65(%rip), %rax      # 0x18000a8a0
180001c3b:     	movq	%rax, (%rdx)
180001c3e:     	movl	$0x1, %eax
180001c43:     	addq	$0x78, %rsp
180001c47:     	popq	%rbx
180001c48:     	popq	%rdi
180001c49:     	popq	%rsi
180001c4a:     	popq	%r14
180001c4c:     	retq
180001c4d:     	movq	0x40(%rsp), %rcx
180001c52:     	movq	%rcx, (%rdi)
180001c55:     	jmp	0x180001c43 <.text+0xc43>
180001c57:     	nopw	(%rax,%rax)
180001c60:     	pushq	%r15
180001c62:     	pushq	%r14
180001c64:     	pushq	%r13
180001c66:     	pushq	%r12
180001c68:     	pushq	%rsi
180001c69:     	pushq	%rdi
180001c6a:     	pushq	%rbp
180001c6b:     	pushq	%rbx
180001c6c:     	subq	$0x278, %rsp            # imm = 0x278
180001c73:     	movaps	%xmm7, 0x260(%rsp)
180001c7b:     	movaps	%xmm6, 0x250(%rsp)
180001c83:     	movq	%rdx, %rcx
180001c86:     	leaq	0x108(%rsp), %rax
180001c8e:     	movq	%rax, 0x60(%rsp)
180001c93:     	leaq	0x110(%rsp), %rax
180001c9b:     	movq	%rax, 0x58(%rsp)
180001ca0:     	leaq	0x118(%rsp), %rax
180001ca8:     	movq	%rax, 0x50(%rsp)
180001cad:     	leaq	0x120(%rsp), %rax
180001cb5:     	movq	%rax, 0x48(%rsp)
180001cba:     	leaq	0x128(%rsp), %rax
180001cc2:     	movq	%rax, 0x40(%rsp)
180001cc7:     	leaq	0x130(%rsp), %rax
180001ccf:     	movq	%rax, 0x38(%rsp)
180001cd4:     	leaq	0x138(%rsp), %rax
180001cdc:     	movq	%rax, 0x30(%rsp)
180001ce1:     	leaq	0x140(%rsp), %rax
180001ce9:     	movq	%rax, 0x28(%rsp)
180001cee:     	leaq	0x148(%rsp), %rax
180001cf6:     	movq	%rax, 0x20(%rsp)
180001cfb:     	leaq	0x8bce(%rip), %rdx      # 0x18000a8d0
180001d02:     	movl	$0x9, %r8d
180001d08:     	movl	$0x9, %r9d
180001d0e:     	callq	0x180008491 <numba_list_iter_next+0x311>
180001d13:     	testl	%eax, %eax
180001d15:     	movq	$0x0, 0xb8(%rsp)
180001d21:     	je	0x1800022cb <.text+0x12cb>
180001d27:     	cmpq	$0x0, 0xffc1(%rip)      # 0x180011cf0
180001d2f:     	je	0x180002203 <.text+0x1203>
180001d35:     	movq	0x148(%rsp), %rcx
180001d3d:     	xorps	%xmm0, %xmm0
180001d40:     	movaps	%xmm0, 0x210(%rsp)
180001d48:     	movaps	%xmm0, 0x220(%rsp)
180001d50:     	movaps	%xmm0, 0x230(%rsp)
180001d58:     	movq	$0x0, 0x240(%rsp)
180001d64:     	leaq	0x210(%rsp), %rdx
180001d6c:     	callq	0x180007150 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4bc0>
180001d71:     	testl	%eax, %eax
180001d73:     	jne	0x18000221b <.text+0x121b>
180001d79:     	cmpq	$0x8, 0x228(%rsp)
180001d82:     	jne	0x18000221b <.text+0x121b>
180001d88:     	movq	0x210(%rsp), %rdi
180001d90:     	movq	0x230(%rsp), %r14
180001d98:     	movq	0x238(%rsp), %r12
180001da0:     	movq	0x240(%rsp), %rbx
180001da8:     	movq	0x140(%rsp), %rcx
180001db0:     	xorps	%xmm0, %xmm0
180001db3:     	movaps	%xmm0, 0x1d0(%rsp)
180001dbb:     	movaps	%xmm0, 0x1e0(%rsp)
180001dc3:     	movaps	%xmm0, 0x1f0(%rsp)
180001dcb:     	movq	$0x0, 0x200(%rsp)
180001dd7:     	leaq	0x1d0(%rsp), %rdx
180001ddf:     	callq	0x180007150 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4bc0>
180001de4:     	testl	%eax, %eax
180001de6:     	jne	0x180002233 <.text+0x1233>
180001dec:     	cmpq	$0x8, 0x1e8(%rsp)
180001df5:     	jne	0x180002233 <.text+0x1233>
180001dfb:     	movq	0x1d0(%rsp), %r15
180001e03:     	movq	0x1f0(%rsp), %rbp
180001e0b:     	movq	0x1f8(%rsp), %rsi
180001e13:     	movq	0x200(%rsp), %r13
180001e1b:     	movq	0x138(%rsp), %rcx
180001e23:     	xorps	%xmm0, %xmm0
180001e26:     	movaps	%xmm0, 0x190(%rsp)
180001e2e:     	movaps	%xmm0, 0x1a0(%rsp)
180001e36:     	movaps	%xmm0, 0x1b0(%rsp)
180001e3e:     	movq	$0x0, 0x1c0(%rsp)
180001e4a:     	leaq	0x190(%rsp), %rdx
180001e52:     	callq	0x180007150 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4bc0>
180001e57:     	testl	%eax, %eax
180001e59:     	jne	0x180002248 <.text+0x1248>
180001e5f:     	cmpq	$0x8, 0x1a8(%rsp)
180001e68:     	jne	0x180002248 <.text+0x1248>
180001e6e:     	movq	%r13, 0x100(%rsp)
180001e76:     	movq	0x190(%rsp), %r13
180001e7e:     	movq	0x1b0(%rsp), %rax
180001e86:     	movq	%rax, 0xf8(%rsp)
180001e8e:     	movq	0x1b8(%rsp), %rax
180001e96:     	movq	%rax, 0xf0(%rsp)
180001e9e:     	movq	0x1c0(%rsp), %rax
180001ea6:     	movq	%rax, 0xe8(%rsp)
180001eae:     	movq	0x130(%rsp), %rcx
180001eb6:     	xorps	%xmm0, %xmm0
180001eb9:     	movaps	%xmm0, 0x150(%rsp)
180001ec1:     	movaps	%xmm0, 0x160(%rsp)
180001ec9:     	movaps	%xmm0, 0x170(%rsp)
180001ed1:     	movq	$0x0, 0x180(%rsp)
180001edd:     	leaq	0x150(%rsp), %rdx
180001ee5:     	callq	0x180007150 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4bc0>
180001eea:     	testl	%eax, %eax
180001eec:     	jne	0x18000225d <.text+0x125d>
180001ef2:     	cmpq	$0x1, 0x168(%rsp)
180001efb:     	jne	0x18000225d <.text+0x125d>
180001f01:     	movq	%rsi, 0xd8(%rsp)
180001f09:     	movq	0x150(%rsp), %rax
180001f11:     	movq	%rax, 0xa8(%rsp)
180001f19:     	movq	0x170(%rsp), %rax
180001f21:     	movq	%rax, 0xd0(%rsp)
180001f29:     	movq	0x178(%rsp), %rax
180001f31:     	movq	%rax, 0xc8(%rsp)
180001f39:     	movq	0x180(%rsp), %rax
180001f41:     	movq	%rax, 0xc0(%rsp)
180001f49:     	movq	0x128(%rsp), %rcx
180001f51:     	callq	0x180008497 <numba_list_iter_next+0x317>
180001f56:     	testq	%rax, %rax
180001f59:     	movq	%r13, 0xb0(%rsp)
180001f61:     	movq	%rbp, 0xe0(%rsp)
180001f69:     	je	0x180002272 <.text+0x1272>
180001f6f:     	movq	%rax, %rsi
180001f72:     	movq	%rax, %rcx
180001f75:     	callq	0x18000849d <numba_list_iter_next+0x31d>
180001f7a:     	movq	%rax, 0xa0(%rsp)
180001f82:     	movq	%rsi, %rcx
180001f85:     	callq	0x1800084a3 <numba_list_iter_next+0x323>
180001f8a:     	callq	0x1800084a9 <numba_list_iter_next+0x329>
180001f8f:     	testq	%rax, %rax
180001f92:     	jne	0x18000229e <.text+0x129e>
180001f98:     	movq	0x120(%rsp), %rcx
180001fa0:     	callq	0x1800084af <numba_list_iter_next+0x32f>
180001fa5:     	movq	%rax, %rsi
180001fa8:     	movq	%rax, %rcx
180001fab:     	callq	0x1800084b5 <numba_list_iter_next+0x335>
180001fb0:     	movaps	%xmm0, %xmm6
180001fb3:     	movq	%rsi, %rcx
180001fb6:     	callq	0x1800084a3 <numba_list_iter_next+0x323>
180001fbb:     	callq	0x1800084a9 <numba_list_iter_next+0x329>
180001fc0:     	testq	%rax, %rax
180001fc3:     	jne	0x18000229e <.text+0x129e>
180001fc9:     	movq	0x118(%rsp), %rcx
180001fd1:     	callq	0x1800084af <numba_list_iter_next+0x32f>
180001fd6:     	movq	%rax, %rsi
180001fd9:     	movq	%rax, %rcx
180001fdc:     	callq	0x1800084b5 <numba_list_iter_next+0x335>
180001fe1:     	movaps	%xmm0, %xmm7
180001fe4:     	movq	%rsi, %rcx
180001fe7:     	callq	0x1800084a3 <numba_list_iter_next+0x323>
180001fec:     	callq	0x1800084a9 <numba_list_iter_next+0x329>
180001ff1:     	testq	%rax, %rax
180001ff4:     	jne	0x18000229e <.text+0x129e>
180001ffa:     	movq	0x110(%rsp), %rcx
180002002:     	callq	0x180008497 <numba_list_iter_next+0x317>
180002007:     	testq	%rax, %rax
18000200a:     	je	0x18000228e <.text+0x128e>
180002010:     	movq	%rax, %rsi
180002013:     	movq	%rax, %rcx
180002016:     	callq	0x18000849d <numba_list_iter_next+0x31d>
18000201b:     	movq	%rax, %rbp
18000201e:     	movq	%rsi, %rcx
180002021:     	callq	0x1800084a3 <numba_list_iter_next+0x323>
180002026:     	callq	0x1800084a9 <numba_list_iter_next+0x329>
18000202b:     	testq	%rax, %rax
18000202e:     	jne	0x18000229e <.text+0x129e>
180002034:     	movq	%rbx, %r13
180002037:     	movq	%r12, %rbx
18000203a:     	movq	%r14, %r12
18000203d:     	movq	%r15, %r14
180002040:     	movq	%rdi, %r15
180002043:     	movq	0x108(%rsp), %rcx
18000204b:     	callq	0x180008497 <numba_list_iter_next+0x317>
180002050:     	testq	%rax, %rax
180002053:     	je	0x1800022d2 <.text+0x12d2>
180002059:     	movq	%rax, %rdi
18000205c:     	movq	%rax, %rcx
18000205f:     	callq	0x18000849d <numba_list_iter_next+0x31d>
180002064:     	movq	%rax, %rsi
180002067:     	movq	%rdi, %rcx
18000206a:     	callq	0x1800084a3 <numba_list_iter_next+0x323>
18000206f:     	callq	0x1800084a9 <numba_list_iter_next+0x329>
180002074:     	testq	%rax, %rax
180002077:     	movq	%r15, %rdi
18000207a:     	movq	%r14, %r15
18000207d:     	jne	0x18000229e <.text+0x129e>
180002083:     	movq	%rsi, 0x90(%rsp)
18000208b:     	movq	%rbp, 0x88(%rsp)
180002093:     	movsd	%xmm7, 0x80(%rsp)
18000209c:     	movsd	%xmm6, 0x78(%rsp)
1800020a2:     	movq	0xa0(%rsp), %rax
1800020aa:     	movq	%rax, 0x70(%rsp)
1800020af:     	movq	0xc0(%rsp), %rax
1800020b7:     	movq	%rax, 0x68(%rsp)
1800020bc:     	movq	0xc8(%rsp), %rax
1800020c4:     	movq	%rax, 0x60(%rsp)
1800020c9:     	movq	0xd0(%rsp), %rax
1800020d1:     	movq	%rax, 0x58(%rsp)
1800020d6:     	movq	0xe8(%rsp), %rax
1800020de:     	movq	%rax, 0x50(%rsp)
1800020e3:     	movq	0xf0(%rsp), %rax
1800020eb:     	movq	%rax, 0x48(%rsp)
1800020f0:     	movq	0xf8(%rsp), %rax
1800020f8:     	movq	%rax, 0x40(%rsp)
1800020fd:     	movq	0x100(%rsp), %rax
180002105:     	movq	%rax, 0x38(%rsp)
18000210a:     	movq	0xd8(%rsp), %rax
180002112:     	movq	%rax, 0x30(%rsp)
180002117:     	movq	0xe0(%rsp), %rax
18000211f:     	movq	%rax, 0x28(%rsp)
180002124:     	movq	%r13, 0x20(%rsp)
180002129:     	leaq	0x248(%rsp), %rcx
180002131:     	leaq	0xb8(%rsp), %rdx
180002139:     	movq	%r12, %r8
18000213c:     	movq	%rbx, %r9
18000213f:     	callq	0x180001b10 <.text+0xb10>
180002144:     	movl	%eax, %ebp
180002146:     	movq	0xb8(%rsp), %rbx
18000214e:     	movq	%rdi, %rcx
180002151:     	callq	0x180001060 <.text+0x60>
180002156:     	movq	%r15, %rcx
180002159:     	callq	0x180001060 <.text+0x60>
18000215e:     	movq	0xb0(%rsp), %rcx
180002166:     	callq	0x180001060 <.text+0x60>
18000216b:     	movq	0xa8(%rsp), %rcx
180002173:     	callq	0x180001060 <.text+0x60>
180002178:     	testl	%ebp, %ebp
18000217a:     	jne	0x1800021b2 <.text+0x11b2>
18000217c:     	movq	0x814d(%rip), %rsi      # 0x18000a2d0
180002183:     	movq	%rsi, %rcx
180002186:     	callq	0x1800084bb <numba_list_iter_next+0x33b>
18000218b:     	movq	%rsi, %rax
18000218e:     	movaps	0x250(%rsp), %xmm6
180002196:     	movaps	0x260(%rsp), %xmm7
18000219e:     	addq	$0x278, %rsp            # imm = 0x278
1800021a5:     	popq	%rbx
1800021a6:     	popq	%rbp
1800021a7:     	popq	%rdi
1800021a8:     	popq	%rsi
1800021a9:     	popq	%r12
1800021ab:     	popq	%r13
1800021ad:     	popq	%r14
1800021af:     	popq	%r15
1800021b1:     	retq
1800021b2:     	jle	0x1800022d9 <.text+0x12d9>
1800021b8:     	callq	0x1800084c1 <numba_list_iter_next+0x341>
1800021bd:     	movl	0x8(%rbx), %edx
1800021c0:     	movq	(%rbx), %rcx
1800021c3:     	cmpl	$0x0, 0x20(%rbx)
1800021c7:     	jle	0x1800022f8 <.text+0x12f8>
1800021cd:     	movslq	%edx, %rdx
1800021d0:     	callq	0x1800084c7 <numba_list_iter_next+0x347>
1800021d5:     	movq	%rax, %rsi
1800021d8:     	movq	0x10(%rbx), %rcx
1800021dc:     	callq	*0x18(%rbx)
1800021df:     	testq	%rax, %rax
1800021e2:     	je	0x180002321 <.text+0x1321>
1800021e8:     	movq	%rsi, %rcx
1800021eb:     	movq	%rax, %rdx
1800021ee:     	callq	0x180006960 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x43d0>
1800021f3:     	movq	%rax, %rsi
1800021f6:     	movq	%rbx, %rcx
1800021f9:     	callq	0x1800083f0 <numba_list_iter_next+0x270>
1800021fe:     	jmp	0x180002304 <.text+0x1304>
180002203:     	movq	0x80a6(%rip), %rcx      # 0x18000a2b0
18000220a:     	leaq	0x86df(%rip), %rdx      # 0x18000a8f0
180002211:     	callq	0x1800084cd <numba_list_iter_next+0x34d>
180002216:     	jmp	0x1800022cb <.text+0x12cb>
18000221b:     	movq	0x807e(%rip), %rcx      # 0x18000a2a0
180002222:     	leaq	0x87c7(%rip), %rdx      # 0x18000a9f0
180002229:     	callq	0x1800084cd <numba_list_iter_next+0x34d>
18000222e:     	jmp	0x1800022cb <.text+0x12cb>
180002233:     	movq	0x8066(%rip), %rcx      # 0x18000a2a0
18000223a:     	leaq	0x87af(%rip), %rdx      # 0x18000a9f0
180002241:     	callq	0x1800084cd <numba_list_iter_next+0x34d>
180002246:     	jmp	0x1800022c3 <.text+0x12c3>
180002248:     	movq	0x8051(%rip), %rcx      # 0x18000a2a0
18000224f:     	leaq	0x879a(%rip), %rdx      # 0x18000a9f0
180002256:     	callq	0x1800084cd <numba_list_iter_next+0x34d>
18000225b:     	jmp	0x1800022bb <.text+0x12bb>
18000225d:     	movq	0x803c(%rip), %rcx      # 0x18000a2a0
180002264:     	leaq	0x8785(%rip), %rdx      # 0x18000a9f0
18000226b:     	callq	0x1800084cd <numba_list_iter_next+0x34d>
180002270:     	jmp	0x1800022b3 <.text+0x12b3>
180002272:     	movq	$0x0, 0xa0(%rsp)
18000227e:     	callq	0x1800084a9 <numba_list_iter_next+0x329>
180002283:     	testq	%rax, %rax
180002286:     	je	0x180001f98 <.text+0xf98>
18000228c:     	jmp	0x18000229e <.text+0x129e>
18000228e:     	xorl	%ebp, %ebp
180002290:     	callq	0x1800084a9 <numba_list_iter_next+0x329>
180002295:     	testq	%rax, %rax
180002298:     	je	0x180002034 <.text+0x1034>
18000229e:     	movq	0xa8(%rsp), %rcx
1800022a6:     	callq	0x180001060 <.text+0x60>
1800022ab:     	movq	0xb0(%rsp), %r13
1800022b3:     	movq	%r13, %rcx
1800022b6:     	callq	0x180001060 <.text+0x60>
1800022bb:     	movq	%r15, %rcx
1800022be:     	callq	0x180001060 <.text+0x60>
1800022c3:     	movq	%rdi, %rcx
1800022c6:     	callq	0x180001060 <.text+0x60>
1800022cb:     	xorl	%esi, %esi
1800022cd:     	jmp	0x18000218b <.text+0x118b>
1800022d2:     	xorl	%esi, %esi
1800022d4:     	jmp	0x18000206f <.text+0x106f>
1800022d9:     	cmpl	$-0x3, %ebp
1800022dc:     	je	0x180002313 <.text+0x1313>
1800022de:     	cmpl	$-0x1, %ebp
1800022e1:     	je	0x1800022cb <.text+0x12cb>
1800022e3:     	movq	0x7fae(%rip), %rcx      # 0x18000a298
1800022ea:     	leaq	0x879f(%rip), %rdx      # 0x18000aa90
1800022f1:     	callq	0x1800084cd <numba_list_iter_next+0x34d>
1800022f6:     	jmp	0x1800022cb <.text+0x12cb>
1800022f8:     	movq	0x10(%rbx), %r8
1800022fc:     	callq	0x180006880 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x42f0>
180002301:     	movq	%rax, %rsi
180002304:     	testq	%rsi, %rsi
180002307:     	je	0x1800022cb <.text+0x12cb>
180002309:     	movq	%rsi, %rcx
18000230c:     	callq	0x180006420 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3e90>
180002311:     	jmp	0x1800022cb <.text+0x12cb>
180002313:     	movq	0x7f76(%rip), %rcx      # 0x18000a290
18000231a:     	callq	0x1800084d3 <numba_list_iter_next+0x353>
18000231f:     	jmp	0x1800022cb <.text+0x12cb>
180002321:     	movq	0x7f88(%rip), %rcx      # 0x18000a2b0
180002328:     	leaq	0x8721(%rip), %rdx      # 0x18000aa50
18000232f:     	callq	0x1800084cd <numba_list_iter_next+0x34d>
180002334:     	jmp	0x1800022cb <.text+0x12cb>
180002336:     	nopw	%cs:(%rax,%rax)
180002340:     	pushq	%r15
180002342:     	pushq	%r14
180002344:     	pushq	%r13
180002346:     	pushq	%r12
180002348:     	pushq	%rsi
180002349:     	pushq	%rdi
18000234a:     	pushq	%rbp
18000234b:     	pushq	%rbx
18000234c:     	subq	$0xb8, %rsp
180002353:     	movq	0x120(%rsp), %r8
18000235b:     	movq	0x128(%rsp), %r9
180002363:     	movq	0x130(%rsp), %rax
18000236b:     	movq	0x158(%rsp), %rcx
180002373:     	movq	0x160(%rsp), %rdx
18000237b:     	movq	0x168(%rsp), %r10
180002383:     	movq	0x190(%rsp), %r11
18000238b:     	movq	0x198(%rsp), %rsi
180002393:     	movq	0x1a0(%rsp), %rdi
18000239b:     	movq	0x1c8(%rsp), %rbx
1800023a3:     	movq	0x1d0(%rsp), %r14
1800023ab:     	movq	0x1d8(%rsp), %r15
1800023b3:     	movq	0x1e0(%rsp), %r12
1800023bb:     	movsd	0x1e8(%rsp), %xmm0
1800023c4:     	movsd	0x1f0(%rsp), %xmm1
1800023cd:     	movq	0x1f8(%rsp), %r13
1800023d5:     	movq	0x200(%rsp), %rbp
1800023dd:     	movq	$0x0, 0xb0(%rsp)
1800023e9:     	movq	$0x0, 0xa8(%rsp)
1800023f5:     	movq	%rbp, 0x90(%rsp)
1800023fd:     	movq	%r13, 0x88(%rsp)
180002405:     	movsd	%xmm1, 0x80(%rsp)
18000240e:     	movsd	%xmm0, 0x78(%rsp)
180002414:     	movq	%r12, 0x70(%rsp)
180002419:     	movq	%r15, 0x68(%rsp)
18000241e:     	movq	%r14, 0x60(%rsp)
180002423:     	movq	%rbx, 0x58(%rsp)
180002428:     	movq	%rdi, 0x50(%rsp)
18000242d:     	movq	%rsi, 0x48(%rsp)
180002432:     	movq	%r11, 0x40(%rsp)
180002437:     	movq	%r10, 0x38(%rsp)
18000243c:     	movq	%rdx, 0x30(%rsp)
180002441:     	movq	%rcx, 0x28(%rsp)
180002446:     	movq	%rax, 0x20(%rsp)
18000244b:     	leaq	0xb0(%rsp), %rcx
180002453:     	leaq	0xa8(%rsp), %rdx
18000245b:     	callq	0x180001b10 <.text+0xb10>
180002460:     	movl	%eax, %edx
180002462:     	movq	0xa8(%rsp), %rsi
18000246a:     	movq	0xb0(%rsp), %rax
180002472:     	movl	$0x0, 0xa4(%rsp)
18000247d:     	testl	%edx, %edx
18000247f:     	jne	0x180002495 <.text+0x1495>
180002481:     	addq	$0xb8, %rsp
180002488:     	popq	%rbx
180002489:     	popq	%rbp
18000248a:     	popq	%rdi
18000248b:     	popq	%rsi
18000248c:     	popq	%r12
18000248e:     	popq	%r13
180002490:     	popq	%r14
180002492:     	popq	%r15
180002494:     	retq
180002495:     	movq	%rax, %rbx
180002498:     	leaq	0xa4(%rsp), %rcx
1800024a0:     	movl	%edx, %edi
1800024a2:     	callq	0x1800063f0 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3e60>
1800024a7:     	testl	%edi, %edi
1800024a9:     	jle	0x1800024ef <.text+0x14ef>
1800024ab:     	callq	0x1800084c1 <numba_list_iter_next+0x341>
1800024b0:     	movl	0x8(%rsi), %edx
1800024b3:     	movq	(%rsi), %rcx
1800024b6:     	cmpl	$0x0, 0x20(%rsi)
1800024ba:     	jle	0x180002510 <.text+0x1510>
1800024bc:     	movslq	%edx, %rdx
1800024bf:     	callq	0x1800084c7 <numba_list_iter_next+0x347>
1800024c4:     	movq	%rax, %rdi
1800024c7:     	movq	0x10(%rsi), %rcx
1800024cb:     	callq	*0x18(%rsi)
1800024ce:     	testq	%rax, %rax
1800024d1:     	je	0x18000256b <.text+0x156b>
1800024d7:     	movq	%rdi, %rcx
1800024da:     	movq	%rax, %rdx
1800024dd:     	callq	0x180006960 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x43d0>
1800024e2:     	movq	%rax, %rdi
1800024e5:     	movq	%rsi, %rcx
1800024e8:     	callq	0x1800083f0 <numba_list_iter_next+0x270>
1800024ed:     	jmp	0x18000251c <.text+0x151c>
1800024ef:     	movl	%edi, %eax
1800024f1:     	cmpl	$-0x3, %edi
1800024f4:     	je	0x18000255d <.text+0x155d>
1800024f6:     	cmpl	$-0x1, %eax
1800024f9:     	je	0x180002529 <.text+0x1529>
1800024fb:     	movq	0x7d96(%rip), %rcx      # 0x18000a298
180002502:     	leaq	0x85f7(%rip), %rdx      # 0x18000ab00
180002509:     	callq	0x1800084cd <numba_list_iter_next+0x34d>
18000250e:     	jmp	0x180002529 <.text+0x1529>
180002510:     	movq	0x10(%rsi), %r8
180002514:     	callq	0x180006880 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x42f0>
180002519:     	movq	%rax, %rdi
18000251c:     	testq	%rdi, %rdi
18000251f:     	je	0x180002529 <.text+0x1529>
180002521:     	movq	%rdi, %rcx
180002524:     	callq	0x180006420 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3e90>
180002529:     	leaq	0x8600(%rip), %rcx      # 0x18000ab30
180002530:     	callq	0x1800084d9 <numba_list_iter_next+0x359>
180002535:     	movq	%rax, %rsi
180002538:     	movq	%rax, %rcx
18000253b:     	callq	0x1800084df <numba_list_iter_next+0x35f>
180002540:     	movq	%rsi, %rcx
180002543:     	callq	0x1800084a3 <numba_list_iter_next+0x323>
180002548:     	leaq	0xa4(%rsp), %rcx
180002550:     	callq	0x180006410 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3e80>
180002555:     	movq	%rbx, %rax
180002558:     	jmp	0x180002481 <.text+0x1481>
18000255d:     	movq	0x7d2c(%rip), %rcx      # 0x18000a290
180002564:     	callq	0x1800084d3 <numba_list_iter_next+0x353>
180002569:     	jmp	0x180002529 <.text+0x1529>
18000256b:     	movq	0x7d3e(%rip), %rcx      # 0x18000a2b0
180002572:     	leaq	0x8547(%rip), %rdx      # 0x18000aac0
180002579:     	callq	0x1800084cd <numba_list_iter_next+0x34d>
18000257e:     	xorl	%eax, %eax
180002580:     	jmp	0x180002481 <.text+0x1481>
180002585:     	nopw	%cs:(%rax,%rax)
18000258f:     	nop

0000000180002590 <PyInit_rcaotr_37bed947cdaa1333e55322a8>:
180002590:     	pushq	%rsi
180002591:     	subq	$0x20, %rsp
180002595:     	leaq	0xeac4(%rip), %rcx      # 0x180011060
18000259c:     	movl	$0x3f5, %edx            # imm = 0x3F5
1800025a1:     	callq	0x1800084e5 <numba_list_iter_next+0x365>
1800025a6:     	testq	%rax, %rax
1800025a9:     	je	0x1800025db <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4b>
1800025ab:     	leaq	0xea4e(%rip), %rdx      # 0x180011000
1800025b2:     	leaq	0x85e7(%rip), %r8       # 0x18000aba0
1800025b9:     	leaq	0x87a0(%rip), %r9       # 0x18000ad60
1800025c0:     	movq	%rax, %rcx
1800025c3:     	movq	%rax, %rsi
1800025c6:     	callq	0x1800073c0 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4e30>
1800025cb:     	movl	%eax, %ecx
1800025cd:     	xorl	%eax, %eax
1800025cf:     	testl	%ecx, %ecx
1800025d1:     	cmoveq	%rsi, %rax
1800025d5:     	addq	$0x20, %rsp
1800025d9:     	popq	%rsi
1800025da:     	retq
1800025db:     	xorl	%eax, %eax
1800025dd:     	addq	$0x20, %rsp
1800025e1:     	popq	%rsi
1800025e2:     	retq
1800025e3:     	nopw	%cs:(%rax,%rax)
1800025ed:     	nopl	(%rax)
1800025f0:     	pushq	%r15
1800025f2:     	pushq	%r14
1800025f4:     	pushq	%r13
1800025f6:     	pushq	%r12
1800025f8:     	pushq	%rsi
1800025f9:     	pushq	%rdi
1800025fa:     	pushq	%rbp
1800025fb:     	pushq	%rbx
1800025fc:     	subq	$0xc8, %rsp
180002603:     	movapd	%xmm8, 0xb0(%rsp)
18000260d:     	movaps	%xmm7, 0xa0(%rsp)
180002615:     	movapd	%xmm6, 0x90(%rsp)
18000261e:     	movq	0x140(%rsp), %rsi
180002626:     	movabsq	$-0x20000000000001, %rax # imm = 0xFFDFFFFFFFFFFFFF
180002630:     	movabsq	$-0x40000000000001, %r10 # imm = 0xFFBFFFFFFFFFFFFF
18000263a:     	movq	$0x0, 0x60(%rsp)
180002643:     	movq	$0x0, 0x70(%rsp)
18000264c:     	movq	0x10(%r8), %rbp
180002650:     	movq	0x18(%r8), %r15
180002654:     	leaq	(%rsi,%rax), %r11
180002658:     	cmpq	%r10, %r11
18000265b:     	jb	0x18000266d <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xdd>
18000265d:     	movq	0x148(%rsp), %rdi
180002665:     	addq	%rdi, %rax
180002668:     	cmpq	%r10, %rax
18000266b:     	jae	0x1800026af <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x11f>
18000266d:     	movb	$0x1, (%r15)
180002671:     	movq	$0x4, 0x18(%rbp)
180002679:     	xorl	%eax, %eax
18000267b:     	movq	$0x0, (%rcx)
180002682:     	movaps	0x90(%rsp), %xmm6
18000268a:     	movaps	0xa0(%rsp), %xmm7
180002692:     	movaps	0xb0(%rsp), %xmm8
18000269b:     	addq	$0xc8, %rsp
1800026a2:     	popq	%rbx
1800026a3:     	popq	%rbp
1800026a4:     	popq	%rdi
1800026a5:     	popq	%rsi
1800026a6:     	popq	%r12
1800026a8:     	popq	%r13
1800026aa:     	popq	%r14
1800026ac:     	popq	%r15
1800026ae:     	retq
1800026af:     	movq	0x20(%r8), %r10
1800026b3:     	movq	(%rbp), %r11
1800026b7:     	leaq	0x4(%r11), %rax
1800026bb:     	cmpq	%r10, %rax
1800026be:     	jle	0x1800026c6 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x136>
1800026c0:     	movb	$0x2, (%r15)
1800026c4:     	jmp	0x180002679 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xe9>
1800026c6:     	movq	(%r8), %r12
1800026c9:     	movq	0x8(%r8), %r13
1800026cd:     	movq	%rax, (%rbp)
1800026d1:     	xorl	%eax, %eax
1800026d3:     	cmpb	$0x0, (%r15)
1800026d7:     	jne	0x18000267b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xeb>
1800026d9:     	cvtsi2sd	%rsi, %xmm0
1800026de:     	movsd	0x7cca(%rip), %xmm1     # 0x18000a3b0
1800026e6:     	mulsd	%xmm1, %xmm0
1800026ea:     	cvtsi2sd	%rdi, %xmm2
1800026ef:     	mulsd	%xmm1, %xmm2
1800026f3:     	movsd	%xmm0, 0x10(%r12,%r11,8)
1800026fa:     	movsd	%xmm2, 0x18(%r12,%r11,8)
180002701:     	movsd	%xmm0, 0x8(%r12,%r11,8)
180002708:     	movsd	%xmm2, (%r12,%r11,8)
18000270e:     	cmpb	$0x0, (%r15)
180002712:     	jne	0x18000267b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xeb>
180002718:     	movq	(%rbp), %rsi
18000271c:     	leaq	0xb(%rsi), %rdi
180002720:     	cmpq	%r10, %rdi
180002723:     	jle	0x18000272e <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x19e>
180002725:     	movb	$0x2, (%r15)
180002729:     	jmp	0x18000267b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xeb>
18000272e:     	movq	%rdi, (%rbp)
180002732:     	cmpb	$0x0, (%r15)
180002736:     	jne	0x18000267b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xeb>
18000273c:     	movq	%r11, (%r13,%rsi,8)
180002741:     	movq	$0x4, 0x8(%r13,%rsi,8)
18000274a:     	movq	(%rbp), %r11
18000274e:     	cmpq	%r10, %r11
180002751:     	movq	%r11, %rdi
180002754:     	jle	0x180002760 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1d0>
180002756:     	movb	$0x2, (%r15)
18000275a:     	movq	(%rbp), %r11
18000275e:     	xorl	%edi, %edi
180002760:     	leaq	0x3(%r11), %rbx
180002764:     	cmpq	%r10, %rbx
180002767:     	jg	0x180002725 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x195>
180002769:     	movq	%rbx, (%rbp)
18000276d:     	cmpb	$0x0, (%r15)
180002771:     	jne	0x18000267b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xeb>
180002777:     	movq	%r11, %rax
18000277a:     	sarq	$0x3f, %rax
18000277e:     	andq	%r10, %rax
180002781:     	leaq	(%r13,%r11,8), %rbx
180002786:     	movq	$0x0, (%rbx,%rax,8)
18000278e:     	xorl	%eax, %eax
180002790:     	cmpq	$-0x1, %r11
180002794:     	movl	$0x0, %r14d
18000279a:     	cmovlq	%r10, %r14
18000279e:     	movq	$0x0, 0x8(%rbx,%r14,8)
1800027a7:     	cmpq	$-0x2, %r11
1800027ab:     	movl	$0x0, %r14d
1800027b1:     	cmovlq	%r10, %r14
1800027b5:     	movq	%rdi, 0x10(%rbx,%r14,8)
1800027ba:     	cmpb	$0x0, (%r15)
1800027be:     	jne	0x18000267b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xeb>
1800027c4:     	leaq	(%r13,%rsi,8), %rdi
1800027c9:     	movq	%r11, 0x30(%rdi)
1800027cd:     	movq	$0x0, 0x18(%rdi)
1800027d5:     	movq	(%rbp), %r11
1800027d9:     	leaq	0x4(%r11), %rbx
1800027dd:     	cmpq	%r10, %rbx
1800027e0:     	jg	0x180002725 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x195>
1800027e6:     	movq	%r8, 0x58(%rsp)
1800027eb:     	movq	%rdx, 0x50(%rsp)
1800027f0:     	movq	%rbx, (%rbp)
1800027f4:     	cmpb	$0x0, (%r15)
1800027f8:     	jne	0x18000267b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xeb>
1800027fe:     	movq	%rcx, 0x40(%rsp)
180002803:     	movq	$0x0, (%r12,%r11,8)
18000280b:     	movq	$0x1, 0x8(%r13,%r11,8)
180002814:     	movq	$0x0, 0x10(%r12,%r11,8)
18000281d:     	movq	$0x1, 0x18(%r13,%r11,8)
180002826:     	cmpb	$0x0, (%r15)
18000282a:     	jne	0x180002b55 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x5c5>
180002830:     	movq	%r9, %r14
180002833:     	movq	%r11, 0x10(%rdi)
180002837:     	movq	$0x0, 0x48(%r12,%rsi,8)
180002840:     	movq	$0x1, 0x50(%rdi)
180002848:     	movq	$-0x1, 0x20(%rdi)
180002850:     	movq	$-0x1, 0x28(%rdi)
180002858:     	movq	$-0x1, 0x38(%rdi)
180002860:     	movq	$-0x1, 0x40(%rdi)
180002868:     	cmpb	$0x0, (%r15)
18000286c:     	jne	0x180002b55 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x5c5>
180002872:     	cmpq	$0x0, (%r13,%r14,8)
180002878:     	jle	0x180002901 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x371>
18000287e:     	movq	0x8(%rbp), %rax
180002882:     	shlq	$0x3, %r14
180002886:     	xorl	%edi, %edi
180002888:     	leaq	0x4f(%rsp), %rbx
18000288d:     	movq	0x10(%r13,%r14), %rcx
180002892:     	leaq	(%r13,%rcx,8), %rcx
180002897:     	movq	(%rcx,%rdi,8), %rcx
18000289b:     	leaq	0x1(%rax), %rdx
18000289f:     	movq	%rdx, 0x8(%rbp)
1800028a3:     	cmpq	0x10(%rbp), %rax
1800028a7:     	jge	0x180002a33 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4a3>
1800028ad:     	movq	%rcx, 0x28(%rsp)
1800028b2:     	movq	%rsi, 0x20(%rsp)
1800028b7:     	movq	$-0x1, 0x30(%rsp)
1800028c0:     	movq	%rbx, %rcx
1800028c3:     	leaq	0x80(%rsp), %rdx
1800028cb:     	movq	0x58(%rsp), %r8
1800028d0:     	xorl	%r9d, %r9d
1800028d3:     	callq	0x180003100 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xb70>
1800028d8:     	testl	%eax, %eax
1800028da:     	jne	0x180002a29 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x499>
1800028e0:     	cmpb	$0x0, (%r15)
1800028e4:     	jne	0x180002b53 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x5c3>
1800028ea:     	incq	%rdi
1800028ed:     	movq	0x8(%rbp), %rax
1800028f1:     	decq	%rax
1800028f4:     	movq	%rax, 0x8(%rbp)
1800028f8:     	cmpq	(%r13,%r14), %rdi
1800028fd:     	jl	0x18000288d <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2fd>
1800028ff:     	jmp	0x180002905 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x375>
180002901:     	shlq	$0x3, %r14
180002905:     	movsd	0x138(%rsp), %xmm6
18000290e:     	movsd	0x130(%rsp), %xmm7
180002917:     	xorl	%ebx, %ebx
180002919:     	xorpd	%xmm8, %xmm8
18000291e:     	jmp	0x180002939 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3a9>
180002920:     	movb	$0x1, (%r15)
180002924:     	movq	$0x4c4b43, 0x18(%rbp)   # imm = 0x4C4B43
18000292c:     	incq	%rbx
18000292f:     	cmpb	$0x0, (%r15)
180002933:     	jne	0x180002b55 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x5c5>
180002939:     	cmpq	(%r13,%r14), %rbx
18000293e:     	jge	0x180002a44 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4b4>
180002944:     	movq	0x10(%r13,%r14), %rax
180002949:     	leaq	(%r13,%rax,8), %rax
18000294e:     	movq	(%rax,%rbx,8), %rdi
180002952:     	movq	0x8(%rbp), %rax
180002956:     	leaq	0x1(%rax), %rcx
18000295a:     	movq	%rcx, 0x8(%rbp)
18000295e:     	cmpq	0x10(%rbp), %rax
180002962:     	jge	0x180002b47 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x5b7>
180002968:     	movsd	%xmm7, 0x28(%rsp)
18000296e:     	movq	%rdi, 0x20(%rsp)
180002973:     	leaq	0x60(%rsp), %rcx
180002978:     	leaq	0x88(%rsp), %rdx
180002980:     	movq	0x58(%rsp), %r8
180002985:     	movq	%rsi, %r9
180002988:     	callq	0x180002b60 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x5d0>
18000298d:     	testl	%eax, %eax
18000298f:     	jne	0x180002a29 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x499>
180002995:     	xorl	%eax, %eax
180002997:     	cmpb	$0x0, (%r15)
18000299b:     	jne	0x180002b55 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x5c5>
1800029a1:     	movsd	0x60(%rsp), %xmm1
1800029a7:     	movsd	0x70(%rsp), %xmm0
1800029ad:     	decq	0x8(%rbp)
1800029b1:     	movsd	0x8(%r12,%rdi,8), %xmm2
1800029b8:     	ucomisd	%xmm8, %xmm2
1800029bd:     	jne	0x1800029c5 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x435>
1800029bf:     	jnp	0x180002920 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x390>
1800029c5:     	movq	(%r13,%rdi,8), %rcx
1800029ca:     	divsd	%xmm2, %xmm1
1800029ce:     	addsd	(%r12,%rcx,8), %xmm1
1800029d4:     	movsd	%xmm1, (%r12,%rcx,8)
1800029da:     	movq	$0x0, 0x8(%r13,%rcx,8)
1800029e3:     	movsd	0x8(%r12,%rdi,8), %xmm1
1800029ea:     	ucomisd	%xmm8, %xmm1
1800029ef:     	jne	0x180002a04 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x474>
1800029f1:     	jp	0x180002a04 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x474>
1800029f3:     	movb	$0x1, (%r15)
1800029f7:     	movq	$0x4c4b44, 0x18(%rbp)   # imm = 0x4C4B44
1800029ff:     	jmp	0x18000292c <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x39c>
180002a04:     	movq	(%r13,%rdi,8), %rcx
180002a09:     	divsd	%xmm1, %xmm0
180002a0d:     	addsd	0x10(%r12,%rcx,8), %xmm0
180002a14:     	movsd	%xmm0, 0x10(%r12,%rcx,8)
180002a1b:     	movq	$0x0, 0x18(%r13,%rcx,8)
180002a24:     	jmp	0x18000292c <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x39c>
180002a29:     	movq	0x50(%rsp), %rcx
180002a2e:     	jmp	0x18000267b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xeb>
180002a33:     	movb	$0x1, (%r15)
180002a37:     	movq	$0x9, 0x18(%rbp)
180002a3f:     	jmp	0x180002b53 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x5c3>
180002a44:     	xorl	%eax, %eax
180002a46:     	xorl	%ecx, %ecx
180002a48:     	cmpq	(%r13,%r14), %rcx
180002a4d:     	jge	0x180002b55 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x5c5>
180002a53:     	movq	0x10(%r13,%r14), %rdx
180002a58:     	leaq	(%r13,%rdx,8), %rdx
180002a5d:     	movq	(%rdx,%rcx,8), %rdx
180002a61:     	incq	%rcx
180002a64:     	movq	(%r13,%rdx,8), %r8
180002a69:     	movq	0x18(%r13,%rdx,8), %r9
180002a6e:     	movsd	(%r12,%r8,8), %xmm0
180002a74:     	mulsd	%xmm6, %xmm0
180002a78:     	addsd	(%r12,%r9,8), %xmm0
180002a7e:     	movsd	%xmm0, (%r12,%r9,8)
180002a84:     	movq	$0x0, 0x8(%r13,%r9,8)
180002a8d:     	movq	(%r13,%rdx,8), %r8
180002a92:     	movq	0x18(%r13,%rdx,8), %r9
180002a97:     	movsd	0x10(%r12,%r8,8), %xmm0
180002a9e:     	mulsd	%xmm6, %xmm0
180002aa2:     	addsd	0x10(%r12,%r9,8), %xmm0
180002aa9:     	movsd	%xmm0, 0x10(%r12,%r9,8)
180002ab0:     	movq	$0x0, 0x18(%r13,%r9,8)
180002ab9:     	movq	0x10(%r13,%rdx,8), %r8
180002abe:     	movq	0x18(%r13,%rdx,8), %r9
180002ac3:     	movsd	(%r12,%r9,8), %xmm0
180002ac9:     	mulsd	%xmm6, %xmm0
180002acd:     	addsd	(%r12,%r8,8), %xmm0
180002ad3:     	movsd	%xmm0, (%r12,%r8,8)
180002ad9:     	movq	$0x0, 0x8(%r13,%r8,8)
180002ae2:     	movq	0x10(%r13,%rdx,8), %r8
180002ae7:     	movq	0x18(%r13,%rdx,8), %r9
180002aec:     	movsd	0x10(%r12,%r9,8), %xmm0
180002af3:     	mulsd	%xmm6, %xmm0
180002af7:     	addsd	0x10(%r12,%r8,8), %xmm0
180002afe:     	movsd	%xmm0, 0x10(%r12,%r8,8)
180002b05:     	movq	$0x0, 0x18(%r13,%r8,8)
180002b0e:     	movq	(%r13,%rdx,8), %r8
180002b13:     	movq	$0x0, (%r12,%r8,8)
180002b1b:     	movq	$0x1, 0x8(%r13,%r8,8)
180002b24:     	movq	(%r13,%rdx,8), %rdx
180002b29:     	movq	$0x0, 0x10(%r12,%rdx,8)
180002b32:     	movq	$0x1, 0x18(%r13,%rdx,8)
180002b3b:     	cmpb	$0x0, (%r15)
180002b3f:     	je	0x180002a48 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4b8>
180002b45:     	jmp	0x180002b55 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x5c5>
180002b47:     	movb	$0x1, (%r15)
180002b4b:     	movq	$0xd, 0x18(%rbp)
180002b53:     	xorl	%eax, %eax
180002b55:     	movq	0x40(%rsp), %rcx
180002b5a:     	jmp	0x18000267b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xeb>
180002b5f:     	nop
180002b60:     	pushq	%r15
180002b62:     	pushq	%r14
180002b64:     	pushq	%r13
180002b66:     	pushq	%r12
180002b68:     	pushq	%rsi
180002b69:     	pushq	%rdi
180002b6a:     	pushq	%rbp
180002b6b:     	pushq	%rbx
180002b6c:     	subq	$0xf8, %rsp
180002b73:     	movapd	%xmm8, 0xe0(%rsp)
180002b7d:     	movapd	%xmm7, 0xd0(%rsp)
180002b86:     	movapd	%xmm6, 0xc0(%rsp)
180002b8f:     	movq	$0x0, 0x40(%rsp)
180002b98:     	movb	$0x0, 0x48(%rsp)
180002b9d:     	movq	$0x0, 0x50(%rsp)
180002ba6:     	movq	(%r8), %rax
180002ba9:     	movsd	0x48(%rax,%r9,8), %xmm0
180002bb0:     	xorpd	%xmm1, %xmm1
180002bb4:     	ucomisd	%xmm1, %xmm0
180002bb8:     	jne	0x180002bd1 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x641>
180002bba:     	jp	0x180002bd1 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x641>
180002bbc:     	movb	$0x1, 0x18(%rcx)
180002bc0:     	movq	$0x0, 0x10(%rcx)
180002bc8:     	movb	$0x1, 0x8(%rcx)
180002bcc:     	jmp	0x180002db6 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x826>
180002bd1:     	movq	0x160(%rsp), %rbx
180002bd9:     	movq	0x8(%r8), %r14
180002bdd:     	movq	0x10(%r8), %rsi
180002be1:     	movq	0x18(%r8), %rdi
180002be5:     	movq	0x30(%r14,%r9,8), %rdx
180002bea:     	cmpq	$0x1, (%r14,%rdx,8)
180002bef:     	jne	0x180002bfc <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x66c>
180002bf1:     	movq	0x10(%r14,%rdx,8), %rdx
180002bf6:     	cmpq	%rbx, (%r14,%rdx,8)
180002bfa:     	je	0x180002bbc <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x62c>
180002bfc:     	movq	0x10(%r14,%r9,8), %r11
180002c01:     	movsd	(%rax,%r11,8), %xmm1
180002c07:     	cmpq	$0x0, 0x8(%r14,%r11,8)
180002c0d:     	setne	%bpl
180002c11:     	movq	0x10(%r14,%rbx,8), %r10
180002c16:     	cmpq	$0x0, 0x8(%r14,%r10,8)
180002c1c:     	setne	%dl
180002c1f:     	subsd	(%rax,%r10,8), %xmm1
180002c25:     	andb	%bpl, %dl
180002c28:     	cmpb	$0x1, %dl
180002c2b:     	jne	0x180002c4f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x6bf>
180002c2d:     	movapd	0x778b(%rip), %xmm2     # 0x18000a3c0
180002c35:     	andpd	%xmm1, %xmm2
180002c39:     	ucomisd	0x778f(%rip), %xmm2     # 0x18000a3d0
180002c41:     	jae	0x180002cfd <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x76d>
180002c47:     	xorpd	%xmm2, %xmm2
180002c4b:     	addsd	%xmm2, %xmm1
180002c4f:     	movsd	0x10(%rax,%r11,8), %xmm2
180002c56:     	cmpq	$0x0, 0x18(%r14,%r11,8)
180002c5c:     	subsd	0x10(%rax,%r10,8), %xmm2
180002c63:     	je	0x180002cd1 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x741>
180002c65:     	cmpq	$0x0, 0x18(%r14,%r10,8)
180002c6b:     	je	0x180002cd1 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x741>
180002c6d:     	movapd	0x774b(%rip), %xmm3     # 0x18000a3c0
180002c75:     	andpd	%xmm2, %xmm3
180002c79:     	ucomisd	0x774f(%rip), %xmm3     # 0x18000a3d0
180002c81:     	jae	0x180002d41 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x7b1>
180002c87:     	movapd	%xmm1, %xmm3
180002c8b:     	mulsd	%xmm1, %xmm3
180002c8f:     	ucomisd	0x7739(%rip), %xmm3     # 0x18000a3d0
180002c97:     	setae	%r10b
180002c9b:     	testb	%r10b, %dl
180002c9e:     	jne	0x180002ced <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x75d>
180002ca0:     	xorpd	%xmm4, %xmm4
180002ca4:     	addsd	%xmm4, %xmm2
180002ca8:     	movapd	%xmm2, %xmm4
180002cac:     	mulsd	%xmm2, %xmm4
180002cb0:     	ucomisd	0x7718(%rip), %xmm4     # 0x18000a3d0
180002cb8:     	jae	0x180002ced <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x75d>
180002cba:     	addsd	%xmm4, %xmm3
180002cbe:     	ucomisd	0x770a(%rip), %xmm3     # 0x18000a3d0
180002cc6:     	setae	%r10b
180002cca:     	testb	%r10b, %dl
180002ccd:     	jne	0x180002ced <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x75d>
180002ccf:     	jmp	0x180002d19 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x789>
180002cd1:     	movapd	%xmm1, %xmm3
180002cd5:     	mulsd	%xmm1, %xmm3
180002cd9:     	ucomisd	0x76ef(%rip), %xmm3     # 0x18000a3d0
180002ce1:     	setae	%r10b
180002ce5:     	andb	%r10b, %dl
180002ce8:     	cmpb	$0x1, %dl
180002ceb:     	jne	0x180002d0d <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x77d>
180002ced:     	movb	$0x1, (%rdi)
180002cf0:     	movq	$0x3d090c, 0x18(%rsi)   # imm = 0x3D090C
180002cf8:     	jmp	0x180002d9e <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x80e>
180002cfd:     	movb	$0x1, (%rdi)
180002d00:     	movq	$0x3d090a, 0x18(%rsi)   # imm = 0x3D090A
180002d08:     	jmp	0x180002d9e <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x80e>
180002d0d:     	movapd	%xmm2, %xmm4
180002d11:     	mulsd	%xmm2, %xmm4
180002d15:     	addsd	%xmm4, %xmm3
180002d19:     	xorps	%xmm4, %xmm4
180002d1c:     	sqrtsd	%xmm3, %xmm4
180002d20:     	cmpq	$0x0, 0x18(%r14,%r9,8)
180002d26:     	je	0x180002d73 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x7e3>
180002d28:     	xorpd	%xmm5, %xmm5
180002d2c:     	ucomisd	%xmm5, %xmm3
180002d30:     	jne	0x180002d4e <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x7be>
180002d32:     	jp	0x180002d4e <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x7be>
180002d34:     	movb	$0x1, (%rdi)
180002d37:     	movq	$0x3d090f, 0x18(%rsi)   # imm = 0x3D090F
180002d3f:     	jmp	0x180002d9e <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x80e>
180002d41:     	movb	$0x1, (%rdi)
180002d44:     	movq	$0x3d090b, 0x18(%rsi)   # imm = 0x3D090B
180002d4c:     	jmp	0x180002d9e <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x80e>
180002d4e:     	movsd	0x168(%rsp), %xmm6
180002d57:     	movq	(%r14,%r9,8), %rdx
180002d5b:     	movsd	0x8(%rax,%rdx,8), %xmm3
180002d61:     	addsd	%xmm3, %xmm3
180002d65:     	divsd	%xmm4, %xmm3
180002d69:     	ucomisd	%xmm3, %xmm6
180002d6d:     	jbe	0x180002e25 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x895>
180002d73:     	movsd	0x765d(%rip), %xmm3     # 0x18000a3d8
180002d7b:     	maxsd	%xmm4, %xmm3
180002d7f:     	movapd	%xmm3, %xmm4
180002d83:     	mulsd	%xmm3, %xmm4
180002d87:     	xorpd	%xmm5, %xmm5
180002d8b:     	ucomisd	%xmm5, %xmm4
180002d8f:     	jne	0x180002dec <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x85c>
180002d91:     	jp	0x180002dec <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x85c>
180002d93:     	movb	$0x1, (%rdi)
180002d96:     	movq	$0x3d0915, 0x18(%rsi)   # imm = 0x3D0915
180002d9e:     	movq	$0x0, 0x18(%rcx)
180002da6:     	movq	$0x0, 0x10(%rcx)
180002dae:     	movq	$0x0, 0x8(%rcx)
180002db6:     	movq	$0x0, (%rcx)
180002dbd:     	xorl	%eax, %eax
180002dbf:     	movaps	0xc0(%rsp), %xmm6
180002dc7:     	movaps	0xd0(%rsp), %xmm7
180002dcf:     	movaps	0xe0(%rsp), %xmm8
180002dd8:     	addq	$0xf8, %rsp
180002ddf:     	popq	%rbx
180002de0:     	popq	%rbp
180002de1:     	popq	%rdi
180002de2:     	popq	%rsi
180002de3:     	popq	%r12
180002de5:     	popq	%r13
180002de7:     	popq	%r14
180002de9:     	popq	%r15
180002deb:     	retq
180002dec:     	movsd	0x8(%rax,%rbx,8), %xmm5
180002df2:     	mulsd	0x75e6(%rip), %xmm5     # 0x18000a3e0
180002dfa:     	mulsd	%xmm5, %xmm0
180002dfe:     	divsd	%xmm4, %xmm0
180002e02:     	mulsd	%xmm0, %xmm1
180002e06:     	divsd	%xmm3, %xmm1
180002e0a:     	mulsd	%xmm0, %xmm2
180002e0e:     	divsd	%xmm3, %xmm2
180002e12:     	movsd	%xmm2, 0x10(%rcx)
180002e17:     	movsd	%xmm1, (%rcx)
180002e1b:     	movb	$0x0, 0x18(%rcx)
180002e1f:     	movb	$0x0, 0x8(%rcx)
180002e23:     	jmp	0x180002dbd <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x82d>
180002e25:     	movq	0x20(%r14,%r9,8), %rax
180002e2a:     	testq	%rax, %rax
180002e2d:     	js	0x180002eba <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x92a>
180002e33:     	movq	0x8(%rsi), %rdx
180002e37:     	leaq	0x1(%rdx), %r10
180002e3b:     	movq	%r10, 0x8(%rsi)
180002e3f:     	cmpq	0x10(%rsi), %rdx
180002e43:     	jge	0x180002fd9 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xa49>
180002e49:     	movq	%r9, %r12
180002e4c:     	movq	%rcx, %r13
180002e4f:     	movsd	%xmm6, 0x28(%rsp)
180002e55:     	movq	%rbx, 0x20(%rsp)
180002e5a:     	leaq	0xa0(%rsp), %rcx
180002e62:     	movq	%r8, %rbp
180002e65:     	movq	%rax, %r9
180002e68:     	callq	0x180002b60 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x5d0>
180002e6d:     	cmpb	$0x0, (%rdi)
180002e70:     	jne	0x180002fb4 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xa24>
180002e76:     	cmpb	$0x0, 0xb8(%rsp)
180002e7e:     	setne	%r15b
180002e82:     	cmpb	$0x0, 0xa8(%rsp)
180002e8a:     	setne	%r11b
180002e8e:     	xorpd	%xmm8, %xmm8
180002e93:     	movsd	0xa0(%rsp), %xmm7
180002e9c:     	addsd	%xmm8, %xmm7
180002ea1:     	addsd	0xb0(%rsp), %xmm8
180002eab:     	decq	0x8(%rsi)
180002eaf:     	movq	%r13, %rcx
180002eb2:     	movq	%rbp, %r8
180002eb5:     	movq	%r12, %r9
180002eb8:     	jmp	0x180002ec9 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x939>
180002eba:     	movb	$0x1, %r11b
180002ebd:     	xorpd	%xmm7, %xmm7
180002ec1:     	xorpd	%xmm8, %xmm8
180002ec6:     	movb	$0x1, %r15b
180002ec9:     	movq	0x28(%r14,%r9,8), %rax
180002ece:     	testq	%rax, %rax
180002ed1:     	js	0x180002f66 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x9d6>
180002ed7:     	movq	0x8(%rsi), %rdx
180002edb:     	leaq	0x1(%rdx), %r10
180002edf:     	movq	%r10, 0x8(%rsi)
180002ee3:     	cmpq	0x10(%rsi), %rdx
180002ee7:     	jge	0x180002fe9 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xa59>
180002eed:     	movl	%r15d, %r12d
180002ef0:     	movl	%r11d, %r15d
180002ef3:     	movq	%r9, 0x38(%rsp)
180002ef8:     	movq	%rcx, %r13
180002efb:     	movsd	%xmm6, 0x28(%rsp)
180002f01:     	movq	%rbx, 0x20(%rsp)
180002f06:     	leaq	0x80(%rsp), %rcx
180002f0e:     	movq	%r8, %rbp
180002f11:     	movq	%rax, %r9
180002f14:     	callq	0x180002b60 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x5d0>
180002f19:     	cmpb	$0x0, (%rdi)
180002f1c:     	jne	0x180002fb4 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xa24>
180002f22:     	cmpb	$0x0, 0x98(%rsp)
180002f2a:     	setne	%al
180002f2d:     	cmpb	$0x0, 0x88(%rsp)
180002f35:     	setne	%cl
180002f38:     	addsd	0x80(%rsp), %xmm7
180002f41:     	addsd	0x90(%rsp), %xmm8
180002f4b:     	decq	0x8(%rsi)
180002f4f:     	movl	%r15d, %r11d
180002f52:     	andb	%cl, %r11b
180002f55:     	movl	%r12d, %r15d
180002f58:     	andb	%al, %r15b
180002f5b:     	movq	%r13, %rcx
180002f5e:     	movq	%rbp, %r8
180002f61:     	movq	0x38(%rsp), %r9
180002f66:     	movq	0x38(%r14,%r9,8), %rax
180002f6b:     	testq	%rax, %rax
180002f6e:     	js	0x180003041 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xab1>
180002f74:     	movq	0x8(%rsi), %rdx
180002f78:     	leaq	0x1(%rdx), %r10
180002f7c:     	movq	%r10, 0x8(%rsi)
180002f80:     	cmpq	0x10(%rsi), %rdx
180002f84:     	jge	0x180002ff9 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xa69>
180002f86:     	movl	%r15d, %r12d
180002f89:     	movl	%r11d, %r15d
180002f8c:     	movq	%r9, 0x38(%rsp)
180002f91:     	movq	%rcx, %r13
180002f94:     	movsd	%xmm6, 0x28(%rsp)
180002f9a:     	movq	%rbx, 0x20(%rsp)
180002f9f:     	leaq	0x60(%rsp), %rcx
180002fa4:     	movq	%r8, %rbp
180002fa7:     	movq	%rax, %r9
180002faa:     	callq	0x180002b60 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x5d0>
180002faf:     	cmpb	$0x0, (%rdi)
180002fb2:     	je	0x180003009 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xa79>
180002fb4:     	movq	$0x0, 0x18(%r13)
180002fbc:     	movq	$0x0, 0x10(%r13)
180002fc4:     	movq	$0x0, 0x8(%r13)
180002fcc:     	movq	$0x0, (%r13)
180002fd4:     	jmp	0x180002dbd <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x82d>
180002fd9:     	movb	$0x1, (%rdi)
180002fdc:     	movq	$0x3d0921, 0x18(%rsi)   # imm = 0x3D0921
180002fe4:     	jmp	0x180002d9e <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x80e>
180002fe9:     	movb	$0x1, (%rdi)
180002fec:     	movq	$0x3d0926, 0x18(%rsi)   # imm = 0x3D0926
180002ff4:     	jmp	0x180002d9e <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x80e>
180002ff9:     	movb	$0x1, (%rdi)
180002ffc:     	movq	$0x3d092b, 0x18(%rsi)   # imm = 0x3D092B
180003004:     	jmp	0x180002d9e <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x80e>
180003009:     	cmpb	$0x0, 0x78(%rsp)
18000300e:     	setne	%al
180003011:     	cmpb	$0x0, 0x68(%rsp)
180003016:     	setne	%cl
180003019:     	addsd	0x60(%rsp), %xmm7
18000301f:     	addsd	0x70(%rsp), %xmm8
180003026:     	decq	0x8(%rsi)
18000302a:     	movl	%r15d, %r11d
18000302d:     	andb	%cl, %r11b
180003030:     	movl	%r12d, %r15d
180003033:     	andb	%al, %r15b
180003036:     	movq	%r13, %rcx
180003039:     	movq	%rbp, %r8
18000303c:     	movq	0x38(%rsp), %r9
180003041:     	movq	0x40(%r14,%r9,8), %r9
180003046:     	testq	%r9, %r9
180003049:     	js	0x1800030e2 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xb52>
18000304f:     	movq	0x8(%rsi), %rax
180003053:     	leaq	0x1(%rax), %rdx
180003057:     	movq	%rdx, 0x8(%rsi)
18000305b:     	cmpq	0x10(%rsi), %rax
18000305f:     	jge	0x1800030a5 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xb15>
180003061:     	movl	%r11d, %ebp
180003064:     	movq	%rcx, %r14
180003067:     	movsd	%xmm6, 0x28(%rsp)
18000306d:     	movq	%rbx, 0x20(%rsp)
180003072:     	leaq	0x40(%rsp), %rcx
180003077:     	callq	0x180002b60 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x5d0>
18000307c:     	cmpb	$0x0, (%rdi)
18000307f:     	je	0x1800030b5 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xb25>
180003081:     	movq	$0x0, 0x18(%r14)
180003089:     	movq	$0x0, 0x10(%r14)
180003091:     	movq	$0x0, 0x8(%r14)
180003099:     	movq	$0x0, (%r14)
1800030a0:     	jmp	0x180002dbd <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x82d>
1800030a5:     	movb	$0x1, (%rdi)
1800030a8:     	movq	$0x3d0930, 0x18(%rsi)   # imm = 0x3D0930
1800030b0:     	jmp	0x180002d9e <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x80e>
1800030b5:     	cmpb	$0x0, 0x58(%rsp)
1800030ba:     	setne	%al
1800030bd:     	cmpb	$0x0, 0x48(%rsp)
1800030c2:     	setne	%cl
1800030c5:     	addsd	0x40(%rsp), %xmm7
1800030cb:     	addsd	0x50(%rsp), %xmm8
1800030d2:     	decq	0x8(%rsi)
1800030d6:     	movl	%ebp, %r11d
1800030d9:     	andb	%cl, %r11b
1800030dc:     	andb	%al, %r15b
1800030df:     	movq	%r14, %rcx
1800030e2:     	movb	%r15b, 0x18(%rcx)
1800030e6:     	movsd	%xmm8, 0x10(%rcx)
1800030ec:     	movb	%r11b, 0x8(%rcx)
1800030f0:     	movsd	%xmm7, (%rcx)
1800030f4:     	jmp	0x180002dbd <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x82d>
1800030f9:     	nopl	(%rax)
180003100:     	pushq	%r15
180003102:     	pushq	%r14
180003104:     	pushq	%r13
180003106:     	pushq	%r12
180003108:     	pushq	%rsi
180003109:     	pushq	%rdi
18000310a:     	pushq	%rbp
18000310b:     	pushq	%rbx
18000310c:     	subq	$0xe8, %rsp
180003113:     	movb	$0x0, 0x4f(%rsp)
180003118:     	movb	$0x0, 0x4a(%rsp)
18000311d:     	movb	$0x0, 0x49(%rsp)
180003122:     	movb	$0x0, 0x48(%rsp)
180003127:     	movb	$0x0, 0x47(%rsp)
18000312c:     	movb	$0x0, 0x4e(%rsp)
180003131:     	movb	$0x0, 0x4d(%rsp)
180003136:     	movb	$0x0, 0x4c(%rsp)
18000313b:     	movb	$0x0, 0x4b(%rsp)
180003140:     	movq	(%r8), %rax
180003143:     	movq	0x8(%r8), %rbp
180003147:     	movq	0x10(%r8), %r13
18000314b:     	movq	0x18(%r8), %r12
18000314f:     	movq	0x20(%r8), %rdi
180003153:     	testq	%r9, %r9
180003156:     	je	0x18000317d <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xbed>
180003158:     	cmpq	$0x1, %r9
18000315c:     	jne	0x180003618 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1088>
180003162:     	movq	(%r13), %r9
180003166:     	leaq	0x4(%r9), %rdx
18000316a:     	cmpq	%rdi, %rdx
18000316d:     	jle	0x180003300 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xd70>
180003173:     	movb	$0x2, (%r12)
180003178:     	jmp	0x180003618 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1088>
18000317d:     	movq	0x158(%rsp), %rbx
180003185:     	movq	0x150(%rsp), %r14
18000318d:     	movq	(%rbp,%r14,8), %rdx
180003192:     	movq	0x10(%rbp,%rbx,8), %r9
180003197:     	movsd	(%rax,%r9,8), %xmm0
18000319d:     	movsd	0x8(%rax,%rdx,8), %xmm2
1800031a3:     	movsd	0x10(%rax,%rdx,8), %xmm1
1800031a9:     	movapd	%xmm1, %xmm3
1800031ad:     	subsd	%xmm2, %xmm3
1800031b1:     	xorl	%r15d, %r15d
1800031b4:     	ucomisd	%xmm3, %xmm0
1800031b8:     	jb	0x18000361b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x108b>
1800031be:     	addsd	%xmm2, %xmm1
1800031c2:     	ucomisd	%xmm0, %xmm1
1800031c6:     	jbe	0x18000361b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x108b>
1800031cc:     	movsd	0x10(%rax,%r9,8), %xmm0
1800031d3:     	movsd	(%rax,%rdx,8), %xmm2
1800031d8:     	movsd	0x18(%rax,%rdx,8), %xmm1
1800031de:     	movapd	%xmm1, %xmm3
1800031e2:     	subsd	%xmm2, %xmm3
1800031e6:     	ucomisd	%xmm3, %xmm0
1800031ea:     	jb	0x180003618 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1088>
1800031f0:     	addsd	%xmm2, %xmm1
1800031f4:     	xorl	%r15d, %r15d
1800031f7:     	ucomisd	%xmm0, %xmm1
1800031fb:     	jbe	0x18000361b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x108b>
180003201:     	cmpb	$0x0, (%r12)
180003206:     	jne	0x18000361b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x108b>
18000320c:     	movq	0x18(%rbp,%r14,8), %r9
180003211:     	movq	0x30(%rbp,%r14,8), %rdx
180003216:     	movq	(%rbp,%rdx,8), %r10
18000321b:     	cmpq	0x8(%rbp,%r14,8), %r10
180003220:     	jge	0x1800034f0 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xf60>
180003226:     	testq	%r9, %r9
180003229:     	jne	0x1800034f5 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xf65>
18000322f:     	leaq	(%rbp,%rdx,8), %r11
180003234:     	movq	%rdx, %r9
180003237:     	sarq	$0x3f, %r9
18000323b:     	andq	%rdi, %r9
18000323e:     	movq	(%r11,%r9,8), %r15
180003242:     	xorl	%r10d, %r10d
180003245:     	cmpq	$-0x1, %rdx
180003249:     	cmovlq	%rdi, %r10
18000324d:     	cmpq	0x8(%r11,%r10,8), %r15
180003252:     	jne	0x1800039c0 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1430>
180003258:     	movq	%r11, 0xa8(%rsp)
180003260:     	leaq	(%r15,%r15), %r8
180003264:     	testq	%r15, %r15
180003267:     	movl	$0x4, %esi
18000326c:     	cmovneq	%r8, %rsi
180003270:     	movq	(%r13), %r11
180003274:     	movq	%r11, 0x60(%rsp)
180003279:     	leaq	(%r11,%rsi), %r8
18000327d:     	cmpq	%rdi, %r8
180003280:     	jg	0x180003173 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xbe3>
180003286:     	movq	%r8, (%r13)
18000328a:     	cmpb	$0x0, (%r12)
18000328f:     	jne	0x180003618 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1088>
180003295:     	movq	%rsi, 0x90(%rsp)
18000329d:     	movq	%r10, 0x98(%rsp)
1800032a5:     	movq	%r9, 0xa0(%rsp)
1800032ad:     	xorl	%r8d, %r8d
1800032b0:     	cmpq	$-0x2, %rdx
1800032b4:     	cmovlq	%rdi, %r8
1800032b8:     	movq	%r8, 0x70(%rsp)
1800032bd:     	movq	%r15, 0x78(%rsp)
1800032c2:     	testq	%r15, %r15
1800032c5:     	jle	0x180003987 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x13f7>
1800032cb:     	leaq	(%rbp,%rdx,8), %r8
1800032d0:     	movq	0x70(%rsp), %r9
1800032d5:     	movq	0x10(%r8,%r9,8), %rsi
1800032da:     	movq	0x78(%rsp), %r8
1800032df:     	movl	%r8d, %r11d
1800032e2:     	andl	$0x7, %r11d
1800032e6:     	cmpq	$0x7, %r8
1800032ea:     	ja	0x1800036b8 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1128>
1800032f0:     	leaq	(,%rdi,8), %r10
1800032f8:     	xorl	%r15d, %r15d
1800032fb:     	jmp	0x180003949 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x13b9>
180003300:     	movq	0x160(%rsp), %r14
180003308:     	movq	(%rbp,%r14,8), %r10
18000330d:     	movsd	0x10(%rax,%r10,8), %xmm2
180003314:     	movsd	0x18(%rax,%r10,8), %xmm1
18000331b:     	movsd	0x708d(%rip), %xmm0     # 0x18000a3b0
180003323:     	movsd	0x8(%rax,%r10,8), %xmm3
18000332a:     	mulsd	%xmm0, %xmm3
18000332e:     	mulsd	(%rax,%r10,8), %xmm0
180003334:     	movq	%rdx, (%r13)
180003338:     	cmpb	$0x0, (%r12)
18000333d:     	jne	0x180003618 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1088>
180003343:     	movapd	%xmm2, %xmm4
180003347:     	addsd	%xmm3, %xmm4
18000334b:     	movapd	%xmm1, %xmm5
18000334f:     	subsd	%xmm0, %xmm5
180003353:     	movsd	%xmm4, 0x10(%rax,%r9,8)
18000335a:     	movsd	%xmm5, 0x18(%rax,%r9,8)
180003361:     	movsd	%xmm3, 0x8(%rax,%r9,8)
180003368:     	movsd	%xmm0, (%rax,%r9,8)
18000336e:     	cmpb	$0x0, (%r12)
180003373:     	jne	0x180003618 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1088>
180003379:     	movq	(%r13), %rdx
18000337d:     	leaq	0xb(%rdx), %r11
180003381:     	cmpq	%rdi, %r11
180003384:     	jg	0x180003173 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xbe3>
18000338a:     	movq	0x8(%rbp,%r14,8), %r10
18000338f:     	movq	%r11, (%r13)
180003393:     	cmpb	$0x0, (%r12)
180003398:     	jne	0x180003618 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1088>
18000339e:     	movq	%r9, (%rbp,%rdx,8)
1800033a3:     	movq	%r10, 0x8(%rbp,%rdx,8)
1800033a8:     	movq	(%r13), %r9
1800033ac:     	cmpq	%rdi, %r9
1800033af:     	movq	%r9, %r10
1800033b2:     	jle	0x1800033c0 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xe30>
1800033b4:     	movb	$0x2, (%r12)
1800033b9:     	movq	(%r13), %r9
1800033bd:     	xorl	%r10d, %r10d
1800033c0:     	leaq	0x3(%r9), %r11
1800033c4:     	cmpq	%rdi, %r11
1800033c7:     	jg	0x180003173 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xbe3>
1800033cd:     	movq	%r11, (%r13)
1800033d1:     	cmpb	$0x0, (%r12)
1800033d6:     	jne	0x180003618 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1088>
1800033dc:     	movq	%r9, %r11
1800033df:     	sarq	$0x3f, %r11
1800033e3:     	andq	%rdi, %r11
1800033e6:     	leaq	(%rbp,%r9,8), %rsi
1800033eb:     	movq	$0x0, (%rsi,%r11,8)
1800033f3:     	xorl	%r15d, %r15d
1800033f6:     	cmpq	$-0x1, %r9
1800033fa:     	movl	$0x0, %r11d
180003400:     	cmovlq	%rdi, %r11
180003404:     	movq	$0x0, 0x8(%rsi,%r11,8)
18000340d:     	cmpq	$-0x2, %r9
180003411:     	movl	$0x0, %r11d
180003417:     	cmovlq	%rdi, %r11
18000341b:     	movq	%r10, 0x10(%rsi,%r11,8)
180003420:     	cmpb	$0x0, (%r12)
180003425:     	jne	0x18000361b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x108b>
18000342b:     	leaq	(%rbp,%rdx,8), %r10
180003430:     	movq	%r9, 0x30(%r10)
180003434:     	movq	$0x0, 0x18(%r10)
18000343c:     	movq	(%r13), %r9
180003440:     	leaq	0x4(%r9), %r11
180003444:     	cmpq	%rdi, %r11
180003447:     	jg	0x180003173 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xbe3>
18000344d:     	movq	%r11, (%r13)
180003451:     	cmpb	$0x0, (%r12)
180003456:     	jne	0x180003618 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1088>
18000345c:     	movq	%rcx, %rbx
18000345f:     	movq	$0x0, (%rax,%r9,8)
180003467:     	movq	$0x1, 0x8(%rbp,%r9,8)
180003470:     	movq	$0x0, 0x10(%rax,%r9,8)
180003479:     	movq	$0x1, 0x18(%rbp,%r9,8)
180003482:     	cmpb	$0x0, (%r12)
180003487:     	jne	0x180003bd3 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1643>
18000348d:     	movq	%r8, %rsi
180003490:     	movq	%r9, 0x10(%r10)
180003494:     	movq	$0x0, 0x48(%rax,%rdx,8)
18000349d:     	movq	$0x1, 0x50(%r10)
1800034a5:     	movq	$-0x1, 0x20(%r10)
1800034ad:     	movq	$-0x1, 0x28(%r10)
1800034b5:     	movq	$-0x1, 0x38(%r10)
1800034bd:     	movq	$-0x1, 0x40(%r10)
1800034c5:     	cmpb	$0x0, (%r12)
1800034ca:     	jne	0x180003bd3 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1643>
1800034d0:     	movq	%rdx, 0x20(%rbp,%r14,8)
1800034d5:     	movq	(%r13), %rcx
1800034d9:     	leaq	0x4(%rcx), %rdx
1800034dd:     	cmpq	%rdi, %rdx
1800034e0:     	jle	0x180003ba6 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1616>
1800034e6:     	movb	$0x2, (%r12)
1800034eb:     	jmp	0x180003bd3 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1643>
1800034f0:     	testq	%r9, %r9
1800034f3:     	je	0x180003573 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xfe3>
1800034f5:     	movq	0x20(%rbp,%r14,8), %rax
1800034fa:     	testq	%rax, %rax
1800034fd:     	js	0x18000360b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x107b>
180003503:     	movq	0x8(%r13), %rdx
180003507:     	leaq	0x1(%rdx), %r9
18000350b:     	movq	%r9, 0x8(%r13)
18000350f:     	cmpq	0x10(%r13), %rdx
180003513:     	jge	0x18000360b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x107b>
180003519:     	movb	$0x0, 0x4a(%rsp)
18000351e:     	movq	%rbx, 0x28(%rsp)
180003523:     	movq	%rax, 0x20(%rsp)
180003528:     	movq	$-0x1, 0x30(%rsp)
180003531:     	xorl	%r15d, %r15d
180003534:     	leaq	0x4a(%rsp), %rax
180003539:     	movq	%rcx, %rdi
18000353c:     	movq	%rax, %rcx
18000353f:     	movq	%r8, %rsi
180003542:     	xorl	%r9d, %r9d
180003545:     	callq	0x180003100 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xb70>
18000354a:     	movq	%rdi, %rcx
18000354d:     	cmpb	$0x0, (%r12)
180003552:     	jne	0x18000361b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x108b>
180003558:     	movq	0x8(%r13), %rdx
18000355c:     	leaq	-0x1(%rdx), %rax
180003560:     	cmpb	$0x0, 0x4a(%rsp)
180003565:     	movq	%rax, 0x8(%r13)
180003569:     	je	0x1800035d0 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1040>
18000356b:     	movb	$0x1, %r15b
18000356e:     	jmp	0x18000361b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x108b>
180003573:     	movq	0x8(%r13), %rax
180003577:     	leaq	0x1(%rax), %rdx
18000357b:     	movq	%rdx, 0x8(%r13)
18000357f:     	cmpq	0x10(%r13), %rax
180003583:     	jge	0x1800035c1 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1031>
180003585:     	movq	%rcx, %rsi
180003588:     	movq	%r14, 0x30(%rsp)
18000358d:     	movq	$-0x1, 0x28(%rsp)
180003596:     	movq	$-0x1, 0x20(%rsp)
18000359f:     	leaq	0x4f(%rsp), %rcx
1800035a4:     	movl	$0x1, %r9d
1800035aa:     	movq	%r8, %rdi
1800035ad:     	callq	0x180003100 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xb70>
1800035b2:     	cmpb	$0x0, (%r12)
1800035b7:     	je	0x1800035f3 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1063>
1800035b9:     	xorl	%r15d, %r15d
1800035bc:     	movq	%rsi, %rcx
1800035bf:     	jmp	0x18000361b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x108b>
1800035c1:     	movb	$0x1, (%r12)
1800035c6:     	movq	$0x2dc6cb, 0x18(%r13)   # imm = 0x2DC6CB
1800035ce:     	jmp	0x180003618 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1088>
1800035d0:     	movq	0x28(%rbp,%r14,8), %rax
1800035d5:     	testq	%rax, %rax
1800035d8:     	js	0x1800035e4 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1054>
1800035da:     	movq	%rdx, 0x8(%r13)
1800035de:     	cmpq	0x10(%r13), %rdx
1800035e2:     	jle	0x180003638 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x10a8>
1800035e4:     	movb	$0x1, (%r12)
1800035e9:     	movq	$0x2dc6ce, 0x18(%r13)   # imm = 0x2DC6CE
1800035f1:     	jmp	0x180003618 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1088>
1800035f3:     	decq	0x8(%r13)
1800035f7:     	movq	%rsi, %rcx
1800035fa:     	movq	%rdi, %r8
1800035fd:     	movq	0x20(%rbp,%r14,8), %rax
180003602:     	testq	%rax, %rax
180003605:     	jns	0x180003503 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xf73>
18000360b:     	movb	$0x1, (%r12)
180003610:     	movq	$0x2dc6cd, 0x18(%r13)   # imm = 0x2DC6CD
180003618:     	xorl	%r15d, %r15d
18000361b:     	andb	$0x1, %r15b
18000361f:     	movb	%r15b, (%rcx)
180003622:     	xorl	%eax, %eax
180003624:     	addq	$0xe8, %rsp
18000362b:     	popq	%rbx
18000362c:     	popq	%rbp
18000362d:     	popq	%rdi
18000362e:     	popq	%rsi
18000362f:     	popq	%r12
180003631:     	popq	%r13
180003633:     	popq	%r14
180003635:     	popq	%r15
180003637:     	retq
180003638:     	movb	$0x0, 0x49(%rsp)
18000363d:     	movq	%rbx, 0x28(%rsp)
180003642:     	movq	%rax, 0x20(%rsp)
180003647:     	movq	$-0x1, 0x30(%rsp)
180003650:     	xorl	%r15d, %r15d
180003653:     	leaq	0x49(%rsp), %rcx
180003658:     	movq	%rsi, %r8
18000365b:     	xorl	%r9d, %r9d
18000365e:     	callq	0x180003100 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xb70>
180003663:     	movq	%rdi, %rcx
180003666:     	cmpb	$0x0, (%r12)
18000366b:     	jne	0x18000361b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x108b>
18000366d:     	movq	0x8(%r13), %rdx
180003671:     	leaq	-0x1(%rdx), %rax
180003675:     	cmpb	$0x0, 0x49(%rsp)
18000367a:     	movq	%rax, 0x8(%r13)
18000367e:     	jne	0x18000356b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xfdb>
180003684:     	movq	0x38(%rbp,%r14,8), %rax
180003689:     	testq	%rax, %rax
18000368c:     	js	0x180003b1b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x158b>
180003692:     	movq	%rdx, 0x8(%r13)
180003696:     	cmpq	0x10(%r13), %rdx
18000369a:     	jle	0x180003b2d <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x159d>
1800036a0:     	movb	$0x1, (%r12)
1800036a5:     	movq	$0x2dc6cf, 0x18(%r13)   # imm = 0x2DC6CF
1800036ad:     	xorl	%r15d, %r15d
1800036b0:     	movq	%rdi, %rcx
1800036b3:     	jmp	0x18000361b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x108b>
1800036b8:     	movq	%rdx, 0x80(%rsp)
1800036c0:     	movq	%r11, 0x88(%rsp)
1800036c8:     	movabsq	$0x7ffffffffffffff8, %r15 # imm = 0x7FFFFFFFFFFFFFF8
1800036d2:     	andq	%r8, %r15
1800036d5:     	movq	0x60(%rsp), %rdx
1800036da:     	leaq	(%rbp,%rdx,8), %rdx
1800036df:     	movq	%rdx, 0xb8(%rsp)
1800036e7:     	leaq	(,%rdi,8), %r10
1800036ef:     	xorl	%r11d, %r11d
1800036f2:     	movq	%r15, 0xc0(%rsp)
1800036fa:     	movq	%rsi, 0xb0(%rsp)
180003702:     	leaq	(%rsi,%r11), %r15
180003706:     	movq	%r15, %r8
180003709:     	sarq	$0x3f, %r8
18000370d:     	andq	%r10, %r8
180003710:     	leaq	(%rbp,%rsi,8), %rsi
180003715:     	addq	%rsi, %r8
180003718:     	movq	%rsi, 0x50(%rsp)
18000371d:     	movq	(%r8,%r11,8), %r10
180003721:     	movq	0x60(%rsp), %rdx
180003726:     	leaq	(%rdx,%r11), %r9
18000372a:     	movq	%r9, %r8
18000372d:     	sarq	$0x3f, %r8
180003731:     	leaq	(,%rdi,8), %rdx
180003739:     	andq	%rdx, %r8
18000373c:     	movq	0xb8(%rsp), %rdx
180003744:     	addq	%rdx, %r8
180003747:     	movq	%r10, (%r8,%r11,8)
18000374b:     	movq	%r15, %r8
18000374e:     	incq	%r8
180003751:     	movl	$0x8, %r8d
180003757:     	leaq	0x8(,%rdi,8), %r10
18000375f:     	movq	%r10, 0x58(%rsp)
180003764:     	cmovsq	%r10, %r8
180003768:     	addq	%rsi, %r8
18000376b:     	movq	(%r8,%r11,8), %r8
18000376f:     	movq	%r9, %r10
180003772:     	incq	%r10
180003775:     	movl	$0x8, %r10d
18000377b:     	cmovsq	0x58(%rsp), %r10
180003781:     	addq	%rdx, %r10
180003784:     	movq	%r8, (%r10,%r11,8)
180003788:     	movq	%r15, %r8
18000378b:     	addq	$0x2, %r8
18000378f:     	movl	$0x10, %r8d
180003795:     	leaq	0x10(,%rdi,8), %r10
18000379d:     	movq	%r10, 0x68(%rsp)
1800037a2:     	cmovsq	%r10, %r8
1800037a6:     	addq	%rsi, %r8
1800037a9:     	movq	(%r8,%r11,8), %r8
1800037ad:     	movq	%r9, %r10
1800037b0:     	addq	$0x2, %r10
1800037b4:     	movl	$0x10, %r10d
1800037ba:     	cmovsq	0x68(%rsp), %r10
1800037c0:     	addq	%rdx, %r10
1800037c3:     	movq	%r8, (%r10,%r11,8)
1800037c7:     	movq	%r15, %r8
1800037ca:     	addq	$0x3, %r8
1800037ce:     	movl	$0x18, %r8d
1800037d4:     	leaq	0x18(,%rdi,8), %r10
1800037dc:     	movq	%r10, 0xe0(%rsp)
1800037e4:     	cmovsq	%r10, %r8
1800037e8:     	addq	%rsi, %r8
1800037eb:     	movq	(%r8,%r11,8), %r8
1800037ef:     	movq	%r9, %r10
1800037f2:     	addq	$0x3, %r10
1800037f6:     	movl	$0x18, %r10d
1800037fc:     	cmovsq	0xe0(%rsp), %r10
180003805:     	addq	%rdx, %r10
180003808:     	movq	%r8, (%r10,%r11,8)
18000380c:     	movq	%r15, %r8
18000380f:     	addq	$0x4, %r8
180003813:     	movl	$0x20, %r8d
180003819:     	leaq	0x20(,%rdi,8), %r10
180003821:     	movq	%r10, 0xd8(%rsp)
180003829:     	cmovsq	%r10, %r8
18000382d:     	addq	%rsi, %r8
180003830:     	movq	(%r8,%r11,8), %r8
180003834:     	movq	%r9, %r10
180003837:     	addq	$0x4, %r10
18000383b:     	movl	$0x20, %r10d
180003841:     	cmovsq	0xd8(%rsp), %r10
18000384a:     	addq	%rdx, %r10
18000384d:     	movq	%r8, (%r10,%r11,8)
180003851:     	movq	%r15, %r8
180003854:     	addq	$0x5, %r8
180003858:     	movl	$0x28, %r8d
18000385e:     	leaq	0x28(,%rdi,8), %r10
180003866:     	movq	%r10, 0xd0(%rsp)
18000386e:     	cmovsq	%r10, %r8
180003872:     	addq	%rsi, %r8
180003875:     	movq	(%r8,%r11,8), %r8
180003879:     	movq	%r9, %r10
18000387c:     	addq	$0x5, %r10
180003880:     	movl	$0x28, %r10d
180003886:     	cmovsq	0xd0(%rsp), %r10
18000388f:     	addq	%rdx, %r10
180003892:     	movq	%r8, (%r10,%r11,8)
180003896:     	movq	%r15, %r8
180003899:     	addq	$0x6, %r8
18000389d:     	movl	$0x30, %r8d
1800038a3:     	leaq	0x30(,%rdi,8), %r10
1800038ab:     	movq	%r10, 0xc8(%rsp)
1800038b3:     	cmovsq	%r10, %r8
1800038b7:     	addq	%rsi, %r8
1800038ba:     	movq	(%r8,%r11,8), %r8
1800038be:     	movq	%r9, %r10
1800038c1:     	addq	$0x6, %r10
1800038c5:     	movl	$0x30, %r10d
1800038cb:     	cmovsq	0xc8(%rsp), %r10
1800038d4:     	addq	%rdx, %r10
1800038d7:     	movq	%r8, (%r10,%r11,8)
1800038db:     	leaq	(,%rdi,8), %r10
1800038e3:     	addq	$0x7, %r15
1800038e7:     	movq	0xc0(%rsp), %r15
1800038ef:     	movl	$0x38, %r8d
1800038f5:     	leaq	0x38(,%rdi,8), %rsi
1800038fd:     	cmovsq	%rsi, %r8
180003901:     	addq	0x50(%rsp), %r8
180003906:     	movq	(%r8,%r11,8), %r8
18000390a:     	addq	$0x7, %r9
18000390e:     	movl	$0x38, %r9d
180003914:     	cmovsq	%rsi, %r9
180003918:     	movq	0xb0(%rsp), %rsi
180003920:     	addq	%rdx, %r9
180003923:     	movq	%r8, (%r9,%r11,8)
180003927:     	addq	$0x8, %r11
18000392b:     	cmpq	%r11, %r15
18000392e:     	jne	0x180003702 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1172>
180003934:     	movq	0x88(%rsp), %r11
18000393c:     	testq	%r11, %r11
18000393f:     	movq	0x80(%rsp), %rdx
180003947:     	je	0x180003987 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x13f7>
180003949:     	movq	0x60(%rsp), %r8
18000394e:     	addq	%r15, %r8
180003951:     	addq	%r15, %rsi
180003954:     	movq	%rsi, %r9
180003957:     	sarq	$0x3f, %r9
18000395b:     	andq	%r10, %r9
18000395e:     	addq	%rbp, %r9
180003961:     	movq	(%r9,%rsi,8), %r9
180003965:     	movq	%r10, %r15
180003968:     	movq	%r8, %r10
18000396b:     	sarq	$0x3f, %r10
18000396f:     	andq	%r15, %r10
180003972:     	addq	%rbp, %r10
180003975:     	movq	%r9, (%r10,%r8,8)
180003979:     	movq	%r15, %r10
18000397c:     	incq	%r8
18000397f:     	incq	%rsi
180003982:     	decq	%r11
180003985:     	jne	0x180003954 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x13c4>
180003987:     	movq	0x98(%rsp), %r8
18000398f:     	movq	0x90(%rsp), %r9
180003997:     	movq	0xa8(%rsp), %r11
18000399f:     	movq	%r9, 0x8(%r11,%r8,8)
1800039a4:     	movq	0x60(%rsp), %r8
1800039a9:     	movq	0x70(%rsp), %r9
1800039ae:     	movq	%r8, 0x10(%r11,%r9,8)
1800039b3:     	movq	0xa0(%rsp), %r9
1800039bb:     	movq	0x78(%rsp), %r15
1800039c0:     	leaq	0x1(%r15), %r8
1800039c4:     	movq	%r8, (%r11,%r9,8)
1800039c8:     	cmpb	$0x0, (%r12)
1800039cd:     	jne	0x180003618 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1088>
1800039d3:     	xorl	%r8d, %r8d
1800039d6:     	cmpq	$-0x2, %rdx
1800039da:     	cmovlq	%rdi, %r8
1800039de:     	addq	0x10(%r11,%r8,8), %r15
1800039e3:     	movq	%r15, %rdx
1800039e6:     	sarq	$0x3f, %rdx
1800039ea:     	andq	%rdi, %rdx
1800039ed:     	leaq	(%rbp,%r15,8), %r8
1800039f2:     	movq	%rbx, (%r8,%rdx,8)
1800039f6:     	movsd	0x48(%rax,%r14,8), %xmm2
1800039fd:     	movsd	0x8(%rax,%rbx,8), %xmm1
180003a03:     	movapd	%xmm2, %xmm0
180003a07:     	addsd	%xmm1, %xmm0
180003a0b:     	xorpd	%xmm3, %xmm3
180003a0f:     	ucomisd	%xmm3, %xmm0
180003a13:     	jbe	0x180003adf <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x154f>
180003a19:     	movq	0x10(%rbp,%r14,8), %rdx
180003a1e:     	cmpq	$0x0, 0x8(%rbp,%rdx,8)
180003a24:     	mulsd	(%rax,%rdx,8), %xmm2
180003a29:     	je	0x180003a55 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x14c5>
180003a2b:     	cmpq	$0x0, 0x50(%rbp,%r14,8)
180003a31:     	je	0x180003a55 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x14c5>
180003a33:     	movapd	0x6985(%rip), %xmm3     # 0x18000a3c0
180003a3b:     	andpd	%xmm2, %xmm3
180003a3f:     	ucomisd	0x6989(%rip), %xmm3     # 0x18000a3d0
180003a47:     	jae	0x180003afd <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x156d>
180003a4d:     	xorpd	%xmm3, %xmm3
180003a51:     	addsd	%xmm3, %xmm2
180003a55:     	movq	0x10(%rbp,%rbx,8), %r8
180003a5a:     	mulsd	(%rax,%r8,8), %xmm1
180003a60:     	addsd	%xmm2, %xmm1
180003a64:     	divsd	%xmm0, %xmm1
180003a68:     	movsd	%xmm1, (%rax,%rdx,8)
180003a6d:     	movq	$0x0, 0x8(%rbp,%rdx,8)
180003a76:     	movq	0x10(%rbp,%r14,8), %rdx
180003a7b:     	movsd	0x10(%rax,%rdx,8), %xmm1
180003a81:     	cmpq	$0x0, 0x18(%rbp,%rdx,8)
180003a87:     	mulsd	0x48(%rax,%r14,8), %xmm1
180003a8e:     	je	0x180003ab6 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1526>
180003a90:     	cmpq	$0x0, 0x50(%rbp,%r14,8)
180003a96:     	je	0x180003ab6 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1526>
180003a98:     	movapd	0x6920(%rip), %xmm2     # 0x18000a3c0
180003aa0:     	andpd	%xmm1, %xmm2
180003aa4:     	ucomisd	0x6924(%rip), %xmm2     # 0x18000a3d0
180003aac:     	jae	0x180003b0c <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x157c>
180003aae:     	xorpd	%xmm2, %xmm2
180003ab2:     	addsd	%xmm2, %xmm1
180003ab6:     	movq	0x10(%rbp,%rbx,8), %r8
180003abb:     	movsd	0x10(%rax,%r8,8), %xmm2
180003ac2:     	mulsd	0x8(%rax,%rbx,8), %xmm2
180003ac8:     	addsd	%xmm1, %xmm2
180003acc:     	divsd	%xmm0, %xmm2
180003ad0:     	movsd	%xmm2, 0x10(%rax,%rdx,8)
180003ad6:     	movq	$0x0, 0x18(%rbp,%rdx,8)
180003adf:     	movsd	%xmm0, 0x48(%rax,%r14,8)
180003ae6:     	movq	$0x0, 0x50(%rbp,%r14,8)
180003aef:     	cmpb	$0x0, (%r12)
180003af4:     	sete	%r15b
180003af8:     	jmp	0x18000361b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x108b>
180003afd:     	movb	$0x1, (%r12)
180003b02:     	movq	$0x895447, 0x18(%r13)   # imm = 0x895447
180003b0a:     	jmp	0x180003aef <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x155f>
180003b0c:     	movb	$0x1, (%r12)
180003b11:     	movq	$0x895449, 0x18(%r13)   # imm = 0x895449
180003b19:     	jmp	0x180003aef <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x155f>
180003b1b:     	movb	$0x1, (%r12)
180003b20:     	movq	$0x2dc6cf, 0x18(%r13)   # imm = 0x2DC6CF
180003b28:     	jmp	0x180003618 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1088>
180003b2d:     	movb	$0x0, 0x48(%rsp)
180003b32:     	movq	%rbx, 0x28(%rsp)
180003b37:     	movq	%rax, 0x20(%rsp)
180003b3c:     	movq	$-0x1, 0x30(%rsp)
180003b45:     	xorl	%r15d, %r15d
180003b48:     	leaq	0x48(%rsp), %rcx
180003b4d:     	movq	%rsi, %r8
180003b50:     	xorl	%r9d, %r9d
180003b53:     	callq	0x180003100 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xb70>
180003b58:     	cmpb	$0x0, (%r12)
180003b5d:     	movq	%rdi, %rcx
180003b60:     	jne	0x18000361b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x108b>
180003b66:     	movq	0x8(%r13), %rax
180003b6a:     	leaq	-0x1(%rax), %rdx
180003b6e:     	cmpb	$0x0, 0x48(%rsp)
180003b73:     	movq	%rdx, 0x8(%r13)
180003b77:     	movb	$0x1, %r15b
180003b7a:     	jne	0x18000361b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x108b>
180003b80:     	movq	0x40(%rbp,%r14,8), %rcx
180003b85:     	testq	%rcx, %rcx
180003b88:     	js	0x180003b94 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1604>
180003b8a:     	movq	%rax, 0x8(%r13)
180003b8e:     	cmpq	0x10(%r13), %rax
180003b92:     	jle	0x180003bde <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x164e>
180003b94:     	movb	$0x1, (%r12)
180003b99:     	movq	$0x2dc6d0, 0x18(%r13)   # imm = 0x2DC6D0
180003ba1:     	jmp	0x1800036ad <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x111d>
180003ba6:     	movq	%rdx, (%r13)
180003baa:     	cmpb	$0x0, (%r12)
180003baf:     	jne	0x180003bd3 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1643>
180003bb1:     	subsd	%xmm3, %xmm2
180003bb5:     	movsd	%xmm2, 0x10(%rax,%rcx,8)
180003bbb:     	movsd	%xmm5, 0x18(%rax,%rcx,8)
180003bc1:     	movsd	%xmm3, 0x8(%rax,%rcx,8)
180003bc7:     	movsd	%xmm0, (%rax,%rcx,8)
180003bcc:     	cmpb	$0x0, (%r12)
180003bd1:     	je	0x180003c26 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1696>
180003bd3:     	xorl	%r15d, %r15d
180003bd6:     	movq	%rbx, %rcx
180003bd9:     	jmp	0x18000361b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x108b>
180003bde:     	movb	$0x0, 0x47(%rsp)
180003be3:     	movq	%rbx, 0x28(%rsp)
180003be8:     	movq	%rcx, 0x20(%rsp)
180003bed:     	movq	$-0x1, 0x30(%rsp)
180003bf6:     	xorl	%r15d, %r15d
180003bf9:     	leaq	0x47(%rsp), %rcx
180003bfe:     	movq	%rsi, %r8
180003c01:     	xorl	%r9d, %r9d
180003c04:     	callq	0x180003100 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xb70>
180003c09:     	cmpb	$0x0, (%r12)
180003c0e:     	movq	%rdi, %rcx
180003c11:     	jne	0x18000361b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x108b>
180003c17:     	movzbl	0x47(%rsp), %r15d
180003c1d:     	decq	0x8(%r13)
180003c21:     	jmp	0x18000361b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x108b>
180003c26:     	movq	(%r13), %rdx
180003c2a:     	leaq	0xb(%rdx), %r9
180003c2e:     	cmpq	%rdi, %r9
180003c31:     	jg	0x1800034e6 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xf56>
180003c37:     	movq	0x8(%rbp,%r14,8), %r8
180003c3c:     	movq	%r9, (%r13)
180003c40:     	cmpb	$0x0, (%r12)
180003c45:     	jne	0x180003bd3 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1643>
180003c47:     	movq	%rcx, (%rbp,%rdx,8)
180003c4c:     	movq	%r8, 0x8(%rbp,%rdx,8)
180003c51:     	movq	(%r13), %r8
180003c55:     	cmpq	%rdi, %r8
180003c58:     	movq	%r8, %rcx
180003c5b:     	jle	0x180003c68 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x16d8>
180003c5d:     	movb	$0x2, (%r12)
180003c62:     	movq	(%r13), %r8
180003c66:     	xorl	%ecx, %ecx
180003c68:     	leaq	0x3(%r8), %r9
180003c6c:     	cmpq	%rdi, %r9
180003c6f:     	jg	0x1800034e6 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xf56>
180003c75:     	movq	%r9, (%r13)
180003c79:     	cmpb	$0x0, (%r12)
180003c7e:     	jne	0x180003bd3 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1643>
180003c84:     	movq	%r8, %r9
180003c87:     	sarq	$0x3f, %r9
180003c8b:     	andq	%rdi, %r9
180003c8e:     	leaq	(%rbp,%r8,8), %r10
180003c93:     	movq	$0x0, (%r10,%r9,8)
180003c9b:     	xorl	%r15d, %r15d
180003c9e:     	cmpq	$-0x1, %r8
180003ca2:     	movl	$0x0, %r9d
180003ca8:     	cmovlq	%rdi, %r9
180003cac:     	movq	$0x0, 0x8(%r10,%r9,8)
180003cb5:     	cmpq	$-0x2, %r8
180003cb9:     	movl	$0x0, %r9d
180003cbf:     	cmovlq	%rdi, %r9
180003cc3:     	movq	%rcx, 0x10(%r10,%r9,8)
180003cc8:     	cmpb	$0x0, (%r12)
180003ccd:     	movq	%rbx, %rcx
180003cd0:     	jne	0x18000361b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x108b>
180003cd6:     	leaq	(%rbp,%rdx,8), %rcx
180003cdb:     	movq	%r8, 0x30(%rcx)
180003cdf:     	movq	$0x0, 0x18(%rcx)
180003ce7:     	movq	(%r13), %r8
180003ceb:     	leaq	0x4(%r8), %r9
180003cef:     	cmpq	%rdi, %r9
180003cf2:     	jg	0x1800034e6 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xf56>
180003cf8:     	movq	%r9, (%r13)
180003cfc:     	cmpb	$0x0, (%r12)
180003d01:     	jne	0x180003bd3 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1643>
180003d07:     	movq	$0x0, (%rax,%r8,8)
180003d0f:     	movq	$0x1, 0x8(%rbp,%r8,8)
180003d18:     	movq	$0x0, 0x10(%rax,%r8,8)
180003d21:     	movq	$0x1, 0x18(%rbp,%r8,8)
180003d2a:     	cmpb	$0x0, (%r12)
180003d2f:     	jne	0x180003bd3 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1643>
180003d35:     	movq	%r8, 0x10(%rcx)
180003d39:     	movq	$0x0, 0x48(%rax,%rdx,8)
180003d42:     	movq	$0x1, 0x50(%rcx)
180003d4a:     	movq	$-0x1, 0x20(%rcx)
180003d52:     	movq	$-0x1, 0x28(%rcx)
180003d5a:     	movq	$-0x1, 0x38(%rcx)
180003d62:     	movq	$-0x1, 0x40(%rcx)
180003d6a:     	cmpb	$0x0, (%r12)
180003d6f:     	jne	0x180003bd3 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1643>
180003d75:     	movq	%rdx, 0x28(%rbp,%r14,8)
180003d7a:     	movq	(%r13), %rcx
180003d7e:     	leaq	0x4(%rcx), %rdx
180003d82:     	cmpq	%rdi, %rdx
180003d85:     	jg	0x1800034e6 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xf56>
180003d8b:     	movq	%rdx, (%r13)
180003d8f:     	cmpb	$0x0, (%r12)
180003d94:     	jne	0x180003bd3 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1643>
180003d9a:     	addsd	%xmm0, %xmm1
180003d9e:     	movsd	%xmm4, 0x10(%rax,%rcx,8)
180003da4:     	movsd	%xmm1, 0x18(%rax,%rcx,8)
180003daa:     	movsd	%xmm3, 0x8(%rax,%rcx,8)
180003db0:     	movsd	%xmm0, (%rax,%rcx,8)
180003db5:     	cmpb	$0x0, (%r12)
180003dba:     	jne	0x180003bd3 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1643>
180003dc0:     	movq	(%r13), %rdx
180003dc4:     	leaq	0xb(%rdx), %r9
180003dc8:     	cmpq	%rdi, %r9
180003dcb:     	jg	0x1800034e6 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xf56>
180003dd1:     	movq	0x8(%rbp,%r14,8), %r8
180003dd6:     	movq	%r9, (%r13)
180003dda:     	cmpb	$0x0, (%r12)
180003ddf:     	jne	0x180003bd3 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1643>
180003de5:     	movq	%rcx, (%rbp,%rdx,8)
180003dea:     	movq	%r8, 0x8(%rbp,%rdx,8)
180003def:     	movq	(%r13), %r8
180003df3:     	cmpq	%rdi, %r8
180003df6:     	movq	%r8, %rcx
180003df9:     	jle	0x180003e06 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1876>
180003dfb:     	movb	$0x2, (%r12)
180003e00:     	movq	(%r13), %r8
180003e04:     	xorl	%ecx, %ecx
180003e06:     	leaq	0x3(%r8), %r9
180003e0a:     	cmpq	%rdi, %r9
180003e0d:     	jg	0x1800034e6 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xf56>
180003e13:     	movq	%r9, (%r13)
180003e17:     	cmpb	$0x0, (%r12)
180003e1c:     	jne	0x180003bd3 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1643>
180003e22:     	movq	%r8, %r9
180003e25:     	sarq	$0x3f, %r9
180003e29:     	andq	%rdi, %r9
180003e2c:     	leaq	(%rbp,%r8,8), %r10
180003e31:     	movq	$0x0, (%r10,%r9,8)
180003e39:     	xorl	%r15d, %r15d
180003e3c:     	cmpq	$-0x1, %r8
180003e40:     	movl	$0x0, %r9d
180003e46:     	cmovlq	%rdi, %r9
180003e4a:     	movq	$0x0, 0x8(%r10,%r9,8)
180003e53:     	cmpq	$-0x2, %r8
180003e57:     	movl	$0x0, %r9d
180003e5d:     	cmovlq	%rdi, %r9
180003e61:     	movq	%rcx, 0x10(%r10,%r9,8)
180003e66:     	cmpb	$0x0, (%r12)
180003e6b:     	movq	%rbx, %rcx
180003e6e:     	jne	0x18000361b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x108b>
180003e74:     	leaq	(%rbp,%rdx,8), %rcx
180003e79:     	movq	%r8, 0x30(%rcx)
180003e7d:     	movq	$0x0, 0x18(%rcx)
180003e85:     	movq	(%r13), %r8
180003e89:     	leaq	0x4(%r8), %r9
180003e8d:     	cmpq	%rdi, %r9
180003e90:     	jg	0x1800034e6 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xf56>
180003e96:     	movq	%r9, (%r13)
180003e9a:     	cmpb	$0x0, (%r12)
180003e9f:     	jne	0x180003bd3 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1643>
180003ea5:     	movq	$0x0, (%rax,%r8,8)
180003ead:     	movq	$0x1, 0x8(%rbp,%r8,8)
180003eb6:     	movq	$0x0, 0x10(%rax,%r8,8)
180003ebf:     	movq	$0x1, 0x18(%rbp,%r8,8)
180003ec8:     	cmpb	$0x0, (%r12)
180003ecd:     	jne	0x180003bd3 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1643>
180003ed3:     	movq	%r8, 0x10(%rcx)
180003ed7:     	movq	$0x0, 0x48(%rax,%rdx,8)
180003ee0:     	movq	$0x1, 0x50(%rcx)
180003ee8:     	movq	$-0x1, 0x20(%rcx)
180003ef0:     	movq	$-0x1, 0x28(%rcx)
180003ef8:     	movq	$-0x1, 0x38(%rcx)
180003f00:     	movq	$-0x1, 0x40(%rcx)
180003f08:     	cmpb	$0x0, (%r12)
180003f0d:     	jne	0x180003bd3 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1643>
180003f13:     	movq	%rdx, 0x38(%rbp,%r14,8)
180003f18:     	movq	(%r13), %rcx
180003f1c:     	leaq	0x4(%rcx), %rdx
180003f20:     	cmpq	%rdi, %rdx
180003f23:     	jg	0x1800034e6 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xf56>
180003f29:     	movq	%rdx, (%r13)
180003f2d:     	cmpb	$0x0, (%r12)
180003f32:     	jne	0x180003bd3 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1643>
180003f38:     	movsd	%xmm2, 0x10(%rax,%rcx,8)
180003f3e:     	movsd	%xmm1, 0x18(%rax,%rcx,8)
180003f44:     	movsd	%xmm3, 0x8(%rax,%rcx,8)
180003f4a:     	movsd	%xmm0, (%rax,%rcx,8)
180003f4f:     	cmpb	$0x0, (%r12)
180003f54:     	jne	0x180003bd3 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1643>
180003f5a:     	movq	(%r13), %rdx
180003f5e:     	leaq	0xb(%rdx), %r9
180003f62:     	cmpq	%rdi, %r9
180003f65:     	jg	0x1800034e6 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xf56>
180003f6b:     	movq	0x8(%rbp,%r14,8), %r8
180003f70:     	movq	%r9, (%r13)
180003f74:     	cmpb	$0x0, (%r12)
180003f79:     	jne	0x180003bd3 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1643>
180003f7f:     	movq	%rcx, (%rbp,%rdx,8)
180003f84:     	movq	%r8, 0x8(%rbp,%rdx,8)
180003f89:     	movq	(%r13), %r8
180003f8d:     	cmpq	%rdi, %r8
180003f90:     	movq	%r8, %rcx
180003f93:     	jle	0x180003fa0 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1a10>
180003f95:     	movb	$0x2, (%r12)
180003f9a:     	movq	(%r13), %r8
180003f9e:     	xorl	%ecx, %ecx
180003fa0:     	leaq	0x3(%r8), %r9
180003fa4:     	cmpq	%rdi, %r9
180003fa7:     	jg	0x1800034e6 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xf56>
180003fad:     	movq	%r9, (%r13)
180003fb1:     	cmpb	$0x0, (%r12)
180003fb6:     	jne	0x180003bd3 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1643>
180003fbc:     	movq	%r8, %r9
180003fbf:     	sarq	$0x3f, %r9
180003fc3:     	andq	%rdi, %r9
180003fc6:     	leaq	(%rbp,%r8,8), %r10
180003fcb:     	movq	$0x0, (%r10,%r9,8)
180003fd3:     	xorl	%r15d, %r15d
180003fd6:     	cmpq	$-0x1, %r8
180003fda:     	movl	$0x0, %r9d
180003fe0:     	cmovlq	%rdi, %r9
180003fe4:     	movq	$0x0, 0x8(%r10,%r9,8)
180003fed:     	cmpq	$-0x2, %r8
180003ff1:     	movl	$0x0, %r9d
180003ff7:     	cmovlq	%rdi, %r9
180003ffb:     	movq	%rcx, 0x10(%r10,%r9,8)
180004000:     	cmpb	$0x0, (%r12)
180004005:     	movq	%rbx, %rcx
180004008:     	jne	0x18000361b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x108b>
18000400e:     	leaq	(%rbp,%rdx,8), %rcx
180004013:     	movq	%r8, 0x30(%rcx)
180004017:     	movq	$0x0, 0x18(%rcx)
18000401f:     	movq	(%r13), %r8
180004023:     	leaq	0x4(%r8), %r9
180004027:     	cmpq	%rdi, %r9
18000402a:     	jg	0x1800034e6 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xf56>
180004030:     	movq	%r9, (%r13)
180004034:     	cmpb	$0x0, (%r12)
180004039:     	jne	0x180003bd3 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1643>
18000403f:     	movq	$0x0, (%rax,%r8,8)
180004047:     	movq	$0x1, 0x8(%rbp,%r8,8)
180004050:     	movq	$0x0, 0x10(%rax,%r8,8)
180004059:     	movq	$0x1, 0x18(%rbp,%r8,8)
180004062:     	cmpb	$0x0, (%r12)
180004067:     	jne	0x180003bd3 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1643>
18000406d:     	movq	%r8, 0x10(%rcx)
180004071:     	movq	$0x0, 0x48(%rax,%rdx,8)
18000407a:     	movq	$0x1, 0x50(%rcx)
180004082:     	movq	$-0x1, 0x20(%rcx)
18000408a:     	movq	$-0x1, 0x28(%rcx)
180004092:     	movq	$-0x1, 0x38(%rcx)
18000409a:     	movq	$-0x1, 0x40(%rcx)
1800040a2:     	cmpb	$0x0, (%r12)
1800040a7:     	jne	0x180003bd3 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1643>
1800040ad:     	movq	%rdx, 0x40(%rbp,%r14,8)
1800040b2:     	movq	$0x1, 0x18(%rbp,%r14,8)
1800040bb:     	movq	0x30(%rbp,%r14,8), %rax
1800040c0:     	movq	%rax, 0x68(%rsp)
1800040c5:     	cmpq	$0x0, (%rbp,%rax,8)
1800040cb:     	jle	0x18000428c <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1cfc>
1800040d1:     	movq	$0x0, 0x58(%rsp)
1800040da:     	movq	0x20(%rbp,%r14,8), %rax
1800040df:     	testq	%rax, %rax
1800040e2:     	js	0x180004314 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1d84>
1800040e8:     	movq	0x68(%rsp), %rcx
1800040ed:     	movq	0x10(%rbp,%rcx,8), %rcx
1800040f2:     	leaq	(%rbp,%rcx,8), %rcx
1800040f7:     	movq	0x58(%rsp), %rdx
1800040fc:     	movq	(%rcx,%rdx,8), %rcx
180004100:     	movq	%rcx, 0x50(%rsp)
180004105:     	movq	0x8(%r13), %rcx
180004109:     	leaq	0x1(%rcx), %rdx
18000410d:     	movq	%rdx, 0x8(%r13)
180004111:     	cmpq	0x10(%r13), %rcx
180004115:     	jge	0x180004314 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1d84>
18000411b:     	movq	0x50(%rsp), %rcx
180004120:     	movq	%rcx, 0x28(%rsp)
180004125:     	movq	%rax, 0x20(%rsp)
18000412a:     	movq	$-0x1, 0x30(%rsp)
180004133:     	xorl	%r15d, %r15d
180004136:     	leaq	0x4e(%rsp), %rcx
18000413b:     	movq	%rsi, %r8
18000413e:     	xorl	%r9d, %r9d
180004141:     	callq	0x180003100 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xb70>
180004146:     	cmpb	$0x0, (%r12)
18000414b:     	jne	0x180003bd6 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1646>
180004151:     	movq	0x8(%r13), %rcx
180004155:     	leaq	-0x1(%rcx), %rax
180004159:     	movq	%rax, 0x8(%r13)
18000415d:     	movq	0x28(%rbp,%r14,8), %rax
180004162:     	testq	%rax, %rax
180004165:     	js	0x180004326 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1d96>
18000416b:     	movq	%rcx, 0x8(%r13)
18000416f:     	cmpq	0x10(%r13), %rcx
180004173:     	jg	0x180004326 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1d96>
180004179:     	movq	0x50(%rsp), %rcx
18000417e:     	movq	%rcx, 0x28(%rsp)
180004183:     	movq	%rax, 0x20(%rsp)
180004188:     	movq	$-0x1, 0x30(%rsp)
180004191:     	xorl	%r15d, %r15d
180004194:     	leaq	0x4d(%rsp), %rcx
180004199:     	movq	%rsi, %r8
18000419c:     	xorl	%r9d, %r9d
18000419f:     	callq	0x180003100 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xb70>
1800041a4:     	cmpb	$0x0, (%r12)
1800041a9:     	jne	0x180003bd6 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1646>
1800041af:     	movq	0x8(%r13), %rcx
1800041b3:     	leaq	-0x1(%rcx), %rax
1800041b7:     	movq	%rax, 0x8(%r13)
1800041bb:     	movq	0x38(%rbp,%r14,8), %rax
1800041c0:     	testq	%rax, %rax
1800041c3:     	js	0x180004338 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1da8>
1800041c9:     	movq	%rcx, 0x8(%r13)
1800041cd:     	cmpq	0x10(%r13), %rcx
1800041d1:     	jg	0x180004338 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1da8>
1800041d7:     	movq	0x50(%rsp), %rcx
1800041dc:     	movq	%rcx, 0x28(%rsp)
1800041e1:     	movq	%rax, 0x20(%rsp)
1800041e6:     	movq	$-0x1, 0x30(%rsp)
1800041ef:     	xorl	%r15d, %r15d
1800041f2:     	leaq	0x4c(%rsp), %rcx
1800041f7:     	movq	%rsi, %r8
1800041fa:     	xorl	%r9d, %r9d
1800041fd:     	callq	0x180003100 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xb70>
180004202:     	cmpb	$0x0, (%r12)
180004207:     	jne	0x180003bd6 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1646>
18000420d:     	movq	0x8(%r13), %rcx
180004211:     	leaq	-0x1(%rcx), %rax
180004215:     	movq	%rax, 0x8(%r13)
180004219:     	movq	0x40(%rbp,%r14,8), %rax
18000421e:     	testq	%rax, %rax
180004221:     	js	0x18000434a <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1dba>
180004227:     	movq	%rcx, 0x8(%r13)
18000422b:     	cmpq	0x10(%r13), %rcx
18000422f:     	jg	0x18000434a <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1dba>
180004235:     	movq	0x50(%rsp), %rcx
18000423a:     	movq	%rcx, 0x28(%rsp)
18000423f:     	movq	%rax, 0x20(%rsp)
180004244:     	movq	$-0x1, 0x30(%rsp)
18000424d:     	xorl	%r15d, %r15d
180004250:     	leaq	0x4b(%rsp), %rcx
180004255:     	movq	%rsi, %r8
180004258:     	xorl	%r9d, %r9d
18000425b:     	callq	0x180003100 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xb70>
180004260:     	cmpb	$0x0, (%r12)
180004265:     	jne	0x180003bd6 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1646>
18000426b:     	movq	0x58(%rsp), %rdx
180004270:     	incq	%rdx
180004273:     	decq	0x8(%r13)
180004277:     	movq	0x68(%rsp), %rax
18000427c:     	movq	%rdx, 0x58(%rsp)
180004281:     	cmpq	(%rbp,%rax,8), %rdx
180004286:     	jl	0x1800040da <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1b4a>
18000428c:     	movq	(%r13), %rax
180004290:     	cmpq	%rdi, %rax
180004293:     	movq	%rax, %rcx
180004296:     	jle	0x1800042a3 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1d13>
180004298:     	movb	$0x2, (%r12)
18000429d:     	movq	(%r13), %rax
1800042a1:     	xorl	%ecx, %ecx
1800042a3:     	leaq	0x3(%rax), %rdx
1800042a7:     	cmpq	%rdi, %rdx
1800042aa:     	jg	0x1800034e6 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0xf56>
1800042b0:     	movq	%rdx, (%r13)
1800042b4:     	cmpb	$0x0, (%r12)
1800042b9:     	jne	0x180003bd3 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1643>
1800042bf:     	movq	%rax, %rdx
1800042c2:     	sarq	$0x3f, %rdx
1800042c6:     	andq	%rdi, %rdx
1800042c9:     	leaq	(%rbp,%rax,8), %r8
1800042ce:     	movq	$0x0, (%r8,%rdx,8)
1800042d6:     	xorl	%r15d, %r15d
1800042d9:     	cmpq	$-0x1, %rax
1800042dd:     	movl	$0x0, %edx
1800042e2:     	cmovlq	%rdi, %rdx
1800042e6:     	movq	$0x0, 0x8(%r8,%rdx,8)
1800042ef:     	cmpq	$-0x2, %rax
1800042f3:     	cmovgeq	%r15, %rdi
1800042f7:     	movq	%rcx, 0x10(%r8,%rdi,8)
1800042fc:     	cmpb	$0x0, (%r12)
180004301:     	movq	%rbx, %rcx
180004304:     	jne	0x18000361b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x108b>
18000430a:     	movq	%rax, 0x30(%rbp,%r14,8)
18000430f:     	jmp	0x180003618 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1088>
180004314:     	movb	$0x1, (%r12)
180004319:     	movq	$0x989697, 0x18(%r13)   # imm = 0x989697
180004321:     	jmp	0x180003bd3 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1643>
180004326:     	movb	$0x1, (%r12)
18000432b:     	movq	$0x989698, 0x18(%r13)   # imm = 0x989698
180004333:     	jmp	0x180003bd3 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1643>
180004338:     	movb	$0x1, (%r12)
18000433d:     	movq	$0x989699, 0x18(%r13)   # imm = 0x989699
180004345:     	jmp	0x180003bd3 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1643>
18000434a:     	movb	$0x1, (%r12)
18000434f:     	movq	$0x98969a, 0x18(%r13)   # imm = 0x98969A
180004357:     	jmp	0x180003bd3 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1643>
18000435c:     	nopl	(%rax)
180004360:     	pushq	%r15
180004362:     	pushq	%r14
180004364:     	pushq	%r13
180004366:     	pushq	%r12
180004368:     	pushq	%rsi
180004369:     	pushq	%rdi
18000436a:     	pushq	%rbp
18000436b:     	pushq	%rbx
18000436c:     	subq	$0xb8, %rsp
180004373:     	movapd	%xmm7, 0xa0(%rsp)
18000437c:     	movaps	%xmm6, 0x90(%rsp)
180004384:     	movq	0x130(%rsp), %r11
18000438c:     	movabsq	$-0x20000000000001, %rax # imm = 0xFFDFFFFFFFFFFFFF
180004396:     	movabsq	$-0x40000000000001, %r10 # imm = 0xFFBFFFFFFFFFFFFF
1800043a0:     	movq	$0x0, 0x70(%rsp)
1800043a9:     	movb	$0x0, 0x78(%rsp)
1800043ae:     	movq	$0x0, 0x80(%rsp)
1800043ba:     	movb	$0x0, 0x88(%rsp)
1800043c2:     	movq	$0x0, 0x68(%rsp)
1800043cb:     	movb	$0x0, 0x47(%rsp)
1800043d0:     	movq	$0x0, 0x60(%rsp)
1800043d9:     	movq	0x10(%r8), %r15
1800043dd:     	movq	0x18(%r8), %r12
1800043e1:     	leaq	(%r11,%rax), %rsi
1800043e5:     	cmpq	%r10, %rsi
1800043e8:     	jb	0x1800043fa <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1e6a>
1800043ea:     	movq	0x138(%rsp), %rsi
1800043f2:     	addq	%rsi, %rax
1800043f5:     	cmpq	%r10, %rax
1800043f8:     	jae	0x180004434 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1ea4>
1800043fa:     	movb	$0x1, (%r12)
1800043ff:     	movq	$0x4, 0x18(%r15)
180004407:     	movq	$0x0, (%rcx)
18000440e:     	xorl	%eax, %eax
180004410:     	movaps	0x90(%rsp), %xmm6
180004418:     	movaps	0xa0(%rsp), %xmm7
180004420:     	addq	$0xb8, %rsp
180004427:     	popq	%rbx
180004428:     	popq	%rbp
180004429:     	popq	%rdi
18000442a:     	popq	%rsi
18000442b:     	popq	%r12
18000442d:     	popq	%r13
18000442f:     	popq	%r14
180004431:     	popq	%r15
180004433:     	retq
180004434:     	movq	0x20(%r8), %rax
180004438:     	movq	(%r15), %r10
18000443b:     	leaq	0x4(%r10), %rdi
18000443f:     	cmpq	%rax, %rdi
180004442:     	jle	0x18000444b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1ebb>
180004444:     	movb	$0x2, (%r12)
180004449:     	jmp	0x180004407 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1e77>
18000444b:     	movq	(%r8), %r13
18000444e:     	movq	0x8(%r8), %rbp
180004452:     	movq	%rdi, (%r15)
180004455:     	cmpb	$0x0, (%r12)
18000445a:     	jne	0x180004407 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1e77>
18000445c:     	testq	%r10, %r10
18000445f:     	js	0x1800044a4 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1f14>
180004461:     	cvtsi2sd	%rsi, %xmm0
180004466:     	movsd	0x5f42(%rip), %xmm1     # 0x18000a3b0
18000446e:     	mulsd	%xmm1, %xmm0
180004472:     	cvtsi2sd	%r11, %xmm2
180004477:     	mulsd	%xmm1, %xmm2
18000447b:     	movsd	%xmm2, 0x10(%r13,%r10,8)
180004482:     	movsd	%xmm0, 0x18(%r13,%r10,8)
180004489:     	movsd	%xmm2, 0x8(%r13,%r10,8)
180004490:     	movsd	%xmm0, (%r13,%r10,8)
180004497:     	cmpb	$0x0, (%r12)
18000449c:     	jne	0x180004407 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1e77>
1800044a2:     	jmp	0x1800044bc <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1f2c>
1800044a4:     	movb	$0x1, (%r12)
1800044a9:     	movq	$0xf4242, 0x18(%r15)    # imm = 0xF4242
1800044b1:     	cmpb	$0x0, (%r12)
1800044b6:     	jne	0x180004407 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1e77>
1800044bc:     	movq	(%r15), %rsi
1800044bf:     	leaq	0xb(%rsi), %r11
1800044c3:     	cmpq	%rax, %r11
1800044c6:     	jg	0x180004444 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1eb4>
1800044cc:     	movq	%r11, (%r15)
1800044cf:     	cmpb	$0x0, (%r12)
1800044d4:     	jne	0x180004407 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1e77>
1800044da:     	movq	%r10, (%rbp,%rsi,8)
1800044df:     	movq	$0x4, 0x8(%rbp,%rsi,8)
1800044e8:     	movq	(%r15), %r11
1800044eb:     	cmpq	%rax, %r11
1800044ee:     	movq	%r11, %r10
1800044f1:     	jle	0x1800044fe <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1f6e>
1800044f3:     	movb	$0x2, (%r12)
1800044f8:     	movq	(%r15), %r11
1800044fb:     	xorl	%r10d, %r10d
1800044fe:     	leaq	0x3(%r11), %rdi
180004502:     	cmpq	%rax, %rdi
180004505:     	jg	0x180004444 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1eb4>
18000450b:     	movq	%rdi, (%r15)
18000450e:     	cmpb	$0x0, (%r12)
180004513:     	jne	0x180004407 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1e77>
180004519:     	movq	%r11, %rdi
18000451c:     	sarq	$0x3f, %rdi
180004520:     	andq	%rax, %rdi
180004523:     	leaq	(%rbp,%r11,8), %rbx
180004528:     	movq	$0x0, (%rbx,%rdi,8)
180004530:     	xorl	%edi, %edi
180004532:     	cmpq	$-0x1, %r11
180004536:     	movl	$0x0, %r14d
18000453c:     	cmovlq	%rax, %r14
180004540:     	movq	$0x0, 0x8(%rbx,%r14,8)
180004549:     	cmpq	$-0x2, %r11
18000454d:     	cmovlq	%rax, %rdi
180004551:     	movq	%r10, 0x10(%rbx,%rdi,8)
180004556:     	cmpb	$0x0, (%r12)
18000455b:     	jne	0x180004407 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1e77>
180004561:     	leaq	(%rbp,%rsi,8), %r10
180004566:     	movq	%r11, 0x30(%r10)
18000456a:     	movq	$0x0, 0x18(%r10)
180004572:     	movq	(%r15), %r11
180004575:     	leaq	0x4(%r11), %rdi
180004579:     	cmpq	%rax, %rdi
18000457c:     	jg	0x180004444 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1eb4>
180004582:     	movq	%rdi, (%r15)
180004585:     	cmpb	$0x0, (%r12)
18000458a:     	jne	0x180004407 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1e77>
180004590:     	movq	%r8, 0x58(%rsp)
180004595:     	movq	%rdx, 0x50(%rsp)
18000459a:     	movq	%r9, %r14
18000459d:     	movq	%rcx, 0x48(%rsp)
1800045a2:     	testq	%r11, %r11
1800045a5:     	js	0x1800045ce <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x203e>
1800045a7:     	movq	$0x0, (%r13,%r11,8)
1800045b0:     	leaq	(%rbp,%r11,8), %rax
1800045b5:     	movq	$0x1, 0x8(%rbp,%r11,8)
1800045be:     	movq	$0x0, 0x10(%r13,%r11,8)
1800045c7:     	movl	$0x1, %ecx
1800045cc:     	jmp	0x1800045db <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x204b>
1800045ce:     	movb	$0x1, (%r12)
1800045d3:     	movl	$0x6acfc2, %ecx         # imm = 0x6ACFC2
1800045d8:     	movq	%r15, %rax
1800045db:     	movq	%rcx, 0x18(%rax)
1800045df:     	cmpb	$0x0, (%r12)
1800045e4:     	movq	0x48(%rsp), %rcx
1800045e9:     	jne	0x180004407 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1e77>
1800045ef:     	movq	%r11, 0x10(%r10)
1800045f3:     	movq	$0x0, 0x48(%r13,%rsi,8)
1800045fc:     	movq	$0x1, 0x50(%r10)
180004604:     	movq	$-0x1, 0x20(%r10)
18000460c:     	movq	$-0x1, 0x28(%r10)
180004614:     	movq	$-0x1, 0x38(%r10)
18000461c:     	movq	$-0x1, 0x40(%r10)
180004624:     	cmpb	$0x0, (%r12)
180004629:     	jne	0x180004407 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1e77>
18000462f:     	cmpq	$0x0, (%rbp,%r14,8)
180004635:     	jle	0x1800046c5 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2135>
18000463b:     	testq	%rsi, %rsi
18000463e:     	js	0x1800047f7 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2267>
180004644:     	movq	0x8(%r15), %rax
180004648:     	shlq	$0x3, %r14
18000464c:     	xorl	%edi, %edi
18000464e:     	leaq	0x47(%rsp), %rbx
180004653:     	movq	0x10(%rbp,%r14), %rcx
180004658:     	leaq	(%rbp,%rcx,8), %rcx
18000465d:     	movq	(%rcx,%rdi,8), %rcx
180004661:     	leaq	0x1(%rax), %rdx
180004665:     	movq	%rdx, 0x8(%r15)
180004669:     	cmpq	0x10(%r15), %rax
18000466d:     	jge	0x1800047f7 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2267>
180004673:     	movq	%rcx, 0x28(%rsp)
180004678:     	movq	%rsi, 0x20(%rsp)
18000467d:     	movq	$-0x1, 0x30(%rsp)
180004686:     	movq	%rbx, %rcx
180004689:     	leaq	0x60(%rsp), %rdx
18000468e:     	movq	0x58(%rsp), %r8
180004693:     	xorl	%r9d, %r9d
180004696:     	callq	0x180004fe0 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2a50>
18000469b:     	testl	%eax, %eax
18000469d:     	jne	0x1800049d1 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2441>
1800046a3:     	cmpb	$0x0, (%r12)
1800046a8:     	jne	0x180004804 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2274>
1800046ae:     	incq	%rdi
1800046b1:     	movq	0x8(%r15), %rax
1800046b5:     	decq	%rax
1800046b8:     	movq	%rax, 0x8(%r15)
1800046bc:     	cmpq	(%rbp,%r14), %rdi
1800046c1:     	jl	0x180004653 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x20c3>
1800046c3:     	jmp	0x1800046d2 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2142>
1800046c5:     	shlq	$0x3, %r14
1800046c9:     	testq	%rsi, %rsi
1800046cc:     	js	0x180004815 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2285>
1800046d2:     	movsd	0x120(%rsp), %xmm6
1800046db:     	xorl	%ebx, %ebx
1800046dd:     	xorpd	%xmm7, %xmm7
1800046e1:     	cmpq	(%rbp,%r14), %rbx
1800046e6:     	jge	0x180004815 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2285>
1800046ec:     	movq	0x10(%rbp,%r14), %rax
1800046f1:     	leaq	(%rbp,%rax,8), %rax
1800046f6:     	movq	(%rax,%rbx,8), %rdi
1800046fa:     	movq	0x8(%r15), %rax
1800046fe:     	leaq	0x1(%rax), %rcx
180004702:     	movq	%rcx, 0x8(%r15)
180004706:     	cmpq	0x10(%r15), %rax
18000470a:     	jge	0x1800049f5 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2465>
180004710:     	movsd	%xmm6, 0x28(%rsp)
180004716:     	movq	%rdi, 0x20(%rsp)
18000471b:     	leaq	0x70(%rsp), %rcx
180004720:     	leaq	0x68(%rsp), %rdx
180004725:     	movq	0x58(%rsp), %r8
18000472a:     	movq	%rsi, %r9
18000472d:     	callq	0x180004a30 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x24a0>
180004732:     	testl	%eax, %eax
180004734:     	jne	0x180004a19 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2489>
18000473a:     	cmpb	$0x0, (%r12)
18000473f:     	jne	0x180004804 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2274>
180004745:     	movsd	0x70(%rsp), %xmm1
18000474b:     	movsd	0x80(%rsp), %xmm0
180004754:     	decq	0x8(%r15)
180004758:     	testq	%rdi, %rdi
18000475b:     	js	0x180004a07 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2477>
180004761:     	movq	(%rbp,%rdi,8), %rax
180004766:     	testq	%rax, %rax
180004769:     	js	0x18000477a <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x21ea>
18000476b:     	movsd	0x8(%r13,%rdi,8), %xmm2
180004772:     	ucomisd	%xmm7, %xmm2
180004776:     	jne	0x180004797 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2207>
180004778:     	jp	0x180004797 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2207>
18000477a:     	movb	$0x1, (%r12)
18000477f:     	movq	$0x4c4b43, 0x18(%r15)   # imm = 0x4C4B43
180004787:     	incq	%rbx
18000478a:     	cmpb	$0x0, (%r12)
18000478f:     	je	0x1800046e1 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2151>
180004795:     	jmp	0x180004804 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2274>
180004797:     	divsd	%xmm2, %xmm1
18000479b:     	addsd	(%r13,%rax,8), %xmm1
1800047a2:     	movsd	%xmm1, (%r13,%rax,8)
1800047a9:     	movq	$0x0, 0x8(%rbp,%rax,8)
1800047b2:     	movq	(%rbp,%rdi,8), %rax
1800047b7:     	testq	%rax, %rax
1800047ba:     	js	0x1800047cb <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x223b>
1800047bc:     	movsd	0x8(%r13,%rdi,8), %xmm1
1800047c3:     	ucomisd	%xmm7, %xmm1
1800047c7:     	jne	0x1800047da <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x224a>
1800047c9:     	jp	0x1800047da <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x224a>
1800047cb:     	movb	$0x1, (%r12)
1800047d0:     	movq	$0x4c4b44, 0x18(%r15)   # imm = 0x4C4B44
1800047d8:     	jmp	0x180004787 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x21f7>
1800047da:     	divsd	%xmm1, %xmm0
1800047de:     	addsd	0x10(%r13,%rax,8), %xmm0
1800047e5:     	movsd	%xmm0, 0x10(%r13,%rax,8)
1800047ec:     	movq	$0x0, 0x18(%rbp,%rax,8)
1800047f5:     	jmp	0x180004787 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x21f7>
1800047f7:     	movb	$0x1, (%r12)
1800047fc:     	movq	$0x9, 0x18(%r15)
180004804:     	movq	0x48(%rsp), %rax
180004809:     	movq	$0x0, (%rax)
180004810:     	jmp	0x18000440e <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1e7e>
180004815:     	movsd	0x128(%rsp), %xmm0
18000481e:     	xorl	%eax, %eax
180004820:     	cmpq	(%rbp,%r14), %rax
180004825:     	jge	0x180004804 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2274>
180004827:     	movq	0x10(%rbp,%r14), %rcx
18000482c:     	leaq	(%rbp,%rcx,8), %rcx
180004831:     	movq	(%rcx,%rax,8), %rcx
180004835:     	testq	%rcx, %rcx
180004838:     	js	0x1800049e3 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2453>
18000483e:     	movq	0x18(%rbp,%rcx,8), %rdx
180004843:     	testq	%rdx, %rdx
180004846:     	js	0x180004971 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x23e1>
18000484c:     	movq	(%rbp,%rcx,8), %r8
180004851:     	testq	%r8, %r8
180004854:     	js	0x180004971 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x23e1>
18000485a:     	movsd	(%r13,%r8,8), %xmm1
180004861:     	mulsd	%xmm0, %xmm1
180004865:     	addsd	(%r13,%rdx,8), %xmm1
18000486c:     	movsd	%xmm1, (%r13,%rdx,8)
180004873:     	movq	$0x0, 0x8(%rbp,%rdx,8)
18000487c:     	movq	0x18(%rbp,%rcx,8), %rdx
180004881:     	testq	%rdx, %rdx
180004884:     	js	0x18000497d <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x23ed>
18000488a:     	movq	(%rbp,%rcx,8), %r8
18000488f:     	testq	%r8, %r8
180004892:     	js	0x18000497d <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x23ed>
180004898:     	movsd	0x10(%r13,%r8,8), %xmm1
18000489f:     	mulsd	%xmm0, %xmm1
1800048a3:     	addsd	0x10(%r13,%rdx,8), %xmm1
1800048aa:     	movsd	%xmm1, 0x10(%r13,%rdx,8)
1800048b1:     	movq	$0x0, 0x18(%rbp,%rdx,8)
1800048ba:     	movq	0x10(%rbp,%rcx,8), %rdx
1800048bf:     	testq	%rdx, %rdx
1800048c2:     	js	0x180004989 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x23f9>
1800048c8:     	movq	0x18(%rbp,%rcx,8), %r8
1800048cd:     	testq	%r8, %r8
1800048d0:     	js	0x180004989 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x23f9>
1800048d6:     	movsd	(%r13,%r8,8), %xmm1
1800048dd:     	mulsd	%xmm0, %xmm1
1800048e1:     	addsd	(%r13,%rdx,8), %xmm1
1800048e8:     	movsd	%xmm1, (%r13,%rdx,8)
1800048ef:     	movq	$0x0, 0x8(%rbp,%rdx,8)
1800048f8:     	movq	0x10(%rbp,%rcx,8), %rdx
1800048fd:     	testq	%rdx, %rdx
180004900:     	js	0x180004995 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2405>
180004906:     	movq	0x18(%rbp,%rcx,8), %r8
18000490b:     	testq	%r8, %r8
18000490e:     	js	0x180004995 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2405>
180004914:     	movsd	0x10(%r13,%r8,8), %xmm1
18000491b:     	mulsd	%xmm0, %xmm1
18000491f:     	addsd	0x10(%r13,%rdx,8), %xmm1
180004926:     	movsd	%xmm1, 0x10(%r13,%rdx,8)
18000492d:     	movq	$0x0, 0x18(%rbp,%rdx,8)
180004936:     	movq	(%rbp,%rcx,8), %rdx
18000493b:     	testq	%rdx, %rdx
18000493e:     	js	0x1800049b9 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2429>
180004940:     	movq	$0x0, (%r13,%rdx,8)
180004949:     	movq	$0x1, 0x8(%rbp,%rdx,8)
180004952:     	movq	(%rbp,%rcx,8), %rcx
180004957:     	testq	%rcx, %rcx
18000495a:     	js	0x1800049c5 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2435>
18000495c:     	movq	$0x0, 0x10(%r13,%rcx,8)
180004965:     	leaq	(%rbp,%rcx,8), %rdx
18000496a:     	movl	$0x1, %ecx
18000496f:     	jmp	0x1800049a2 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2412>
180004971:     	movb	$0x1, (%r12)
180004976:     	movl	$0x5b8d83, %ecx         # imm = 0x5B8D83
18000497b:     	jmp	0x18000499f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x240f>
18000497d:     	movb	$0x1, (%r12)
180004982:     	movl	$0x5b8d84, %ecx         # imm = 0x5B8D84
180004987:     	jmp	0x18000499f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x240f>
180004989:     	movb	$0x1, (%r12)
18000498e:     	movl	$0x5b8d87, %ecx         # imm = 0x5B8D87
180004993:     	jmp	0x18000499f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x240f>
180004995:     	movb	$0x1, (%r12)
18000499a:     	movl	$0x5b8d88, %ecx         # imm = 0x5B8D88
18000499f:     	movq	%r15, %rdx
1800049a2:     	movq	%rcx, 0x18(%rdx)
1800049a6:     	incq	%rax
1800049a9:     	cmpb	$0x0, (%r12)
1800049ae:     	je	0x180004820 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2290>
1800049b4:     	jmp	0x180004804 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2274>
1800049b9:     	movb	$0x1, (%r12)
1800049be:     	movl	$0x5b8d8b, %ecx         # imm = 0x5B8D8B
1800049c3:     	jmp	0x18000499f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x240f>
1800049c5:     	movb	$0x1, (%r12)
1800049ca:     	movl	$0x5b8d8c, %ecx         # imm = 0x5B8D8C
1800049cf:     	jmp	0x18000499f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x240f>
1800049d1:     	movq	0x60(%rsp), %rdx
1800049d6:     	movq	0x50(%rsp), %rcx
1800049db:     	movq	%rdx, (%rcx)
1800049de:     	jmp	0x180004410 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1e80>
1800049e3:     	movb	$0x1, (%r12)
1800049e8:     	movq	$0x12, 0x18(%r15)
1800049f0:     	jmp	0x180004804 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2274>
1800049f5:     	movb	$0x1, (%r12)
1800049fa:     	movq	$0xd, 0x18(%r15)
180004a02:     	jmp	0x180004804 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2274>
180004a07:     	movb	$0x1, (%r12)
180004a0c:     	movq	$0xe, 0x18(%r15)
180004a14:     	jmp	0x180004804 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2274>
180004a19:     	movq	0x50(%rsp), %rcx
180004a1e:     	movq	$0x0, (%rcx)
180004a25:     	jmp	0x180004410 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x1e80>
180004a2a:     	nopw	(%rax,%rax)
180004a30:     	pushq	%r15
180004a32:     	pushq	%r14
180004a34:     	pushq	%r13
180004a36:     	pushq	%r12
180004a38:     	pushq	%rsi
180004a39:     	pushq	%rdi
180004a3a:     	pushq	%rbp
180004a3b:     	pushq	%rbx
180004a3c:     	subq	$0xf8, %rsp
180004a43:     	movapd	%xmm8, 0xe0(%rsp)
180004a4d:     	movapd	%xmm7, 0xd0(%rsp)
180004a56:     	movapd	%xmm6, 0xc0(%rsp)
180004a5f:     	movq	$0x0, 0x40(%rsp)
180004a68:     	movb	$0x0, 0x48(%rsp)
180004a6d:     	movq	$0x0, 0x50(%rsp)
180004a76:     	movq	(%r8), %rax
180004a79:     	movsd	0x48(%rax,%r9,8), %xmm0
180004a80:     	xorpd	%xmm1, %xmm1
180004a84:     	ucomisd	%xmm1, %xmm0
180004a88:     	jne	0x180004aa1 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2511>
180004a8a:     	jp	0x180004aa1 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2511>
180004a8c:     	movb	$0x1, 0x18(%rcx)
180004a90:     	movq	$0x0, 0x10(%rcx)
180004a98:     	movb	$0x1, 0x8(%rcx)
180004a9c:     	jmp	0x180004bf2 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2662>
180004aa1:     	movq	0x160(%rsp), %r14
180004aa9:     	movq	0x8(%r8), %r15
180004aad:     	movq	0x10(%r8), %rdi
180004ab1:     	movq	0x18(%r8), %rbx
180004ab5:     	movq	0x30(%r15,%r9,8), %rdx
180004aba:     	cmpq	$0x1, (%r15,%rdx,8)
180004abf:     	jne	0x180004acc <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x253c>
180004ac1:     	movq	0x10(%r15,%rdx,8), %rdx
180004ac6:     	cmpq	%r14, (%r15,%rdx,8)
180004aca:     	je	0x180004a8c <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x24fc>
180004acc:     	movq	0x10(%r15,%r9,8), %r10
180004ad1:     	testq	%r10, %r10
180004ad4:     	js	0x180004bcf <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x263f>
180004ada:     	testq	%r14, %r14
180004add:     	js	0x180004bcf <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x263f>
180004ae3:     	movq	0x10(%r15,%r14,8), %r11
180004ae8:     	testq	%r11, %r11
180004aeb:     	js	0x180004bcf <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x263f>
180004af1:     	movsd	(%rax,%r10,8), %xmm1
180004af7:     	cmpq	$0x0, 0x8(%r15,%r10,8)
180004afd:     	setne	%sil
180004b01:     	cmpq	$0x0, 0x8(%r15,%r11,8)
180004b07:     	setne	%dl
180004b0a:     	subsd	(%rax,%r11,8), %xmm1
180004b10:     	andb	%sil, %dl
180004b13:     	cmpb	$0x1, %dl
180004b16:     	jne	0x180004b3a <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x25aa>
180004b18:     	movapd	0x58a0(%rip), %xmm2     # 0x18000a3c0
180004b20:     	andpd	%xmm1, %xmm2
180004b24:     	ucomisd	0x58a4(%rip), %xmm2     # 0x18000a3d0
180004b2c:     	jae	0x180004bcf <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x263f>
180004b32:     	xorpd	%xmm2, %xmm2
180004b36:     	addsd	%xmm2, %xmm1
180004b3a:     	movsd	0x10(%rax,%r10,8), %xmm2
180004b41:     	cmpq	$0x0, 0x18(%r15,%r10,8)
180004b47:     	subsd	0x10(%rax,%r11,8), %xmm2
180004b4e:     	je	0x180004c28 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2698>
180004b54:     	cmpq	$0x0, 0x18(%r15,%r11,8)
180004b5a:     	je	0x180004c28 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2698>
180004b60:     	movapd	0x5858(%rip), %xmm3     # 0x18000a3c0
180004b68:     	andpd	%xmm2, %xmm3
180004b6c:     	ucomisd	0x585c(%rip), %xmm3     # 0x18000a3d0
180004b74:     	jae	0x180004c91 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2701>
180004b7a:     	movapd	%xmm1, %xmm3
180004b7e:     	mulsd	%xmm1, %xmm3
180004b82:     	ucomisd	0x5846(%rip), %xmm3     # 0x18000a3d0
180004b8a:     	setae	%r10b
180004b8e:     	testb	%r10b, %dl
180004b91:     	jne	0x180004c44 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x26b4>
180004b97:     	xorpd	%xmm4, %xmm4
180004b9b:     	addsd	%xmm4, %xmm2
180004b9f:     	movapd	%xmm2, %xmm4
180004ba3:     	mulsd	%xmm2, %xmm4
180004ba7:     	ucomisd	0x5821(%rip), %xmm4     # 0x18000a3d0
180004baf:     	jae	0x180004c44 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x26b4>
180004bb5:     	addsd	%xmm4, %xmm3
180004bb9:     	ucomisd	0x580f(%rip), %xmm3     # 0x18000a3d0
180004bc1:     	setae	%r10b
180004bc5:     	testb	%r10b, %dl
180004bc8:     	jne	0x180004c44 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x26b4>
180004bca:     	jmp	0x180004c5d <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x26cd>
180004bcf:     	movb	$0x1, (%rbx)
180004bd2:     	movq	$0x3d090a, 0x18(%rdi)   # imm = 0x3D090A
180004bda:     	movq	$0x0, 0x18(%rcx)
180004be2:     	movq	$0x0, 0x10(%rcx)
180004bea:     	movq	$0x0, 0x8(%rcx)
180004bf2:     	movq	$0x0, (%rcx)
180004bf9:     	xorl	%eax, %eax
180004bfb:     	movaps	0xc0(%rsp), %xmm6
180004c03:     	movaps	0xd0(%rsp), %xmm7
180004c0b:     	movaps	0xe0(%rsp), %xmm8
180004c14:     	addq	$0xf8, %rsp
180004c1b:     	popq	%rbx
180004c1c:     	popq	%rbp
180004c1d:     	popq	%rdi
180004c1e:     	popq	%rsi
180004c1f:     	popq	%r12
180004c21:     	popq	%r13
180004c23:     	popq	%r14
180004c25:     	popq	%r15
180004c27:     	retq
180004c28:     	movapd	%xmm1, %xmm3
180004c2c:     	mulsd	%xmm1, %xmm3
180004c30:     	ucomisd	0x5798(%rip), %xmm3     # 0x18000a3d0
180004c38:     	setae	%r10b
180004c3c:     	andb	%r10b, %dl
180004c3f:     	cmpb	$0x1, %dl
180004c42:     	jne	0x180004c51 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x26c1>
180004c44:     	movb	$0x1, (%rbx)
180004c47:     	movq	$0x3d090c, 0x18(%rdi)   # imm = 0x3D090C
180004c4f:     	jmp	0x180004bda <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x264a>
180004c51:     	movapd	%xmm2, %xmm4
180004c55:     	mulsd	%xmm2, %xmm4
180004c59:     	addsd	%xmm4, %xmm3
180004c5d:     	xorps	%xmm4, %xmm4
180004c60:     	sqrtsd	%xmm3, %xmm4
180004c64:     	cmpq	$0x0, 0x18(%r15,%r9,8)
180004c6a:     	je	0x180004cbe <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x272e>
180004c6c:     	movq	(%r15,%r9,8), %rdx
180004c70:     	testq	%rdx, %rdx
180004c73:     	js	0x180004c81 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x26f1>
180004c75:     	xorpd	%xmm5, %xmm5
180004c79:     	ucomisd	%xmm5, %xmm3
180004c7d:     	jne	0x180004ca1 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2711>
180004c7f:     	jp	0x180004ca1 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2711>
180004c81:     	movb	$0x1, (%rbx)
180004c84:     	movq	$0x3d090f, 0x18(%rdi)   # imm = 0x3D090F
180004c8c:     	jmp	0x180004bda <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x264a>
180004c91:     	movb	$0x1, (%rbx)
180004c94:     	movq	$0x3d090b, 0x18(%rdi)   # imm = 0x3D090B
180004c9c:     	jmp	0x180004bda <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x264a>
180004ca1:     	movsd	0x168(%rsp), %xmm7
180004caa:     	movsd	0x8(%rax,%rdx,8), %xmm3
180004cb0:     	addsd	%xmm3, %xmm3
180004cb4:     	divsd	%xmm4, %xmm3
180004cb8:     	ucomisd	%xmm3, %xmm7
180004cbc:     	jbe	0x180004d2b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x279b>
180004cbe:     	movsd	0x5712(%rip), %xmm3     # 0x18000a3d8
180004cc6:     	maxsd	%xmm4, %xmm3
180004cca:     	movapd	%xmm3, %xmm4
180004cce:     	mulsd	%xmm3, %xmm4
180004cd2:     	xorpd	%xmm5, %xmm5
180004cd6:     	ucomisd	%xmm5, %xmm4
180004cda:     	jne	0x180004cee <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x275e>
180004cdc:     	jp	0x180004cee <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x275e>
180004cde:     	movb	$0x1, (%rbx)
180004ce1:     	movq	$0x3d0915, 0x18(%rdi)   # imm = 0x3D0915
180004ce9:     	jmp	0x180004bda <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x264a>
180004cee:     	movsd	0x8(%rax,%r14,8), %xmm5
180004cf5:     	mulsd	0x56e3(%rip), %xmm5     # 0x18000a3e0
180004cfd:     	mulsd	%xmm5, %xmm0
180004d01:     	divsd	%xmm4, %xmm0
180004d05:     	mulsd	%xmm0, %xmm1
180004d09:     	divsd	%xmm3, %xmm1
180004d0d:     	mulsd	%xmm0, %xmm2
180004d11:     	divsd	%xmm3, %xmm2
180004d15:     	movsd	%xmm2, 0x10(%rcx)
180004d1a:     	movsd	%xmm1, (%rcx)
180004d1e:     	movb	$0x0, 0x18(%rcx)
180004d22:     	movb	$0x0, 0x8(%rcx)
180004d26:     	jmp	0x180004bf9 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2669>
180004d2b:     	movq	0x20(%r15,%r9,8), %rax
180004d30:     	testq	%rax, %rax
180004d33:     	js	0x180004dc0 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2830>
180004d39:     	movq	0x8(%rdi), %rdx
180004d3d:     	leaq	0x1(%rdx), %r10
180004d41:     	movq	%r10, 0x8(%rdi)
180004d45:     	cmpq	0x10(%rdi), %rdx
180004d49:     	jge	0x180004eee <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x295e>
180004d4f:     	movq	%r9, %rsi
180004d52:     	movq	%rcx, %r13
180004d55:     	movsd	%xmm7, 0x28(%rsp)
180004d5b:     	movq	%r14, 0x20(%rsp)
180004d60:     	leaq	0xa0(%rsp), %rcx
180004d68:     	movq	%r8, %rbp
180004d6b:     	movq	%rax, %r9
180004d6e:     	callq	0x180004a30 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x24a0>
180004d73:     	cmpb	$0x0, (%rbx)
180004d76:     	jne	0x180004fb2 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2a22>
180004d7c:     	cmpb	$0x0, 0xb8(%rsp)
180004d84:     	setne	%r12b
180004d88:     	cmpb	$0x0, 0xa8(%rsp)
180004d90:     	setne	%r11b
180004d94:     	xorpd	%xmm8, %xmm8
180004d99:     	movsd	0xa0(%rsp), %xmm6
180004da2:     	addsd	%xmm8, %xmm6
180004da7:     	addsd	0xb0(%rsp), %xmm8
180004db1:     	decq	0x8(%rdi)
180004db5:     	movq	%r13, %rcx
180004db8:     	movq	%rbp, %r8
180004dbb:     	movq	%rsi, %r9
180004dbe:     	jmp	0x180004dcf <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x283f>
180004dc0:     	movb	$0x1, %r11b
180004dc3:     	xorpd	%xmm6, %xmm6
180004dc7:     	xorpd	%xmm8, %xmm8
180004dcc:     	movb	$0x1, %r12b
180004dcf:     	movq	0x28(%r15,%r9,8), %rax
180004dd4:     	testq	%rax, %rax
180004dd7:     	js	0x180004e6c <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x28dc>
180004ddd:     	movq	0x8(%rdi), %rdx
180004de1:     	leaq	0x1(%rdx), %r10
180004de5:     	movq	%r10, 0x8(%rdi)
180004de9:     	cmpq	0x10(%rdi), %rdx
180004ded:     	jge	0x180004efe <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x296e>
180004df3:     	movl	%r12d, %esi
180004df6:     	movl	%r11d, %r12d
180004df9:     	movq	%r9, 0x38(%rsp)
180004dfe:     	movq	%rcx, %r13
180004e01:     	movsd	%xmm7, 0x28(%rsp)
180004e07:     	movq	%r14, 0x20(%rsp)
180004e0c:     	leaq	0x80(%rsp), %rcx
180004e14:     	movq	%r8, %rbp
180004e17:     	movq	%rax, %r9
180004e1a:     	callq	0x180004a30 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x24a0>
180004e1f:     	cmpb	$0x0, (%rbx)
180004e22:     	jne	0x180004fb2 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2a22>
180004e28:     	cmpb	$0x0, 0x98(%rsp)
180004e30:     	setne	%al
180004e33:     	cmpb	$0x0, 0x88(%rsp)
180004e3b:     	setne	%cl
180004e3e:     	addsd	0x80(%rsp), %xmm6
180004e47:     	addsd	0x90(%rsp), %xmm8
180004e51:     	decq	0x8(%rdi)
180004e55:     	movl	%r12d, %r11d
180004e58:     	andb	%cl, %r11b
180004e5b:     	movl	%esi, %r12d
180004e5e:     	andb	%al, %r12b
180004e61:     	movq	%r13, %rcx
180004e64:     	movq	%rbp, %r8
180004e67:     	movq	0x38(%rsp), %r9
180004e6c:     	movq	0x38(%r15,%r9,8), %rax
180004e71:     	testq	%rax, %rax
180004e74:     	js	0x180004f0e <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x297e>
180004e7a:     	movq	%r9, %rsi
180004e7d:     	movq	0x8(%rdi), %rdx
180004e81:     	leaq	0x1(%rdx), %r9
180004e85:     	movq	%r9, 0x8(%rdi)
180004e89:     	cmpq	0x10(%rdi), %rdx
180004e8d:     	jge	0x180004f97 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2a07>
180004e93:     	movl	%r11d, %ebp
180004e96:     	movq	%rcx, %r13
180004e99:     	movsd	%xmm7, 0x28(%rsp)
180004e9f:     	movq	%r14, 0x20(%rsp)
180004ea4:     	leaq	0x60(%rsp), %rcx
180004ea9:     	movq	%r8, 0x38(%rsp)
180004eae:     	movq	%rax, %r9
180004eb1:     	callq	0x180004a30 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x24a0>
180004eb6:     	cmpb	$0x0, (%rbx)
180004eb9:     	jne	0x180004fb2 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2a22>
180004ebf:     	cmpb	$0x0, 0x78(%rsp)
180004ec4:     	setne	%al
180004ec7:     	cmpb	$0x0, 0x68(%rsp)
180004ecc:     	setne	%cl
180004ecf:     	addsd	0x60(%rsp), %xmm6
180004ed5:     	addsd	0x70(%rsp), %xmm8
180004edc:     	decq	0x8(%rdi)
180004ee0:     	movl	%ebp, %r11d
180004ee3:     	andb	%cl, %r11b
180004ee6:     	andb	%al, %r12b
180004ee9:     	movq	%rsi, %r9
180004eec:     	jmp	0x180004f16 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2986>
180004eee:     	movb	$0x1, (%rbx)
180004ef1:     	movq	$0x3d0921, 0x18(%rdi)   # imm = 0x3D0921
180004ef9:     	jmp	0x180004bda <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x264a>
180004efe:     	movb	$0x1, (%rbx)
180004f01:     	movq	$0x3d0926, 0x18(%rdi)   # imm = 0x3D0926
180004f09:     	jmp	0x180004bda <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x264a>
180004f0e:     	movq	%r8, 0x38(%rsp)
180004f13:     	movq	%rcx, %r13
180004f16:     	movq	0x40(%r15,%r9,8), %r9
180004f1b:     	testq	%r9, %r9
180004f1e:     	js	0x180004f7e <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x29ee>
180004f20:     	movq	0x8(%rdi), %rax
180004f24:     	leaq	0x1(%rax), %rcx
180004f28:     	movq	%rcx, 0x8(%rdi)
180004f2c:     	cmpq	0x10(%rdi), %rax
180004f30:     	jge	0x180004fa7 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2a17>
180004f32:     	movl	%r11d, %esi
180004f35:     	movsd	%xmm7, 0x28(%rsp)
180004f3b:     	movq	%r14, 0x20(%rsp)
180004f40:     	leaq	0x40(%rsp), %rcx
180004f45:     	movq	0x38(%rsp), %r8
180004f4a:     	callq	0x180004a30 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x24a0>
180004f4f:     	cmpb	$0x0, (%rbx)
180004f52:     	jne	0x180004fb2 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2a22>
180004f54:     	cmpb	$0x0, 0x58(%rsp)
180004f59:     	setne	%al
180004f5c:     	cmpb	$0x0, 0x48(%rsp)
180004f61:     	setne	%cl
180004f64:     	addsd	0x40(%rsp), %xmm6
180004f6a:     	addsd	0x50(%rsp), %xmm8
180004f71:     	decq	0x8(%rdi)
180004f75:     	movl	%esi, %r11d
180004f78:     	andb	%cl, %r11b
180004f7b:     	andb	%al, %r12b
180004f7e:     	movb	%r12b, 0x18(%r13)
180004f82:     	movsd	%xmm8, 0x10(%r13)
180004f88:     	movb	%r11b, 0x8(%r13)
180004f8c:     	movsd	%xmm6, (%r13)
180004f92:     	jmp	0x180004bf9 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2669>
180004f97:     	movb	$0x1, (%rbx)
180004f9a:     	movq	$0x3d092b, 0x18(%rdi)   # imm = 0x3D092B
180004fa2:     	jmp	0x180004bda <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x264a>
180004fa7:     	movb	$0x1, (%rbx)
180004faa:     	movq	$0x3d0930, 0x18(%rdi)   # imm = 0x3D0930
180004fb2:     	movq	$0x0, 0x18(%r13)
180004fba:     	movq	$0x0, 0x10(%r13)
180004fc2:     	movq	$0x0, 0x8(%r13)
180004fca:     	movq	$0x0, (%r13)
180004fd2:     	jmp	0x180004bf9 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2669>
180004fd7:     	nopw	(%rax,%rax)
180004fe0:     	pushq	%r15
180004fe2:     	pushq	%r14
180004fe4:     	pushq	%r13
180004fe6:     	pushq	%r12
180004fe8:     	pushq	%rsi
180004fe9:     	pushq	%rdi
180004fea:     	pushq	%rbp
180004feb:     	pushq	%rbx
180004fec:     	subq	$0x128, %rsp            # imm = 0x128
180004ff3:     	movb	$0x0, 0x47(%rsp)
180004ff8:     	movq	$0x0, 0xc0(%rsp)
180005004:     	movb	$0x0, 0x42(%rsp)
180005009:     	movq	$0x0, 0xb8(%rsp)
180005015:     	movb	$0x0, 0x41(%rsp)
18000501a:     	movq	$0x0, 0xb0(%rsp)
180005026:     	movb	$0x0, 0x40(%rsp)
18000502b:     	movq	$0x0, 0xa8(%rsp)
180005037:     	movb	$0x0, 0x3f(%rsp)
18000503c:     	movq	$0x0, 0xa0(%rsp)
180005048:     	movb	$0x0, 0x46(%rsp)
18000504d:     	movq	$0x0, 0x98(%rsp)
180005059:     	movb	$0x0, 0x45(%rsp)
18000505e:     	movq	$0x0, 0x90(%rsp)
18000506a:     	movb	$0x0, 0x44(%rsp)
18000506f:     	movq	$0x0, 0x88(%rsp)
18000507b:     	movb	$0x0, 0x43(%rsp)
180005080:     	movq	$0x0, 0x80(%rsp)
18000508c:     	movq	(%r8), %rax
18000508f:     	movq	0x8(%r8), %r15
180005093:     	movq	0x10(%r8), %r14
180005097:     	movq	0x18(%r8), %rbx
18000509b:     	movq	0x20(%r8), %r12
18000509f:     	cmpq	$0x1, %r9
1800050a3:     	je	0x18000514b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2bbb>
1800050a9:     	testq	%r9, %r9
1800050ac:     	jne	0x180005535 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2fa5>
1800050b2:     	movq	0x190(%rsp), %rdi
1800050ba:     	movq	(%r15,%rdi,8), %r9
1800050be:     	testq	%r9, %r9
1800050c1:     	js	0x180005175 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2be5>
1800050c7:     	movq	0x198(%rsp), %r13
1800050cf:     	testq	%r13, %r13
1800050d2:     	js	0x180005175 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2be5>
1800050d8:     	movq	0x10(%r15,%r13,8), %r11
1800050dd:     	testq	%r11, %r11
1800050e0:     	js	0x180005201 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2c71>
1800050e6:     	movsd	(%rax,%r11,8), %xmm0
1800050ec:     	movsd	0x8(%rax,%r9,8), %xmm2
1800050f3:     	movsd	0x10(%rax,%r9,8), %xmm1
1800050fa:     	movapd	%xmm1, %xmm3
1800050fe:     	subsd	%xmm2, %xmm3
180005102:     	xorl	%r10d, %r10d
180005105:     	ucomisd	%xmm3, %xmm0
180005109:     	jb	0x180005220 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2c90>
18000510f:     	addsd	%xmm2, %xmm1
180005113:     	ucomisd	%xmm0, %xmm1
180005117:     	jbe	0x180005220 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2c90>
18000511d:     	movsd	0x10(%rax,%r11,8), %xmm0
180005124:     	movsd	(%rax,%r9,8), %xmm1
18000512a:     	movsd	0x18(%rax,%r9,8), %xmm2
180005131:     	movapd	%xmm2, %xmm3
180005135:     	subsd	%xmm1, %xmm3
180005139:     	ucomisd	%xmm3, %xmm0
18000513d:     	jae	0x180005214 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2c84>
180005143:     	xorl	%r10d, %r10d
180005146:     	jmp	0x180005220 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2c90>
18000514b:     	movq	0x1a0(%rsp), %r13
180005153:     	testq	%r13, %r13
180005156:     	js	0x180005185 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2bf5>
180005158:     	movq	(%r15,%r13,8), %r9
18000515c:     	testq	%r9, %r9
18000515f:     	js	0x180005185 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2bf5>
180005161:     	movq	(%r14), %r10
180005164:     	leaq	0x4(%r10), %r11
180005168:     	cmpq	%r12, %r11
18000516b:     	jle	0x180005195 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2c05>
18000516d:     	movb	$0x2, (%rbx)
180005170:     	jmp	0x180005535 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2fa5>
180005175:     	movb	$0x1, (%rbx)
180005178:     	movq	$0x2dc6c2, 0x18(%r14)   # imm = 0x2DC6C2
180005180:     	jmp	0x180005535 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2fa5>
180005185:     	movb	$0x1, (%rbx)
180005188:     	movq	$0x989682, 0x18(%r14)   # imm = 0x989682
180005190:     	jmp	0x180005535 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2fa5>
180005195:     	movsd	0x10(%rax,%r9,8), %xmm2
18000519c:     	movsd	0x18(%rax,%r9,8), %xmm1
1800051a3:     	movsd	0x5205(%rip), %xmm0     # 0x18000a3b0
1800051ab:     	movsd	0x8(%rax,%r9,8), %xmm3
1800051b2:     	mulsd	%xmm0, %xmm3
1800051b6:     	mulsd	(%rax,%r9,8), %xmm0
1800051bc:     	movq	%r11, (%r14)
1800051bf:     	cmpb	$0x0, (%rbx)
1800051c2:     	jne	0x180005535 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2fa5>
1800051c8:     	movapd	%xmm2, %xmm4
1800051cc:     	addsd	%xmm3, %xmm4
1800051d0:     	movapd	%xmm1, %xmm5
1800051d4:     	subsd	%xmm0, %xmm5
1800051d8:     	testq	%r10, %r10
1800051db:     	js	0x180005324 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2d94>
1800051e1:     	movsd	%xmm4, 0x10(%rax,%r10,8)
1800051e8:     	movsd	%xmm5, 0x18(%rax,%r10,8)
1800051ef:     	movsd	%xmm3, 0x8(%rax,%r10,8)
1800051f6:     	movsd	%xmm0, (%rax,%r10,8)
1800051fc:     	jmp	0x18000532f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2d9f>
180005201:     	movb	$0x1, (%rbx)
180005204:     	movq	$0x7a1202, 0x18(%r14)   # imm = 0x7A1202
18000520c:     	cmpb	$0x0, (%rbx)
18000520f:     	jmp	0x180005535 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2fa5>
180005214:     	addsd	%xmm1, %xmm2
180005218:     	ucomisd	%xmm0, %xmm2
18000521c:     	seta	%r10b
180005220:     	cmpb	$0x0, (%rbx)
180005223:     	jne	0x180005535 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2fa5>
180005229:     	testb	%r10b, %r10b
18000522c:     	je	0x180005535 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2fa5>
180005232:     	movq	0x18(%r15,%rdi,8), %r10
180005237:     	movq	0x30(%r15,%rdi,8), %r9
18000523c:     	movq	(%r15,%r9,8), %r11
180005240:     	cmpq	0x8(%r15,%rdi,8), %r11
180005245:     	jge	0x180005439 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2ea9>
18000524b:     	testq	%r10, %r10
18000524e:     	jne	0x18000543e <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2eae>
180005254:     	leaq	(%r15,%r9,8), %r11
180005258:     	movq	%r9, %r8
18000525b:     	sarq	$0x3f, %r8
18000525f:     	andq	%r12, %r8
180005262:     	movq	(%r11,%r8,8), %rbp
180005266:     	xorl	%r10d, %r10d
180005269:     	cmpq	$-0x1, %r9
18000526d:     	cmovlq	%r12, %r10
180005271:     	cmpq	0x8(%r11,%r10,8), %rbp
180005276:     	jne	0x1800058dc <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x334c>
18000527c:     	movq	%r11, 0xf0(%rsp)
180005284:     	leaq	(%rbp,%rbp), %rdx
180005289:     	testq	%rbp, %rbp
18000528c:     	movl	$0x4, %esi
180005291:     	cmovneq	%rdx, %rsi
180005295:     	movq	(%r14), %r11
180005298:     	movq	%r11, 0x58(%rsp)
18000529d:     	leaq	(%r11,%rsi), %rdx
1800052a1:     	cmpq	%r12, %rdx
1800052a4:     	jg	0x18000516d <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2bdd>
1800052aa:     	movq	%rdx, (%r14)
1800052ad:     	cmpb	$0x0, (%rbx)
1800052b0:     	jne	0x180005535 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2fa5>
1800052b6:     	movq	%rsi, 0xd8(%rsp)
1800052be:     	movq	%r10, 0xe0(%rsp)
1800052c6:     	movq	%r8, 0xe8(%rsp)
1800052ce:     	xorl	%edx, %edx
1800052d0:     	cmpq	$-0x2, %r9
1800052d4:     	cmovlq	%r12, %rdx
1800052d8:     	movq	%rdx, 0x68(%rsp)
1800052dd:     	movq	%rbp, 0x70(%rsp)
1800052e2:     	testq	%rbp, %rbp
1800052e5:     	jle	0x1800058a3 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3313>
1800052eb:     	leaq	(%r15,%r9,8), %rdx
1800052ef:     	movq	0x68(%rsp), %r8
1800052f4:     	movq	0x10(%rdx,%r8,8), %rsi
1800052f9:     	movq	0x70(%rsp), %rdx
1800052fe:     	movl	%edx, %r11d
180005301:     	andl	$0x7, %r11d
180005305:     	cmpq	$0x7, %rdx
180005309:     	ja	0x1800055e5 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3055>
18000530f:     	leaq	(,%r12,8), %rdx
180005317:     	movq	%rdx, 0x78(%rsp)
18000531c:     	xorl	%r10d, %r10d
18000531f:     	jmp	0x180005866 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x32d6>
180005324:     	movb	$0x1, (%rbx)
180005327:     	movq	$0xf4242, 0x18(%r14)    # imm = 0xF4242
18000532f:     	cmpb	$0x0, (%rbx)
180005332:     	jne	0x180005535 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2fa5>
180005338:     	movq	(%r14), %r9
18000533b:     	leaq	0xb(%r9), %rsi
18000533f:     	cmpq	%r12, %rsi
180005342:     	jg	0x18000516d <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2bdd>
180005348:     	movq	0x8(%r15,%r13,8), %r11
18000534d:     	movq	%rsi, (%r14)
180005350:     	cmpb	$0x0, (%rbx)
180005353:     	jne	0x180005535 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2fa5>
180005359:     	movq	%r10, (%r15,%r9,8)
18000535d:     	movq	%r11, 0x8(%r15,%r9,8)
180005362:     	movq	(%r14), %r11
180005365:     	cmpq	%r12, %r11
180005368:     	movq	%r11, %r10
18000536b:     	jle	0x180005376 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2de6>
18000536d:     	movb	$0x2, (%rbx)
180005370:     	movq	(%r14), %r11
180005373:     	xorl	%r10d, %r10d
180005376:     	leaq	0x3(%r11), %rsi
18000537a:     	cmpq	%r12, %rsi
18000537d:     	jg	0x18000516d <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2bdd>
180005383:     	movq	%rsi, (%r14)
180005386:     	cmpb	$0x0, (%rbx)
180005389:     	jne	0x180005535 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2fa5>
18000538f:     	movq	%r11, %rsi
180005392:     	sarq	$0x3f, %rsi
180005396:     	andq	%r12, %rsi
180005399:     	leaq	(%r15,%r11,8), %rdi
18000539d:     	movq	$0x0, (%rdi,%rsi,8)
1800053a5:     	xorl	%esi, %esi
1800053a7:     	cmpq	$-0x1, %r11
1800053ab:     	movl	$0x0, %ebp
1800053b0:     	cmovlq	%r12, %rbp
1800053b4:     	movq	$0x0, 0x8(%rdi,%rbp,8)
1800053bd:     	cmpq	$-0x2, %r11
1800053c1:     	cmovlq	%r12, %rsi
1800053c5:     	movq	%r10, 0x10(%rdi,%rsi,8)
1800053ca:     	cmpb	$0x0, (%rbx)
1800053cd:     	jne	0x180005535 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2fa5>
1800053d3:     	leaq	(%r15,%r9,8), %r10
1800053d7:     	movq	%r11, 0x30(%r10)
1800053db:     	movq	$0x0, 0x18(%r10)
1800053e3:     	movq	(%r14), %r11
1800053e6:     	leaq	0x4(%r11), %rsi
1800053ea:     	cmpq	%r12, %rsi
1800053ed:     	jg	0x18000516d <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2bdd>
1800053f3:     	movq	%rsi, (%r14)
1800053f6:     	cmpb	$0x0, (%rbx)
1800053f9:     	jne	0x180005535 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2fa5>
1800053ff:     	movq	%r8, %rsi
180005402:     	movq	%rdx, %rdi
180005405:     	movq	%rcx, %rbp
180005408:     	testq	%r11, %r11
18000540b:     	js	0x180005b37 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x35a7>
180005411:     	movq	$0x0, (%rax,%r11,8)
180005419:     	leaq	(%r15,%r11,8), %rcx
18000541d:     	movq	$0x1, 0x8(%r15,%r11,8)
180005426:     	movq	$0x0, 0x10(%rax,%r11,8)
18000542f:     	movl	$0x1, %edx
180005434:     	jmp	0x180005b42 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x35b2>
180005439:     	testq	%r10, %r10
18000543c:     	je	0x1800054b4 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2f24>
18000543e:     	movq	0x20(%r15,%rdi,8), %rax
180005443:     	testq	%rax, %rax
180005446:     	js	0x18000552a <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2f9a>
18000544c:     	movq	0x8(%r14), %r9
180005450:     	leaq	0x1(%r9), %r10
180005454:     	movq	%r10, 0x8(%r14)
180005458:     	cmpq	0x10(%r14), %r9
18000545c:     	jge	0x18000552a <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2f9a>
180005462:     	movq	%rdx, %rbp
180005465:     	movq	%rcx, %r12
180005468:     	movb	$0x0, 0x42(%rsp)
18000546d:     	movq	%r13, 0x28(%rsp)
180005472:     	movq	%rax, 0x20(%rsp)
180005477:     	movq	$-0x1, 0x30(%rsp)
180005480:     	leaq	0x42(%rsp), %rcx
180005485:     	leaq	0xb8(%rsp), %rdx
18000548d:     	movq	%r8, %rsi
180005490:     	xorl	%r9d, %r9d
180005493:     	callq	0x180004fe0 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2a50>
180005498:     	testl	%eax, %eax
18000549a:     	jne	0x180005a94 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3504>
1800054a0:     	cmpb	$0x0, (%rbx)
1800054a3:     	movq	%r12, %rax
1800054a6:     	je	0x18000555b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2fcb>
1800054ac:     	movb	$0x0, (%rax)
1800054af:     	jmp	0x180005538 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2fa8>
1800054b4:     	movq	0x8(%r14), %rax
1800054b8:     	leaq	0x1(%rax), %r9
1800054bc:     	movq	%r9, 0x8(%r14)
1800054c0:     	cmpq	0x10(%r14), %rax
1800054c4:     	jge	0x18000554e <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2fbe>
1800054ca:     	movq	%rdx, %rsi
1800054cd:     	movq	%rcx, %r12
1800054d0:     	movq	%rdi, 0x30(%rsp)
1800054d5:     	movq	$-0x1, 0x28(%rsp)
1800054de:     	movq	$-0x1, 0x20(%rsp)
1800054e7:     	leaq	0x47(%rsp), %rcx
1800054ec:     	leaq	0xc0(%rsp), %rdx
1800054f4:     	movl	$0x1, %r9d
1800054fa:     	movq	%r8, %rbp
1800054fd:     	callq	0x180004fe0 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2a50>
180005502:     	testl	%eax, %eax
180005504:     	jne	0x180005aa5 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3515>
18000550a:     	cmpb	$0x0, (%rbx)
18000550d:     	movq	%r12, %rcx
180005510:     	jne	0x180005535 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2fa5>
180005512:     	movq	%rsi, %rdx
180005515:     	decq	0x8(%r14)
180005519:     	movq	%rbp, %r8
18000551c:     	movq	0x20(%r15,%rdi,8), %rax
180005521:     	testq	%rax, %rax
180005524:     	jns	0x18000544c <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2ebc>
18000552a:     	movb	$0x1, (%rbx)
18000552d:     	movq	$0x2dc6cd, 0x18(%r14)   # imm = 0x2DC6CD
180005535:     	movb	$0x0, (%rcx)
180005538:     	xorl	%eax, %eax
18000553a:     	addq	$0x128, %rsp            # imm = 0x128
180005541:     	popq	%rbx
180005542:     	popq	%rbp
180005543:     	popq	%rdi
180005544:     	popq	%rsi
180005545:     	popq	%r12
180005547:     	popq	%r13
180005549:     	popq	%r14
18000554b:     	popq	%r15
18000554d:     	retq
18000554e:     	movb	$0x1, (%rbx)
180005551:     	movq	$0x2dc6cb, 0x18(%r14)   # imm = 0x2DC6CB
180005559:     	jmp	0x180005535 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2fa5>
18000555b:     	movzbl	0x42(%rsp), %ecx
180005560:     	movq	0x8(%r14), %rdx
180005564:     	leaq	-0x1(%rdx), %r8
180005568:     	movq	%r8, 0x8(%r14)
18000556c:     	testb	$0x1, %cl
18000556f:     	je	0x180005576 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2fe6>
180005571:     	movb	$0x1, (%rax)
180005574:     	jmp	0x180005538 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2fa8>
180005576:     	movq	0x28(%r15,%rdi,8), %rcx
18000557b:     	testq	%rcx, %rcx
18000557e:     	js	0x18000558a <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2ffa>
180005580:     	movq	%rdx, 0x8(%r14)
180005584:     	cmpq	0x10(%r14), %rdx
180005588:     	jle	0x18000559a <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x300a>
18000558a:     	movb	$0x1, (%rbx)
18000558d:     	movq	$0x2dc6ce, 0x18(%r14)   # imm = 0x2DC6CE
180005595:     	jmp	0x1800054ac <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2f1c>
18000559a:     	movb	$0x0, 0x41(%rsp)
18000559f:     	movq	%r13, 0x28(%rsp)
1800055a4:     	movq	%rcx, 0x20(%rsp)
1800055a9:     	movq	$-0x1, 0x30(%rsp)
1800055b2:     	leaq	0x41(%rsp), %rcx
1800055b7:     	leaq	0xb0(%rsp), %rdx
1800055bf:     	movq	%rsi, %r8
1800055c2:     	xorl	%r9d, %r9d
1800055c5:     	callq	0x180004fe0 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2a50>
1800055ca:     	testl	%eax, %eax
1800055cc:     	jne	0x180005ba9 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3619>
1800055d2:     	cmpb	$0x0, (%rbx)
1800055d5:     	je	0x180005a35 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x34a5>
1800055db:     	movb	$0x0, (%r12)
1800055e0:     	jmp	0x180005538 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2fa8>
1800055e5:     	movq	%r9, 0xc8(%rsp)
1800055ed:     	movq	%r11, 0xd0(%rsp)
1800055f5:     	movabsq	$0x7ffffffffffffff8, %r10 # imm = 0x7FFFFFFFFFFFFFF8
1800055ff:     	andq	%rdx, %r10
180005602:     	movq	0x58(%rsp), %rdx
180005607:     	leaq	(%r15,%rdx,8), %rdx
18000560b:     	movq	%rdx, 0xf8(%rsp)
180005613:     	leaq	(,%r12,8), %rdx
18000561b:     	movq	%rdx, 0x78(%rsp)
180005620:     	xorl	%r11d, %r11d
180005623:     	movq	%r10, 0x100(%rsp)
18000562b:     	leaq	(%rsi,%r11), %rbp
18000562f:     	movq	%rbp, %rdx
180005632:     	sarq	$0x3f, %rdx
180005636:     	leaq	(,%r12,8), %r9
18000563e:     	andq	%r9, %rdx
180005641:     	leaq	(%r15,%rsi,8), %r8
180005645:     	movq	%r8, 0x48(%rsp)
18000564a:     	addq	%r8, %rdx
18000564d:     	movq	(%rdx,%r11,8), %r10
180005651:     	movq	0x58(%rsp), %rdx
180005656:     	leaq	(%rdx,%r11), %r8
18000565a:     	movq	%r8, %rdx
18000565d:     	sarq	$0x3f, %rdx
180005661:     	andq	%r9, %rdx
180005664:     	movq	0xf8(%rsp), %r9
18000566c:     	addq	%r9, %rdx
18000566f:     	movq	%r10, (%rdx,%r11,8)
180005673:     	movq	%rbp, %rdx
180005676:     	incq	%rdx
180005679:     	movl	$0x8, %edx
18000567e:     	leaq	0x8(,%r12,8), %r10
180005686:     	movq	%r10, 0x50(%rsp)
18000568b:     	cmovsq	%r10, %rdx
18000568f:     	addq	0x48(%rsp), %rdx
180005694:     	movq	(%rdx,%r11,8), %rdx
180005698:     	movq	%r8, %r10
18000569b:     	incq	%r10
18000569e:     	movl	$0x8, %r10d
1800056a4:     	cmovsq	0x50(%rsp), %r10
1800056aa:     	addq	%r9, %r10
1800056ad:     	movq	%rdx, (%r10,%r11,8)
1800056b1:     	movq	%rbp, %rdx
1800056b4:     	addq	$0x2, %rdx
1800056b8:     	movl	$0x10, %edx
1800056bd:     	leaq	0x10(,%r12,8), %r10
1800056c5:     	movq	%r10, 0x60(%rsp)
1800056ca:     	cmovsq	%r10, %rdx
1800056ce:     	addq	0x48(%rsp), %rdx
1800056d3:     	movq	(%rdx,%r11,8), %rdx
1800056d7:     	movq	%r8, %r10
1800056da:     	addq	$0x2, %r10
1800056de:     	movl	$0x10, %r10d
1800056e4:     	cmovsq	0x60(%rsp), %r10
1800056ea:     	addq	%r9, %r10
1800056ed:     	movq	%rdx, (%r10,%r11,8)
1800056f1:     	movq	%rbp, %rdx
1800056f4:     	addq	$0x3, %rdx
1800056f8:     	movl	$0x18, %edx
1800056fd:     	leaq	0x18(,%r12,8), %r10
180005705:     	movq	%r10, 0x120(%rsp)
18000570d:     	cmovsq	%r10, %rdx
180005711:     	addq	0x48(%rsp), %rdx
180005716:     	movq	(%rdx,%r11,8), %rdx
18000571a:     	movq	%r8, %r10
18000571d:     	addq	$0x3, %r10
180005721:     	movl	$0x18, %r10d
180005727:     	cmovsq	0x120(%rsp), %r10
180005730:     	addq	%r9, %r10
180005733:     	movq	%rdx, (%r10,%r11,8)
180005737:     	movq	%rbp, %rdx
18000573a:     	addq	$0x4, %rdx
18000573e:     	movl	$0x20, %edx
180005743:     	leaq	0x20(,%r12,8), %r10
18000574b:     	movq	%r10, 0x118(%rsp)
180005753:     	cmovsq	%r10, %rdx
180005757:     	addq	0x48(%rsp), %rdx
18000575c:     	movq	(%rdx,%r11,8), %rdx
180005760:     	movq	%r8, %r10
180005763:     	addq	$0x4, %r10
180005767:     	movl	$0x20, %r10d
18000576d:     	cmovsq	0x118(%rsp), %r10
180005776:     	addq	%r9, %r10
180005779:     	movq	%rdx, (%r10,%r11,8)
18000577d:     	movq	%rbp, %rdx
180005780:     	addq	$0x5, %rdx
180005784:     	movl	$0x28, %edx
180005789:     	leaq	0x28(,%r12,8), %r10
180005791:     	movq	%r10, 0x110(%rsp)
180005799:     	cmovsq	%r10, %rdx
18000579d:     	addq	0x48(%rsp), %rdx
1800057a2:     	movq	(%rdx,%r11,8), %rdx
1800057a6:     	movq	%r8, %r10
1800057a9:     	addq	$0x5, %r10
1800057ad:     	movl	$0x28, %r10d
1800057b3:     	cmovsq	0x110(%rsp), %r10
1800057bc:     	addq	%r9, %r10
1800057bf:     	movq	%rdx, (%r10,%r11,8)
1800057c3:     	movq	%rbp, %rdx
1800057c6:     	addq	$0x6, %rdx
1800057ca:     	movl	$0x30, %edx
1800057cf:     	leaq	0x30(,%r12,8), %r10
1800057d7:     	movq	%r10, 0x108(%rsp)
1800057df:     	cmovsq	%r10, %rdx
1800057e3:     	addq	0x48(%rsp), %rdx
1800057e8:     	movq	(%rdx,%r11,8), %rdx
1800057ec:     	movq	%r8, %r10
1800057ef:     	addq	$0x6, %r10
1800057f3:     	movl	$0x30, %r10d
1800057f9:     	cmovsq	0x108(%rsp), %r10
180005802:     	addq	%r9, %r10
180005805:     	movq	%rdx, (%r10,%r11,8)
180005809:     	movq	0x100(%rsp), %r10
180005811:     	addq	$0x7, %rbp
180005815:     	movl	$0x38, %edx
18000581a:     	leaq	0x38(,%r12,8), %rbp
180005822:     	cmovsq	%rbp, %rdx
180005826:     	addq	0x48(%rsp), %rdx
18000582b:     	movq	(%rdx,%r11,8), %rdx
18000582f:     	addq	$0x7, %r8
180005833:     	movl	$0x38, %r8d
180005839:     	cmovsq	%rbp, %r8
18000583d:     	addq	%r9, %r8
180005840:     	movq	%rdx, (%r8,%r11,8)
180005844:     	addq	$0x8, %r11
180005848:     	cmpq	%r11, %r10
18000584b:     	jne	0x18000562b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x309b>
180005851:     	movq	0xd0(%rsp), %r11
180005859:     	testq	%r11, %r11
18000585c:     	movq	0xc8(%rsp), %r9
180005864:     	je	0x1800058a3 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3313>
180005866:     	movq	0x58(%rsp), %rdx
18000586b:     	addq	%r10, %rdx
18000586e:     	addq	%r10, %rsi
180005871:     	movq	0x78(%rsp), %rbp
180005876:     	movq	%rsi, %r8
180005879:     	sarq	$0x3f, %r8
18000587d:     	andq	%rbp, %r8
180005880:     	addq	%r15, %r8
180005883:     	movq	(%r8,%rsi,8), %r8
180005887:     	movq	%rdx, %r10
18000588a:     	sarq	$0x3f, %r10
18000588e:     	andq	%rbp, %r10
180005891:     	addq	%r15, %r10
180005894:     	movq	%r8, (%r10,%rdx,8)
180005898:     	incq	%rdx
18000589b:     	incq	%rsi
18000589e:     	decq	%r11
1800058a1:     	jne	0x180005876 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x32e6>
1800058a3:     	movq	0xe0(%rsp), %rdx
1800058ab:     	movq	0xd8(%rsp), %r8
1800058b3:     	movq	0xf0(%rsp), %r11
1800058bb:     	movq	%r8, 0x8(%r11,%rdx,8)
1800058c0:     	movq	0x58(%rsp), %rdx
1800058c5:     	movq	0x68(%rsp), %r8
1800058ca:     	movq	%rdx, 0x10(%r11,%r8,8)
1800058cf:     	movq	0xe8(%rsp), %r8
1800058d7:     	movq	0x70(%rsp), %rbp
1800058dc:     	leaq	0x1(%rbp), %rdx
1800058e0:     	movq	%rdx, (%r11,%r8,8)
1800058e4:     	cmpb	$0x0, (%rbx)
1800058e7:     	jne	0x180005535 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2fa5>
1800058ed:     	xorl	%edx, %edx
1800058ef:     	cmpq	$-0x2, %r9
1800058f3:     	cmovlq	%r12, %rdx
1800058f7:     	addq	0x10(%r11,%rdx,8), %rbp
1800058fc:     	movq	%rbp, %rdx
1800058ff:     	sarq	$0x3f, %rdx
180005903:     	andq	%r12, %rdx
180005906:     	leaq	(%r15,%rbp,8), %r8
18000590a:     	movq	%r13, (%r8,%rdx,8)
18000590e:     	movsd	0x48(%rax,%rdi,8), %xmm1
180005914:     	movsd	0x8(%rax,%r13,8), %xmm2
18000591b:     	movapd	%xmm1, %xmm0
18000591f:     	addsd	%xmm2, %xmm0
180005923:     	xorpd	%xmm3, %xmm3
180005927:     	ucomisd	%xmm3, %xmm0
18000592b:     	jbe	0x180005a17 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3487>
180005931:     	movq	0x10(%r15,%rdi,8), %rdx
180005936:     	testq	%rdx, %rdx
180005939:     	js	0x180005a28 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3498>
18000593f:     	cmpq	$0x0, 0x8(%r15,%rdx,8)
180005945:     	mulsd	(%rax,%rdx,8), %xmm1
18000594a:     	je	0x180005976 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x33e6>
18000594c:     	cmpq	$0x0, 0x50(%r15,%rdi,8)
180005952:     	je	0x180005976 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x33e6>
180005954:     	movapd	0x4a64(%rip), %xmm3     # 0x18000a3c0
18000595c:     	andpd	%xmm1, %xmm3
180005960:     	ucomisd	0x4a68(%rip), %xmm3     # 0x18000a3d0
180005968:     	jae	0x180005a28 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3498>
18000596e:     	xorpd	%xmm3, %xmm3
180005972:     	addsd	%xmm3, %xmm1
180005976:     	movq	0x10(%r15,%r13,8), %r8
18000597b:     	testq	%r8, %r8
18000597e:     	js	0x180005a28 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3498>
180005984:     	mulsd	(%rax,%r8,8), %xmm2
18000598a:     	addsd	%xmm2, %xmm1
18000598e:     	divsd	%xmm0, %xmm1
180005992:     	movsd	%xmm1, (%rax,%rdx,8)
180005997:     	movq	$0x0, 0x8(%r15,%rdx,8)
1800059a0:     	movq	0x10(%r15,%rdi,8), %rdx
1800059a5:     	testq	%rdx, %rdx
1800059a8:     	js	0x180005a54 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x34c4>
1800059ae:     	movsd	0x10(%rax,%rdx,8), %xmm1
1800059b4:     	cmpq	$0x0, 0x18(%r15,%rdx,8)
1800059ba:     	mulsd	0x48(%rax,%rdi,8), %xmm1
1800059c0:     	je	0x1800059e8 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3458>
1800059c2:     	cmpq	$0x0, 0x50(%r15,%rdi,8)
1800059c8:     	je	0x1800059e8 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3458>
1800059ca:     	movapd	0x49ee(%rip), %xmm2     # 0x18000a3c0
1800059d2:     	andpd	%xmm1, %xmm2
1800059d6:     	ucomisd	0x49f2(%rip), %xmm2     # 0x18000a3d0
1800059de:     	jae	0x180005a54 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x34c4>
1800059e0:     	xorpd	%xmm2, %xmm2
1800059e4:     	addsd	%xmm2, %xmm1
1800059e8:     	movq	0x10(%r15,%r13,8), %r8
1800059ed:     	testq	%r8, %r8
1800059f0:     	js	0x180005a54 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x34c4>
1800059f2:     	movsd	0x10(%rax,%r8,8), %xmm2
1800059f9:     	mulsd	0x8(%rax,%r13,8), %xmm2
180005a00:     	addsd	%xmm2, %xmm1
180005a04:     	divsd	%xmm0, %xmm1
180005a08:     	movsd	%xmm1, 0x10(%rax,%rdx,8)
180005a0e:     	movq	$0x0, 0x18(%r15,%rdx,8)
180005a17:     	movsd	%xmm0, 0x48(%rax,%rdi,8)
180005a1d:     	movq	$0x0, 0x50(%r15,%rdi,8)
180005a26:     	jmp	0x180005a5f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x34cf>
180005a28:     	movb	$0x1, (%rbx)
180005a2b:     	movq	$0x895447, 0x18(%r14)   # imm = 0x895447
180005a33:     	jmp	0x180005a5f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x34cf>
180005a35:     	movzbl	0x41(%rsp), %eax
180005a3a:     	movq	0x8(%r14), %rcx
180005a3e:     	leaq	-0x1(%rcx), %rdx
180005a42:     	movq	%rdx, 0x8(%r14)
180005a46:     	testb	$0x1, %al
180005a48:     	je	0x180005a70 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x34e0>
180005a4a:     	movb	$0x1, (%r12)
180005a4f:     	jmp	0x180005538 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2fa8>
180005a54:     	movb	$0x1, (%rbx)
180005a57:     	movq	$0x895449, 0x18(%r14)   # imm = 0x895449
180005a5f:     	cmpb	$0x0, (%rbx)
180005a62:     	jne	0x180005535 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2fa5>
180005a68:     	movb	$0x1, (%rcx)
180005a6b:     	jmp	0x180005538 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2fa8>
180005a70:     	movq	0x38(%r15,%rdi,8), %rax
180005a75:     	testq	%rax, %rax
180005a78:     	js	0x180005a84 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x34f4>
180005a7a:     	movq	%rcx, 0x8(%r14)
180005a7e:     	cmpq	0x10(%r14), %rcx
180005a82:     	jle	0x180005ab5 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3525>
180005a84:     	movb	$0x1, (%rbx)
180005a87:     	movq	$0x2dc6cf, 0x18(%r14)   # imm = 0x2DC6CF
180005a8f:     	jmp	0x1800055db <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x304b>
180005a94:     	movq	0xb8(%rsp), %rcx
180005a9c:     	movq	%rcx, (%rbp)
180005aa0:     	jmp	0x18000553a <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2faa>
180005aa5:     	movq	0xc0(%rsp), %rcx
180005aad:     	movq	%rcx, (%rsi)
180005ab0:     	jmp	0x18000553a <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2faa>
180005ab5:     	movb	$0x0, 0x40(%rsp)
180005aba:     	movq	%r13, 0x28(%rsp)
180005abf:     	movq	%rax, 0x20(%rsp)
180005ac4:     	movq	$-0x1, 0x30(%rsp)
180005acd:     	leaq	0x40(%rsp), %rcx
180005ad2:     	leaq	0xa8(%rsp), %rdx
180005ada:     	movq	%rsi, %r8
180005add:     	xorl	%r9d, %r9d
180005ae0:     	callq	0x180004fe0 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2a50>
180005ae5:     	testl	%eax, %eax
180005ae7:     	jne	0x180005d43 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x37b3>
180005aed:     	cmpb	$0x0, (%rbx)
180005af0:     	jne	0x1800055db <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x304b>
180005af6:     	movzbl	0x40(%rsp), %eax
180005afb:     	movq	0x8(%r14), %rcx
180005aff:     	leaq	-0x1(%rcx), %rdx
180005b03:     	movq	%rdx, 0x8(%r14)
180005b07:     	testb	$0x1, %al
180005b09:     	jne	0x180005a4a <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x34ba>
180005b0f:     	movq	0x40(%r15,%rdi,8), %rax
180005b14:     	testq	%rax, %rax
180005b17:     	js	0x180005b27 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3597>
180005b19:     	movq	%rcx, 0x8(%r14)
180005b1d:     	cmpq	0x10(%r14), %rcx
180005b21:     	jle	0x180005be8 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3658>
180005b27:     	movb	$0x1, (%rbx)
180005b2a:     	movq	$0x2dc6d0, 0x18(%r14)   # imm = 0x2DC6D0
180005b32:     	jmp	0x1800055db <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x304b>
180005b37:     	movb	$0x1, (%rbx)
180005b3a:     	movl	$0x6acfc2, %edx         # imm = 0x6ACFC2
180005b3f:     	movq	%r14, %rcx
180005b42:     	movq	%rdx, 0x18(%rcx)
180005b46:     	cmpb	$0x0, (%rbx)
180005b49:     	movq	%rbp, %rcx
180005b4c:     	jne	0x180005535 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2fa5>
180005b52:     	movq	%r11, 0x10(%r10)
180005b56:     	movq	$0x0, 0x48(%rax,%r9,8)
180005b5f:     	movq	$0x1, 0x50(%r10)
180005b67:     	movq	$-0x1, 0x20(%r10)
180005b6f:     	movq	$-0x1, 0x28(%r10)
180005b77:     	movq	$-0x1, 0x38(%r10)
180005b7f:     	movq	$-0x1, 0x40(%r10)
180005b87:     	cmpb	$0x0, (%rbx)
180005b8a:     	jne	0x180005535 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2fa5>
180005b90:     	movq	%r9, 0x20(%r15,%r13,8)
180005b95:     	movq	(%r14), %rdx
180005b98:     	leaq	0x4(%rdx), %rcx
180005b9c:     	cmpq	%r12, %rcx
180005b9f:     	jle	0x180005bba <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x362a>
180005ba1:     	movb	$0x2, (%rbx)
180005ba4:     	jmp	0x180005c4f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x36bf>
180005ba9:     	movq	0xb0(%rsp), %rcx
180005bb1:     	movq	%rcx, (%rbp)
180005bb5:     	jmp	0x18000553a <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2faa>
180005bba:     	movq	%rcx, (%r14)
180005bbd:     	cmpb	$0x0, (%rbx)
180005bc0:     	jne	0x180005c4f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x36bf>
180005bc6:     	subsd	%xmm3, %xmm2
180005bca:     	testq	%rdx, %rdx
180005bcd:     	js	0x180005c3f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x36af>
180005bcf:     	movsd	%xmm2, 0x10(%rax,%rdx,8)
180005bd5:     	movsd	%xmm5, 0x18(%rax,%rdx,8)
180005bdb:     	movsd	%xmm3, 0x8(%rax,%rdx,8)
180005be1:     	movsd	%xmm0, (%rax,%rdx,8)
180005be6:     	jmp	0x180005c4a <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x36ba>
180005be8:     	movb	$0x0, 0x3f(%rsp)
180005bed:     	movq	%r13, 0x28(%rsp)
180005bf2:     	movq	%rax, 0x20(%rsp)
180005bf7:     	movq	$-0x1, 0x30(%rsp)
180005c00:     	leaq	0x3f(%rsp), %rcx
180005c05:     	leaq	0xa0(%rsp), %rdx
180005c0d:     	movq	%rsi, %r8
180005c10:     	xorl	%r9d, %r9d
180005c13:     	callq	0x180004fe0 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2a50>
180005c18:     	testl	%eax, %eax
180005c1a:     	jne	0x180005d54 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x37c4>
180005c20:     	cmpb	$0x0, (%rbx)
180005c23:     	jne	0x1800055db <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x304b>
180005c29:     	movzbl	0x3f(%rsp), %eax
180005c2e:     	decq	0x8(%r14)
180005c32:     	testb	$0x1, %al
180005c34:     	je	0x1800055db <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x304b>
180005c3a:     	jmp	0x180005a4a <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x34ba>
180005c3f:     	movb	$0x1, (%rbx)
180005c42:     	movq	$0xf4242, 0x18(%r14)    # imm = 0xF4242
180005c4a:     	cmpb	$0x0, (%rbx)
180005c4d:     	je	0x180005c58 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x36c8>
180005c4f:     	movb	$0x0, (%rbp)
180005c53:     	jmp	0x180005538 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2fa8>
180005c58:     	movq	(%r14), %rcx
180005c5b:     	leaq	0xb(%rcx), %r9
180005c5f:     	cmpq	%r12, %r9
180005c62:     	jg	0x180005ba1 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3611>
180005c68:     	movq	0x8(%r15,%r13,8), %r8
180005c6d:     	movq	%r9, (%r14)
180005c70:     	cmpb	$0x0, (%rbx)
180005c73:     	jne	0x180005c4f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x36bf>
180005c75:     	movq	%rdx, (%r15,%rcx,8)
180005c79:     	movq	%r8, 0x8(%r15,%rcx,8)
180005c7e:     	movq	(%r14), %r8
180005c81:     	cmpq	%r12, %r8
180005c84:     	movq	%r8, %rdx
180005c87:     	jle	0x180005c91 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3701>
180005c89:     	movb	$0x2, (%rbx)
180005c8c:     	movq	(%r14), %r8
180005c8f:     	xorl	%edx, %edx
180005c91:     	leaq	0x3(%r8), %r9
180005c95:     	cmpq	%r12, %r9
180005c98:     	jg	0x180005ba1 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3611>
180005c9e:     	movq	%r9, (%r14)
180005ca1:     	cmpb	$0x0, (%rbx)
180005ca4:     	jne	0x180005c4f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x36bf>
180005ca6:     	movq	%r8, %r9
180005ca9:     	sarq	$0x3f, %r9
180005cad:     	andq	%r12, %r9
180005cb0:     	leaq	(%r15,%r8,8), %r10
180005cb4:     	movq	$0x0, (%r10,%r9,8)
180005cbc:     	xorl	%r9d, %r9d
180005cbf:     	cmpq	$-0x1, %r8
180005cc3:     	movl	$0x0, %r11d
180005cc9:     	cmovlq	%r12, %r11
180005ccd:     	movq	$0x0, 0x8(%r10,%r11,8)
180005cd6:     	cmpq	$-0x2, %r8
180005cda:     	cmovlq	%r12, %r9
180005cde:     	movq	%rdx, 0x10(%r10,%r9,8)
180005ce3:     	cmpb	$0x0, (%rbx)
180005ce6:     	jne	0x180005c4f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x36bf>
180005cec:     	leaq	(%r15,%rcx,8), %rdx
180005cf0:     	movq	%r8, 0x30(%rdx)
180005cf4:     	movq	$0x0, 0x18(%rdx)
180005cfc:     	movq	(%r14), %r8
180005cff:     	leaq	0x4(%r8), %r9
180005d03:     	cmpq	%r12, %r9
180005d06:     	jg	0x180005ba1 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3611>
180005d0c:     	movq	%r9, (%r14)
180005d0f:     	cmpb	$0x0, (%rbx)
180005d12:     	jne	0x180005c4f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x36bf>
180005d18:     	testq	%r8, %r8
180005d1b:     	js	0x180005d65 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x37d5>
180005d1d:     	movq	$0x0, (%rax,%r8,8)
180005d25:     	leaq	(%r15,%r8,8), %r9
180005d29:     	movq	$0x1, 0x8(%r15,%r8,8)
180005d32:     	movq	$0x0, 0x10(%rax,%r8,8)
180005d3b:     	movl	$0x1, %r10d
180005d41:     	jmp	0x180005d71 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x37e1>
180005d43:     	movq	0xa8(%rsp), %rcx
180005d4b:     	movq	%rcx, (%rbp)
180005d4f:     	jmp	0x18000553a <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2faa>
180005d54:     	movq	0xa0(%rsp), %rcx
180005d5c:     	movq	%rcx, (%rbp)
180005d60:     	jmp	0x18000553a <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2faa>
180005d65:     	movb	$0x1, (%rbx)
180005d68:     	movl	$0x6acfc2, %r10d        # imm = 0x6ACFC2
180005d6e:     	movq	%r14, %r9
180005d71:     	movq	%r10, 0x18(%r9)
180005d75:     	cmpb	$0x0, (%rbx)
180005d78:     	jne	0x180005c4f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x36bf>
180005d7e:     	movq	%r8, 0x10(%rdx)
180005d82:     	movq	$0x0, 0x48(%rax,%rcx,8)
180005d8b:     	movq	$0x1, 0x50(%rdx)
180005d93:     	movq	$-0x1, 0x20(%rdx)
180005d9b:     	movq	$-0x1, 0x28(%rdx)
180005da3:     	movq	$-0x1, 0x38(%rdx)
180005dab:     	movq	$-0x1, 0x40(%rdx)
180005db3:     	cmpb	$0x0, (%rbx)
180005db6:     	jne	0x180005c4f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x36bf>
180005dbc:     	movq	%rcx, 0x28(%r15,%r13,8)
180005dc1:     	movq	(%r14), %rdx
180005dc4:     	leaq	0x4(%rdx), %rcx
180005dc8:     	cmpq	%r12, %rcx
180005dcb:     	jg	0x180005ba1 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3611>
180005dd1:     	movq	%rcx, (%r14)
180005dd4:     	cmpb	$0x0, (%rbx)
180005dd7:     	jne	0x180005c4f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x36bf>
180005ddd:     	addsd	%xmm0, %xmm1
180005de1:     	testq	%rdx, %rdx
180005de4:     	js	0x180005dff <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x386f>
180005de6:     	movsd	%xmm4, 0x10(%rax,%rdx,8)
180005dec:     	movsd	%xmm1, 0x18(%rax,%rdx,8)
180005df2:     	movsd	%xmm3, 0x8(%rax,%rdx,8)
180005df8:     	movsd	%xmm0, (%rax,%rdx,8)
180005dfd:     	jmp	0x180005e0a <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x387a>
180005dff:     	movb	$0x1, (%rbx)
180005e02:     	movq	$0xf4242, 0x18(%r14)    # imm = 0xF4242
180005e0a:     	cmpb	$0x0, (%rbx)
180005e0d:     	jne	0x180005c4f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x36bf>
180005e13:     	movq	(%r14), %rcx
180005e16:     	leaq	0xb(%rcx), %r9
180005e1a:     	cmpq	%r12, %r9
180005e1d:     	jg	0x180005ba1 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3611>
180005e23:     	movq	0x8(%r15,%r13,8), %r8
180005e28:     	movq	%r9, (%r14)
180005e2b:     	cmpb	$0x0, (%rbx)
180005e2e:     	jne	0x180005c4f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x36bf>
180005e34:     	movq	%rdx, (%r15,%rcx,8)
180005e38:     	movq	%r8, 0x8(%r15,%rcx,8)
180005e3d:     	movq	(%r14), %r8
180005e40:     	cmpq	%r12, %r8
180005e43:     	movq	%r8, %rdx
180005e46:     	jle	0x180005e50 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x38c0>
180005e48:     	movb	$0x2, (%rbx)
180005e4b:     	movq	(%r14), %r8
180005e4e:     	xorl	%edx, %edx
180005e50:     	leaq	0x3(%r8), %r9
180005e54:     	cmpq	%r12, %r9
180005e57:     	jg	0x180005ba1 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3611>
180005e5d:     	movq	%r9, (%r14)
180005e60:     	cmpb	$0x0, (%rbx)
180005e63:     	jne	0x180005c4f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x36bf>
180005e69:     	movq	%r8, %r9
180005e6c:     	sarq	$0x3f, %r9
180005e70:     	andq	%r12, %r9
180005e73:     	leaq	(%r15,%r8,8), %r10
180005e77:     	movq	$0x0, (%r10,%r9,8)
180005e7f:     	xorl	%r9d, %r9d
180005e82:     	cmpq	$-0x1, %r8
180005e86:     	movl	$0x0, %r11d
180005e8c:     	cmovlq	%r12, %r11
180005e90:     	movq	$0x0, 0x8(%r10,%r11,8)
180005e99:     	cmpq	$-0x2, %r8
180005e9d:     	cmovlq	%r12, %r9
180005ea1:     	movq	%rdx, 0x10(%r10,%r9,8)
180005ea6:     	cmpb	$0x0, (%rbx)
180005ea9:     	jne	0x180005c4f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x36bf>
180005eaf:     	leaq	(%r15,%rcx,8), %rdx
180005eb3:     	movq	%r8, 0x30(%rdx)
180005eb7:     	movq	$0x0, 0x18(%rdx)
180005ebf:     	movq	(%r14), %r8
180005ec2:     	leaq	0x4(%r8), %r9
180005ec6:     	cmpq	%r12, %r9
180005ec9:     	jg	0x180005ba1 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3611>
180005ecf:     	movq	%r9, (%r14)
180005ed2:     	cmpb	$0x0, (%rbx)
180005ed5:     	jne	0x180005c4f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x36bf>
180005edb:     	testq	%r8, %r8
180005ede:     	js	0x180005f06 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3976>
180005ee0:     	movq	$0x0, (%rax,%r8,8)
180005ee8:     	leaq	(%r15,%r8,8), %r9
180005eec:     	movq	$0x1, 0x8(%r15,%r8,8)
180005ef5:     	movq	$0x0, 0x10(%rax,%r8,8)
180005efe:     	movl	$0x1, %r10d
180005f04:     	jmp	0x180005f12 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3982>
180005f06:     	movb	$0x1, (%rbx)
180005f09:     	movl	$0x6acfc2, %r10d        # imm = 0x6ACFC2
180005f0f:     	movq	%r14, %r9
180005f12:     	movq	%r10, 0x18(%r9)
180005f16:     	cmpb	$0x0, (%rbx)
180005f19:     	jne	0x180005c4f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x36bf>
180005f1f:     	movq	%r8, 0x10(%rdx)
180005f23:     	movq	$0x0, 0x48(%rax,%rcx,8)
180005f2c:     	movq	$0x1, 0x50(%rdx)
180005f34:     	movq	$-0x1, 0x20(%rdx)
180005f3c:     	movq	$-0x1, 0x28(%rdx)
180005f44:     	movq	$-0x1, 0x38(%rdx)
180005f4c:     	movq	$-0x1, 0x40(%rdx)
180005f54:     	cmpb	$0x0, (%rbx)
180005f57:     	jne	0x180005c4f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x36bf>
180005f5d:     	movq	%rcx, 0x38(%r15,%r13,8)
180005f62:     	movq	(%r14), %rdx
180005f65:     	leaq	0x4(%rdx), %rcx
180005f69:     	cmpq	%r12, %rcx
180005f6c:     	jg	0x180005ba1 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3611>
180005f72:     	movq	%rcx, (%r14)
180005f75:     	cmpb	$0x0, (%rbx)
180005f78:     	jne	0x180005c4f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x36bf>
180005f7e:     	testq	%rdx, %rdx
180005f81:     	js	0x180005f9c <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3a0c>
180005f83:     	movsd	%xmm2, 0x10(%rax,%rdx,8)
180005f89:     	movsd	%xmm1, 0x18(%rax,%rdx,8)
180005f8f:     	movsd	%xmm3, 0x8(%rax,%rdx,8)
180005f95:     	movsd	%xmm0, (%rax,%rdx,8)
180005f9a:     	jmp	0x180005fa7 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3a17>
180005f9c:     	movb	$0x1, (%rbx)
180005f9f:     	movq	$0xf4242, 0x18(%r14)    # imm = 0xF4242
180005fa7:     	cmpb	$0x0, (%rbx)
180005faa:     	jne	0x180005c4f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x36bf>
180005fb0:     	movq	(%r14), %rcx
180005fb3:     	leaq	0xb(%rcx), %r9
180005fb7:     	cmpq	%r12, %r9
180005fba:     	jg	0x180005ba1 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3611>
180005fc0:     	movq	0x8(%r15,%r13,8), %r8
180005fc5:     	movq	%r9, (%r14)
180005fc8:     	cmpb	$0x0, (%rbx)
180005fcb:     	jne	0x180005c4f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x36bf>
180005fd1:     	movq	%rdx, (%r15,%rcx,8)
180005fd5:     	movq	%r8, 0x8(%r15,%rcx,8)
180005fda:     	movq	(%r14), %r8
180005fdd:     	cmpq	%r12, %r8
180005fe0:     	movq	%r8, %rdx
180005fe3:     	jle	0x180005fed <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3a5d>
180005fe5:     	movb	$0x2, (%rbx)
180005fe8:     	movq	(%r14), %r8
180005feb:     	xorl	%edx, %edx
180005fed:     	leaq	0x3(%r8), %r9
180005ff1:     	cmpq	%r12, %r9
180005ff4:     	jg	0x180005ba1 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3611>
180005ffa:     	movq	%r9, (%r14)
180005ffd:     	cmpb	$0x0, (%rbx)
180006000:     	jne	0x180005c4f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x36bf>
180006006:     	movq	%r8, %r9
180006009:     	sarq	$0x3f, %r9
18000600d:     	andq	%r12, %r9
180006010:     	leaq	(%r15,%r8,8), %r10
180006014:     	movq	$0x0, (%r10,%r9,8)
18000601c:     	xorl	%r9d, %r9d
18000601f:     	cmpq	$-0x1, %r8
180006023:     	movl	$0x0, %r11d
180006029:     	cmovlq	%r12, %r11
18000602d:     	movq	$0x0, 0x8(%r10,%r11,8)
180006036:     	cmpq	$-0x2, %r8
18000603a:     	cmovlq	%r12, %r9
18000603e:     	movq	%rdx, 0x10(%r10,%r9,8)
180006043:     	cmpb	$0x0, (%rbx)
180006046:     	jne	0x180005c4f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x36bf>
18000604c:     	leaq	(%r15,%rcx,8), %rdx
180006050:     	movq	%r8, 0x30(%rdx)
180006054:     	movq	$0x0, 0x18(%rdx)
18000605c:     	movq	(%r14), %r8
18000605f:     	leaq	0x4(%r8), %r9
180006063:     	cmpq	%r12, %r9
180006066:     	jg	0x180005ba1 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3611>
18000606c:     	movq	%r9, (%r14)
18000606f:     	cmpb	$0x0, (%rbx)
180006072:     	jne	0x180005c4f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x36bf>
180006078:     	testq	%r8, %r8
18000607b:     	js	0x1800060a3 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3b13>
18000607d:     	movq	$0x0, (%rax,%r8,8)
180006085:     	leaq	(%r15,%r8,8), %r9
180006089:     	movq	$0x1, 0x8(%r15,%r8,8)
180006092:     	movq	$0x0, 0x10(%rax,%r8,8)
18000609b:     	movl	$0x1, %r10d
1800060a1:     	jmp	0x1800060af <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3b1f>
1800060a3:     	movb	$0x1, (%rbx)
1800060a6:     	movl	$0x6acfc2, %r10d        # imm = 0x6ACFC2
1800060ac:     	movq	%r14, %r9
1800060af:     	movq	%r10, 0x18(%r9)
1800060b3:     	cmpb	$0x0, (%rbx)
1800060b6:     	jne	0x180005c4f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x36bf>
1800060bc:     	movq	%r8, 0x10(%rdx)
1800060c0:     	movq	$0x0, 0x48(%rax,%rcx,8)
1800060c9:     	movq	$0x1, 0x50(%rdx)
1800060d1:     	movq	$-0x1, 0x20(%rdx)
1800060d9:     	movq	$-0x1, 0x28(%rdx)
1800060e1:     	movq	$-0x1, 0x38(%rdx)
1800060e9:     	movq	$-0x1, 0x40(%rdx)
1800060f1:     	cmpb	$0x0, (%rbx)
1800060f4:     	jne	0x180005c4f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x36bf>
1800060fa:     	movq	%rcx, 0x40(%r15,%r13,8)
1800060ff:     	movq	$0x1, 0x18(%r15,%r13,8)
180006108:     	movq	0x30(%r15,%r13,8), %rax
18000610d:     	movq	%rax, 0x60(%rsp)
180006112:     	cmpq	$0x0, (%r15,%rax,8)
180006117:     	jle	0x180006302 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3d72>
18000611d:     	movq	$0x0, 0x50(%rsp)
180006126:     	movq	0x20(%r15,%r13,8), %rax
18000612b:     	testq	%rax, %rax
18000612e:     	js	0x180006381 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3df1>
180006134:     	movq	0x60(%rsp), %rcx
180006139:     	movq	0x10(%r15,%rcx,8), %rcx
18000613e:     	leaq	(%r15,%rcx,8), %rcx
180006142:     	movq	0x50(%rsp), %rdx
180006147:     	movq	(%rcx,%rdx,8), %rcx
18000614b:     	movq	%rcx, 0x48(%rsp)
180006150:     	movq	0x8(%r14), %rcx
180006154:     	leaq	0x1(%rcx), %rdx
180006158:     	movq	%rdx, 0x8(%r14)
18000615c:     	cmpq	0x10(%r14), %rcx
180006160:     	jge	0x180006381 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3df1>
180006166:     	movq	0x48(%rsp), %rcx
18000616b:     	movq	%rcx, 0x28(%rsp)
180006170:     	movq	%rax, 0x20(%rsp)
180006175:     	movq	$-0x1, 0x30(%rsp)
18000617e:     	leaq	0x46(%rsp), %rcx
180006183:     	leaq	0x98(%rsp), %rdx
18000618b:     	movq	%rsi, %r8
18000618e:     	xorl	%r9d, %r9d
180006191:     	callq	0x180004fe0 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2a50>
180006196:     	testl	%eax, %eax
180006198:     	jne	0x180006391 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3e01>
18000619e:     	cmpb	$0x0, (%rbx)
1800061a1:     	jne	0x180005c4f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x36bf>
1800061a7:     	movq	0x8(%r14), %rcx
1800061ab:     	leaq	-0x1(%rcx), %rax
1800061af:     	movq	%rax, 0x8(%r14)
1800061b3:     	movq	0x28(%r15,%r13,8), %rax
1800061b8:     	testq	%rax, %rax
1800061bb:     	js	0x18000639b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3e0b>
1800061c1:     	movq	%rcx, 0x8(%r14)
1800061c5:     	cmpq	0x10(%r14), %rcx
1800061c9:     	jg	0x18000639b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3e0b>
1800061cf:     	movq	0x48(%rsp), %rcx
1800061d4:     	movq	%rcx, 0x28(%rsp)
1800061d9:     	movq	%rax, 0x20(%rsp)
1800061de:     	movq	$-0x1, 0x30(%rsp)
1800061e7:     	leaq	0x45(%rsp), %rcx
1800061ec:     	leaq	0x90(%rsp), %rdx
1800061f4:     	movq	%rsi, %r8
1800061f7:     	xorl	%r9d, %r9d
1800061fa:     	callq	0x180004fe0 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2a50>
1800061ff:     	testl	%eax, %eax
180006201:     	jne	0x1800063ab <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3e1b>
180006207:     	cmpb	$0x0, (%rbx)
18000620a:     	jne	0x180005c4f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x36bf>
180006210:     	movq	0x8(%r14), %rcx
180006214:     	leaq	-0x1(%rcx), %rax
180006218:     	movq	%rax, 0x8(%r14)
18000621c:     	movq	0x38(%r15,%r13,8), %rax
180006221:     	testq	%rax, %rax
180006224:     	js	0x1800063b5 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3e25>
18000622a:     	movq	%rcx, 0x8(%r14)
18000622e:     	cmpq	0x10(%r14), %rcx
180006232:     	jg	0x1800063b5 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3e25>
180006238:     	movq	0x48(%rsp), %rcx
18000623d:     	movq	%rcx, 0x28(%rsp)
180006242:     	movq	%rax, 0x20(%rsp)
180006247:     	movq	$-0x1, 0x30(%rsp)
180006250:     	leaq	0x44(%rsp), %rcx
180006255:     	leaq	0x88(%rsp), %rdx
18000625d:     	movq	%rsi, %r8
180006260:     	xorl	%r9d, %r9d
180006263:     	callq	0x180004fe0 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2a50>
180006268:     	testl	%eax, %eax
18000626a:     	jne	0x1800063c5 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3e35>
180006270:     	cmpb	$0x0, (%rbx)
180006273:     	jne	0x180005c4f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x36bf>
180006279:     	movq	0x8(%r14), %rcx
18000627d:     	leaq	-0x1(%rcx), %rax
180006281:     	movq	%rax, 0x8(%r14)
180006285:     	movq	0x40(%r15,%r13,8), %rax
18000628a:     	testq	%rax, %rax
18000628d:     	js	0x1800063cf <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3e3f>
180006293:     	movq	%rcx, 0x8(%r14)
180006297:     	cmpq	0x10(%r14), %rcx
18000629b:     	jg	0x1800063cf <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3e3f>
1800062a1:     	movq	0x48(%rsp), %rcx
1800062a6:     	movq	%rcx, 0x28(%rsp)
1800062ab:     	movq	%rax, 0x20(%rsp)
1800062b0:     	movq	$-0x1, 0x30(%rsp)
1800062b9:     	leaq	0x43(%rsp), %rcx
1800062be:     	leaq	0x80(%rsp), %rdx
1800062c6:     	movq	%rsi, %r8
1800062c9:     	xorl	%r9d, %r9d
1800062cc:     	callq	0x180004fe0 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2a50>
1800062d1:     	testl	%eax, %eax
1800062d3:     	jne	0x1800063df <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3e4f>
1800062d9:     	cmpb	$0x0, (%rbx)
1800062dc:     	jne	0x180005c4f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x36bf>
1800062e2:     	movq	0x50(%rsp), %rdx
1800062e7:     	incq	%rdx
1800062ea:     	decq	0x8(%r14)
1800062ee:     	movq	0x60(%rsp), %rax
1800062f3:     	movq	%rdx, 0x50(%rsp)
1800062f8:     	cmpq	(%r15,%rax,8), %rdx
1800062fc:     	jl	0x180006126 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3b96>
180006302:     	movq	(%r14), %rcx
180006305:     	cmpq	%r12, %rcx
180006308:     	movq	%rcx, %rdx
18000630b:     	jle	0x180006315 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3d85>
18000630d:     	movb	$0x2, (%rbx)
180006310:     	movq	(%r14), %rcx
180006313:     	xorl	%edx, %edx
180006315:     	leaq	0x3(%rcx), %rax
180006319:     	cmpq	%r12, %rax
18000631c:     	jg	0x180005ba1 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3611>
180006322:     	movq	%rax, (%r14)
180006325:     	cmpb	$0x0, (%rbx)
180006328:     	jne	0x180005c4f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x36bf>
18000632e:     	movq	%rcx, %rax
180006331:     	sarq	$0x3f, %rax
180006335:     	andq	%r12, %rax
180006338:     	leaq	(%r15,%rcx,8), %r8
18000633c:     	movq	$0x0, (%r8,%rax,8)
180006344:     	xorl	%eax, %eax
180006346:     	cmpq	$-0x1, %rcx
18000634a:     	movl	$0x0, %r9d
180006350:     	cmovlq	%r12, %r9
180006354:     	movq	$0x0, 0x8(%r8,%r9,8)
18000635d:     	cmpq	$-0x2, %rcx
180006361:     	cmovgeq	%rax, %r12
180006365:     	movq	%rdx, 0x10(%r8,%r12,8)
18000636a:     	cmpb	$0x0, (%rbx)
18000636d:     	jne	0x180005c4f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x36bf>
180006373:     	movq	%rcx, 0x30(%r15,%r13,8)
180006378:     	movb	$0x0, (%rbp)
18000637c:     	jmp	0x18000553a <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2faa>
180006381:     	movb	$0x1, (%rbx)
180006384:     	movq	$0x989697, 0x18(%r14)   # imm = 0x989697
18000638c:     	jmp	0x180005c4f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x36bf>
180006391:     	movq	0x98(%rsp), %rcx
180006399:     	jmp	0x1800063e7 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3e57>
18000639b:     	movb	$0x1, (%rbx)
18000639e:     	movq	$0x989698, 0x18(%r14)   # imm = 0x989698
1800063a6:     	jmp	0x180005c4f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x36bf>
1800063ab:     	movq	0x90(%rsp), %rcx
1800063b3:     	jmp	0x1800063e7 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3e57>
1800063b5:     	movb	$0x1, (%rbx)
1800063b8:     	movq	$0x989699, 0x18(%r14)   # imm = 0x989699
1800063c0:     	jmp	0x180005c4f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x36bf>
1800063c5:     	movq	0x88(%rsp), %rcx
1800063cd:     	jmp	0x1800063e7 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3e57>
1800063cf:     	movb	$0x1, (%rbx)
1800063d2:     	movq	$0x98969a, 0x18(%r14)   # imm = 0x98969A
1800063da:     	jmp	0x180005c4f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x36bf>
1800063df:     	movq	0x80(%rsp), %rcx
1800063e7:     	movq	%rcx, (%rdi)
1800063ea:     	jmp	0x18000553a <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x2faa>
1800063ef:     	int3
1800063f0:     	pushq	%rbx
1800063f2:     	subq	$0x20, %rsp
1800063f6:     	movq	%rcx, %rbx
1800063f9:     	callq	*0x3cf1(%rip)           # 0x18000a0f0
1800063ff:     	movl	%eax, (%rbx)
180006401:     	addq	$0x20, %rsp
180006405:     	popq	%rbx
180006406:     	retq
180006407:     	int3
180006408:     	int3
180006409:     	int3
18000640a:     	int3
18000640b:     	int3
18000640c:     	int3
18000640d:     	int3
18000640e:     	int3
18000640f:     	int3
180006410:     	movl	(%rcx), %ecx
180006412:     	jmpq	*0x3df7(%rip)           # 0x18000a210
180006419:     	int3
18000641a:     	int3
18000641b:     	int3
18000641c:     	int3
18000641d:     	int3
18000641e:     	int3
18000641f:     	int3
180006420:     	pushq	%rbp
180006422:     	pushq	%rbx
180006423:     	pushq	%rsi
180006424:     	pushq	%rdi
180006425:     	pushq	%r14
180006427:     	pushq	%r15
180006429:     	movq	%rsp, %rbp
18000642c:     	subq	$0x48, %rsp
180006430:     	movq	0x3da9(%rip), %rax      # 0x18000a1e0
180006437:     	xorl	%r15d, %r15d
18000643a:     	movq	%rcx, %rsi
18000643d:     	movq	%r15, 0x38(%rbp)
180006441:     	movl	%r15d, %r14d
180006444:     	movq	%r15, 0x50(%rbp)
180006448:     	movq	%r15, 0x48(%rbp)
18000644c:     	cmpq	%rax, 0x8(%rcx)
180006450:     	jne	0x1800065be <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x402e>
180006456:     	leaq	0x48(%rbp), %rax
18000645a:     	leaq	0x50(%rbp), %r9
18000645e:     	movq	%rax, 0x20(%rsp)
180006463:     	leaq	0x38(%rbp), %r8
180006467:     	leaq	0x4cb6(%rip), %rdx      # 0x18000b124
18000646e:     	callq	*0x3cbc(%rip)           # 0x18000a130
180006474:     	testl	%eax, %eax
180006476:     	jne	0x1800065b4 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4024>
18000647c:     	movq	0x48(%rbp), %rbx
180006480:     	testq	%rbx, %rbx
180006483:     	je	0x1800065a5 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4015>
180006489:     	cmpq	0x3e40(%rip), %rbx      # 0x18000a2d0
180006490:     	je	0x1800065a5 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4015>
180006496:     	movq	0x8(%rbx), %rax
18000649a:     	testl	$0x4000000, 0xa8(%rax)  # imm = 0x4000000
1800064a4:     	je	0x1800065a5 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4015>
1800064aa:     	movq	0x20(%rbx), %rcx
1800064ae:     	callq	*0x3ccc(%rip)           # 0x18000a180
1800064b4:     	movq	0x28(%rbx), %rcx
1800064b8:     	movq	%rax, %rdi
1800064bb:     	callq	*0x3cbf(%rip)           # 0x18000a180
1800064c1:     	movq	0x30(%rbx), %rcx
1800064c5:     	movq	%rax, %r14
1800064c8:     	callq	*0x3cc2(%rip)           # 0x18000a190
1800064ce:     	leaq	-0x10(%rbp), %r8
1800064d2:     	movl	%eax, %ebx
1800064d4:     	leaq	-0x18(%rbp), %rdx
1800064d8:     	leaq	0x40(%rbp), %rcx
1800064dc:     	callq	*0x3cbe(%rip)           # 0x18000a1a0
1800064e2:     	callq	*0x3c78(%rip)           # 0x18000a160
1800064e8:     	movq	%rax, %rsi
1800064eb:     	testq	%rax, %rax
1800064ee:     	je	0x18000659b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x400b>
1800064f4:     	movl	%ebx, %r8d
1800064f7:     	movq	%rdi, %rdx
1800064fa:     	movq	%r14, %rcx
1800064fd:     	callq	*0x3d55(%rip)           # 0x18000a258
180006503:     	movq	%rax, %rdi
180006506:     	testq	%rax, %rax
180006509:     	je	0x18000659b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x400b>
18000650f:     	callq	*0x3d53(%rip)           # 0x18000a268
180006515:     	xorl	%r9d, %r9d
180006518:     	movq	%rsi, %r8
18000651b:     	movq	%rax, %rcx
18000651e:     	movq	%rdi, %rdx
180006521:     	callq	*0x3d19(%rip)           # 0x18000a240
180006527:     	movl	(%rsi), %ecx
180006529:     	movq	%rax, %rbx
18000652c:     	testl	%ecx, %ecx
18000652e:     	js	0x180006540 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3fb0>
180006530:     	subl	$0x1, %ecx
180006533:     	movl	%ecx, (%rsi)
180006535:     	jne	0x180006540 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3fb0>
180006537:     	movq	%rsi, %rcx
18000653a:     	callq	*0x3c88(%rip)           # 0x18000a1c8
180006540:     	movl	(%rdi), %eax
180006542:     	testl	%eax, %eax
180006544:     	js	0x180006556 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3fc6>
180006546:     	subl	$0x1, %eax
180006549:     	movl	%eax, (%rdi)
18000654b:     	jne	0x180006556 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x3fc6>
18000654d:     	movq	%rdi, %rcx
180006550:     	callq	*0x3c72(%rip)           # 0x18000a1c8
180006556:     	testq	%rbx, %rbx
180006559:     	je	0x18000659b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x400b>
18000655b:     	movq	-0x10(%rbp), %r8
18000655f:     	movq	-0x18(%rbp), %rdx
180006563:     	movq	0x40(%rbp), %rcx
180006567:     	callq	*0x3c63(%rip)           # 0x18000a1d0
18000656d:     	movq	%rbx, %rcx
180006570:     	callq	*0x3cb2(%rip)           # 0x18000a228
180006576:     	movl	(%rbx), %eax
180006578:     	testl	%eax, %eax
18000657a:     	js	0x1800065a5 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4015>
18000657c:     	subl	$0x1, %eax
18000657f:     	movl	%eax, (%rbx)
180006581:     	jne	0x1800065a5 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4015>
180006583:     	movq	%rbx, %rcx
180006586:     	callq	*0x3c3c(%rip)           # 0x18000a1c8
18000658c:     	xorl	%eax, %eax
18000658e:     	addq	$0x48, %rsp
180006592:     	popq	%r15
180006594:     	popq	%r14
180006596:     	popq	%rdi
180006597:     	popq	%rsi
180006598:     	popq	%rbx
180006599:     	popq	%rbp
18000659a:     	retq
18000659b:     	movq	0x40(%rbp), %rcx
18000659f:     	callq	*0x3c5b(%rip)           # 0x18000a200
1800065a5:     	xorl	%eax, %eax
1800065a7:     	addq	$0x48, %rsp
1800065ab:     	popq	%r15
1800065ad:     	popq	%r14
1800065af:     	popq	%rdi
1800065b0:     	popq	%rsi
1800065b1:     	popq	%rbx
1800065b2:     	popq	%rbp
1800065b3:     	retq
1800065b4:     	movq	0x38(%rbp), %rbx
1800065b8:     	movq	0x50(%rbp), %r14
1800065bc:     	jmp	0x1800065c5 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4035>
1800065be:     	movq	%rsi, %rbx
1800065c1:     	movq	%rbx, 0x38(%rbp)
1800065c5:     	cmpq	0x3d04(%rip), %rbx      # 0x18000a2d0
1800065cc:     	jne	0x180006664 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x40d4>
1800065d2:     	leaq	-0x18(%rbp), %r8
1800065d6:     	leaq	-0x10(%rbp), %rdx
1800065da:     	leaq	0x40(%rbp), %rcx
1800065de:     	callq	*0x3b3c(%rip)           # 0x18000a120
1800065e4:     	movq	0x3ce5(%rip), %rax      # 0x18000a2d0
1800065eb:     	cmpq	%rax, 0x40(%rbp)
1800065ef:     	jne	0x180006604 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4074>
1800065f1:     	movq	0x3cb8(%rip), %rcx      # 0x18000a2b0
1800065f8:     	leaq	0x4ad9(%rip), %rdx      # 0x18000b0d8
1800065ff:     	jmp	0x180006725 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4195>
180006604:     	movq	0x40(%rbp), %rcx
180006608:     	testq	%rcx, %rcx
18000660b:     	je	0x18000661a <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x408a>
18000660d:     	movl	(%rcx), %eax
18000660f:     	cmpl	$0xc0000000, %eax       # imm = 0xC0000000
180006614:     	jae	0x18000661a <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x408a>
180006616:     	incl	%eax
180006618:     	movl	%eax, (%rcx)
18000661a:     	movq	-0x10(%rbp), %rcx
18000661e:     	testq	%rcx, %rcx
180006621:     	je	0x180006630 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x40a0>
180006623:     	movl	(%rcx), %eax
180006625:     	cmpl	$0xc0000000, %eax       # imm = 0xC0000000
18000662a:     	jae	0x180006630 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x40a0>
18000662c:     	incl	%eax
18000662e:     	movl	%eax, (%rcx)
180006630:     	movq	-0x18(%rbp), %r8
180006634:     	testq	%r8, %r8
180006637:     	je	0x18000664c <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x40bc>
180006639:     	movl	(%r8), %eax
18000663c:     	cmpl	$0xc0000000, %eax       # imm = 0xC0000000
180006641:     	jae	0x18000664c <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x40bc>
180006643:     	incl	%eax
180006645:     	movl	%eax, (%r8)
180006648:     	movq	-0x18(%rbp), %r8
18000664c:     	movq	-0x10(%rbp), %rdx
180006650:     	movq	0x40(%rbp), %rcx
180006654:     	callq	*0x3b76(%rip)           # 0x18000a1d0
18000665a:     	movl	$0x1, %ebx
18000665f:     	jmp	0x180006731 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x41a1>
180006664:     	movq	0x8(%rbx), %rcx
180006668:     	movl	0xa8(%rcx), %eax
18000666e:     	testl	%eax, %eax
180006670:     	jns	0x180006706 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4176>
180006676:     	testl	$0x40000000, 0xa8(%rbx) # imm = 0x40000000
180006680:     	je	0x180006706 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4176>
180006686:     	movq	%r14, %rdx
180006689:     	movq	%rbx, %rcx
18000668c:     	callq	*0x3a56(%rip)           # 0x18000a0e8
180006692:     	movq	%rax, %rdi
180006695:     	testq	%rax, %rax
180006698:     	je	0x18000672e <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x419e>
18000669e:     	movq	0x8(%rax), %rax
1800066a2:     	testl	$0x40000000, 0xa8(%rax) # imm = 0x40000000
1800066ac:     	jne	0x1800066dd <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x414d>
1800066ae:     	movq	0x3beb(%rip), %rcx      # 0x18000a2a0
1800066b5:     	leaq	0x4a3c(%rip), %rdx      # 0x18000b0f8
1800066bc:     	movq	(%rcx), %rcx
1800066bf:     	callq	*0x3be3(%rip)           # 0x18000a2a8
1800066c5:     	movl	(%rdi), %eax
1800066c7:     	testl	%eax, %eax
1800066c9:     	js	0x18000672e <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x419e>
1800066cb:     	subl	$0x1, %eax
1800066ce:     	movl	%eax, (%rdi)
1800066d0:     	jne	0x18000672e <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x419e>
1800066d2:     	movq	%rdi, %rcx
1800066d5:     	callq	*0x3aed(%rip)           # 0x18000a1c8
1800066db:     	jmp	0x18000672e <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x419e>
1800066dd:     	movl	(%rdi), %eax
1800066df:     	testl	%eax, %eax
1800066e1:     	js	0x1800066f3 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4163>
1800066e3:     	subl	$0x1, %eax
1800066e6:     	movl	%eax, (%rdi)
1800066e8:     	jne	0x1800066f3 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4163>
1800066ea:     	movq	%rdi, %rcx
1800066ed:     	callq	*0x3ad5(%rip)           # 0x18000a1c8
1800066f3:     	movq	%r14, %rdx
1800066f6:     	movq	%rbx, %rcx
1800066f9:     	callq	*0x3b61(%rip)           # 0x18000a260
1800066ff:     	movl	$0x1, %ebx
180006704:     	jmp	0x180006731 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x41a1>
180006706:     	btl	$0x1e, %eax
18000670a:     	jae	0x180006717 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4187>
18000670c:     	movq	%rbx, %rdx
18000670f:     	callq	*0x3b4b(%rip)           # 0x18000a260
180006715:     	jmp	0x18000672e <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x419e>
180006717:     	movq	0x3b82(%rip), %rcx      # 0x18000a2a0
18000671e:     	leaq	0x49d3(%rip), %rdx      # 0x18000b0f8
180006725:     	movq	(%rcx), %rcx
180006728:     	callq	*0x3b7a(%rip)           # 0x18000a2a8
18000672e:     	movl	%r15d, %ebx
180006731:     	movq	0x48(%rbp), %rdi
180006735:     	testq	%rdi, %rdi
180006738:     	je	0x18000685b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x42cb>
18000673e:     	cmpq	0x3b8b(%rip), %rdi      # 0x18000a2d0
180006745:     	je	0x18000685b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x42cb>
18000674b:     	movq	0x8(%rdi), %rax
18000674f:     	testl	$0x4000000, 0xa8(%rax)  # imm = 0x4000000
180006759:     	je	0x18000685b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x42cb>
18000675f:     	movq	0x20(%rdi), %rcx
180006763:     	movq	%r12, 0x40(%rsp)
180006768:     	callq	*0x3a12(%rip)           # 0x18000a180
18000676e:     	movq	0x28(%rdi), %rcx
180006772:     	movq	%rax, %r14
180006775:     	callq	*0x3a05(%rip)           # 0x18000a180
18000677b:     	movq	0x30(%rdi), %rcx
18000677f:     	movq	%rax, %r12
180006782:     	callq	*0x3a08(%rip)           # 0x18000a190
180006788:     	leaq	-0x10(%rbp), %r8
18000678c:     	movl	%eax, %edi
18000678e:     	leaq	-0x18(%rbp), %rdx
180006792:     	leaq	0x40(%rbp), %rcx
180006796:     	callq	*0x3a04(%rip)           # 0x18000a1a0
18000679c:     	callq	*0x39be(%rip)           # 0x18000a160
1800067a2:     	movq	%rax, %r15
1800067a5:     	testq	%rax, %rax
1800067a8:     	je	0x18000684c <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x42bc>
1800067ae:     	movl	%edi, %r8d
1800067b1:     	movq	%r14, %rdx
1800067b4:     	movq	%r12, %rcx
1800067b7:     	callq	*0x3a9b(%rip)           # 0x18000a258
1800067bd:     	movq	%rax, %r14
1800067c0:     	testq	%rax, %rax
1800067c3:     	je	0x18000684c <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x42bc>
1800067c9:     	callq	*0x3a99(%rip)           # 0x18000a268
1800067cf:     	xorl	%r9d, %r9d
1800067d2:     	movq	%r15, %r8
1800067d5:     	movq	%rax, %rcx
1800067d8:     	movq	%r14, %rdx
1800067db:     	callq	*0x3a5f(%rip)           # 0x18000a240
1800067e1:     	movl	(%r15), %ecx
1800067e4:     	movq	%rax, %rdi
1800067e7:     	testl	%ecx, %ecx
1800067e9:     	js	0x1800067fc <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x426c>
1800067eb:     	subl	$0x1, %ecx
1800067ee:     	movl	%ecx, (%r15)
1800067f1:     	jne	0x1800067fc <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x426c>
1800067f3:     	movq	%r15, %rcx
1800067f6:     	callq	*0x39cc(%rip)           # 0x18000a1c8
1800067fc:     	movl	(%r14), %eax
1800067ff:     	testl	%eax, %eax
180006801:     	js	0x180006814 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4284>
180006803:     	subl	$0x1, %eax
180006806:     	movl	%eax, (%r14)
180006809:     	jne	0x180006814 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4284>
18000680b:     	movq	%r14, %rcx
18000680e:     	callq	*0x39b4(%rip)           # 0x18000a1c8
180006814:     	testq	%rdi, %rdi
180006817:     	je	0x18000684c <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x42bc>
180006819:     	movq	-0x10(%rbp), %r8
18000681d:     	movq	-0x18(%rbp), %rdx
180006821:     	movq	0x40(%rbp), %rcx
180006825:     	callq	*0x39a5(%rip)           # 0x18000a1d0
18000682b:     	movq	%rdi, %rcx
18000682e:     	callq	*0x39f4(%rip)           # 0x18000a228
180006834:     	movl	(%rdi), %eax
180006836:     	testl	%eax, %eax
180006838:     	js	0x180006856 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x42c6>
18000683a:     	subl	$0x1, %eax
18000683d:     	movl	%eax, (%rdi)
18000683f:     	jne	0x180006856 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x42c6>
180006841:     	movq	%rdi, %rcx
180006844:     	callq	*0x397e(%rip)           # 0x18000a1c8
18000684a:     	jmp	0x180006856 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x42c6>
18000684c:     	movq	0x40(%rbp), %rcx
180006850:     	callq	*0x39aa(%rip)           # 0x18000a200
180006856:     	movq	0x40(%rsp), %r12
18000685b:     	movl	(%rsi), %ecx
18000685d:     	testl	%ecx, %ecx
18000685f:     	js	0x180006871 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x42e1>
180006861:     	subl	$0x1, %ecx
180006864:     	movl	%ecx, (%rsi)
180006866:     	jne	0x180006871 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x42e1>
180006868:     	movq	%rsi, %rcx
18000686b:     	callq	*0x3957(%rip)           # 0x18000a1c8
180006871:     	movl	%ebx, %eax
180006873:     	addq	$0x48, %rsp
180006877:     	popq	%r15
180006879:     	popq	%r14
18000687b:     	popq	%rdi
18000687c:     	popq	%rsi
18000687d:     	popq	%rbx
18000687e:     	popq	%rbp
18000687f:     	retq
180006880:     	movq	%rbx, 0x8(%rsp)
180006885:     	movq	%rsi, 0x10(%rsp)
18000688a:     	pushq	%rdi
18000688b:     	subq	$0x20, %rsp
18000688f:     	cmpq	$0x0, 0xb401(%rip)      # 0x180011c98
180006897:     	movq	%rcx, %rsi
18000689a:     	movslq	%edx, %rdi
18000689d:     	jne	0x1800068ed <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x435d>
18000689f:     	leaq	0x4882(%rip), %rcx      # 0x18000b128
1800068a6:     	callq	*0x398c(%rip)           # 0x18000a238
1800068ac:     	movq	%rax, %rbx
1800068af:     	testq	%rax, %rax
1800068b2:     	je	0x180006901 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4371>
1800068b4:     	leaq	0x4875(%rip), %rdx      # 0x18000b130
1800068bb:     	movq	%rax, %rcx
1800068be:     	callq	*0x38a4(%rip)           # 0x18000a168
1800068c4:     	movl	(%rbx), %ecx
1800068c6:     	movq	%rax, 0xb3cb(%rip)      # 0x180011c98
1800068cd:     	testl	%ecx, %ecx
1800068cf:     	js	0x1800068e8 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4358>
1800068d1:     	subl	$0x1, %ecx
1800068d4:     	movl	%ecx, (%rbx)
1800068d6:     	jne	0x1800068e8 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4358>
1800068d8:     	movq	%rbx, %rcx
1800068db:     	callq	*0x38e7(%rip)           # 0x18000a1c8
1800068e1:     	movq	0xb3b0(%rip), %rax      # 0x180011c98
1800068e8:     	testq	%rax, %rax
1800068eb:     	je	0x180006901 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4371>
1800068ed:     	movq	%rdi, %rdx
1800068f0:     	movq	%rsi, %rcx
1800068f3:     	callq	*0x39bf(%rip)           # 0x18000a2b8
1800068f9:     	movq	%rax, %rbx
1800068fc:     	testq	%rax, %rax
1800068ff:     	jne	0x180006913 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4383>
180006901:     	xorl	%eax, %eax
180006903:     	movq	0x30(%rsp), %rbx
180006908:     	movq	0x38(%rsp), %rsi
18000690d:     	addq	$0x20, %rsp
180006911:     	popq	%rdi
180006912:     	retq
180006913:     	movq	0xb37e(%rip), %rcx      # 0x180011c98
18000691a:     	xorl	%r8d, %r8d
18000691d:     	movq	%rbx, %rdx
180006920:     	callq	*0x3872(%rip)           # 0x18000a198
180006926:     	movl	(%rbx), %ecx
180006928:     	movq	%rax, %rdi
18000692b:     	testl	%ecx, %ecx
18000692d:     	js	0x18000693f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x43af>
18000692f:     	subl	$0x1, %ecx
180006932:     	movl	%ecx, (%rbx)
180006934:     	jne	0x18000693f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x43af>
180006936:     	movq	%rbx, %rcx
180006939:     	callq	*0x3889(%rip)           # 0x18000a1c8
18000693f:     	movq	0x30(%rsp), %rbx
180006944:     	movq	%rdi, %rax
180006947:     	movq	0x38(%rsp), %rsi
18000694c:     	addq	$0x20, %rsp
180006950:     	popq	%rdi
180006951:     	retq
180006952:     	int3
180006953:     	int3
180006954:     	int3
180006955:     	int3
180006956:     	int3
180006957:     	int3
180006958:     	int3
180006959:     	int3
18000695a:     	int3
18000695b:     	int3
18000695c:     	int3
18000695d:     	int3
18000695e:     	int3
18000695f:     	int3
180006960:     	movq	%rbx, 0x8(%rsp)
180006965:     	movq	%rsi, 0x10(%rsp)
18000696a:     	pushq	%rdi
18000696b:     	subq	$0x20, %rsp
18000696f:     	movq	0xb31a(%rip), %rax      # 0x180011c90
180006976:     	movq	%rdx, %rdi
180006979:     	movq	%rcx, %rsi
18000697c:     	testq	%rax, %rax
18000697f:     	jne	0x1800069e1 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4451>
180006981:     	leaq	0x47b0(%rip), %rcx      # 0x18000b138
180006988:     	callq	*0x38aa(%rip)           # 0x18000a238
18000698e:     	movq	%rax, %rbx
180006991:     	testq	%rax, %rax
180006994:     	je	0x1800069cf <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x443f>
180006996:     	leaq	0x47b3(%rip), %rdx      # 0x18000b150
18000699d:     	movq	%rax, %rcx
1800069a0:     	callq	*0x37c2(%rip)           # 0x18000a168
1800069a6:     	movl	(%rbx), %ecx
1800069a8:     	movq	%rax, 0xb2e1(%rip)      # 0x180011c90
1800069af:     	testl	%ecx, %ecx
1800069b1:     	js	0x1800069ca <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x443a>
1800069b3:     	subl	$0x1, %ecx
1800069b6:     	movl	%ecx, (%rbx)
1800069b8:     	jne	0x1800069ca <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x443a>
1800069ba:     	movq	%rbx, %rcx
1800069bd:     	callq	*0x3805(%rip)           # 0x18000a1c8
1800069c3:     	movq	0xb2c6(%rip), %rax      # 0x180011c90
1800069ca:     	testq	%rax, %rax
1800069cd:     	jne	0x1800069e1 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4451>
1800069cf:     	xorl	%eax, %eax
1800069d1:     	movq	0x30(%rsp), %rbx
1800069d6:     	movq	0x38(%rsp), %rsi
1800069db:     	addq	$0x20, %rsp
1800069df:     	popq	%rdi
1800069e0:     	retq
1800069e1:     	xorl	%r9d, %r9d
1800069e4:     	movq	%rdi, %r8
1800069e7:     	movq	%rsi, %rdx
1800069ea:     	movq	%rax, %rcx
1800069ed:     	movq	0x30(%rsp), %rbx
1800069f2:     	movq	0x38(%rsp), %rsi
1800069f7:     	addq	$0x20, %rsp
1800069fb:     	popq	%rdi
1800069fc:     	jmpq	*0x3795(%rip)           # 0x18000a198
180006a03:     	int3
180006a04:     	int3
180006a05:     	int3
180006a06:     	int3
180006a07:     	int3
180006a08:     	int3
180006a09:     	int3
180006a0a:     	int3
180006a0b:     	int3
180006a0c:     	int3
180006a0d:     	int3
180006a0e:     	int3
180006a0f:     	int3
180006a10:     	movq	%rbx, 0x8(%rsp)
180006a15:     	movq	%rsi, 0x10(%rsp)
180006a1a:     	pushq	%rdi
180006a1b:     	subq	$0x20, %rsp
180006a1f:     	movq	%rcx, %rbx
180006a22:     	movq	%r8, %rdi
180006a25:     	movq	0x10(%rcx), %rcx
180006a29:     	movq	%rdx, %rsi
180006a2c:     	testq	%rcx, %rcx
180006a2f:     	je	0x180006a3a <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x44aa>
180006a31:     	movq	%r8, %rdx
180006a34:     	callq	*%rsi
180006a36:     	testl	%eax, %eax
180006a38:     	jne	0x180006a5d <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x44cd>
180006a3a:     	movq	0x18(%rbx), %rcx
180006a3e:     	testq	%rcx, %rcx
180006a41:     	je	0x180006a5b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x44cb>
180006a43:     	movq	%rdi, %rdx
180006a46:     	movq	%rsi, %rax
180006a49:     	movq	0x30(%rsp), %rbx
180006a4e:     	movq	0x38(%rsp), %rsi
180006a53:     	addq	$0x20, %rsp
180006a57:     	popq	%rdi
180006a58:     	jmpq	*%rax
180006a5b:     	xorl	%eax, %eax
180006a5d:     	movq	0x30(%rsp), %rbx
180006a62:     	movq	0x38(%rsp), %rsi
180006a67:     	addq	$0x20, %rsp
180006a6b:     	popq	%rdi
180006a6c:     	retq
180006a6d:     	int3
180006a6e:     	int3
180006a6f:     	int3
180006a70:     	pushq	%rbx
180006a72:     	subq	$0x20, %rsp
180006a76:     	movq	%rcx, %rbx
180006a79:     	movq	0x10(%rcx), %rcx
180006a7d:     	testq	%rcx, %rcx
180006a80:     	je	0x180006a9d <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x450d>
180006a82:     	movq	$0x0, 0x10(%rbx)
180006a8a:     	movl	(%rcx), %eax
180006a8c:     	testl	%eax, %eax
180006a8e:     	js	0x180006a9d <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x450d>
180006a90:     	subl	$0x1, %eax
180006a93:     	movl	%eax, (%rcx)
180006a95:     	jne	0x180006a9d <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x450d>
180006a97:     	callq	*0x372b(%rip)           # 0x18000a1c8
180006a9d:     	movq	0x18(%rbx), %rcx
180006aa1:     	testq	%rcx, %rcx
180006aa4:     	je	0x180006ac1 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4531>
180006aa6:     	movq	$0x0, 0x18(%rbx)
180006aae:     	movl	(%rcx), %eax
180006ab0:     	testl	%eax, %eax
180006ab2:     	js	0x180006ac1 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4531>
180006ab4:     	subl	$0x1, %eax
180006ab7:     	movl	%eax, (%rcx)
180006ab9:     	jne	0x180006ac1 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4531>
180006abb:     	callq	*0x3707(%rip)           # 0x18000a1c8
180006ac1:     	xorl	%eax, %eax
180006ac3:     	addq	$0x20, %rsp
180006ac7:     	popq	%rbx
180006ac8:     	retq
180006ac9:     	int3
180006aca:     	int3
180006acb:     	int3
180006acc:     	int3
180006acd:     	int3
180006ace:     	int3
180006acf:     	int3
180006ad0:     	pushq	%rbx
180006ad2:     	subq	$0x20, %rsp
180006ad6:     	movq	%rcx, %rbx
180006ad9:     	callq	*0x3739(%rip)           # 0x18000a218
180006adf:     	movq	0x10(%rbx), %rcx
180006ae3:     	testq	%rcx, %rcx
180006ae6:     	je	0x180006b03 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4573>
180006ae8:     	movq	$0x0, 0x10(%rbx)
180006af0:     	movl	(%rcx), %eax
180006af2:     	testl	%eax, %eax
180006af4:     	js	0x180006b03 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4573>
180006af6:     	subl	$0x1, %eax
180006af9:     	movl	%eax, (%rcx)
180006afb:     	jne	0x180006b03 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4573>
180006afd:     	callq	*0x36c5(%rip)           # 0x18000a1c8
180006b03:     	movq	0x18(%rbx), %rcx
180006b07:     	testq	%rcx, %rcx
180006b0a:     	je	0x180006b27 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4597>
180006b0c:     	movq	$0x0, 0x18(%rbx)
180006b14:     	movl	(%rcx), %eax
180006b16:     	testl	%eax, %eax
180006b18:     	js	0x180006b27 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4597>
180006b1a:     	subl	$0x1, %eax
180006b1d:     	movl	%eax, (%rcx)
180006b1f:     	jne	0x180006b27 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4597>
180006b21:     	callq	*0x36a1(%rip)           # 0x18000a1c8
180006b27:     	movq	0x8(%rbx), %rax
180006b2b:     	movq	%rbx, %rcx
180006b2e:     	addq	$0x20, %rsp
180006b32:     	popq	%rbx
180006b33:     	jmpq	*0x140(%rax)
180006b3a:     	int3
180006b3b:     	int3
180006b3c:     	int3
180006b3d:     	int3
180006b3e:     	int3
180006b3f:     	int3
180006b40:     	pushq	%rbx
180006b42:     	subq	$0x30, %rsp
180006b46:     	movq	%r8, %r10
180006b49:     	leaq	0x58(%rsp), %rax
180006b4e:     	movq	%rax, 0x28(%rsp)
180006b53:     	leaq	0xae76(%rip), %r9       # 0x1800119d0
180006b5a:     	movq	0x3687(%rip), %rax      # 0x18000a1e8
180006b61:     	leaq	0x4618(%rip), %r8       # 0x18000b180
180006b68:     	movq	%rdx, %r11
180006b6b:     	movq	%rax, 0x20(%rsp)
180006b70:     	movq	%rcx, %rbx
180006b73:     	movq	%r10, %rdx
180006b76:     	movq	%r11, %rcx
180006b79:     	callq	*0x3579(%rip)           # 0x18000a0f8
180006b7f:     	testl	%eax, %eax
180006b81:     	je	0x180006bdc <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x464c>
180006b83:     	xorl	%r8d, %r8d
180006b86:     	xorl	%edx, %edx
180006b88:     	movq	%rbx, %rcx
180006b8b:     	callq	*0x36b7(%rip)           # 0x18000a248
180006b91:     	movq	%rax, %rbx
180006b94:     	testq	%rax, %rax
180006b97:     	je	0x180006bdc <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x464c>
180006b99:     	movq	0x58(%rsp), %rax
180006b9e:     	movl	(%rax), %ecx
180006ba0:     	cmpl	$0xc0000000, %ecx       # imm = 0xC0000000
180006ba6:     	jae	0x180006bb1 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4621>
180006ba8:     	incl	%ecx
180006baa:     	movl	%ecx, (%rax)
180006bac:     	movq	0x58(%rsp), %rax
180006bb1:     	xorl	%ecx, %ecx
180006bb3:     	movq	%rax, 0x10(%rbx)
180006bb7:     	callq	*0x35bb(%rip)           # 0x18000a178
180006bbd:     	movq	%rax, 0x18(%rbx)
180006bc1:     	testq	%rax, %rax
180006bc4:     	jne	0x180006be4 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4654>
180006bc6:     	movl	(%rbx), %eax
180006bc8:     	testl	%eax, %eax
180006bca:     	js	0x180006bdc <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x464c>
180006bcc:     	subl	$0x1, %eax
180006bcf:     	movl	%eax, (%rbx)
180006bd1:     	jne	0x180006bdc <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x464c>
180006bd3:     	movq	%rbx, %rcx
180006bd6:     	callq	*0x35ec(%rip)           # 0x18000a1c8
180006bdc:     	xorl	%eax, %eax
180006bde:     	addq	$0x30, %rsp
180006be2:     	popq	%rbx
180006be3:     	retq
180006be4:     	movq	%rbx, %rax
180006be7:     	addq	$0x30, %rsp
180006beb:     	popq	%rbx
180006bec:     	retq
180006bed:     	int3
180006bee:     	int3
180006bef:     	int3
180006bf0:     	movq	%rbx, 0x8(%rsp)
180006bf5:     	movq	%rsi, 0x10(%rsp)
180006bfa:     	pushq	%rdi
180006bfb:     	subq	$0x20, %rsp
180006bff:     	movq	%rcx, %rbx
180006c02:     	movq	%r8, %rdi
180006c05:     	movq	0x18(%rcx), %rcx
180006c09:     	movq	%rdx, %rsi
180006c0c:     	testq	%rcx, %rcx
180006c0f:     	je	0x180006c1a <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x468a>
180006c11:     	movq	%r8, %rdx
180006c14:     	callq	*%rsi
180006c16:     	testl	%eax, %eax
180006c18:     	jne	0x180006c3d <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x46ad>
180006c1a:     	movq	0x40(%rbx), %rcx
180006c1e:     	testq	%rcx, %rcx
180006c21:     	je	0x180006c3b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x46ab>
180006c23:     	movq	%rdi, %rdx
180006c26:     	movq	%rsi, %rax
180006c29:     	movq	0x30(%rsp), %rbx
180006c2e:     	movq	0x38(%rsp), %rsi
180006c33:     	addq	$0x20, %rsp
180006c37:     	popq	%rdi
180006c38:     	jmpq	*%rax
180006c3b:     	xorl	%eax, %eax
180006c3d:     	movq	0x30(%rsp), %rbx
180006c42:     	movq	0x38(%rsp), %rsi
180006c47:     	addq	$0x20, %rsp
180006c4b:     	popq	%rdi
180006c4c:     	retq
180006c4d:     	int3
180006c4e:     	int3
180006c4f:     	int3
180006c50:     	pushq	%rbx
180006c52:     	subq	$0x20, %rsp
180006c56:     	movq	%rcx, %rbx
180006c59:     	callq	*0x35b9(%rip)           # 0x18000a218
180006c5f:     	cmpq	$0x0, 0x48(%rbx)
180006c64:     	je	0x180006c6f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x46df>
180006c66:     	movq	%rbx, %rcx
180006c69:     	callq	*0x3519(%rip)           # 0x18000a188
180006c6f:     	movq	0x20(%rbx), %rcx
180006c73:     	callq	*0x353f(%rip)           # 0x18000a1b8
180006c79:     	movq	0x38(%rbx), %rcx
180006c7d:     	callq	*0x3535(%rip)           # 0x18000a1b8
180006c83:     	movq	0x18(%rbx), %rcx
180006c87:     	testq	%rcx, %rcx
180006c8a:     	je	0x180006c9f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x470f>
180006c8c:     	movl	(%rcx), %eax
180006c8e:     	testl	%eax, %eax
180006c90:     	js	0x180006c9f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x470f>
180006c92:     	subl	$0x1, %eax
180006c95:     	movl	%eax, (%rcx)
180006c97:     	jne	0x180006c9f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x470f>
180006c99:     	callq	*0x3529(%rip)           # 0x18000a1c8
180006c9f:     	movq	0x40(%rbx), %rcx
180006ca3:     	testq	%rcx, %rcx
180006ca6:     	je	0x180006cbb <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x472b>
180006ca8:     	movl	(%rcx), %eax
180006caa:     	testl	%eax, %eax
180006cac:     	js	0x180006cbb <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x472b>
180006cae:     	subl	$0x1, %eax
180006cb1:     	movl	%eax, (%rcx)
180006cb3:     	jne	0x180006cbb <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x472b>
180006cb5:     	callq	*0x350d(%rip)           # 0x18000a1c8
180006cbb:     	movq	0x8(%rbx), %rax
180006cbf:     	movq	%rbx, %rcx
180006cc2:     	addq	$0x20, %rsp
180006cc6:     	popq	%rbx
180006cc7:     	jmpq	*0x140(%rax)
180006cce:     	int3
180006ccf:     	int3
180006cd0:     	pushq	%rbx
180006cd2:     	subq	$0x20, %rsp
180006cd6:     	callq	*0x34a4(%rip)           # 0x18000a180
180006cdc:     	movq	%rax, %rbx
180006cdf:     	testq	%rax, %rax
180006ce2:     	jne	0x180006cea <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x475a>
180006ce4:     	addq	$0x20, %rsp
180006ce8:     	popq	%rbx
180006ce9:     	retq
180006cea:     	movq	%rbx, %rcx
180006ced:     	movq	%rdi, 0x30(%rsp)
180006cf2:     	callq	0x180009055 <numba_list_iter_next+0xed5>
180006cf7:     	leaq	0x1(%rax), %rcx
180006cfb:     	callq	*0x354f(%rip)           # 0x18000a250
180006d01:     	movq	%rax, %rdi
180006d04:     	testq	%rax, %rax
180006d07:     	jne	0x180006d1c <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x478c>
180006d09:     	callq	*0x3431(%rip)           # 0x18000a140
180006d0f:     	movq	0x30(%rsp), %rdi
180006d14:     	xorl	%eax, %eax
180006d16:     	addq	$0x20, %rsp
180006d1a:     	popq	%rbx
180006d1b:     	retq
180006d1c:     	movq	%rbx, %rdx
180006d1f:     	movq	%rdi, %rcx
180006d22:     	callq	0x18000904f <numba_list_iter_next+0xecf>
180006d27:     	movq	%rdi, %rax
180006d2a:     	movq	0x30(%rsp), %rdi
180006d2f:     	addq	$0x20, %rsp
180006d33:     	popq	%rbx
180006d34:     	retq
180006d35:     	int3
180006d36:     	int3
180006d37:     	int3
180006d38:     	int3
180006d39:     	int3
180006d3a:     	int3
180006d3b:     	int3
180006d3c:     	int3
180006d3d:     	int3
180006d3e:     	int3
180006d3f:     	int3
180006d40:     	movq	0x18(%rcx), %rcx
180006d44:     	movq	%rdx, %rax
180006d47:     	testq	%rcx, %rcx
180006d4a:     	je	0x180006d52 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x47c2>
180006d4c:     	movq	%r8, %rdx
180006d4f:     	jmpq	*%rax
180006d52:     	xorl	%eax, %eax
180006d54:     	retq
180006d55:     	int3
180006d56:     	int3
180006d57:     	int3
180006d58:     	int3
180006d59:     	int3
180006d5a:     	int3
180006d5b:     	int3
180006d5c:     	int3
180006d5d:     	int3
180006d5e:     	int3
180006d5f:     	int3
180006d60:     	movq	%rbx, 0x8(%rsp)
180006d65:     	pushq	%rdi
180006d66:     	subq	$0x20, %rsp
180006d6a:     	movq	0x28(%rcx), %rax
180006d6e:     	xorl	%edi, %edi
180006d70:     	movq	%rcx, %rbx
180006d73:     	testq	%rax, %rax
180006d76:     	je	0x180006d82 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x47f2>
180006d78:     	addq	$0x38, %rcx
180006d7c:     	callq	*%rax
180006d7e:     	movq	%rdi, 0x28(%rbx)
180006d82:     	movq	0x18(%rbx), %rcx
180006d86:     	testq	%rcx, %rcx
180006d89:     	je	0x180006da2 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4812>
180006d8b:     	movq	%rdi, 0x18(%rbx)
180006d8f:     	movl	(%rcx), %eax
180006d91:     	testl	%eax, %eax
180006d93:     	js	0x180006da2 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4812>
180006d95:     	subl	$0x1, %eax
180006d98:     	movl	%eax, (%rcx)
180006d9a:     	jne	0x180006da2 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4812>
180006d9c:     	callq	*0x3426(%rip)           # 0x18000a1c8
180006da2:     	movq	%rdi, 0x20(%rbx)
180006da6:     	xorl	%eax, %eax
180006da8:     	movq	0x30(%rsp), %rbx
180006dad:     	addq	$0x20, %rsp
180006db1:     	popq	%rdi
180006db2:     	retq
180006db3:     	int3
180006db4:     	int3
180006db5:     	int3
180006db6:     	int3
180006db7:     	int3
180006db8:     	int3
180006db9:     	int3
180006dba:     	int3
180006dbb:     	int3
180006dbc:     	int3
180006dbd:     	int3
180006dbe:     	int3
180006dbf:     	int3
180006dc0:     	pushq	%rbx
180006dc2:     	subq	$0x20, %rsp
180006dc6:     	movq	%rcx, %rbx
180006dc9:     	callq	*0x3449(%rip)           # 0x18000a218
180006dcf:     	cmpq	$0x0, 0x30(%rbx)
180006dd4:     	je	0x180006ddf <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x484f>
180006dd6:     	movq	%rbx, %rcx
180006dd9:     	callq	*0x33a9(%rip)           # 0x18000a188
180006ddf:     	callq	*0x3323(%rip)           # 0x18000a108
180006de5:     	testl	%eax, %eax
180006de7:     	jne	0x180006df8 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4868>
180006de9:     	movq	0x28(%rbx), %rax
180006ded:     	testq	%rax, %rax
180006df0:     	je	0x180006df8 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4868>
180006df2:     	leaq	0x38(%rbx), %rcx
180006df6:     	callq	*%rax
180006df8:     	movq	0x18(%rbx), %rcx
180006dfc:     	testq	%rcx, %rcx
180006dff:     	je	0x180006e14 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4884>
180006e01:     	movl	(%rcx), %eax
180006e03:     	testl	%eax, %eax
180006e05:     	js	0x180006e14 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4884>
180006e07:     	subl	$0x1, %eax
180006e0a:     	movl	%eax, (%rcx)
180006e0c:     	jne	0x180006e14 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4884>
180006e0e:     	callq	*0x33b4(%rip)           # 0x18000a1c8
180006e14:     	movq	0x8(%rbx), %rax
180006e18:     	movq	%rbx, %rcx
180006e1b:     	addq	$0x20, %rsp
180006e1f:     	popq	%rbx
180006e20:     	jmpq	*0x140(%rax)
180006e27:     	int3
180006e28:     	int3
180006e29:     	int3
180006e2a:     	int3
180006e2b:     	int3
180006e2c:     	int3
180006e2d:     	int3
180006e2e:     	int3
180006e2f:     	int3
180006e30:     	pushq	%rdi
180006e32:     	subq	$0x20, %rsp
180006e36:     	cmpq	$0x0, 0x20(%rcx)
180006e3b:     	movq	%rcx, %rdi
180006e3e:     	jne	0x180006e5f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x48cf>
180006e40:     	movq	0x3469(%rip), %rcx      # 0x18000a2b0
180006e47:     	leaq	0x4382(%rip), %rdx      # 0x18000b1d0
180006e4e:     	movq	(%rcx), %rcx
180006e51:     	callq	*0x3451(%rip)           # 0x18000a2a8
180006e57:     	xorl	%eax, %eax
180006e59:     	addq	$0x20, %rsp
180006e5d:     	popq	%rdi
180006e5e:     	retq
180006e5f:     	movq	%rdi, %rdx
180006e62:     	movq	%rbx, 0x30(%rsp)
180006e67:     	movl	$0x1, %ecx
180006e6c:     	callq	*0x3496(%rip)           # 0x18000a308
180006e72:     	movq	%rax, %rbx
180006e75:     	testq	%rax, %rax
180006e78:     	jne	0x180006e85 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x48f5>
180006e7a:     	movq	0x30(%rsp), %rbx
180006e7f:     	addq	$0x20, %rsp
180006e83:     	popq	%rdi
180006e84:     	retq
180006e85:     	xorl	%r8d, %r8d
180006e88:     	movq	%rbx, %rdx
180006e8b:     	movq	%rdi, %rcx
180006e8e:     	callq	*0x20(%rdi)
180006e91:     	movl	(%rbx), %ecx
180006e93:     	movq	%rax, %rdi
180006e96:     	testl	%ecx, %ecx
180006e98:     	js	0x180006eaa <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x491a>
180006e9a:     	subl	$0x1, %ecx
180006e9d:     	movl	%ecx, (%rbx)
180006e9f:     	jne	0x180006eaa <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x491a>
180006ea1:     	movq	%rbx, %rcx
180006ea4:     	callq	*0x331e(%rip)           # 0x18000a1c8
180006eaa:     	movq	0x30(%rsp), %rbx
180006eaf:     	movq	%rdi, %rax
180006eb2:     	addq	$0x20, %rsp
180006eb6:     	popq	%rdi
180006eb7:     	retq
180006eb8:     	int3
180006eb9:     	int3
180006eba:     	int3
180006ebb:     	int3
180006ebc:     	int3
180006ebd:     	int3
180006ebe:     	int3
180006ebf:     	int3
180006ec0:     	movq	%rbx, 0x8(%rsp)
180006ec5:     	pushq	%rdi
180006ec6:     	subq	$0x20, %rsp
180006eca:     	movq	%r8, %rbx
180006ecd:     	callq	*0x321d(%rip)           # 0x18000a0f0
180006ed3:     	movl	(%rbx), %ecx
180006ed5:     	movl	%eax, %edi
180006ed7:     	testl	%ecx, %ecx
180006ed9:     	js	0x180006eeb <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x495b>
180006edb:     	subl	$0x1, %ecx
180006ede:     	movl	%ecx, (%rbx)
180006ee0:     	jne	0x180006eeb <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x495b>
180006ee2:     	movq	%rbx, %rcx
180006ee5:     	callq	*0x32dd(%rip)           # 0x18000a1c8
180006eeb:     	movl	%edi, %ecx
180006eed:     	movq	0x30(%rsp), %rbx
180006ef2:     	addq	$0x20, %rsp
180006ef6:     	popq	%rdi
180006ef7:     	jmpq	*0x3312(%rip)           # 0x18000a210
180006efe:     	int3
180006eff:     	int3
180006f00:     	movq	%rbx, 0x8(%rsp)
180006f05:     	pushq	%rdi
180006f06:     	subq	$0x20, %rsp
180006f0a:     	movl	(%rdx), %eax
180006f0c:     	movq	%rdx, %rbx
180006f0f:     	movq	%rcx, %rdi
180006f12:     	cmpl	$0xc0000000, %eax       # imm = 0xC0000000
180006f17:     	jae	0x180006f1d <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x498d>
180006f19:     	incl	%eax
180006f1b:     	movl	%eax, (%rdx)
180006f1d:     	movl	$0x30, %ecx
180006f22:     	callq	*0xad40(%rip)           # 0x180011c68
180006f28:     	cmpb	$0x0, 0xad11(%rip)      # 0x180011c40
180006f2f:     	je	0x180006f39 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x49a9>
180006f31:     	lock
180006f32:     	incq	0xad0f(%rip)            # 0x180011c48
180006f39:     	testq	%rax, %rax
180006f3c:     	je	0x180006f73 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x49e3>
180006f3e:     	movl	$0x1, %ecx
180006f43:     	leaq	-0x8a(%rip), %rdx       # 0x180006ec0 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4930>
180006f4a:     	xchgq	%rcx, (%rax)
180006f4d:     	xorl	%ecx, %ecx
180006f4f:     	movq	%rdx, 0x8(%rax)
180006f53:     	movq	%rcx, 0x20(%rax)
180006f57:     	movq	%rcx, 0x28(%rax)
180006f5b:     	movq	%rbx, 0x10(%rax)
180006f5f:     	movq	%rdi, 0x18(%rax)
180006f63:     	cmpb	%cl, 0xacd7(%rip)       # 0x180011c40
180006f69:     	je	0x180006f73 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x49e3>
180006f6b:     	lock
180006f6c:     	incq	0xace5(%rip)            # 0x180011c58
180006f73:     	movq	0x30(%rsp), %rbx
180006f78:     	addq	$0x20, %rsp
180006f7c:     	popq	%rdi
180006f7d:     	retq
180006f7e:     	int3
180006f7f:     	int3
180006f80:     	movq	%rbx, 0x8(%rsp)
180006f85:     	pushq	%rdi
180006f86:     	subq	$0x30, %rsp
180006f8a:     	movq	%rcx, %rdi
180006f8d:     	leaq	0xaa2c(%rip), %r9       # 0x1800119c0
180006f94:     	movq	%r8, %rax
180006f97:     	leaq	0x58(%rsp), %rcx
180006f9c:     	movq	%rdx, %r10
180006f9f:     	movq	%rcx, 0x20(%rsp)
180006fa4:     	movq	%r10, %rcx
180006fa7:     	leaq	0x426a(%rip), %r8       # 0x18000b218
180006fae:     	movq	%rax, %rdx
180006fb1:     	callq	*0x3141(%rip)           # 0x18000a0f8
180006fb7:     	testl	%eax, %eax
180006fb9:     	je	0x180006fe3 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4a53>
180006fbb:     	movq	0x58(%rsp), %rcx
180006fc0:     	callq	*0x311a(%rip)           # 0x18000a0e0
180006fc6:     	movq	%rax, %rbx
180006fc9:     	callq	*0x3319(%rip)           # 0x18000a2e8
180006fcf:     	testq	%rax, %rax
180006fd2:     	jne	0x180006fe3 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4a53>
180006fd4:     	movq	%rbx, 0x10(%rdi)
180006fd8:     	movq	0x40(%rsp), %rbx
180006fdd:     	addq	$0x30, %rsp
180006fe1:     	popq	%rdi
180006fe2:     	retq
180006fe3:     	movq	0x40(%rsp), %rbx
180006fe8:     	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
180006fed:     	addq	$0x30, %rsp
180006ff1:     	popq	%rdi
180006ff2:     	retq
180006ff3:     	int3
180006ff4:     	int3
180006ff5:     	int3
180006ff6:     	int3
180006ff7:     	int3
180006ff8:     	int3
180006ff9:     	int3
180006ffa:     	int3
180006ffb:     	int3
180006ffc:     	int3
180006ffd:     	int3
180006ffe:     	int3
180006fff:     	int3
180007000:     	subq	$0x38, %rsp
180007004:     	movl	%r8d, %eax
180007007:     	movq	%rdx, %r10
18000700a:     	movq	0x10(%rcx), %r8
18000700e:     	movq	%rcx, %rdx
180007011:     	movl	%eax, 0x28(%rsp)
180007015:     	movq	%r10, %rcx
180007018:     	movl	$0x0, 0x20(%rsp)
180007020:     	movq	0x20(%r8), %r9
180007024:     	movq	0x18(%r8), %r8
180007028:     	callq	*0x31da(%rip)           # 0x18000a208
18000702e:     	addq	$0x38, %rsp
180007032:     	retq
180007033:     	int3
180007034:     	int3
180007035:     	int3
180007036:     	int3
180007037:     	int3
180007038:     	int3
180007039:     	int3
18000703a:     	int3
18000703b:     	int3
18000703c:     	int3
18000703d:     	int3
18000703e:     	int3
18000703f:     	int3
180007040:     	movq	0x10(%rcx), %rax
180007044:     	lock
180007045:     	incq	(%rax)
180007048:     	movq	0x3281(%rip), %rax      # 0x18000a2d0
18000704f:     	retq
180007050:     	subq	$0x28, %rsp
180007054:     	movq	0x10(%rcx), %rcx
180007058:     	callq	0x180008350 <numba_list_iter_next+0x1d0>
18000705d:     	movq	0x326c(%rip), %rax      # 0x18000a2d0
180007064:     	addq	$0x28, %rsp
180007068:     	retq
180007069:     	int3
18000706a:     	int3
18000706b:     	int3
18000706c:     	int3
18000706d:     	int3
18000706e:     	int3
18000706f:     	int3
180007070:     	movq	0x10(%rcx), %rcx
180007074:     	movq	0x18(%rcx), %rcx
180007078:     	jmpq	*0x30d9(%rip)           # 0x18000a158
18000707f:     	int3
180007080:     	subq	$0x28, %rsp
180007084:     	movq	0x10(%rcx), %rax
180007088:     	testq	%rax, %rax
18000708b:     	je	0x1800070a9 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4b19>
18000708d:     	cmpq	$0x0, 0x18(%rax)
180007092:     	je	0x1800070a9 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4b19>
180007094:     	movq	(%rax), %rcx
180007097:     	nop
180007098:     	cmpq	$-0x1, %rcx
18000709c:     	je	0x1800070a9 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4b19>
18000709e:     	addq	$0x28, %rsp
1800070a2:     	jmpq	*0x307f(%rip)           # 0x18000a128
1800070a9:     	movq	0x3148(%rip), %rcx      # 0x18000a1f8
1800070b0:     	leaq	0x4169(%rip), %rdx      # 0x18000b220
1800070b7:     	movq	(%rcx), %rcx
1800070ba:     	callq	*0x31e8(%rip)           # 0x18000a2a8
1800070c0:     	xorl	%eax, %eax
1800070c2:     	addq	$0x28, %rsp
1800070c6:     	retq
1800070c7:     	int3
1800070c8:     	int3
1800070c9:     	int3
1800070ca:     	int3
1800070cb:     	int3
1800070cc:     	int3
1800070cd:     	int3
1800070ce:     	int3
1800070cf:     	int3
1800070d0:     	movq	0x10(%rcx), %rcx
1800070d4:     	movq	0x28(%rcx), %rcx
1800070d8:     	jmpq	*0x3079(%rip)           # 0x18000a158
1800070df:     	int3
1800070e0:     	movq	0x10(%rcx), %rax
1800070e4:     	movq	0x10(%rax), %rax
1800070e8:     	testq	%rax, %rax
1800070eb:     	je	0x1800070fc <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4b6c>
1800070ed:     	movl	(%rax), %ecx
1800070ef:     	cmpl	$0xc0000000, %ecx       # imm = 0xC0000000
1800070f5:     	jae	0x18000711a <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4b8a>
1800070f7:     	incl	%ecx
1800070f9:     	movl	%ecx, (%rax)
1800070fb:     	retq
1800070fc:     	movq	0x31cd(%rip), %rcx      # 0x18000a2d0
180007103:     	movl	(%rcx), %eax
180007105:     	cmpl	$0xc0000000, %eax       # imm = 0xC0000000
18000710a:     	jae	0x180007117 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4b87>
18000710c:     	incl	%eax
18000710e:     	movl	%eax, (%rcx)
180007110:     	movq	0x31b9(%rip), %rcx      # 0x18000a2d0
180007117:     	movq	%rcx, %rax
18000711a:     	retq
18000711b:     	int3
18000711c:     	int3
18000711d:     	int3
18000711e:     	int3
18000711f:     	int3
180007120:     	pushq	%rbx
180007122:     	subq	$0x20, %rsp
180007126:     	movq	%rcx, %rbx
180007129:     	movq	0x10(%rcx), %rcx
18000712d:     	callq	0x180008350 <numba_list_iter_next+0x1d0>
180007132:     	movq	0x8(%rbx), %rax
180007136:     	movq	%rbx, %rcx
180007139:     	addq	$0x20, %rsp
18000713d:     	popq	%rbx
18000713e:     	jmpq	*0x140(%rax)
180007145:     	int3
180007146:     	int3
180007147:     	int3
180007148:     	int3
180007149:     	int3
18000714a:     	int3
18000714b:     	int3
18000714c:     	int3
18000714d:     	int3
18000714e:     	int3
18000714f:     	int3
180007150:     	movq	%rdi, 0x18(%rsp)
180007155:     	pushq	%r14
180007157:     	subq	$0x20, %rsp
18000715b:     	movq	0xab1e(%rip), %rax      # 0x180011c80
180007162:     	movq	%rdx, %r14
180007165:     	movq	%rcx, %rdi
180007168:     	movq	0x8(%rcx), %rcx
18000716c:     	movq	0x10(%rax), %rdx
180007170:     	cmpq	%rdx, %rcx
180007173:     	je	0x180007190 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4c00>
180007175:     	callq	*0x305d(%rip)           # 0x18000a1d8
18000717b:     	testl	%eax, %eax
18000717d:     	jne	0x180007190 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4c00>
18000717f:     	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
180007184:     	movq	0x40(%rsp), %rdi
180007189:     	addq	$0x20, %rsp
18000718d:     	popq	%r14
18000718f:     	retq
180007190:     	movq	%rbx, 0x30(%rsp)
180007195:     	movq	%rdi, %rdx
180007198:     	movq	0x10(%rdi), %rbx
18000719c:     	movq	%rbx, %rcx
18000719f:     	movq	%rsi, 0x38(%rsp)
1800071a4:     	movl	0x18(%rdi), %esi
1800071a7:     	callq	0x180006f00 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4970>
1800071ac:     	movq	%rax, (%r14)
1800071af:     	movq	0xaaca(%rip), %rax      # 0x180011c80
1800071b6:     	movq	%rbx, 0x20(%r14)
1800071ba:     	movl	0x18(%rdi), %edx
1800071bd:     	movq	0x20(%rdi), %rcx
1800071c1:     	callq	*0x4f0(%rax)
1800071c7:     	cmpl	$0x12, 0xaabe(%rip)     # 0x180011c8c
1800071ce:     	movq	0x30(%rsp), %rbx
1800071d3:     	movq	%rax, 0x10(%r14)
1800071d7:     	movq	0x38(%rdi), %rax
1800071db:     	jl	0x1800071e3 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4c53>
1800071dd:     	movq	0x28(%rax), %rax
1800071e1:     	jmp	0x1800071e7 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4c57>
1800071e3:     	movslq	0x20(%rax), %rax
1800071e7:     	xorl	%r8d, %r8d
1800071ea:     	movq	%rax, 0x18(%r14)
1800071ee:     	movq	%rdi, 0x8(%r14)
1800071f2:     	leaq	0x28(%r14), %rax
1800071f6:     	testl	%esi, %esi
1800071f8:     	jle	0x18000723b <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4cab>
1800071fa:     	nopw	(%rax,%rax)
180007200:     	movq	0x20(%rdi), %rcx
180007204:     	movq	(%rcx,%r8,8), %rdx
180007208:     	incl	%r8d
18000720b:     	movq	%rdx, (%rax)
18000720e:     	addq	$0x8, %rax
180007212:     	cmpl	%esi, %r8d
180007215:     	jl	0x180007200 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4c70>
180007217:     	xorl	%r8d, %r8d
18000721a:     	nopw	(%rax,%rax)
180007220:     	movq	0x28(%rdi), %rcx
180007224:     	leaq	0x8(%rax), %rax
180007228:     	movslq	%r8d, %rdx
18000722b:     	incl	%r8d
18000722e:     	movq	(%rcx,%rdx,8), %rdx
180007232:     	movq	%rdx, -0x8(%rax)
180007236:     	cmpl	%esi, %r8d
180007239:     	jl	0x180007220 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4c90>
18000723b:     	movq	0x38(%rsp), %rsi
180007240:     	xorl	%eax, %eax
180007242:     	movq	0x40(%rsp), %rdi
180007247:     	addq	$0x20, %rsp
18000724b:     	popq	%r14
18000724d:     	retq
18000724e:     	int3
18000724f:     	int3
180007250:     	pushq	%rbx
180007252:     	pushq	%rbp
180007253:     	pushq	%rsi
180007254:     	pushq	%rdi
180007255:     	subq	$0x28, %rsp
180007259:     	cmpq	$0x0, 0xaa37(%rip)      # 0x180011c98
180007261:     	movq	%rcx, %rbp
180007264:     	movslq	0x8(%rdx), %rdi
180007268:     	movq	(%rdx), %rsi
18000726b:     	jne	0x1800072c3 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4d33>
18000726d:     	leaq	0x3eb4(%rip), %rcx      # 0x18000b128
180007274:     	callq	*0x2fbe(%rip)           # 0x18000a238
18000727a:     	movq	%rax, %rbx
18000727d:     	testq	%rax, %rax
180007280:     	je	0x18000734a <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4dba>
180007286:     	leaq	0x3ea3(%rip), %rdx      # 0x18000b130
18000728d:     	movq	%rax, %rcx
180007290:     	callq	*0x2ed2(%rip)           # 0x18000a168
180007296:     	movl	(%rbx), %edx
180007298:     	movq	%rax, 0xa9f9(%rip)      # 0x180011c98
18000729f:     	testl	%edx, %edx
1800072a1:     	js	0x1800072ba <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4d2a>
1800072a3:     	subl	$0x1, %edx
1800072a6:     	movl	%edx, (%rbx)
1800072a8:     	jne	0x1800072ba <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4d2a>
1800072aa:     	movq	%rbx, %rcx
1800072ad:     	callq	*0x2f15(%rip)           # 0x18000a1c8
1800072b3:     	movq	0xa9de(%rip), %rax      # 0x180011c98
1800072ba:     	testq	%rax, %rax
1800072bd:     	je	0x18000734a <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4dba>
1800072c3:     	movq	%rdi, %rdx
1800072c6:     	movq	%rsi, %rcx
1800072c9:     	callq	*0x2fe9(%rip)           # 0x18000a2b8
1800072cf:     	movq	%rax, %rdi
1800072d2:     	testq	%rax, %rax
1800072d5:     	je	0x18000734a <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4dba>
1800072d7:     	movq	0xa9ba(%rip), %rcx      # 0x180011c98
1800072de:     	xorl	%r8d, %r8d
1800072e1:     	movq	%rax, %rdx
1800072e4:     	callq	*0x2eae(%rip)           # 0x18000a198
1800072ea:     	movl	(%rdi), %ecx
1800072ec:     	movq	%rax, %rbx
1800072ef:     	testl	%ecx, %ecx
1800072f1:     	js	0x180007303 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4d73>
1800072f3:     	subl	$0x1, %ecx
1800072f6:     	movl	%ecx, (%rdi)
1800072f8:     	jne	0x180007303 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4d73>
1800072fa:     	movq	%rdi, %rcx
1800072fd:     	callq	*0x2ec5(%rip)           # 0x18000a1c8
180007303:     	testq	%rbx, %rbx
180007306:     	je	0x18000734a <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4dba>
180007308:     	movq	0x8(%rbx), %r8
18000730c:     	testl	$0x2000000, 0xa8(%r8)   # imm = 0x2000000
180007317:     	jne	0x180007355 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4dc5>
180007319:     	movq	0x2f80(%rip), %rcx      # 0x18000a2a0
180007320:     	leaq	0x4001(%rip), %rdx      # 0x18000b328
180007327:     	movq	0x18(%r8), %r8
18000732b:     	movq	(%rcx), %rcx
18000732e:     	callq	*0x2ebc(%rip)           # 0x18000a1f0
180007334:     	movl	(%rbx), %eax
180007336:     	testl	%eax, %eax
180007338:     	js	0x18000734a <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4dba>
18000733a:     	subl	$0x1, %eax
18000733d:     	movl	%eax, (%rbx)
18000733f:     	jne	0x18000734a <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4dba>
180007341:     	movq	%rbx, %rcx
180007344:     	callq	*0x2e7e(%rip)           # 0x18000a1c8
18000734a:     	xorl	%eax, %eax
18000734c:     	addq	$0x28, %rsp
180007350:     	popq	%rdi
180007351:     	popq	%rsi
180007352:     	popq	%rbp
180007353:     	popq	%rbx
180007354:     	retq
180007355:     	xorl	%r8d, %r8d
180007358:     	leaq	0x9fe1(%rip), %rcx      # 0x180011340
18000735f:     	xorl	%edx, %edx
180007361:     	callq	*0x2ee1(%rip)           # 0x18000a248
180007367:     	movq	%rax, %rdi
18000736a:     	testq	%rax, %rax
18000736d:     	je	0x180007334 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4da4>
18000736f:     	movq	%rbp, %rcx
180007372:     	movq	%rbx, 0x18(%rax)
180007376:     	callq	*0x2e44(%rip)           # 0x18000a1c0
18000737c:     	movq	%rax, 0x10(%rdi)
180007380:     	movq	%rax, %rcx
180007383:     	testq	%rax, %rax
180007386:     	jne	0x18000739a <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4e0a>
180007388:     	movl	(%rdi), %eax
18000738a:     	testl	%eax, %eax
18000738c:     	js	0x18000734a <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4dba>
18000738e:     	subl	$0x1, %eax
180007391:     	movl	%eax, (%rdi)
180007393:     	jne	0x18000734a <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4dba>
180007395:     	movq	%rdi, %rcx
180007398:     	jmp	0x180007344 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4db4>
18000739a:     	movl	(%rax), %eax
18000739c:     	cmpl	$0xc0000000, %eax       # imm = 0xC0000000
1800073a1:     	jae	0x1800073a7 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4e17>
1800073a3:     	incl	%eax
1800073a5:     	movl	%eax, (%rcx)
1800073a7:     	movq	%rdi, %rax
1800073aa:     	addq	$0x28, %rsp
1800073ae:     	popq	%rdi
1800073af:     	popq	%rsi
1800073b0:     	popq	%rbp
1800073b1:     	popq	%rbx
1800073b2:     	retq
1800073b3:     	int3
1800073b4:     	int3
1800073b5:     	int3
1800073b6:     	int3
1800073b7:     	int3
1800073b8:     	int3
1800073b9:     	int3
1800073ba:     	int3
1800073bb:     	int3
1800073bc:     	int3
1800073bd:     	int3
1800073be:     	int3
1800073bf:     	int3
1800073c0:     	movq	%r9, 0x20(%rsp)
1800073c5:     	movq	%r8, 0x18(%rsp)
1800073ca:     	movq	%rdx, 0x10(%rsp)
1800073cf:     	movq	%rcx, 0x8(%rsp)
1800073d4:     	pushq	%rbx
1800073d5:     	pushq	%rbp
1800073d6:     	pushq	%rsi
1800073d7:     	pushq	%rdi
1800073d8:     	pushq	%r12
1800073da:     	pushq	%r13
1800073dc:     	pushq	%r14
1800073de:     	pushq	%r15
1800073e0:     	subq	$0x68, %rsp
1800073e4:     	movq	%rcx, %r14
1800073e7:     	movq	%r9, %r15
1800073ea:     	leaq	0x39ef(%rip), %rcx      # 0x18000ade0
1800073f1:     	movq	%r8, %r13
1800073f4:     	movq	%rdx, %rsi
1800073f7:     	callq	*0x2e3b(%rip)           # 0x18000a238
1800073fd:     	movq	%rax, %rdi
180007400:     	testq	%rax, %rax
180007403:     	jne	0x18000743c <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4eac>
180007405:     	movq	0x2d2c(%rip), %rcx      # 0x18000a138
18000740c:     	movq	(%rcx), %rcx
18000740f:     	callq	*0x2d9b(%rip)           # 0x18000a1b0
180007415:     	testl	%eax, %eax
180007417:     	je	0x180007537 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4fa7>
18000741d:     	callq	*0x2e9d(%rip)           # 0x18000a2c0
180007423:     	leaq	0x39d6(%rip), %rcx      # 0x18000ae00
18000742a:     	callq	*0x2e08(%rip)           # 0x18000a238
180007430:     	movq	%rax, %rdi
180007433:     	testq	%rax, %rax
180007436:     	je	0x180007537 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4fa7>
18000743c:     	leaq	0x39dd(%rip), %rdx      # 0x18000ae20
180007443:     	movq	%rdi, %rcx
180007446:     	callq	*0x2d1c(%rip)           # 0x18000a168
18000744c:     	movl	(%rdi), %ecx
18000744e:     	movq	%rax, %rbx
180007451:     	testl	%ecx, %ecx
180007453:     	js	0x180007465 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4ed5>
180007455:     	subl	$0x1, %ecx
180007458:     	movl	%ecx, (%rdi)
18000745a:     	jne	0x180007465 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4ed5>
18000745c:     	movq	%rdi, %rcx
18000745f:     	callq	*0x2d63(%rip)           # 0x18000a1c8
180007465:     	testq	%rbx, %rbx
180007468:     	je	0x180007537 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4fa7>
18000746e:     	movq	0x2c8b(%rip), %rax      # 0x18000a100
180007475:     	cmpq	%rax, 0x8(%rbx)
180007479:     	je	0x1800074b5 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4f25>
18000747b:     	movq	0x2e2e(%rip), %rcx      # 0x18000a2b0
180007482:     	leaq	0x39a7(%rip), %rdx      # 0x18000ae30
180007489:     	movq	(%rcx), %rcx
18000748c:     	callq	*0x2e16(%rip)           # 0x18000a2a8
180007492:     	movl	(%rbx), %eax
180007494:     	testl	%eax, %eax
180007496:     	js	0x180007537 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4fa7>
18000749c:     	subl	$0x1, %eax
18000749f:     	movl	%eax, (%rbx)
1800074a1:     	jne	0x180007537 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4fa7>
1800074a7:     	movq	%rbx, %rcx
1800074aa:     	callq	*0x2d18(%rip)           # 0x18000a1c8
1800074b0:     	jmp	0x180007537 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4fa7>
1800074b5:     	xorl	%edx, %edx
1800074b7:     	movq	%rbx, %rcx
1800074ba:     	callq	*0x2ce8(%rip)           # 0x18000a1a8
1800074c0:     	movl	(%rbx), %ecx
1800074c2:     	movq	%rax, 0xa7b7(%rip)      # 0x180011c80
1800074c9:     	testl	%ecx, %ecx
1800074cb:     	js	0x1800074e4 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4f54>
1800074cd:     	subl	$0x1, %ecx
1800074d0:     	movl	%ecx, (%rbx)
1800074d2:     	jne	0x1800074e4 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4f54>
1800074d4:     	movq	%rbx, %rcx
1800074d7:     	callq	*0x2ceb(%rip)           # 0x18000a1c8
1800074dd:     	movq	0xa79c(%rip), %rax      # 0x180011c80
1800074e4:     	testq	%rax, %rax
1800074e7:     	jne	0x180007502 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4f72>
1800074e9:     	leaq	0x3968(%rip), %rdx      # 0x18000ae58
1800074f0:     	movq	0x2db9(%rip), %rcx      # 0x18000a2b0
1800074f7:     	movq	(%rcx), %rcx
1800074fa:     	callq	*0x2da8(%rip)           # 0x18000a2a8
180007500:     	jmp	0x180007537 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4fa7>
180007502:     	callq	*(%rax)
180007504:     	cmpl	$0x2000000, %eax        # imm = 0x2000000
180007509:     	jbe	0x18000756a <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4fda>
18000750b:     	movq	0x2d9e(%rip), %rax      # 0x18000a2b0
180007512:     	movq	(%rax), %rbx
180007515:     	movq	0xa764(%rip), %rax      # 0x180011c80
18000751c:     	callq	*(%rax)
18000751e:     	movl	$0x2000000, %r8d        # imm = 0x2000000
180007524:     	leaq	0x3955(%rip), %rdx      # 0x18000ae80
18000752b:     	movl	%eax, %r9d
18000752e:     	movq	%rbx, %rcx
180007531:     	callq	*0x2cb9(%rip)           # 0x18000a1f0
180007537:     	callq	*0x2bdb(%rip)           # 0x18000a118
18000753d:     	movq	0x2bcc(%rip), %rcx      # 0x18000a110
180007544:     	leaq	0x3b5d(%rip), %rdx      # 0x18000b0a8
18000754b:     	movq	(%rcx), %rcx
18000754e:     	callq	*0x2d54(%rip)           # 0x18000a2a8
180007554:     	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
180007559:     	addq	$0x68, %rsp
18000755d:     	popq	%r15
18000755f:     	popq	%r14
180007561:     	popq	%r13
180007563:     	popq	%r12
180007565:     	popq	%rdi
180007566:     	popq	%rsi
180007567:     	popq	%rbp
180007568:     	popq	%rbx
180007569:     	retq
18000756a:     	movq	0xa70f(%rip), %rax      # 0x180011c80
180007571:     	callq	*0x698(%rax)
180007577:     	movl	%eax, 0xa70f(%rip)      # 0x180011c8c
18000757d:     	cmpl	$0x10, %eax
180007580:     	jge	0x18000759e <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x500e>
180007582:     	movq	0x2d27(%rip), %rcx      # 0x18000a2b0
180007589:     	leaq	0x3940(%rip), %rdx      # 0x18000aed0
180007590:     	movl	%eax, %r9d
180007593:     	movl	$0x10, %r8d
180007599:     	movq	(%rcx), %rcx
18000759c:     	jmp	0x180007531 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4fa1>
18000759e:     	movq	0xa6db(%rip), %rax      # 0x180011c80
1800075a5:     	callq	*0x690(%rax)
1800075ab:     	testl	%eax, %eax
1800075ad:     	jne	0x1800075bb <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x502b>
1800075af:     	leaq	0x3a6a(%rip), %rdx      # 0x18000b020
1800075b6:     	jmp	0x1800074f0 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4f60>
1800075bb:     	cmpl	$0x1, %eax
1800075be:     	je	0x1800075cc <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x503c>
1800075c0:     	leaq	0x3a89(%rip), %rdx      # 0x18000b050
1800075c7:     	jmp	0x1800074f0 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4f60>
1800075cc:     	leaq	0xa24d(%rip), %rcx      # 0x180011820
1800075d3:     	callq	*0x2b97(%rip)           # 0x18000a170
1800075d9:     	testl	%eax, %eax
1800075db:     	jne	0x180007554 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4fc4>
1800075e1:     	leaq	0x9d58(%rip), %rcx      # 0x180011340
1800075e8:     	callq	*0x2b82(%rip)           # 0x18000a170
1800075ee:     	testl	%eax, %eax
1800075f0:     	jne	0x180007554 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4fc4>
1800075f6:     	leaq	0xa083(%rip), %rcx      # 0x180011680
1800075fd:     	callq	*0x2b6d(%rip)           # 0x18000a170
180007603:     	testl	%eax, %eax
180007605:     	jne	0x180007554 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4fc4>
18000760b:     	xorl	%ebx, %ebx
18000760d:     	cmpl	%ebx, 0xa675(%rip)      # 0x180011c88
180007613:     	jne	0x180007656 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x50c6>
180007615:     	movq	%gs:0x58, %rax
18000761e:     	movl	0xa67c(%rip), %ecx      # 0x180011ca0
180007624:     	movl	$0x1, 0xa65a(%rip)      # 0x180011c88
18000762e:     	movq	(%rax,%rcx,8), %rdx
180007632:     	movl	$0x10, %eax
180007637:     	movl	%ebx, 0x9d0(%rax,%rdx)
18000763e:     	movl	$0x9f0, %eax            # imm = 0x9F0
180007643:     	movl	%ebx, 0x9d0(%rax,%rdx)
18000764a:     	movl	$0x13d0, %eax           # imm = 0x13D0
18000764f:     	movl	%ebx, 0x9d0(%rax,%rdx)
180007656:     	movl	%ebx, 0xa5dc(%rip)      # 0x180011c38
18000765c:     	movq	%rbx, %rax
18000765f:     	movb	%bl, 0xa5db(%rip)       # 0x180011c40
180007665:     	movq	%rbx, %rcx
180007668:     	xchgq	%rax, 0xa5d9(%rip)      # 0x180011c48
18000766f:     	xchgq	%rcx, 0xa5da(%rip)      # 0x180011c50
180007676:     	movq	%rbx, %rax
180007679:     	movq	%rbx, %rcx
18000767c:     	xchgq	%rax, 0xa5d5(%rip)      # 0x180011c58
180007683:     	xchgq	%rcx, 0xa5d6(%rip)      # 0x180011c60
18000768a:     	movq	0x29cf(%rip), %rax      # 0x18000a060
180007691:     	leaq	0x9e48(%rip), %rcx      # 0x1800114e0
180007698:     	movq	%rax, 0xa5c9(%rip)      # 0x180011c68
18000769f:     	movq	0x29ca(%rip), %rax      # 0x18000a070
1800076a6:     	movq	%rax, 0xa5c3(%rip)      # 0x180011c70
1800076ad:     	movq	0x29b4(%rip), %rax      # 0x18000a068
1800076b4:     	movq	%rax, 0xa5bd(%rip)      # 0x180011c78
1800076bb:     	movq	0x2b86(%rip), %rax      # 0x18000a248
1800076c2:     	movq	%rax, 0x9f4f(%rip)      # 0x180011618
1800076c9:     	callq	*0x2aa1(%rip)           # 0x18000a170
1800076cf:     	testl	%eax, %eax
1800076d1:     	jne	0x180007554 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4fc4>
1800076d7:     	leaq	0x3ae2(%rip), %rdx      # 0x18000b1c0
1800076de:     	movq	%r14, %rcx
1800076e1:     	callq	*0x2a81(%rip)           # 0x18000a168
1800076e7:     	movq	%rax, 0x28(%rsp)
1800076ec:     	movq	%rax, %rdi
1800076ef:     	testq	%rax, %rax
1800076f2:     	je	0x180007554 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4fc4>
1800076f8:     	leaq	0x3c5a(%rip), %rcx      # 0x18000b359
1800076ff:     	callq	*0x2b7b(%rip)           # 0x18000a280
180007705:     	movq	%rax, 0x20(%rsp)
18000770a:     	movq	%rax, %r12
18000770d:     	testq	%rax, %rax
180007710:     	je	0x180007a54 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x54c4>
180007716:     	movl	%ebx, %ebp
180007718:     	cmpq	%rbx, (%rsi)
18000771b:     	je	0x1800078c4 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x5334>
180007721:     	movslq	%ebp, %rbx
180007724:     	leaq	0x30(%rsp), %rdx
180007729:     	movq	%r14, %rcx
18000772c:     	leaq	(%rbx,%rbx,4), %rax
180007730:     	movups	(%r13,%rax,8), %xmm0
180007736:     	movups	0x10(%r13,%rax,8), %xmm1
18000773c:     	movaps	%xmm0, 0x30(%rsp)
180007741:     	movsd	0x20(%r13,%rax,8), %xmm0
180007748:     	movsd	%xmm0, 0x50(%rsp)
18000774e:     	movaps	%xmm1, 0x40(%rsp)
180007753:     	callq	0x180007250 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4cc0>
180007758:     	movq	%rax, %r14
18000775b:     	testq	%rax, %rax
18000775e:     	je	0x180007a30 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x54a0>
180007764:     	movq	(%rsi), %rcx
180007767:     	callq	*0x2b13(%rip)           # 0x18000a280
18000776d:     	movq	%rax, %r13
180007770:     	testq	%rax, %rax
180007773:     	je	0x180007a77 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x54e7>
180007779:     	movq	(%r15,%rbx,8), %rcx
18000777d:     	xorl	%edx, %edx
18000777f:     	movq	%r14, (%rcx)
180007782:     	leaq	0xa097(%rip), %rcx      # 0x180011820
180007789:     	movq	0x8(%rsi), %r12
18000778d:     	callq	*0x29bd(%rip)           # 0x18000a150
180007793:     	movq	%rax, %rbx
180007796:     	testq	%rax, %rax
180007799:     	je	0x180007816 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x5286>
18000779b:     	movq	%r13, %rcx
18000779e:     	callq	*0x29dc(%rip)           # 0x18000a180
1800077a4:     	movq	%rax, %rdi
1800077a7:     	testq	%rax, %rax
1800077aa:     	je	0x1800077cc <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x523c>
1800077ac:     	movq	%rax, %rcx
1800077af:     	callq	0x180009055 <numba_list_iter_next+0xed5>
1800077b4:     	leaq	0x1(%rax), %rcx
1800077b8:     	callq	*0x2a92(%rip)           # 0x18000a250
1800077be:     	movq	%rax, %rsi
1800077c1:     	testq	%rax, %rax
1800077c4:     	jne	0x1800077d4 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x5244>
1800077c6:     	callq	*0x2974(%rip)           # 0x18000a140
1800077cc:     	xorl	%eax, %eax
1800077ce:     	movq	%rax, 0x20(%rbx)
1800077d2:     	jmp	0x180007805 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x5275>
1800077d4:     	movq	%rdi, %rdx
1800077d7:     	movq	%rsi, %rcx
1800077da:     	callq	0x18000904f <numba_list_iter_next+0xecf>
1800077df:     	movq	0x20(%rsp), %rcx
1800077e4:     	movq	%rsi, 0x20(%rbx)
1800077e8:     	movq	%r12, 0x28(%rbx)
1800077ec:     	movl	$0x3, 0x30(%rbx)
1800077f3:     	callq	0x180006cd0 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4740>
1800077f8:     	movq	%rax, 0x38(%rbx)
1800077fc:     	testq	%rax, %rax
1800077ff:     	jne	0x180007970 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x53e0>
180007805:     	movl	(%rbx), %eax
180007807:     	testl	%eax, %eax
180007809:     	js	0x180007816 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x5286>
18000780b:     	subl	$0x1, %eax
18000780e:     	movl	%eax, (%rbx)
180007810:     	je	0x1800079bd <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x542d>
180007816:     	xorl	%edi, %edi
180007818:     	movl	(%r14), %eax
18000781b:     	testl	%eax, %eax
18000781d:     	js	0x180007830 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x52a0>
18000781f:     	subl	$0x1, %eax
180007822:     	movl	%eax, (%r14)
180007825:     	jne	0x180007830 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x52a0>
180007827:     	movq	%r14, %rcx
18000782a:     	callq	*0x2998(%rip)           # 0x18000a1c8
180007830:     	movl	(%r13), %eax
180007834:     	testl	%eax, %eax
180007836:     	js	0x18000784a <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x52ba>
180007838:     	subl	$0x1, %eax
18000783b:     	movl	%eax, (%r13)
18000783f:     	jne	0x18000784a <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x52ba>
180007841:     	movq	%r13, %rcx
180007844:     	callq	*0x297e(%rip)           # 0x18000a1c8
18000784a:     	testq	%rdi, %rdi
18000784d:     	je	0x180007a30 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x54a0>
180007853:     	movq	0xb8(%rsp), %rsi
18000785b:     	movq	%rdi, %r8
18000785e:     	movq	0xb0(%rsp), %r14
180007866:     	movq	%r14, %rcx
180007869:     	movq	(%rsi), %rdx
18000786c:     	callq	*0x29ae(%rip)           # 0x18000a220
180007872:     	movl	(%rdi), %ecx
180007874:     	testl	%eax, %eax
180007876:     	jne	0x180007a1a <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x548a>
18000787c:     	testl	%ecx, %ecx
18000787e:     	js	0x180007892 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x5302>
180007880:     	leal	-0x1(%rcx), %eax
180007883:     	movl	%eax, (%rdi)
180007885:     	testl	%eax, %eax
180007887:     	jne	0x180007892 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x5302>
180007889:     	movq	%rdi, %rcx
18000788c:     	callq	*0x2936(%rip)           # 0x18000a1c8
180007892:     	movq	0xc8(%rsp), %r15
18000789a:     	addq	$0x20, %rsi
18000789e:     	movq	0xc0(%rsp), %r13
1800078a6:     	incl	%ebp
1800078a8:     	movq	%rsi, 0xb8(%rsp)
1800078b0:     	cmpq	$0x0, (%rsi)
1800078b4:     	jne	0x180007721 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x5191>
1800078ba:     	movq	0x20(%rsp), %r12
1800078bf:     	movq	0x28(%rsp), %rdi
1800078c4:     	movslq	%ebp, %rax
1800078c7:     	cmpq	$0x0, (%r15,%rax,8)
1800078cc:     	je	0x180007939 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x53a9>
1800078ce:     	nop
1800078d0:     	movslq	%ebp, %rbx
1800078d3:     	leaq	0x30(%rsp), %rdx
1800078d8:     	movq	%r14, %rcx
1800078db:     	leaq	(%rbx,%rbx,4), %rax
1800078df:     	movups	(%r13,%rax,8), %xmm0
1800078e5:     	movups	0x10(%r13,%rax,8), %xmm1
1800078eb:     	movaps	%xmm0, 0x30(%rsp)
1800078f0:     	movsd	0x20(%r13,%rax,8), %xmm0
1800078f7:     	movsd	%xmm0, 0x50(%rsp)
1800078fd:     	movaps	%xmm1, 0x40(%rsp)
180007902:     	callq	0x180007250 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4cc0>
180007907:     	testq	%rax, %rax
18000790a:     	je	0x180007a35 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x54a5>
180007910:     	movq	(%r15,%rbx,8), %rcx
180007914:     	movq	%rax, (%rcx)
180007917:     	movl	(%rax), %ecx
180007919:     	testl	%ecx, %ecx
18000791b:     	js	0x18000792d <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x539d>
18000791d:     	subl	$0x1, %ecx
180007920:     	movl	%ecx, (%rax)
180007922:     	jne	0x18000792d <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x539d>
180007924:     	movq	%rax, %rcx
180007927:     	callq	*0x289b(%rip)           # 0x18000a1c8
18000792d:     	incl	%ebp
18000792f:     	movslq	%ebp, %rax
180007932:     	cmpq	$0x0, (%r15,%rax,8)
180007937:     	jne	0x1800078d0 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x5340>
180007939:     	movl	(%r12), %eax
18000793d:     	testl	%eax, %eax
18000793f:     	js	0x180007953 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x53c3>
180007941:     	subl	$0x1, %eax
180007944:     	movl	%eax, (%r12)
180007948:     	jne	0x180007953 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x53c3>
18000794a:     	movq	%r12, %rcx
18000794d:     	callq	*0x2875(%rip)           # 0x18000a1c8
180007953:     	movl	(%rdi), %eax
180007955:     	testl	%eax, %eax
180007957:     	js	0x180007969 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x53d9>
180007959:     	subl	$0x1, %eax
18000795c:     	movl	%eax, (%rdi)
18000795e:     	jne	0x180007969 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x53d9>
180007960:     	movq	%rdi, %rcx
180007963:     	callq	*0x285f(%rip)           # 0x18000a1c8
180007969:     	xorl	%eax, %eax
18000796b:     	jmp	0x180007559 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4fc9>
180007970:     	movl	(%r14), %eax
180007973:     	cmpl	$0xc0000000, %eax       # imm = 0xC0000000
180007978:     	jae	0x18000797f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x53ef>
18000797a:     	incl	%eax
18000797c:     	movl	%eax, (%r14)
18000797f:     	movq	0xb0(%rsp), %rcx
180007987:     	leaq	0x3832(%rip), %rdx      # 0x18000b1c0
18000798e:     	movq	%r14, 0x18(%rbx)
180007992:     	movq	$0x0, 0x40(%rbx)
18000799a:     	callq	*0x27c8(%rip)           # 0x18000a168
1800079a0:     	movq	%rax, %rsi
1800079a3:     	testq	%rax, %rax
1800079a6:     	jne	0x1800079cb <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x543b>
1800079a8:     	movl	(%rbx), %eax
1800079aa:     	testl	%eax, %eax
1800079ac:     	js	0x180007816 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x5286>
1800079b2:     	subl	$0x1, %eax
1800079b5:     	movl	%eax, (%rbx)
1800079b7:     	jne	0x180007816 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x5286>
1800079bd:     	movq	%rbx, %rcx
1800079c0:     	callq	*0x2802(%rip)           # 0x18000a1c8
1800079c6:     	jmp	0x180007816 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x5286>
1800079cb:     	xorl	%r9d, %r9d
1800079ce:     	leaq	0x20(%rbx), %rcx
1800079d2:     	movq	%rsi, %r8
1800079d5:     	movq	%rbx, %rdx
1800079d8:     	callq	*0x276a(%rip)           # 0x18000a148
1800079de:     	movq	%rax, %rdi
1800079e1:     	movl	(%rbx), %eax
1800079e3:     	testl	%eax, %eax
1800079e5:     	js	0x1800079f7 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x5467>
1800079e7:     	subl	$0x1, %eax
1800079ea:     	movl	%eax, (%rbx)
1800079ec:     	jne	0x1800079f7 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x5467>
1800079ee:     	movq	%rbx, %rcx
1800079f1:     	callq	*0x27d1(%rip)           # 0x18000a1c8
1800079f7:     	movl	(%rsi), %eax
1800079f9:     	testl	%eax, %eax
1800079fb:     	js	0x180007818 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x5288>
180007a01:     	subl	$0x1, %eax
180007a04:     	movl	%eax, (%rsi)
180007a06:     	jne	0x180007818 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x5288>
180007a0c:     	movq	%rsi, %rcx
180007a0f:     	callq	*0x27b3(%rip)           # 0x18000a1c8
180007a15:     	jmp	0x180007818 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x5288>
180007a1a:     	testl	%ecx, %ecx
180007a1c:     	js	0x180007a30 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x54a0>
180007a1e:     	leal	-0x1(%rcx), %eax
180007a21:     	movl	%eax, (%rdi)
180007a23:     	testl	%eax, %eax
180007a25:     	jne	0x180007a30 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x54a0>
180007a27:     	movq	%rdi, %rcx
180007a2a:     	callq	*0x2798(%rip)           # 0x18000a1c8
180007a30:     	movq	0x20(%rsp), %r12
180007a35:     	movl	(%r12), %eax
180007a39:     	testl	%eax, %eax
180007a3b:     	js	0x180007a4f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x54bf>
180007a3d:     	subl	$0x1, %eax
180007a40:     	movl	%eax, (%r12)
180007a44:     	jne	0x180007a4f <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x54bf>
180007a46:     	movq	%r12, %rcx
180007a49:     	callq	*0x2779(%rip)           # 0x18000a1c8
180007a4f:     	movq	0x28(%rsp), %rdi
180007a54:     	movl	(%rdi), %eax
180007a56:     	testl	%eax, %eax
180007a58:     	js	0x180007554 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4fc4>
180007a5e:     	subl	$0x1, %eax
180007a61:     	movl	%eax, (%rdi)
180007a63:     	jne	0x180007554 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4fc4>
180007a69:     	movq	%rdi, %rcx
180007a6c:     	callq	*0x2756(%rip)           # 0x18000a1c8
180007a72:     	jmp	0x180007554 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x4fc4>
180007a77:     	movl	(%r14), %eax
180007a7a:     	testl	%eax, %eax
180007a7c:     	js	0x180007a30 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x54a0>
180007a7e:     	subl	$0x1, %eax
180007a81:     	movl	%eax, (%r14)
180007a84:     	jne	0x180007a30 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x54a0>
180007a86:     	movq	%r14, %rcx
180007a89:     	jmp	0x180007a2a <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x549a>
180007a8b:     	int3
180007a8c:     	int3
180007a8d:     	int3
180007a8e:     	int3
180007a8f:     	int3
180007a90:     	leaq	0xa271(%rip), %rax      # 0x180011d08
180007a97:     	retq
180007a98:     	int3
180007a99:     	int3
180007a9a:     	int3
180007a9b:     	int3
180007a9c:     	int3
180007a9d:     	int3
180007a9e:     	int3
180007a9f:     	int3

0000000180007aa0 <numba_list_set_method_table>:
180007aa0:     	movups	(%rdx), %xmm0
180007aa3:     	movups	%xmm0, 0x20(%rcx)
180007aa7:     	retq
180007aa8:     	int3
180007aa9:     	int3
180007aaa:     	int3
180007aab:     	int3
180007aac:     	int3
180007aad:     	int3
180007aae:     	int3
180007aaf:     	int3

0000000180007ab0 <numba_list_new>:
180007ab0:     	pushq	%rbx
180007ab2:     	pushq	%rbp
180007ab3:     	pushq	%rsi
180007ab4:     	pushq	%rdi
180007ab5:     	subq	$0x28, %rsp
180007ab9:     	movq	%rcx, %rsi
180007abc:     	movq	%r8, %rdi
180007abf:     	movl	$0x38, %ecx
180007ac4:     	movq	%rdx, %rbp
180007ac7:     	callq	*0x2593(%rip)           # 0x18000a060
180007acd:     	movq	%rax, %rbx
180007ad0:     	testq	%rax, %rax
180007ad3:     	je	0x180007b3d <numba_list_new+0x8d>
180007ad5:     	movq	$0x0, (%rax)
180007adc:     	xorps	%xmm0, %xmm0
180007adf:     	movq	%rbp, 0x8(%rax)
180007ae3:     	movq	%rdi, 0x10(%rax)
180007ae7:     	movl	$0x1, 0x18(%rax)
180007aee:     	movups	%xmm0, 0x20(%rax)
180007af2:     	testq	%rdi, %rdi
180007af5:     	je	0x180007b4b <numba_list_new+0x9b>
180007af7:     	imulq	%rbp, %rdi
180007afb:     	movl	$0x8, %ecx
180007b00:     	movq	%rdi, %rax
180007b03:     	cqto
180007b05:     	andl	$0x7, %edx
180007b08:     	addq	%rdx, %rax
180007b0b:     	andl	$0x7, %eax
180007b0e:     	subq	%rdx, %rax
180007b11:     	subq	%rax, %rcx
180007b14:     	movq	%rcx, %rax
180007b17:     	cqto
180007b19:     	andl	$0x7, %edx
180007b1c:     	leaq	(%rdx,%rax), %rcx
180007b20:     	andl	$0x7, %ecx
180007b23:     	subq	%rdx, %rcx
180007b26:     	addq	%rdi, %rcx
180007b29:     	callq	*0x2531(%rip)           # 0x18000a060
180007b2f:     	testq	%rax, %rax
180007b32:     	jne	0x180007b4d <numba_list_new+0x9d>
180007b34:     	movq	%rbx, %rcx
180007b37:     	callq	*0x252b(%rip)           # 0x18000a068
180007b3d:     	movl	$0xfffffffe, %eax       # imm = 0xFFFFFFFE
180007b42:     	addq	$0x28, %rsp
180007b46:     	popq	%rdi
180007b47:     	popq	%rsi
180007b48:     	popq	%rbp
180007b49:     	popq	%rbx
180007b4a:     	retq
180007b4b:     	xorl	%eax, %eax
180007b4d:     	movq	%rax, 0x30(%rbx)
180007b51:     	xorl	%eax, %eax
180007b53:     	movq	%rbx, (%rsi)
180007b56:     	addq	$0x28, %rsp
180007b5a:     	popq	%rdi
180007b5b:     	popq	%rsi
180007b5c:     	popq	%rbp
180007b5d:     	popq	%rbx
180007b5e:     	retq
180007b5f:     	int3

0000000180007b60 <numba_list_free>:
180007b60:     	pushq	%rbx
180007b62:     	subq	$0x20, %rsp
180007b66:     	cmpq	$0x0, 0x28(%rcx)
180007b6b:     	movq	%rcx, %rbx
180007b6e:     	je	0x180007ba4 <numba_list_free+0x44>
180007b70:     	movq	%rdi, 0x30(%rsp)
180007b75:     	xorl	%edi, %edi
180007b77:     	cmpq	%rdi, (%rcx)
180007b7a:     	jle	0x180007b9f <numba_list_free+0x3f>
180007b7c:     	nopl	(%rax)
180007b80:     	movq	0x28(%rbx), %rax
180007b84:     	testq	%rax, %rax
180007b87:     	je	0x180007b97 <numba_list_free+0x37>
180007b89:     	movq	%rdi, %rcx
180007b8c:     	imulq	0x8(%rbx), %rcx
180007b91:     	addq	0x30(%rbx), %rcx
180007b95:     	callq	*%rax
180007b97:     	incq	%rdi
180007b9a:     	cmpq	(%rbx), %rdi
180007b9d:     	jl	0x180007b80 <numba_list_free+0x20>
180007b9f:     	movq	0x30(%rsp), %rdi
180007ba4:     	movq	0x30(%rbx), %rcx
180007ba8:     	testq	%rcx, %rcx
180007bab:     	je	0x180007bb3 <numba_list_free+0x53>
180007bad:     	callq	*0x24b5(%rip)           # 0x18000a068
180007bb3:     	movq	%rbx, %rcx
180007bb6:     	addq	$0x20, %rsp
180007bba:     	popq	%rbx
180007bbb:     	jmpq	*0x24a6(%rip)           # 0x18000a068
180007bc2:     	int3
180007bc3:     	int3
180007bc4:     	int3
180007bc5:     	int3
180007bc6:     	int3
180007bc7:     	int3
180007bc8:     	int3
180007bc9:     	int3
180007bca:     	int3
180007bcb:     	int3
180007bcc:     	int3
180007bcd:     	int3
180007bce:     	int3
180007bcf:     	int3

0000000180007bd0 <numba_list_base_ptr>:
180007bd0:     	movq	0x30(%rcx), %rax
180007bd4:     	retq
180007bd5:     	int3
180007bd6:     	int3
180007bd7:     	int3
180007bd8:     	int3
180007bd9:     	int3
180007bda:     	int3
180007bdb:     	int3
180007bdc:     	int3
180007bdd:     	int3
180007bde:     	int3
180007bdf:     	int3

0000000180007be0 <numba_list_size_address>:
180007be0:     	movq	%rcx, %rax
180007be3:     	retq
180007be4:     	int3
180007be5:     	int3
180007be6:     	int3
180007be7:     	int3
180007be8:     	int3
180007be9:     	int3
180007bea:     	int3
180007beb:     	int3
180007bec:     	int3
180007bed:     	int3
180007bee:     	int3
180007bef:     	int3

0000000180007bf0 <numba_list_length>:
180007bf0:     	movq	(%rcx), %rax
180007bf3:     	retq
180007bf4:     	int3
180007bf5:     	int3
180007bf6:     	int3
180007bf7:     	int3
180007bf8:     	int3
180007bf9:     	int3
180007bfa:     	int3
180007bfb:     	int3
180007bfc:     	int3
180007bfd:     	int3
180007bfe:     	int3
180007bff:     	int3

0000000180007c00 <numba_list_allocated>:
180007c00:     	movq	0x10(%rcx), %rax
180007c04:     	retq
180007c05:     	int3
180007c06:     	int3
180007c07:     	int3
180007c08:     	int3
180007c09:     	int3
180007c0a:     	int3
180007c0b:     	int3
180007c0c:     	int3
180007c0d:     	int3
180007c0e:     	int3
180007c0f:     	int3

0000000180007c10 <numba_list_is_mutable>:
180007c10:     	movl	0x18(%rcx), %eax
180007c13:     	retq
180007c14:     	int3
180007c15:     	int3
180007c16:     	int3
180007c17:     	int3
180007c18:     	int3
180007c19:     	int3
180007c1a:     	int3
180007c1b:     	int3
180007c1c:     	int3
180007c1d:     	int3
180007c1e:     	int3
180007c1f:     	int3

0000000180007c20 <numba_list_set_is_mutable>:
180007c20:     	movl	%edx, 0x18(%rcx)
180007c23:     	retq
180007c24:     	int3
180007c25:     	int3
180007c26:     	int3
180007c27:     	int3
180007c28:     	int3
180007c29:     	int3
180007c2a:     	int3
180007c2b:     	int3
180007c2c:     	int3
180007c2d:     	int3
180007c2e:     	int3
180007c2f:     	int3

0000000180007c30 <numba_list_setitem>:
180007c30:     	movq	%rbx, 0x10(%rsp)
180007c35:     	pushq	%rsi
180007c36:     	subq	$0x20, %rsp
180007c3a:     	cmpl	$0x0, 0x18(%rcx)
180007c3e:     	movq	%r8, %rsi
180007c41:     	movq	%rcx, %rbx
180007c44:     	jne	0x180007c56 <numba_list_setitem+0x26>
180007c46:     	movl	$0xfffffffb, %eax       # imm = 0xFFFFFFFB
180007c4b:     	movq	0x38(%rsp), %rbx
180007c50:     	addq	$0x20, %rsp
180007c54:     	popq	%rsi
180007c55:     	retq
180007c56:     	cmpq	(%rcx), %rdx
180007c59:     	jb	0x180007c6b <numba_list_setitem+0x3b>
180007c5b:     	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
180007c60:     	movq	0x38(%rsp), %rbx
180007c65:     	addq	$0x20, %rsp
180007c69:     	popq	%rsi
180007c6a:     	retq
180007c6b:     	imulq	0x8(%rcx), %rdx
180007c70:     	movq	0x28(%rcx), %rax
180007c74:     	movq	%rdi, 0x30(%rsp)
180007c79:     	movq	0x30(%rcx), %rdi
180007c7d:     	addq	%rdx, %rdi
180007c80:     	testq	%rax, %rax
180007c83:     	je	0x180007c8a <numba_list_setitem+0x5a>
180007c85:     	movq	%rdi, %rcx
180007c88:     	callq	*%rax
180007c8a:     	movq	0x8(%rbx), %r8
180007c8e:     	movq	%rsi, %rdx
180007c91:     	movq	%rdi, %rcx
180007c94:     	callq	0x180009043 <numba_list_iter_next+0xec3>
180007c99:     	movq	0x20(%rbx), %rax
180007c9d:     	testq	%rax, %rax
180007ca0:     	je	0x180007ca7 <numba_list_setitem+0x77>
180007ca2:     	movq	%rdi, %rcx
180007ca5:     	callq	*%rax
180007ca7:     	movq	0x30(%rsp), %rdi
180007cac:     	xorl	%eax, %eax
180007cae:     	movq	0x38(%rsp), %rbx
180007cb3:     	addq	$0x20, %rsp
180007cb7:     	popq	%rsi
180007cb8:     	retq
180007cb9:     	int3
180007cba:     	int3
180007cbb:     	int3
180007cbc:     	int3
180007cbd:     	int3
180007cbe:     	int3
180007cbf:     	int3

0000000180007cc0 <numba_list_getitem>:
180007cc0:     	subq	$0x28, %rsp
180007cc4:     	movq	%r8, %r9
180007cc7:     	movq	%rdx, %rax
180007cca:     	cmpq	(%rcx), %rdx
180007ccd:     	jb	0x180007cd9 <numba_list_getitem+0x19>
180007ccf:     	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
180007cd4:     	addq	$0x28, %rsp
180007cd8:     	retq
180007cd9:     	movq	0x8(%rcx), %r8
180007cdd:     	movq	%r8, %rdx
180007ce0:     	imulq	%rax, %rdx
180007ce4:     	addq	0x30(%rcx), %rdx
180007ce8:     	movq	%r9, %rcx
180007ceb:     	callq	0x180009043 <numba_list_iter_next+0xec3>
180007cf0:     	xorl	%eax, %eax
180007cf2:     	addq	$0x28, %rsp
180007cf6:     	retq
180007cf7:     	int3
180007cf8:     	int3
180007cf9:     	int3
180007cfa:     	int3
180007cfb:     	int3
180007cfc:     	int3
180007cfd:     	int3
180007cfe:     	int3
180007cff:     	int3

0000000180007d00 <numba_list_append>:
180007d00:     	movq	%rbx, 0x10(%rsp)
180007d05:     	pushq	%rsi
180007d06:     	subq	$0x20, %rsp
180007d0a:     	cmpl	$0x0, 0x18(%rcx)
180007d0e:     	movq	%rdx, %rsi
180007d11:     	movq	%rcx, %rbx
180007d14:     	jne	0x180007d26 <numba_list_append+0x26>
180007d16:     	movl	$0xfffffffb, %eax       # imm = 0xFFFFFFFB
180007d1b:     	movq	0x38(%rsp), %rbx
180007d20:     	addq	$0x20, %rsp
180007d24:     	popq	%rsi
180007d25:     	retq
180007d26:     	movq	(%rcx), %rdx
180007d29:     	incq	%rdx
180007d2c:     	callq	0x180007d80 <numba_list_resize>
180007d31:     	testl	%eax, %eax
180007d33:     	js	0x180007d6c <numba_list_append+0x6c>
180007d35:     	movq	0x8(%rbx), %r8
180007d39:     	movq	%rsi, %rdx
180007d3c:     	movq	%rdi, 0x30(%rsp)
180007d41:     	movq	(%rbx), %rdi
180007d44:     	decq	%rdi
180007d47:     	imulq	%r8, %rdi
180007d4b:     	addq	0x30(%rbx), %rdi
180007d4f:     	movq	%rdi, %rcx
180007d52:     	callq	0x180009043 <numba_list_iter_next+0xec3>
180007d57:     	movq	0x20(%rbx), %rax
180007d5b:     	testq	%rax, %rax
180007d5e:     	je	0x180007d65 <numba_list_append+0x65>
180007d60:     	movq	%rdi, %rcx
180007d63:     	callq	*%rax
180007d65:     	movq	0x30(%rsp), %rdi
180007d6a:     	xorl	%eax, %eax
180007d6c:     	movq	0x38(%rsp), %rbx
180007d71:     	addq	$0x20, %rsp
180007d75:     	popq	%rsi
180007d76:     	retq
180007d77:     	int3
180007d78:     	int3
180007d79:     	int3
180007d7a:     	int3
180007d7b:     	int3
180007d7c:     	int3
180007d7d:     	int3
180007d7e:     	int3
180007d7f:     	int3

0000000180007d80 <numba_list_resize>:
180007d80:     	movq	%rsi, 0x18(%rsp)
180007d85:     	pushq	%rdi
180007d86:     	subq	$0x20, %rsp
180007d8a:     	cmpl	$0x0, 0x18(%rcx)
180007d8e:     	movq	%rdx, %rsi
180007d91:     	movq	%rcx, %rdi
180007d94:     	jne	0x180007da6 <numba_list_resize+0x26>
180007d96:     	movl	$0xfffffffb, %eax       # imm = 0xFFFFFFFB
180007d9b:     	movq	0x40(%rsp), %rsi
180007da0:     	addq	$0x20, %rsp
180007da4:     	popq	%rdi
180007da5:     	retq
180007da6:     	movq	0x10(%rcx), %rax
180007daa:     	cmpq	%rsi, %rax
180007dad:     	jl	0x180007dc7 <numba_list_resize+0x47>
180007daf:     	sarq	%rax
180007db2:     	cmpq	%rax, %rsi
180007db5:     	jl	0x180007dc7 <numba_list_resize+0x47>
180007db7:     	movq	%rsi, (%rcx)
180007dba:     	xorl	%eax, %eax
180007dbc:     	movq	0x40(%rsp), %rsi
180007dc1:     	addq	$0x20, %rsp
180007dc5:     	popq	%rdi
180007dc6:     	retq
180007dc7:     	cmpq	$0x9, %rsi
180007dcb:     	movq	%rbp, 0x38(%rsp)
180007dd0:     	movl	$0x3, %ecx
180007dd5:     	movl	$0x6, %eax
180007dda:     	cmovll	%ecx, %eax
180007ddd:     	movq	%rsi, %r8
180007de0:     	movq	0x8(%rdi), %rcx
180007de4:     	addq	%rsi, %rax
180007de7:     	sarq	$0x3, %r8
180007deb:     	xorl	%edx, %edx
180007ded:     	addq	%rax, %r8
180007df0:     	movabsq	$0x7fffffffffffffff, %rax # imm = 0x7FFFFFFFFFFFFFFF
180007dfa:     	divq	%rcx
180007dfd:     	cmpq	%rax, %r8
180007e00:     	ja	0x180007e7b <numba_list_resize+0xfb>
180007e02:     	xorl	%ebp, %ebp
180007e04:     	movq	%rbx, 0x30(%rsp)
180007e09:     	testq	%rsi, %rsi
180007e0c:     	cmovneq	%r8, %rbp
180007e10:     	movq	%rbp, %rbx
180007e13:     	imulq	%rcx, %rbx
180007e17:     	movl	$0x8, %ecx
180007e1c:     	movq	%rbx, %rax
180007e1f:     	cqto
180007e21:     	andl	$0x7, %edx
180007e24:     	addq	%rdx, %rax
180007e27:     	andl	$0x7, %eax
180007e2a:     	subq	%rdx, %rax
180007e2d:     	subq	%rax, %rcx
180007e30:     	movq	%rcx, %rax
180007e33:     	movq	0x30(%rdi), %rcx
180007e37:     	cqto
180007e39:     	andl	$0x7, %edx
180007e3c:     	addq	%rdx, %rax
180007e3f:     	andl	$0x7, %eax
180007e42:     	subq	%rdx, %rax
180007e45:     	leaq	(%rbx,%rax), %rdx
180007e49:     	callq	*0x2221(%rip)           # 0x18000a070
180007e4f:     	testq	%rbx, %rbx
180007e52:     	movq	0x30(%rsp), %rbx
180007e57:     	je	0x180007e5e <numba_list_resize+0xde>
180007e59:     	testq	%rax, %rax
180007e5c:     	je	0x180007e7b <numba_list_resize+0xfb>
180007e5e:     	movq	%rax, 0x30(%rdi)
180007e62:     	xorl	%eax, %eax
180007e64:     	movq	%rbp, 0x10(%rdi)
180007e68:     	movq	0x38(%rsp), %rbp
180007e6d:     	movq	%rsi, (%rdi)
180007e70:     	movq	0x40(%rsp), %rsi
180007e75:     	addq	$0x20, %rsp
180007e79:     	popq	%rdi
180007e7a:     	retq
180007e7b:     	movq	0x38(%rsp), %rbp
180007e80:     	movl	$0xfffffffe, %eax       # imm = 0xFFFFFFFE
180007e85:     	movq	0x40(%rsp), %rsi
180007e8a:     	addq	$0x20, %rsp
180007e8e:     	popq	%rdi
180007e8f:     	retq

0000000180007e90 <numba_list_delitem>:
180007e90:     	movq	%rbx, 0x10(%rsp)
180007e95:     	pushq	%rdi
180007e96:     	subq	$0x20, %rsp
180007e9a:     	cmpl	$0x0, 0x18(%rcx)
180007e9e:     	movq	%rdx, %rdi
180007ea1:     	movq	%rcx, %rbx
180007ea4:     	jne	0x180007eb6 <numba_list_delitem+0x26>
180007ea6:     	movl	$0xfffffffb, %eax       # imm = 0xFFFFFFFB
180007eab:     	movq	0x38(%rsp), %rbx
180007eb0:     	addq	$0x20, %rsp
180007eb4:     	popq	%rdi
180007eb5:     	retq
180007eb6:     	cmpq	(%rcx), %rdi
180007eb9:     	jb	0x180007ecb <numba_list_delitem+0x3b>
180007ebb:     	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
180007ec0:     	movq	0x38(%rsp), %rbx
180007ec5:     	addq	$0x20, %rsp
180007ec9:     	popq	%rdi
180007eca:     	retq
180007ecb:     	movq	0x28(%rcx), %rax
180007ecf:     	movq	%rsi, 0x30(%rsp)
180007ed4:     	movq	%rdi, %rsi
180007ed7:     	imulq	0x8(%rcx), %rsi
180007edc:     	addq	0x30(%rcx), %rsi
180007ee0:     	testq	%rax, %rax
180007ee3:     	je	0x180007eea <numba_list_delitem+0x5a>
180007ee5:     	movq	%rsi, %rcx
180007ee8:     	callq	*%rax
180007eea:     	movq	(%rbx), %r8
180007eed:     	leaq	-0x1(%r8), %rax
180007ef1:     	cmpq	%rax, %rdi
180007ef4:     	je	0x180007f16 <numba_list_delitem+0x86>
180007ef6:     	subq	%rdi, %r8
180007ef9:     	leaq	0x1(%rdi), %rdx
180007efd:     	imulq	0x8(%rbx), %rdx
180007f02:     	decq	%r8
180007f05:     	movq	%rsi, %rcx
180007f08:     	imulq	0x8(%rbx), %r8
180007f0d:     	addq	0x30(%rbx), %rdx
180007f11:     	callq	0x180009049 <numba_list_iter_next+0xec9>
180007f16:     	movq	(%rbx), %rdx
180007f19:     	movq	%rbx, %rcx
180007f1c:     	decq	%rdx
180007f1f:     	callq	0x180007d80 <numba_list_resize>
180007f24:     	movq	0x30(%rsp), %rsi
180007f29:     	xorl	%ecx, %ecx
180007f2b:     	movq	0x38(%rsp), %rbx
180007f30:     	testl	%eax, %eax
180007f32:     	cmovsl	%eax, %ecx
180007f35:     	movl	%ecx, %eax
180007f37:     	addq	$0x20, %rsp
180007f3b:     	popq	%rdi
180007f3c:     	retq
180007f3d:     	int3
180007f3e:     	int3
180007f3f:     	int3

0000000180007f40 <numba_list_delete_slice>:
180007f40:     	pushq	%rbx
180007f42:     	pushq	%rbp
180007f43:     	pushq	%rdi
180007f44:     	pushq	%r15
180007f46:     	subq	$0x38, %rsp
180007f4a:     	cmpl	$0x0, 0x18(%rcx)
180007f4e:     	movq	%r9, %rdi
180007f51:     	movq	%r8, %rbp
180007f54:     	movq	%rdx, %r15
180007f57:     	movq	%rcx, %rbx
180007f5a:     	jne	0x180007f6b <numba_list_delete_slice+0x2b>
180007f5c:     	movl	$0xfffffffb, %eax       # imm = 0xFFFFFFFB
180007f61:     	addq	$0x38, %rsp
180007f65:     	popq	%r15
180007f67:     	popq	%rdi
180007f68:     	popq	%rbp
180007f69:     	popq	%rbx
180007f6a:     	retq
180007f6b:     	movq	%r13, 0x78(%rsp)
180007f70:     	testq	%rdi, %rdi
180007f73:     	jle	0x180007f92 <numba_list_delete_slice+0x52>
180007f75:     	cmpq	%r8, %r15
180007f78:     	jge	0x180008131 <numba_list_delete_slice+0x1f1>
180007f7e:     	movq	%r8, %rax
180007f81:     	subq	%r15, %rax
180007f84:     	decq	%rax
180007f87:     	cqto
180007f89:     	idivq	%rdi
180007f8c:     	leal	0x1(%rax), %r13d
180007f90:     	jmp	0x180007fb2 <numba_list_delete_slice+0x72>
180007f92:     	cmpq	%r15, %r8
180007f95:     	jge	0x180008131 <numba_list_delete_slice+0x1f1>
180007f9b:     	movq	%r15, %rax
180007f9e:     	movl	$0x1, %r13d
180007fa4:     	subq	%r8, %rax
180007fa7:     	decq	%rax
180007faa:     	cqto
180007fac:     	idivq	%rdi
180007faf:     	subl	%eax, %r13d
180007fb2:     	testl	%r13d, %r13d
180007fb5:     	jle	0x180008131 <numba_list_delete_slice+0x1f1>
180007fbb:     	movq	%rsi, 0x68(%rsp)
180007fc0:     	movl	(%rcx), %esi
180007fc2:     	subl	%r13d, %esi
180007fc5:     	movl	%esi, 0x20(%rsp)
180007fc9:     	testq	%rdi, %rdi
180007fcc:     	jns	0x180007fe7 <numba_list_delete_slice+0xa7>
180007fce:     	leaq	0x1(%r15), %rbp
180007fd2:     	leal	-0x1(%r13), %eax
180007fd6:     	movslq	%eax, %rcx
180007fd9:     	leaq	-0x1(%rbp), %r15
180007fdd:     	imulq	%rdi, %rcx
180007fe1:     	addq	%rcx, %r15
180007fe4:     	negq	%rdi
180007fe7:     	cmpq	$0x1, %rdi
180007feb:     	jne	0x180008037 <numba_list_delete_slice+0xf7>
180007fed:     	cmpq	$0x0, 0x28(%rbx)
180007ff2:     	je	0x180008019 <numba_list_delete_slice+0xd9>
180007ff4:     	movslq	%r15d, %rdi
180007ff7:     	cmpq	%rbp, %rdi
180007ffa:     	jge	0x180008019 <numba_list_delete_slice+0xd9>
180007ffc:     	nopl	(%rax)
180008000:     	movslq	%edi, %rcx
180008003:     	imulq	0x8(%rbx), %rcx
180008008:     	addq	0x30(%rbx), %rcx
18000800c:     	callq	*0x28(%rbx)
18000800f:     	incl	%edi
180008011:     	movslq	%edi, %rax
180008014:     	cmpq	%rbp, %rax
180008017:     	jl	0x180008000 <numba_list_delete_slice+0xc0>
180008019:     	movq	0x8(%rbx), %rcx
18000801d:     	movq	(%rbx), %r8
180008020:     	movq	%rcx, %rdx
180008023:     	subq	%rbp, %r8
180008026:     	imulq	%rcx, %r8
18000802a:     	imulq	%rbp, %rdx
18000802e:     	imulq	%r15, %rcx
180008032:     	jmp	0x1800080fc <numba_list_delete_slice+0x1bc>
180008037:     	movq	%r14, 0x30(%rsp)
18000803c:     	movq	%r15, %r14
18000803f:     	movl	$0x0, 0x60(%rsp)
180008047:     	cmpq	%rbp, %r15
18000804a:     	jge	0x1800080c9 <numba_list_delete_slice+0x189>
18000804c:     	movq	%r12, 0x70(%rsp)
180008051:     	movq	(%rbx), %rax
180008054:     	leaq	(%r14,%rdi), %r12
180008058:     	cmpq	%rax, %r12
18000805b:     	jl	0x180008068 <numba_list_delete_slice+0x128>
18000805d:     	movq	%r14, %rsi
180008060:     	notq	%rsi
180008063:     	addq	%rax, %rsi
180008066:     	jmp	0x18000806c <numba_list_delete_slice+0x12c>
180008068:     	leaq	-0x1(%rdi), %rsi
18000806c:     	movq	0x28(%rbx), %rax
180008070:     	testq	%rax, %rax
180008073:     	je	0x180008083 <numba_list_delete_slice+0x143>
180008075:     	movq	%r14, %rcx
180008078:     	imulq	0x8(%rbx), %rcx
18000807d:     	addq	0x30(%rbx), %rcx
180008081:     	callq	*%rax
180008083:     	movq	0x8(%rbx), %r9
180008087:     	leaq	0x1(%r14), %rdx
18000808b:     	movq	0x30(%rbx), %r10
18000808f:     	movq	%r9, %r8
180008092:     	imulq	%rsi, %r8
180008096:     	imulq	%r9, %rdx
18000809a:     	movslq	0x60(%rsp), %rsi
18000809f:     	subq	%rsi, %r14
1800080a2:     	imulq	%r9, %r14
1800080a6:     	addq	%r10, %rdx
1800080a9:     	leaq	(%r10,%r14), %rcx
1800080ad:     	callq	0x180009049 <numba_list_iter_next+0xec9>
1800080b2:     	incl	%esi
1800080b4:     	movq	%r12, %r14
1800080b7:     	movl	%esi, 0x60(%rsp)
1800080bb:     	cmpq	%rbp, %r12
1800080be:     	jl	0x180008051 <numba_list_delete_slice+0x111>
1800080c0:     	movq	0x70(%rsp), %r12
1800080c5:     	movl	0x20(%rsp), %esi
1800080c9:     	movq	(%rbx), %r8
1800080cc:     	movq	0x30(%rsp), %r14
1800080d1:     	movslq	%r13d, %r10
1800080d4:     	movq	%r10, %rcx
1800080d7:     	imulq	%rdi, %rcx
1800080db:     	addq	%r15, %rcx
1800080de:     	cmpq	%r8, %rcx
1800080e1:     	jge	0x180008109 <numba_list_delete_slice+0x1c9>
1800080e3:     	movq	0x8(%rbx), %rax
1800080e7:     	subq	%rcx, %r8
1800080ea:     	movq	%rax, %rdx
1800080ed:     	imulq	%rcx, %rdx
1800080f1:     	imulq	%rax, %r8
1800080f5:     	subq	%r10, %rcx
1800080f8:     	imulq	%rax, %rcx
1800080fc:     	addq	0x30(%rbx), %rdx
180008100:     	addq	0x30(%rbx), %rcx
180008104:     	callq	0x180009049 <numba_list_iter_next+0xec9>
180008109:     	movslq	%esi, %rdx
18000810c:     	movq	%rbx, %rcx
18000810f:     	callq	0x180007d80 <numba_list_resize>
180008114:     	movq	0x68(%rsp), %rsi
180008119:     	xorl	%ecx, %ecx
18000811b:     	movq	0x78(%rsp), %r13
180008120:     	testl	%eax, %eax
180008122:     	cmovsl	%eax, %ecx
180008125:     	movl	%ecx, %eax
180008127:     	addq	$0x38, %rsp
18000812b:     	popq	%r15
18000812d:     	popq	%rdi
18000812e:     	popq	%rbp
18000812f:     	popq	%rbx
180008130:     	retq
180008131:     	movq	0x78(%rsp), %r13
180008136:     	xorl	%eax, %eax
180008138:     	addq	$0x38, %rsp
18000813c:     	popq	%r15
18000813e:     	popq	%rdi
18000813f:     	popq	%rbp
180008140:     	popq	%rbx
180008141:     	retq
180008142:     	int3
180008143:     	int3
180008144:     	int3
180008145:     	int3
180008146:     	int3
180008147:     	int3
180008148:     	int3
180008149:     	int3
18000814a:     	int3
18000814b:     	int3
18000814c:     	int3
18000814d:     	int3
18000814e:     	int3
18000814f:     	int3

0000000180008150 <numba_list_iter_sizeof>:
180008150:     	movl	$0x18, %eax
180008155:     	retq
180008156:     	int3
180008157:     	int3
180008158:     	int3
180008159:     	int3
18000815a:     	int3
18000815b:     	int3
18000815c:     	int3
18000815d:     	int3
18000815e:     	int3
18000815f:     	int3

0000000180008160 <numba_list_iter>:
180008160:     	movq	%rdx, (%rcx)
180008163:     	movq	(%rdx), %rax
180008166:     	movq	%rax, 0x8(%rcx)
18000816a:     	movq	$0x0, 0x10(%rcx)
180008172:     	retq
180008173:     	int3
180008174:     	int3
180008175:     	int3
180008176:     	int3
180008177:     	int3
180008178:     	int3
180008179:     	int3
18000817a:     	int3
18000817b:     	int3
18000817c:     	int3
18000817d:     	int3
18000817e:     	int3
18000817f:     	int3

0000000180008180 <numba_list_iter_next>:
180008180:     	movq	(%rcx), %r8
180008183:     	movq	(%r8), %r9
180008186:     	cmpq	0x8(%rcx), %r9
18000818a:     	je	0x180008192 <numba_list_iter_next+0x12>
18000818c:     	movl	$0xfffffffd, %eax       # imm = 0xFFFFFFFD
180008191:     	retq
180008192:     	movq	0x10(%rcx), %rax
180008196:     	cmpq	%r9, %rax
180008199:     	jge	0x1800081ae <numba_list_iter_next+0x2e>
18000819b:     	imulq	0x8(%r8), %rax
1800081a0:     	addq	0x30(%r8), %rax
1800081a4:     	movq	%rax, (%rdx)
1800081a7:     	incq	0x10(%rcx)
1800081ab:     	xorl	%eax, %eax
1800081ad:     	retq
1800081ae:     	movl	$0xfffffffc, %eax       # imm = 0xFFFFFFFC
1800081b3:     	retq
1800081b4:     	int3
1800081b5:     	int3
1800081b6:     	int3
1800081b7:     	int3
1800081b8:     	int3
1800081b9:     	int3
1800081ba:     	int3
1800081bb:     	int3
1800081bc:     	int3
1800081bd:     	int3
1800081be:     	int3
1800081bf:     	int3
1800081c0:     	pushq	%rbx
1800081c2:     	subq	$0x20, %rsp
1800081c6:     	movq	%rcx, %rbx
1800081c9:     	addq	$0x30, %rcx
1800081cd:     	callq	*0x9a95(%rip)           # 0x180011c68
1800081d3:     	cmpb	$0x0, 0x9a66(%rip)      # 0x180011c40
1800081da:     	je	0x1800081e4 <numba_list_iter_next+0x64>
1800081dc:     	lock
1800081dd:     	incq	0x9a64(%rip)            # 0x180011c48
1800081e4:     	testq	%rax, %rax
1800081e7:     	je	0x180008228 <numba_list_iter_next+0xa8>
1800081e9:     	leaq	0x30(%rax), %rdx
1800081ed:     	testq	%rdx, %rdx
1800081f0:     	je	0x180008228 <numba_list_iter_next+0xa8>
1800081f2:     	xorl	%r8d, %r8d
1800081f5:     	movl	$0x1, %ecx
1800081fa:     	xchgq	%rcx, (%rax)
1800081fd:     	movq	%r8, 0x8(%rax)
180008201:     	movq	%r8, 0x10(%rax)
180008205:     	movq	%rdx, 0x18(%rax)
180008209:     	movq	%rbx, 0x20(%rax)
18000820d:     	movq	%r8, 0x28(%rax)
180008211:     	cmpb	%r8b, 0x9a28(%rip)      # 0x180011c40
180008218:     	je	0x18000822a <numba_list_iter_next+0xaa>
18000821a:     	lock
18000821b:     	incq	0x9a36(%rip)            # 0x180011c58
180008222:     	addq	$0x20, %rsp
180008226:     	popq	%rbx
180008227:     	retq
180008228:     	xorl	%eax, %eax
18000822a:     	addq	$0x20, %rsp
18000822e:     	popq	%rbx
18000822f:     	retq
180008230:     	movq	%rbx, 0x8(%rsp)
180008235:     	pushq	%rdi
180008236:     	subq	$0x20, %rsp
18000823a:     	movq	%rcx, %rdi
18000823d:     	movq	%rdx, %rbx
180008240:     	addq	$0x30, %rcx
180008244:     	testq	%rdx, %rdx
180008247:     	je	0x180008251 <numba_list_iter_next+0xd1>
180008249:     	movq	0x18(%rdx), %rdx
18000824d:     	callq	*(%rbx)
18000824f:     	jmp	0x180008257 <numba_list_iter_next+0xd7>
180008251:     	callq	*0x9a11(%rip)           # 0x180011c68
180008257:     	cmpb	$0x0, 0x99e2(%rip)      # 0x180011c40
18000825e:     	movq	%rax, %r8
180008261:     	je	0x18000826b <numba_list_iter_next+0xeb>
180008263:     	lock
180008264:     	incq	0x99dd(%rip)            # 0x180011c48
18000826b:     	xorl	%edx, %edx
18000826d:     	leaq	0x30(%r8), %rax
180008271:     	testq	%r8, %r8
180008274:     	movl	%edx, %ecx
180008276:     	cmovneq	%rax, %rcx
18000827a:     	testq	%rcx, %rcx
18000827d:     	jne	0x18000828c <numba_list_iter_next+0x10c>
18000827f:     	xorl	%eax, %eax
180008281:     	movq	0x30(%rsp), %rbx
180008286:     	addq	$0x20, %rsp
18000828a:     	popq	%rdi
18000828b:     	retq
18000828c:     	movl	$0x1, %eax
180008291:     	xchgq	%rax, (%r8)
180008294:     	movq	%rdx, 0x8(%r8)
180008298:     	movq	%rdx, 0x10(%r8)
18000829c:     	movq	%rcx, 0x18(%r8)
1800082a0:     	movq	%rdi, 0x20(%r8)
1800082a4:     	movq	%rbx, 0x28(%r8)
1800082a8:     	cmpb	%dl, 0x9992(%rip)       # 0x180011c40
1800082ae:     	je	0x1800082b8 <numba_list_iter_next+0x138>
1800082b0:     	lock
1800082b1:     	incq	0x99a0(%rip)            # 0x180011c58
1800082b8:     	movq	0x30(%rsp), %rbx
1800082bd:     	movq	%r8, %rax
1800082c0:     	addq	$0x20, %rsp
1800082c4:     	popq	%rdi
1800082c5:     	retq
1800082c6:     	int3
1800082c7:     	int3
1800082c8:     	int3
1800082c9:     	int3
1800082ca:     	int3
1800082cb:     	int3
1800082cc:     	int3
1800082cd:     	int3
1800082ce:     	int3
1800082cf:     	int3
1800082d0:     	lock
1800082d1:     	incq	(%rcx)
1800082d4:     	retq
1800082d5:     	int3
1800082d6:     	int3
1800082d7:     	int3
1800082d8:     	int3
1800082d9:     	int3
1800082da:     	int3
1800082db:     	int3
1800082dc:     	int3
1800082dd:     	int3
1800082de:     	int3
1800082df:     	int3
1800082e0:     	pushq	%rbx
1800082e2:     	subq	$0x20, %rsp
1800082e6:     	movq	0x8(%rcx), %rax
1800082ea:     	movq	%rcx, %rbx
1800082ed:     	testq	%rax, %rax
1800082f0:     	je	0x180008309 <numba_list_iter_next+0x189>
1800082f2:     	cmpl	$0x0, 0x993f(%rip)      # 0x180011c38
1800082f9:     	jne	0x180008309 <numba_list_iter_next+0x189>
1800082fb:     	movq	0x10(%rcx), %r8
1800082ff:     	movq	0x20(%rcx), %rdx
180008303:     	movq	0x18(%rcx), %rcx
180008307:     	callq	*%rax
180008309:     	movq	0x28(%rbx), %rax
18000830d:     	movq	%rbx, %rcx
180008310:     	testq	%rax, %rax
180008313:     	je	0x18000831e <numba_list_iter_next+0x19e>
180008315:     	movq	0x18(%rax), %rdx
180008319:     	callq	*0x10(%rax)
18000831c:     	jmp	0x180008324 <numba_list_iter_next+0x1a4>
18000831e:     	callq	*0x9954(%rip)           # 0x180011c78
180008324:     	cmpb	$0x0, 0x9915(%rip)      # 0x180011c40
18000832b:     	je	0x180008349 <numba_list_iter_next+0x1c9>
18000832d:     	leaq	0x991c(%rip), %rax      # 0x180011c50
180008334:     	lock
180008335:     	incq	(%rax)
180008338:     	cmpb	$0x0, 0x9901(%rip)      # 0x180011c40
18000833f:     	je	0x180008349 <numba_list_iter_next+0x1c9>
180008341:     	lock
180008342:     	incq	0x9917(%rip)            # 0x180011c60
180008349:     	addq	$0x20, %rsp
18000834d:     	popq	%rbx
18000834e:     	retq
18000834f:     	int3
180008350:     	pushq	%rbx
180008352:     	subq	$0x20, %rsp
180008356:     	movq	%rcx, %rbx
180008359:     	movq	$-0x1, %rax
180008360:     	lock
180008361:     	xaddq	%rax, (%rcx)
180008365:     	cmpq	$0x1, %rax
180008369:     	jne	0x1800083cb <numba_list_iter_next+0x24b>
18000836b:     	movq	0x8(%rcx), %rax
18000836f:     	testq	%rax, %rax
180008372:     	je	0x18000838b <numba_list_iter_next+0x20b>
180008374:     	cmpl	$0x0, 0x98bd(%rip)      # 0x180011c38
18000837b:     	jne	0x18000838b <numba_list_iter_next+0x20b>
18000837d:     	movq	0x10(%rcx), %r8
180008381:     	movq	0x20(%rcx), %rdx
180008385:     	movq	0x18(%rcx), %rcx
180008389:     	callq	*%rax
18000838b:     	movq	0x28(%rbx), %rax
18000838f:     	movq	%rbx, %rcx
180008392:     	testq	%rax, %rax
180008395:     	je	0x1800083a0 <numba_list_iter_next+0x220>
180008397:     	movq	0x18(%rax), %rdx
18000839b:     	callq	*0x10(%rax)
18000839e:     	jmp	0x1800083a6 <numba_list_iter_next+0x226>
1800083a0:     	callq	*0x98d2(%rip)           # 0x180011c78
1800083a6:     	cmpb	$0x0, 0x9893(%rip)      # 0x180011c40
1800083ad:     	je	0x1800083cb <numba_list_iter_next+0x24b>
1800083af:     	leaq	0x989a(%rip), %rax      # 0x180011c50
1800083b6:     	lock
1800083b7:     	incq	(%rax)
1800083ba:     	cmpb	$0x0, 0x987f(%rip)      # 0x180011c40
1800083c1:     	je	0x1800083cb <numba_list_iter_next+0x24b>
1800083c3:     	lock
1800083c4:     	incq	0x9895(%rip)            # 0x180011c60
1800083cb:     	addq	$0x20, %rsp
1800083cf:     	popq	%rbx
1800083d0:     	retq
1800083d1:     	int3
1800083d2:     	int3
1800083d3:     	int3
1800083d4:     	int3
1800083d5:     	int3
1800083d6:     	int3
1800083d7:     	int3
1800083d8:     	int3
1800083d9:     	int3
1800083da:     	int3
1800083db:     	int3
1800083dc:     	int3
1800083dd:     	int3
1800083de:     	int3
1800083df:     	int3
1800083e0:     	movq	0x18(%rcx), %rax
1800083e4:     	retq
1800083e5:     	int3
1800083e6:     	int3
1800083e7:     	int3
1800083e8:     	int3
1800083e9:     	int3
1800083ea:     	int3
1800083eb:     	int3
1800083ec:     	int3
1800083ed:     	int3
1800083ee:     	int3
1800083ef:     	int3
1800083f0:     	subq	$0x28, %rsp
1800083f4:     	callq	*0x987e(%rip)           # 0x180011c78
1800083fa:     	cmpb	$0x0, 0x983f(%rip)      # 0x180011c40
180008401:     	je	0x18000840b <numba_list_iter_next+0x28b>
180008403:     	lock
180008404:     	incq	0x9845(%rip)            # 0x180011c50
18000840b:     	addq	$0x28, %rsp
18000840f:     	retq
180008410:     	jmpq	*%r8
180008413:     	int3
180008414:     	int3
180008415:     	int3
180008416:     	int3
180008417:     	int3
180008418:     	int3
180008419:     	int3
18000841a:     	int3
18000841b:     	int3
18000841c:     	int3
18000841d:     	int3
18000841e:     	int3
18000841f:     	int3
180008420:     	movq	%rbx, 0x8(%rsp)
180008425:     	pushq	%rdi
180008426:     	subq	$0x20, %rsp
18000842a:     	movq	%rcx, %rdi
18000842d:     	movq	%rdx, %rbx
180008430:     	movl	$0x30, %ecx
180008435:     	callq	*0x982d(%rip)           # 0x180011c68
18000843b:     	cmpb	$0x0, 0x97fe(%rip)      # 0x180011c40
180008442:     	je	0x18000844c <numba_list_iter_next+0x2cc>
180008444:     	lock
180008445:     	incq	0x97fc(%rip)            # 0x180011c48
18000844c:     	testq	%rax, %rax
18000844f:     	je	0x180008486 <numba_list_iter_next+0x306>
180008451:     	leaq	-0x48(%rip), %rcx       # 0x180008410 <numba_list_iter_next+0x290>
180008458:     	movl	$0x1, %edx
18000845d:     	xchgq	%rdx, (%rax)
180008460:     	movq	%rcx, 0x8(%rax)
180008464:     	xorl	%ecx, %ecx
180008466:     	movq	%rcx, 0x20(%rax)
18000846a:     	movq	%rcx, 0x28(%rax)
18000846e:     	movq	%rbx, 0x10(%rax)
180008472:     	movq	%rdi, 0x18(%rax)
180008476:     	cmpb	%cl, 0x97c4(%rip)       # 0x180011c40
18000847c:     	je	0x180008486 <numba_list_iter_next+0x306>
18000847e:     	lock
18000847f:     	incq	0x97d2(%rip)            # 0x180011c58
180008486:     	movq	0x30(%rsp), %rbx
18000848b:     	addq	$0x20, %rsp
18000848f:     	popq	%rdi
180008490:     	retq
180008491:     	jmpq	*0x1e79(%rip)           # 0x18000a310
180008497:     	jmpq	*0x1e63(%rip)           # 0x18000a300
18000849d:     	jmpq	*0x1e55(%rip)           # 0x18000a2f8
1800084a3:     	jmpq	*0x1e47(%rip)           # 0x18000a2f0
1800084a9:     	jmpq	*0x1e39(%rip)           # 0x18000a2e8
1800084af:     	jmpq	*0x1e2b(%rip)           # 0x18000a2e0
1800084b5:     	jmpq	*0x1e1d(%rip)           # 0x18000a2d8
1800084bb:     	jmpq	*0x1e07(%rip)           # 0x18000a2c8
1800084c1:     	jmpq	*0x1df9(%rip)           # 0x18000a2c0
1800084c7:     	jmpq	*0x1deb(%rip)           # 0x18000a2b8
1800084cd:     	jmpq	*0x1dd5(%rip)           # 0x18000a2a8
1800084d3:     	jmpq	*0x1daf(%rip)           # 0x18000a288
1800084d9:     	jmpq	*0x1da1(%rip)           # 0x18000a280
1800084df:     	jmpq	*0x1d93(%rip)           # 0x18000a278
1800084e5:     	jmpq	*0x1d85(%rip)           # 0x18000a270
1800084eb:     	jmpq	*0x1d3f(%rip)           # 0x18000a230
1800084f1:     	int3
1800084f2:     	int3
1800084f3:     	int3
1800084f4:     	int3
1800084f5:     	int3
1800084f6:     	int3
1800084f7:     	int3
1800084f8:     	int3
1800084f9:     	int3
1800084fa:     	int3
1800084fb:     	int3
1800084fc:     	int3
1800084fd:     	int3
1800084fe:     	int3
1800084ff:     	int3
180008500:     	int3
180008501:     	int3
180008502:     	int3
180008503:     	int3
180008504:     	int3
180008505:     	int3
180008506:     	nopw	(%rax,%rax)
180008510:     	cmpq	0x8be9(%rip), %rcx      # 0x180011100
180008517:     	jne	0x180008529 <numba_list_iter_next+0x3a9>
180008519:     	rolq	$0x10, %rcx
18000851d:     	testw	$0xffff, %cx            # imm = 0xFFFF
180008522:     	jne	0x180008525 <numba_list_iter_next+0x3a5>
180008524:     	retq
180008525:     	rorq	$0x10, %rcx
180008529:     	jmp	0x180008884 <numba_list_iter_next+0x704>
18000852e:     	int3
18000852f:     	int3
180008530:     	subq	$0x28, %rsp
180008534:     	testl	%edx, %edx
180008536:     	je	0x180008571 <numba_list_iter_next+0x3f1>
180008538:     	subl	$0x1, %edx
18000853b:     	je	0x180008565 <numba_list_iter_next+0x3e5>
18000853d:     	subl	$0x1, %edx
180008540:     	je	0x180008558 <numba_list_iter_next+0x3d8>
180008542:     	cmpl	$0x1, %edx
180008545:     	je	0x180008551 <numba_list_iter_next+0x3d1>
180008547:     	movl	$0x1, %eax
18000854c:     	addq	$0x28, %rsp
180008550:     	retq
180008551:     	callq	0x180008a50 <numba_list_iter_next+0x8d0>
180008556:     	jmp	0x18000855d <numba_list_iter_next+0x3dd>
180008558:     	callq	0x180008a28 <numba_list_iter_next+0x8a8>
18000855d:     	movzbl	%al, %eax
180008560:     	addq	$0x28, %rsp
180008564:     	retq
180008565:     	movq	%r8, %rdx
180008568:     	addq	$0x28, %rsp
18000856c:     	jmp	0x180008580 <numba_list_iter_next+0x400>
180008571:     	testq	%r8, %r8
180008574:     	setne	%cl
180008577:     	addq	$0x28, %rsp
18000857b:     	jmp	0x180008698 <numba_list_iter_next+0x518>
180008580:     	movq	%rbx, 0x8(%rsp)
180008585:     	movq	%rsi, 0x10(%rsp)
18000858a:     	movq	%rdi, 0x20(%rsp)
18000858f:     	pushq	%r14
180008591:     	subq	$0x20, %rsp
180008595:     	movq	%rdx, %rsi
180008598:     	movq	%rcx, %r14
18000859b:     	xorl	%ecx, %ecx
18000859d:     	callq	0x180008b0c <numba_list_iter_next+0x98c>
1800085a2:     	testb	%al, %al
1800085a4:     	je	0x180008672 <numba_list_iter_next+0x4f2>
1800085aa:     	callq	0x1800089a0 <numba_list_iter_next+0x820>
1800085af:     	movb	%al, %bl
1800085b1:     	movb	%al, 0x40(%rsp)
1800085b5:     	movb	$0x1, %dil
1800085b8:     	cmpl	$0x0, 0x9449(%rip)      # 0x180011a08
1800085bf:     	jne	0x18000868a <numba_list_iter_next+0x50a>
1800085c5:     	movl	$0x1, 0x9439(%rip)      # 0x180011a08
1800085cf:     	callq	0x180008a10 <numba_list_iter_next+0x890>
1800085d4:     	testb	%al, %al
1800085d6:     	je	0x180008627 <numba_list_iter_next+0x4a7>
1800085d8:     	callq	0x180008ccc <numba_list_iter_next+0xb4c>
1800085dd:     	callq	0x180008960 <numba_list_iter_next+0x7e0>
1800085e2:     	callq	0x180008984 <numba_list_iter_next+0x804>
1800085e7:     	leaq	0x1d82(%rip), %rdx      # 0x18000a370
1800085ee:     	leaq	0x1d73(%rip), %rcx      # 0x18000a368
1800085f5:     	callq	0x180009012 <numba_list_iter_next+0xe92>
1800085fa:     	testl	%eax, %eax
1800085fc:     	jne	0x180008627 <numba_list_iter_next+0x4a7>
1800085fe:     	callq	0x1800089dc <numba_list_iter_next+0x85c>
180008603:     	testb	%al, %al
180008605:     	je	0x180008627 <numba_list_iter_next+0x4a7>
180008607:     	leaq	0x1d52(%rip), %rdx      # 0x18000a360
18000860e:     	leaq	0x1d43(%rip), %rcx      # 0x18000a358
180008615:     	callq	0x18000900c <numba_list_iter_next+0xe8c>
18000861a:     	movl	$0x2, 0x93e4(%rip)      # 0x180011a08
180008624:     	xorb	%dil, %dil
180008627:     	movb	%bl, %cl
180008629:     	callq	0x180008c6c <numba_list_iter_next+0xaec>
18000862e:     	testb	%dil, %dil
180008631:     	jne	0x180008672 <numba_list_iter_next+0x4f2>
180008633:     	callq	0x180008cbc <numba_list_iter_next+0xb3c>
180008638:     	movq	%rax, %rbx
18000863b:     	cmpq	$0x0, (%rax)
18000863f:     	je	0x180008665 <numba_list_iter_next+0x4e5>
180008641:     	movq	%rax, %rcx
180008644:     	callq	0x180008bd4 <numba_list_iter_next+0xa54>
180008649:     	testb	%al, %al
18000864b:     	je	0x180008665 <numba_list_iter_next+0x4e5>
18000864d:     	movq	%rsi, %r8
180008650:     	movl	$0x2, %edx
180008655:     	movq	%r14, %rcx
180008658:     	movq	(%rbx), %rax
18000865b:     	movq	0x1cce(%rip), %r9       # 0x18000a330
180008662:     	callq	*%r9
180008665:     	incl	0x9375(%rip)            # 0x1800119e0
18000866b:     	movl	$0x1, %eax
180008670:     	jmp	0x180008674 <numba_list_iter_next+0x4f4>
180008672:     	xorl	%eax, %eax
180008674:     	movq	0x30(%rsp), %rbx
180008679:     	movq	0x38(%rsp), %rsi
18000867e:     	movq	0x48(%rsp), %rdi
180008683:     	addq	$0x20, %rsp
180008687:     	popq	%r14
180008689:     	retq
18000868a:     	movl	$0x7, %ecx
18000868f:     	callq	0x180008cc4 <numba_list_iter_next+0xb44>
180008694:     	nop
180008695:     	int3
180008696:     	int3
180008697:     	int3
180008698:     	movq	%rbx, 0x8(%rsp)
18000869d:     	pushq	%rdi
18000869e:     	subq	$0x30, %rsp
1800086a2:     	movb	%cl, %dil
1800086a5:     	movl	0x9335(%rip), %eax      # 0x1800119e0
1800086ab:     	testl	%eax, %eax
1800086ad:     	jg	0x1800086bc <numba_list_iter_next+0x53c>
1800086af:     	xorl	%eax, %eax
1800086b1:     	movq	0x40(%rsp), %rbx
1800086b6:     	addq	$0x30, %rsp
1800086ba:     	popq	%rdi
1800086bb:     	retq
1800086bc:     	decl	%eax
1800086be:     	movl	%eax, 0x931c(%rip)      # 0x1800119e0
1800086c4:     	callq	0x1800089a0 <numba_list_iter_next+0x820>
1800086c9:     	movb	%al, %bl
1800086cb:     	movb	%al, 0x20(%rsp)
1800086cf:     	cmpl	$0x2, 0x9332(%rip)      # 0x180011a08
1800086d6:     	jne	0x18000870e <numba_list_iter_next+0x58e>
1800086d8:     	callq	0x180008ac8 <numba_list_iter_next+0x948>
1800086dd:     	callq	0x180008970 <numba_list_iter_next+0x7f0>
1800086e2:     	callq	0x180008d08 <numba_list_iter_next+0xb88>
1800086e7:     	movl	$0x0, 0x9317(%rip)      # 0x180011a08
1800086f1:     	movb	%bl, %cl
1800086f3:     	callq	0x180008c6c <numba_list_iter_next+0xaec>
1800086f8:     	xorl	%edx, %edx
1800086fa:     	movb	%dil, %cl
1800086fd:     	callq	0x180008c90 <numba_list_iter_next+0xb10>
180008702:     	movzbl	%al, %ebx
180008705:     	callq	0x180008af8 <numba_list_iter_next+0x978>
18000870a:     	movl	%ebx, %eax
18000870c:     	jmp	0x1800086b1 <numba_list_iter_next+0x531>
18000870e:     	movl	$0x7, %ecx
180008713:     	callq	0x180008cc4 <numba_list_iter_next+0xb44>
180008718:     	nop
180008719:     	nop
18000871a:     	int3
18000871b:     	int3
18000871c:     	movq	%rsp, %rax
18000871f:     	movq	%rbx, 0x20(%rax)
180008723:     	movq	%r8, 0x18(%rax)
180008727:     	movl	%edx, 0x10(%rax)
18000872a:     	movq	%rcx, 0x8(%rax)
18000872e:     	pushq	%rsi
18000872f:     	pushq	%rdi
180008730:     	pushq	%r14
180008732:     	subq	$0x40, %rsp
180008736:     	movq	%r8, %rsi
180008739:     	movl	%edx, %edi
18000873b:     	movq	%rcx, %r14
18000873e:     	testl	%edx, %edx
180008740:     	jne	0x180008751 <numba_list_iter_next+0x5d1>
180008742:     	cmpl	%edx, 0x9298(%rip)      # 0x1800119e0
180008748:     	jg	0x180008751 <numba_list_iter_next+0x5d1>
18000874a:     	xorl	%eax, %eax
18000874c:     	jmp	0x180008836 <numba_list_iter_next+0x6b6>
180008751:     	leal	-0x1(%rdx), %eax
180008754:     	cmpl	$0x1, %eax
180008757:     	ja	0x180008799 <numba_list_iter_next+0x619>
180008759:     	movq	0x2660(%rip), %rax      # 0x18000adc0
180008760:     	testq	%rax, %rax
180008763:     	jne	0x18000876a <numba_list_iter_next+0x5ea>
180008765:     	leal	0x1(%rax), %ebx
180008768:     	jmp	0x180008772 <numba_list_iter_next+0x5f2>
18000876a:     	callq	*0x1bc0(%rip)           # 0x18000a330
180008770:     	movl	%eax, %ebx
180008772:     	movl	%ebx, 0x30(%rsp)
180008776:     	testl	%ebx, %ebx
180008778:     	je	0x18000882c <numba_list_iter_next+0x6ac>
18000877e:     	movq	%rsi, %r8
180008781:     	movl	%edi, %edx
180008783:     	movq	%r14, %rcx
180008786:     	callq	0x180008530 <numba_list_iter_next+0x3b0>
18000878b:     	movl	%eax, %ebx
18000878d:     	movl	%eax, 0x30(%rsp)
180008791:     	testl	%eax, %eax
180008793:     	je	0x18000882c <numba_list_iter_next+0x6ac>
180008799:     	movq	%rsi, %r8
18000879c:     	movl	%edi, %edx
18000879e:     	movq	%r14, %rcx
1800087a1:     	callq	0x18000893c <numba_list_iter_next+0x7bc>
1800087a6:     	movl	%eax, %ebx
1800087a8:     	movl	%eax, 0x30(%rsp)
1800087ac:     	cmpl	$0x1, %edi
1800087af:     	jne	0x1800087e7 <numba_list_iter_next+0x667>
1800087b1:     	testl	%eax, %eax
1800087b3:     	jne	0x1800087e7 <numba_list_iter_next+0x667>
1800087b5:     	movq	%rsi, %r8
1800087b8:     	xorl	%edx, %edx
1800087ba:     	movq	%r14, %rcx
1800087bd:     	callq	0x18000893c <numba_list_iter_next+0x7bc>
1800087c2:     	testq	%rsi, %rsi
1800087c5:     	setne	%cl
1800087c8:     	callq	0x180008698 <numba_list_iter_next+0x518>
1800087cd:     	movq	0x25ec(%rip), %rax      # 0x18000adc0
1800087d4:     	testq	%rax, %rax
1800087d7:     	je	0x1800087e7 <numba_list_iter_next+0x667>
1800087d9:     	movq	%rsi, %r8
1800087dc:     	xorl	%edx, %edx
1800087de:     	movq	%r14, %rcx
1800087e1:     	callq	*0x1b49(%rip)           # 0x18000a330
1800087e7:     	testl	%edi, %edi
1800087e9:     	je	0x1800087f0 <numba_list_iter_next+0x670>
1800087eb:     	cmpl	$0x3, %edi
1800087ee:     	jne	0x18000882c <numba_list_iter_next+0x6ac>
1800087f0:     	movq	%rsi, %r8
1800087f3:     	movl	%edi, %edx
1800087f5:     	movq	%r14, %rcx
1800087f8:     	callq	0x180008530 <numba_list_iter_next+0x3b0>
1800087fd:     	movl	%eax, %ebx
1800087ff:     	movl	%eax, 0x30(%rsp)
180008803:     	testl	%eax, %eax
180008805:     	je	0x18000882c <numba_list_iter_next+0x6ac>
180008807:     	movq	0x25b2(%rip), %rax      # 0x18000adc0
18000880e:     	testq	%rax, %rax
180008811:     	jne	0x180008818 <numba_list_iter_next+0x698>
180008813:     	leal	0x1(%rax), %ebx
180008816:     	jmp	0x180008828 <numba_list_iter_next+0x6a8>
180008818:     	movq	%rsi, %r8
18000881b:     	movl	%edi, %edx
18000881d:     	movq	%r14, %rcx
180008820:     	callq	*0x1b0a(%rip)           # 0x18000a330
180008826:     	movl	%eax, %ebx
180008828:     	movl	%ebx, 0x30(%rsp)
18000882c:     	jmp	0x180008834 <numba_list_iter_next+0x6b4>
18000882e:     	xorl	%ebx, %ebx
180008830:     	movl	%ebx, 0x30(%rsp)
180008834:     	movl	%ebx, %eax
180008836:     	movq	0x78(%rsp), %rbx
18000883b:     	addq	$0x40, %rsp
18000883f:     	popq	%r14
180008841:     	popq	%rdi
180008842:     	popq	%rsi
180008843:     	retq
180008844:     	movq	%rbx, 0x8(%rsp)
180008849:     	movq	%rsi, 0x10(%rsp)
18000884e:     	pushq	%rdi
18000884f:     	subq	$0x20, %rsp
180008853:     	movq	%r8, %rdi
180008856:     	movl	%edx, %ebx
180008858:     	movq	%rcx, %rsi
18000885b:     	cmpl	$0x1, %edx
18000885e:     	jne	0x180008865 <numba_list_iter_next+0x6e5>
180008860:     	callq	0x18000888c <numba_list_iter_next+0x70c>
180008865:     	movq	%rdi, %r8
180008868:     	movl	%ebx, %edx
18000886a:     	movq	%rsi, %rcx
18000886d:     	movq	0x30(%rsp), %rbx
180008872:     	movq	0x38(%rsp), %rsi
180008877:     	addq	$0x20, %rsp
18000887b:     	popq	%rdi
18000887c:     	jmp	0x18000871c <numba_list_iter_next+0x59c>
180008881:     	int3
180008882:     	int3
180008883:     	int3
180008884:     	movl	$0x2, %ecx
180008889:     	int	$0x29
18000888b:     	retq
18000888c:     	movq	%rbx, 0x18(%rsp)
180008891:     	pushq	%rbp
180008892:     	movq	%rsp, %rbp
180008895:     	subq	$0x30, %rsp
180008899:     	movq	0x8860(%rip), %rax      # 0x180011100
1800088a0:     	movabsq	$0x2b992ddfa232, %rbx   # imm = 0x2B992DDFA232
1800088aa:     	cmpq	%rbx, %rax
1800088ad:     	jne	0x180008926 <numba_list_iter_next+0x7a6>
1800088af:     	leaq	0x10(%rbp), %rcx
1800088b3:     	movq	$0x0, 0x10(%rbp)
1800088bb:     	callq	*0x175f(%rip)           # 0x18000a020
1800088c1:     	movq	0x10(%rbp), %rax
1800088c5:     	movq	%rax, -0x10(%rbp)
1800088c9:     	callq	*0x1749(%rip)           # 0x18000a018
1800088cf:     	movl	%eax, %eax
1800088d1:     	xorq	%rax, -0x10(%rbp)
1800088d5:     	callq	*0x1735(%rip)           # 0x18000a010
1800088db:     	movl	%eax, %eax
1800088dd:     	leaq	0x18(%rbp), %rcx
1800088e1:     	xorq	%rax, -0x10(%rbp)
1800088e5:     	callq	*0x1715(%rip)           # 0x18000a000
1800088eb:     	movl	0x18(%rbp), %eax
1800088ee:     	leaq	-0x10(%rbp), %rcx
1800088f2:     	shlq	$0x20, %rax
1800088f6:     	xorq	0x18(%rbp), %rax
1800088fa:     	xorq	-0x10(%rbp), %rax
1800088fe:     	xorq	%rcx, %rax
180008901:     	movabsq	$0xffffffffffff, %rcx   # imm = 0xFFFFFFFFFFFF
18000890b:     	andq	%rcx, %rax
18000890e:     	movabsq	$0x2b992ddfa233, %rcx   # imm = 0x2B992DDFA233
180008918:     	cmpq	%rbx, %rax
18000891b:     	cmoveq	%rcx, %rax
18000891f:     	movq	%rax, 0x87da(%rip)      # 0x180011100
180008926:     	movq	0x50(%rsp), %rbx
18000892b:     	notq	%rax
18000892e:     	movq	%rax, 0x880b(%rip)      # 0x180011140
180008935:     	addq	$0x30, %rsp
180008939:     	popq	%rbp
18000893a:     	retq
18000893b:     	int3
18000893c:     	subq	$0x28, %rsp
180008940:     	cmpl	$0x1, %edx
180008943:     	jne	0x180008955 <numba_list_iter_next+0x7d5>
180008945:     	cmpq	$0x0, 0x2473(%rip)      # 0x18000adc0
18000894d:     	jne	0x180008955 <numba_list_iter_next+0x7d5>
18000894f:     	callq	*0x16d3(%rip)           # 0x18000a028
180008955:     	movl	$0x1, %eax
18000895a:     	addq	$0x28, %rsp
18000895e:     	retq
18000895f:     	int3
180008960:     	leaq	0x9089(%rip), %rcx      # 0x1800119f0
180008967:     	jmpq	*0x169a(%rip)           # 0x18000a008
18000896e:     	int3
18000896f:     	int3
180008970:     	leaq	0x9079(%rip), %rcx      # 0x1800119f0
180008977:     	jmp	0x180009006 <numba_list_iter_next+0xe86>
18000897c:     	leaq	0x907d(%rip), %rax      # 0x180011a00
180008983:     	retq
180008984:     	subq	$0x28, %rsp
180008988:     	callq	0x180007a90 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x5500>
18000898d:     	orq	$0x24, (%rax)
180008991:     	callq	0x18000897c <numba_list_iter_next+0x7fc>
180008996:     	orq	$0x2, (%rax)
18000899a:     	addq	$0x28, %rsp
18000899e:     	retq
18000899f:     	int3
1800089a0:     	subq	$0x28, %rsp
1800089a4:     	callq	0x180008fec <numba_list_iter_next+0xe6c>
1800089a9:     	testl	%eax, %eax
1800089ab:     	je	0x1800089ce <numba_list_iter_next+0x84e>
1800089ad:     	movq	%gs:0x30, %rax
1800089b6:     	movq	0x8(%rax), %rcx
1800089ba:     	jmp	0x1800089c1 <numba_list_iter_next+0x841>
1800089bc:     	cmpq	%rax, %rcx
1800089bf:     	je	0x1800089d5 <numba_list_iter_next+0x855>
1800089c1:     	xorl	%eax, %eax
1800089c3:     	lock
1800089c4:     	cmpxchgq	%rcx, 0x9044(%rip)      # 0x180011a10
1800089cc:     	jne	0x1800089bc <numba_list_iter_next+0x83c>
1800089ce:     	xorb	%al, %al
1800089d0:     	addq	$0x28, %rsp
1800089d4:     	retq
1800089d5:     	movb	$0x1, %al
1800089d7:     	jmp	0x1800089d0 <numba_list_iter_next+0x850>
1800089d9:     	int3
1800089da:     	int3
1800089db:     	int3
1800089dc:     	subq	$0x28, %rsp
1800089e0:     	callq	0x180008fec <numba_list_iter_next+0xe6c>
1800089e5:     	testl	%eax, %eax
1800089e7:     	je	0x1800089f0 <numba_list_iter_next+0x870>
1800089e9:     	callq	0x180008d48 <numba_list_iter_next+0xbc8>
1800089ee:     	jmp	0x180008a09 <numba_list_iter_next+0x889>
1800089f0:     	callq	0x180008fe4 <numba_list_iter_next+0xe64>
1800089f5:     	movl	%eax, %ecx
1800089f7:     	callq	0x18000901e <numba_list_iter_next+0xe9e>
1800089fc:     	testl	%eax, %eax
1800089fe:     	je	0x180008a04 <numba_list_iter_next+0x884>
180008a00:     	xorb	%al, %al
180008a02:     	jmp	0x180008a0b <numba_list_iter_next+0x88b>
180008a04:     	callq	0x180009024 <numba_list_iter_next+0xea4>
180008a09:     	movb	$0x1, %al
180008a0b:     	addq	$0x28, %rsp
180008a0f:     	retq
180008a10:     	subq	$0x28, %rsp
180008a14:     	xorl	%ecx, %ecx
180008a16:     	callq	0x180008b48 <numba_list_iter_next+0x9c8>
180008a1b:     	testb	%al, %al
180008a1d:     	setne	%al
180008a20:     	addq	$0x28, %rsp
180008a24:     	retq
180008a25:     	int3
180008a26:     	int3
180008a27:     	int3
180008a28:     	subq	$0x28, %rsp
180008a2c:     	callq	0x18000903c <numba_list_iter_next+0xebc>
180008a31:     	testb	%al, %al
180008a33:     	jne	0x180008a39 <numba_list_iter_next+0x8b9>
180008a35:     	xorb	%al, %al
180008a37:     	jmp	0x180008a4b <numba_list_iter_next+0x8cb>
180008a39:     	callq	0x18000903c <numba_list_iter_next+0xebc>
180008a3e:     	testb	%al, %al
180008a40:     	jne	0x180008a49 <numba_list_iter_next+0x8c9>
180008a42:     	callq	0x18000903c <numba_list_iter_next+0xebc>
180008a47:     	jmp	0x180008a35 <numba_list_iter_next+0x8b5>
180008a49:     	movb	$0x1, %al
180008a4b:     	addq	$0x28, %rsp
180008a4f:     	retq
180008a50:     	subq	$0x28, %rsp
180008a54:     	callq	0x18000903c <numba_list_iter_next+0xebc>
180008a59:     	callq	0x18000903c <numba_list_iter_next+0xebc>
180008a5e:     	movb	$0x1, %al
180008a60:     	addq	$0x28, %rsp
180008a64:     	retq
180008a65:     	int3
180008a66:     	int3
180008a67:     	int3
180008a68:     	movq	%rbx, 0x8(%rsp)
180008a6d:     	movq	%rbp, 0x10(%rsp)
180008a72:     	movq	%rsi, 0x18(%rsp)
180008a77:     	pushq	%rdi
180008a78:     	subq	$0x20, %rsp
180008a7c:     	movq	%r9, %rdi
180008a7f:     	movq	%r8, %rsi
180008a82:     	movl	%edx, %ebx
180008a84:     	movq	%rcx, %rbp
180008a87:     	callq	0x180008fec <numba_list_iter_next+0xe6c>
180008a8c:     	testl	%eax, %eax
180008a8e:     	jne	0x180008aa6 <numba_list_iter_next+0x926>
180008a90:     	cmpl	$0x1, %ebx
180008a93:     	jne	0x180008aa6 <numba_list_iter_next+0x926>
180008a95:     	movq	%rsi, %r8
180008a98:     	xorl	%edx, %edx
180008a9a:     	movq	%rbp, %rcx
180008a9d:     	movq	%rdi, %rax
180008aa0:     	callq	*0x188a(%rip)           # 0x18000a330
180008aa6:     	movq	0x58(%rsp), %rdx
180008aab:     	movl	0x50(%rsp), %ecx
180008aaf:     	movq	0x30(%rsp), %rbx
180008ab4:     	movq	0x38(%rsp), %rbp
180008ab9:     	movq	0x40(%rsp), %rsi
180008abe:     	addq	$0x20, %rsp
180008ac2:     	popq	%rdi
180008ac3:     	jmp	0x180009018 <numba_list_iter_next+0xe98>
180008ac8:     	subq	$0x28, %rsp
180008acc:     	callq	0x180008fec <numba_list_iter_next+0xe6c>
180008ad1:     	testl	%eax, %eax
180008ad3:     	je	0x180008ae5 <numba_list_iter_next+0x965>
180008ad5:     	leaq	0x8f44(%rip), %rcx      # 0x180011a20
180008adc:     	addq	$0x28, %rsp
180008ae0:     	jmp	0x180009030 <numba_list_iter_next+0xeb0>
180008ae5:     	callq	0x180009040 <numba_list_iter_next+0xec0>
180008aea:     	testl	%eax, %eax
180008aec:     	jne	0x180008af3 <numba_list_iter_next+0x973>
180008aee:     	callq	0x180009036 <numba_list_iter_next+0xeb6>
180008af3:     	addq	$0x28, %rsp
180008af7:     	retq
180008af8:     	subq	$0x28, %rsp
180008afc:     	xorl	%ecx, %ecx
180008afe:     	callq	0x18000903c <numba_list_iter_next+0xebc>
180008b03:     	addq	$0x28, %rsp
180008b07:     	jmp	0x18000903c <numba_list_iter_next+0xebc>
180008b0c:     	subq	$0x28, %rsp
180008b10:     	testl	%ecx, %ecx
180008b12:     	jne	0x180008b1b <numba_list_iter_next+0x99b>
180008b14:     	movb	$0x1, 0x8efd(%rip)      # 0x180011a18
180008b1b:     	callq	0x180008d48 <numba_list_iter_next+0xbc8>
180008b20:     	callq	0x18000903c <numba_list_iter_next+0xebc>
180008b25:     	testb	%al, %al
180008b27:     	jne	0x180008b2d <numba_list_iter_next+0x9ad>
180008b29:     	xorb	%al, %al
180008b2b:     	jmp	0x180008b41 <numba_list_iter_next+0x9c1>
180008b2d:     	callq	0x18000903c <numba_list_iter_next+0xebc>
180008b32:     	testb	%al, %al
180008b34:     	jne	0x180008b3f <numba_list_iter_next+0x9bf>
180008b36:     	xorl	%ecx, %ecx
180008b38:     	callq	0x18000903c <numba_list_iter_next+0xebc>
180008b3d:     	jmp	0x180008b29 <numba_list_iter_next+0x9a9>
180008b3f:     	movb	$0x1, %al
180008b41:     	addq	$0x28, %rsp
180008b45:     	retq
180008b46:     	int3
180008b47:     	int3
180008b48:     	pushq	%rbx
180008b4a:     	subq	$0x20, %rsp
180008b4e:     	cmpb	$0x0, 0x8ec4(%rip)      # 0x180011a19
180008b55:     	movl	%ecx, %ebx
180008b57:     	jne	0x180008bc0 <numba_list_iter_next+0xa40>
180008b59:     	cmpl	$0x1, %ecx
180008b5c:     	ja	0x180008bc8 <numba_list_iter_next+0xa48>
180008b5e:     	callq	0x180008fec <numba_list_iter_next+0xe6c>
180008b63:     	testl	%eax, %eax
180008b65:     	je	0x180008b8f <numba_list_iter_next+0xa0f>
180008b67:     	testl	%ebx, %ebx
180008b69:     	jne	0x180008b8f <numba_list_iter_next+0xa0f>
180008b6b:     	leaq	0x8eae(%rip), %rcx      # 0x180011a20
180008b72:     	callq	0x18000902a <numba_list_iter_next+0xeaa>
180008b77:     	testl	%eax, %eax
180008b79:     	jne	0x180008b8b <numba_list_iter_next+0xa0b>
180008b7b:     	leaq	0x8eb6(%rip), %rcx      # 0x180011a38
180008b82:     	callq	0x18000902a <numba_list_iter_next+0xeaa>
180008b87:     	testl	%eax, %eax
180008b89:     	je	0x180008bb9 <numba_list_iter_next+0xa39>
180008b8b:     	xorb	%al, %al
180008b8d:     	jmp	0x180008bc2 <numba_list_iter_next+0xa42>
180008b8f:     	movdqa	0x2239(%rip), %xmm0     # 0x18000add0
180008b97:     	orq	$-0x1, %rax
180008b9b:     	movdqu	%xmm0, 0x8e7d(%rip)     # 0x180011a20
180008ba3:     	movq	%rax, 0x8e86(%rip)      # 0x180011a30
180008baa:     	movdqu	%xmm0, 0x8e86(%rip)     # 0x180011a38
180008bb2:     	movq	%rax, 0x8e8f(%rip)      # 0x180011a48
180008bb9:     	movb	$0x1, 0x8e59(%rip)      # 0x180011a19
180008bc0:     	movb	$0x1, %al
180008bc2:     	addq	$0x20, %rsp
180008bc6:     	popq	%rbx
180008bc7:     	retq
180008bc8:     	movl	$0x5, %ecx
180008bcd:     	callq	0x180008cc4 <numba_list_iter_next+0xb44>
180008bd2:     	int3
180008bd3:     	int3
180008bd4:     	subq	$0x18, %rsp
180008bd8:     	movq	%rcx, %r8
180008bdb:     	movl	$0x5a4d, %eax           # imm = 0x5A4D
180008be0:     	cmpw	%ax, -0x8be7(%rip)      # 0x180000000
180008be7:     	jne	0x180008c61 <numba_list_iter_next+0xae1>
180008be9:     	movslq	-0x8bb4(%rip), %rcx     # 0x18000003c
180008bf0:     	leaq	-0x8bf7(%rip), %rdx     # 0x180000000
180008bf7:     	addq	%rdx, %rcx
180008bfa:     	cmpl	$0x4550, (%rcx)         # imm = 0x4550
180008c00:     	jne	0x180008c61 <numba_list_iter_next+0xae1>
180008c02:     	movl	$0x20b, %eax            # imm = 0x20B
180008c07:     	cmpw	%ax, 0x18(%rcx)
180008c0b:     	jne	0x180008c61 <numba_list_iter_next+0xae1>
180008c0d:     	subq	%rdx, %r8
180008c10:     	movzwl	0x14(%rcx), %edx
180008c14:     	addq	$0x18, %rdx
180008c18:     	addq	%rcx, %rdx
180008c1b:     	movzwl	0x6(%rcx), %eax
180008c1f:     	leaq	(%rax,%rax,4), %rcx
180008c23:     	leaq	(%rdx,%rcx,8), %r9
180008c27:     	movq	%rdx, (%rsp)
180008c2b:     	cmpq	%r9, %rdx
180008c2e:     	je	0x180008c48 <numba_list_iter_next+0xac8>
180008c30:     	movl	0xc(%rdx), %ecx
180008c33:     	cmpq	%rcx, %r8
180008c36:     	jb	0x180008c42 <numba_list_iter_next+0xac2>
180008c38:     	movl	0x8(%rdx), %eax
180008c3b:     	addl	%ecx, %eax
180008c3d:     	cmpq	%rax, %r8
180008c40:     	jb	0x180008c4a <numba_list_iter_next+0xaca>
180008c42:     	addq	$0x28, %rdx
180008c46:     	jmp	0x180008c27 <numba_list_iter_next+0xaa7>
180008c48:     	xorl	%edx, %edx
180008c4a:     	testq	%rdx, %rdx
180008c4d:     	jne	0x180008c53 <numba_list_iter_next+0xad3>
180008c4f:     	xorb	%al, %al
180008c51:     	jmp	0x180008c67 <numba_list_iter_next+0xae7>
180008c53:     	cmpl	$0x0, 0x24(%rdx)
180008c57:     	jge	0x180008c5d <numba_list_iter_next+0xadd>
180008c59:     	xorb	%al, %al
180008c5b:     	jmp	0x180008c67 <numba_list_iter_next+0xae7>
180008c5d:     	movb	$0x1, %al
180008c5f:     	jmp	0x180008c67 <numba_list_iter_next+0xae7>
180008c61:     	xorb	%al, %al
180008c63:     	jmp	0x180008c67 <numba_list_iter_next+0xae7>
180008c65:     	xorb	%al, %al
180008c67:     	addq	$0x18, %rsp
180008c6b:     	retq
180008c6c:     	pushq	%rbx
180008c6e:     	subq	$0x20, %rsp
180008c72:     	movb	%cl, %bl
180008c74:     	callq	0x180008fec <numba_list_iter_next+0xe6c>
180008c79:     	xorl	%edx, %edx
180008c7b:     	testl	%eax, %eax
180008c7d:     	je	0x180008c8a <numba_list_iter_next+0xb0a>
180008c7f:     	testb	%bl, %bl
180008c81:     	jne	0x180008c8a <numba_list_iter_next+0xb0a>
180008c83:     	xchgq	%rdx, 0x8d86(%rip)      # 0x180011a10
180008c8a:     	addq	$0x20, %rsp
180008c8e:     	popq	%rbx
180008c8f:     	retq
180008c90:     	pushq	%rbx
180008c92:     	subq	$0x20, %rsp
180008c96:     	cmpb	$0x0, 0x8d7b(%rip)      # 0x180011a18
180008c9d:     	movb	%cl, %bl
180008c9f:     	je	0x180008ca5 <numba_list_iter_next+0xb25>
180008ca1:     	testb	%dl, %dl
180008ca3:     	jne	0x180008cb1 <numba_list_iter_next+0xb31>
180008ca5:     	callq	0x18000903c <numba_list_iter_next+0xebc>
180008caa:     	movb	%bl, %cl
180008cac:     	callq	0x18000903c <numba_list_iter_next+0xebc>
180008cb1:     	movb	$0x1, %al
180008cb3:     	addq	$0x20, %rsp
180008cb7:     	popq	%rbx
180008cb8:     	retq
180008cb9:     	int3
180008cba:     	int3
180008cbb:     	int3
180008cbc:     	leaq	0x903d(%rip), %rax      # 0x180011d00
180008cc3:     	retq
180008cc4:     	movl	%ecx, %ecx
180008cc6:     	int	$0x29
180008cc8:     	retq
180008cc9:     	int3
180008cca:     	int3
180008ccb:     	int3
180008ccc:     	movq	%rbx, 0x8(%rsp)
180008cd1:     	pushq	%rdi
180008cd2:     	subq	$0x20, %rsp
180008cd6:     	leaq	0x4aeb(%rip), %rbx      # 0x18000d7c8
180008cdd:     	leaq	0x4ae4(%rip), %rdi      # 0x18000d7c8
180008ce4:     	jmp	0x180008cf8 <numba_list_iter_next+0xb78>
180008ce6:     	movq	(%rbx), %rax
180008ce9:     	testq	%rax, %rax
180008cec:     	je	0x180008cf4 <numba_list_iter_next+0xb74>
180008cee:     	callq	*0x163c(%rip)           # 0x18000a330
180008cf4:     	addq	$0x8, %rbx
180008cf8:     	cmpq	%rdi, %rbx
180008cfb:     	jb	0x180008ce6 <numba_list_iter_next+0xb66>
180008cfd:     	movq	0x30(%rsp), %rbx
180008d02:     	addq	$0x20, %rsp
180008d06:     	popq	%rdi
180008d07:     	retq
180008d08:     	movq	%rbx, 0x8(%rsp)
180008d0d:     	pushq	%rdi
180008d0e:     	subq	$0x20, %rsp
180008d12:     	leaq	0x4abf(%rip), %rbx      # 0x18000d7d8
180008d19:     	leaq	0x4ab8(%rip), %rdi      # 0x18000d7d8
180008d20:     	jmp	0x180008d34 <numba_list_iter_next+0xbb4>
180008d22:     	movq	(%rbx), %rax
180008d25:     	testq	%rax, %rax
180008d28:     	je	0x180008d30 <numba_list_iter_next+0xbb0>
180008d2a:     	callq	*0x1600(%rip)           # 0x18000a330
180008d30:     	addq	$0x8, %rbx
180008d34:     	cmpq	%rdi, %rbx
180008d37:     	jb	0x180008d22 <numba_list_iter_next+0xba2>
180008d39:     	movq	0x30(%rsp), %rbx
180008d3e:     	addq	$0x20, %rsp
180008d42:     	popq	%rdi
180008d43:     	retq
180008d44:     	retq	$0x0
180008d47:     	int3
180008d48:     	movq	%rbx, 0x10(%rsp)
180008d4d:     	movq	%rbp, 0x18(%rsp)
180008d52:     	movq	%rsi, 0x20(%rsp)
180008d57:     	pushq	%rdi
180008d58:     	subq	$0x10, %rsp
180008d5c:     	xorl	%eax, %eax
180008d5e:     	xorl	%ecx, %ecx
180008d60:     	cpuid
180008d62:     	xorl	$0x6c65746e, %ecx       # imm = 0x6C65746E
180008d68:     	xorl	$0x49656e69, %edx       # imm = 0x49656E69
180008d6e:     	orl	%ecx, %edx
180008d70:     	movl	%eax, %ebp
180008d72:     	movl	$0x1, %eax
180008d77:     	xorl	$0x756e6547, %ebx       # imm = 0x756E6547
180008d7d:     	orl	%ebx, %edx
180008d7f:     	leal	-0x1(%rax), %ecx
180008d82:     	cpuid
180008d84:     	movl	%ecx, %edi
180008d86:     	jne	0x180008de6 <numba_list_iter_next+0xc66>
180008d88:     	andl	$0xfff3ff0, %eax        # imm = 0xFFF3FF0
180008d8d:     	movq	$0x8000, 0x83c0(%rip)   # imm = 0x8000
                                                # 0x180011158
180008d98:     	movq	$-0x1, 0x83bd(%rip)     # 0x180011160
180008da3:     	cmpl	$0x106c0, %eax          # imm = 0x106C0
180008da8:     	je	0x180008dd2 <numba_list_iter_next+0xc52>
180008daa:     	cmpl	$0x20660, %eax          # imm = 0x20660
180008daf:     	je	0x180008dd2 <numba_list_iter_next+0xc52>
180008db1:     	cmpl	$0x20670, %eax          # imm = 0x20670
180008db6:     	je	0x180008dd2 <numba_list_iter_next+0xc52>
180008db8:     	addl	$0xfffcf9b0, %eax       # imm = 0xFFFCF9B0
180008dbd:     	cmpl	$0x20, %eax
180008dc0:     	ja	0x180008de6 <numba_list_iter_next+0xc66>
180008dc2:     	movabsq	$0x100010001, %rcx      # imm = 0x100010001
180008dcc:     	btq	%rax, %rcx
180008dd0:     	jae	0x180008de6 <numba_list_iter_next+0xc66>
180008dd2:     	movl	0x8c7b(%rip), %r8d      # 0x180011a54
180008dd9:     	orl	$0x1, %r8d
180008ddd:     	movl	%r8d, 0x8c70(%rip)      # 0x180011a54
180008de4:     	jmp	0x180008ded <numba_list_iter_next+0xc6d>
180008de6:     	movl	0x8c67(%rip), %r8d      # 0x180011a54
180008ded:     	xorl	%r9d, %r9d
180008df0:     	movl	%r9d, %r11d
180008df3:     	cmpl	$0x7, %ebp
180008df6:     	jl	0x180008e3a <numba_list_iter_next+0xcba>
180008df8:     	xorl	%ecx, %ecx
180008dfa:     	leal	0x7(%r9), %eax
180008dfe:     	cpuid
180008e00:     	movl	%edx, %esi
180008e02:     	movl	%ebx, %r10d
180008e05:     	btl	$0x9, %ebx
180008e09:     	jae	0x180008e16 <numba_list_iter_next+0xc96>
180008e0b:     	orl	$0x2, %r8d
180008e0f:     	movl	%r8d, 0x8c3e(%rip)      # 0x180011a54
180008e16:     	cmpl	$0x1, %eax
180008e19:     	jl	0x180008e28 <numba_list_iter_next+0xca8>
180008e1b:     	movl	$0x7, %eax
180008e20:     	leal	-0x6(%rax), %ecx
180008e23:     	cpuid
180008e25:     	movl	%edx, %r9d
180008e28:     	movl	$0x24, %eax
180008e2d:     	cmpl	%eax, %ebp
180008e2f:     	jl	0x180008e40 <numba_list_iter_next+0xcc0>
180008e31:     	xorl	%ecx, %ecx
180008e33:     	cpuid
180008e35:     	movl	%ebx, %r11d
180008e38:     	jmp	0x180008e40 <numba_list_iter_next+0xcc0>
180008e3a:     	movl	%r9d, %r10d
180008e3d:     	movl	%r9d, %esi
180008e40:     	movq	0x8321(%rip), %rax      # 0x180011168
180008e47:     	andq	$-0x2, %rax
180008e4b:     	movl	$0x1, 0x82fb(%rip)      # 0x180011150
180008e55:     	movl	$0x2, 0x82f5(%rip)      # 0x180011154
180008e5f:     	movq	%rax, 0x8302(%rip)      # 0x180011168
180008e66:     	btl	$0x14, %edi
180008e6a:     	jae	0x180008e8b <numba_list_iter_next+0xd0b>
180008e6c:     	andq	$-0x11, %rax
180008e70:     	movl	$0x2, 0x82d6(%rip)      # 0x180011150
180008e7a:     	movq	%rax, 0x82e7(%rip)      # 0x180011168
180008e81:     	movl	$0x6, 0x82c9(%rip)      # 0x180011154
180008e8b:     	btl	$0x1b, %edi
180008e8f:     	jae	0x180008fcc <numba_list_iter_next+0xe4c>
180008e95:     	xorl	%ecx, %ecx
180008e97:     	xgetbv
180008e9a:     	shlq	$0x20, %rdx
180008e9e:     	orq	%rax, %rdx
180008ea1:     	movq	%rdx, 0x20(%rsp)
180008ea6:     	btl	$0x1c, %edi
180008eaa:     	jae	0x180008fb0 <numba_list_iter_next+0xe30>
180008eb0:     	movq	0x20(%rsp), %rax
180008eb5:     	andb	$0x6, %al
180008eb7:     	cmpb	$0x6, %al
180008eb9:     	jne	0x180008fb0 <numba_list_iter_next+0xe30>
180008ebf:     	movl	0x828f(%rip), %eax      # 0x180011154
180008ec5:     	movb	$-0x20, %dl
180008ec7:     	orl	$0x8, %eax
180008eca:     	movl	$0x3, 0x827c(%rip)      # 0x180011150
180008ed4:     	movl	%eax, 0x827a(%rip)      # 0x180011154
180008eda:     	testb	$0x20, %r10b
180008ede:     	je	0x180008f42 <numba_list_iter_next+0xdc2>
180008ee0:     	orl	$0x20, %eax
180008ee3:     	movl	$0x5, 0x8263(%rip)      # 0x180011150
180008eed:     	movl	%eax, 0x8261(%rip)      # 0x180011154
180008ef3:     	movl	$0xd0030000, %ecx       # imm = 0xD0030000
180008ef8:     	movq	0x8269(%rip), %rax      # 0x180011168
180008eff:     	andl	%ecx, %r10d
180008f02:     	andq	$-0x3, %rax
180008f06:     	movq	%rax, 0x825b(%rip)      # 0x180011168
180008f0d:     	cmpl	%ecx, %r10d
180008f10:     	jne	0x180008f49 <numba_list_iter_next+0xdc9>
180008f12:     	movq	0x20(%rsp), %rax
180008f17:     	andb	%dl, %al
180008f19:     	cmpb	%dl, %al
180008f1b:     	jne	0x180008f42 <numba_list_iter_next+0xdc2>
180008f1d:     	movq	0x8244(%rip), %rax      # 0x180011168
180008f24:     	orl	$0x40, 0x8229(%rip)     # 0x180011154
180008f2b:     	andq	$-0x25, %rax
180008f2f:     	movl	$0x6, 0x8217(%rip)      # 0x180011150
180008f39:     	movq	%rax, 0x8228(%rip)      # 0x180011168
180008f40:     	jmp	0x180008f49 <numba_list_iter_next+0xdc9>
180008f42:     	movq	0x821f(%rip), %rax      # 0x180011168
180008f49:     	btl	$0x17, %esi
180008f4d:     	jae	0x180008f5b <numba_list_iter_next+0xddb>
180008f4f:     	btrq	$0x18, %rax
180008f54:     	movq	%rax, 0x820d(%rip)      # 0x180011168
180008f5b:     	btl	$0x13, %r9d
180008f60:     	jae	0x180008fb0 <numba_list_iter_next+0xe30>
180008f62:     	movq	0x20(%rsp), %rax
180008f67:     	andb	%dl, %al
180008f69:     	cmpb	%dl, %al
180008f6b:     	jne	0x180008fb0 <numba_list_iter_next+0xe30>
180008f6d:     	movq	0x81f4(%rip), %rdx      # 0x180011168
180008f74:     	movl	%r11d, %eax
180008f77:     	shrq	$0x10, %rax
180008f7b:     	movl	%r11d, %ecx
180008f7e:     	andl	$0x6, %eax
180008f81:     	andl	$0x400ff, %ecx          # imm = 0x400FF
180008f87:     	orq	$0x1000029, %rax        # imm = 0x1000029
180008f8d:     	movl	%ecx, 0x8ac5(%rip)      # 0x180011a58
180008f93:     	notq	%rax
180008f96:     	andq	%rax, %rdx
180008f99:     	movq	%rdx, 0x81c8(%rip)      # 0x180011168
180008fa0:     	cmpb	$0x1, %cl
180008fa3:     	jbe	0x180008fb0 <numba_list_iter_next+0xe30>
180008fa5:     	andq	$-0x41, %rdx
180008fa9:     	movq	%rdx, 0x81b8(%rip)      # 0x180011168
180008fb0:     	btl	$0x15, %r9d
180008fb5:     	jae	0x180008fcc <numba_list_iter_next+0xe4c>
180008fb7:     	movq	0x20(%rsp), %rax
180008fbc:     	btq	$0x13, %rax
180008fc1:     	jae	0x180008fcc <numba_list_iter_next+0xe4c>
180008fc3:     	btrq	$0x7, 0x819c(%rip)      # 0x180011168
180008fcc:     	movq	0x28(%rsp), %rbx
180008fd1:     	xorl	%eax, %eax
180008fd3:     	movq	0x30(%rsp), %rbp
180008fd8:     	movq	0x38(%rsp), %rsi
180008fdd:     	addq	$0x10, %rsp
180008fe1:     	popq	%rdi
180008fe2:     	retq
180008fe3:     	int3
180008fe4:     	movl	$0x1, %eax
180008fe9:     	retq
180008fea:     	int3
180008feb:     	int3
180008fec:     	xorl	%eax, %eax
180008fee:     	cmpl	%eax, 0x817c(%rip)      # 0x180011170
180008ff4:     	setne	%al
180008ff7:     	retq
180008ff8:     	int3
180008ff9:     	int3
180008ffa:     	int3
180008ffb:     	int3
180008ffc:     	int3
180008ffd:     	int3
180008ffe:     	int3
180008fff:     	int3
180009000:     	jmpq	*0x1042(%rip)           # 0x18000a048
180009006:     	jmpq	*0x1044(%rip)           # 0x18000a050
18000900c:     	jmpq	*0x107e(%rip)           # 0x18000a090
180009012:     	jmpq	*0x1080(%rip)           # 0x18000a098
180009018:     	jmpq	*0x1082(%rip)           # 0x18000a0a0
18000901e:     	jmpq	*0x1084(%rip)           # 0x18000a0a8
180009024:     	jmpq	*0x1086(%rip)           # 0x18000a0b0
18000902a:     	jmpq	*0x1050(%rip)           # 0x18000a080
180009030:     	jmpq	*0x1082(%rip)           # 0x18000a0b8
180009036:     	jmpq	*0x104c(%rip)           # 0x18000a088
18000903c:     	movb	$0x1, %al
18000903e:     	retq
18000903f:     	int3
180009040:     	xorl	%eax, %eax
180009042:     	retq
180009043:     	jmpq	*0xfef(%rip)            # 0x18000a038
180009049:     	jmpq	*0xff1(%rip)            # 0x18000a040
18000904f:     	jmpq	*0x1073(%rip)           # 0x18000a0c8
180009055:     	jmpq	*0x1075(%rip)           # 0x18000a0d0
18000905b:     	int3
18000905c:     	int3
18000905d:     	int3
18000905e:     	int3
18000905f:     	int3
180009060:     	int3
180009061:     	int3
180009062:     	int3
180009063:     	int3
180009064:     	int3
180009065:     	int3
180009066:     	nopw	(%rax,%rax)
180009070:     	jmpq	*%rax
180009072:     	int3
180009073:     	int3
180009074:     	int3
180009075:     	int3
180009076:     	int3
180009077:     	int3
180009078:     	int3
180009079:     	int3
18000907a:     	int3
18000907b:     	int3
18000907c:     	int3
18000907d:     	int3
18000907e:     	int3
18000907f:     	int3
180009080:     	int3
180009081:     	int3
180009082:     	int3
180009083:     	int3
180009084:     	int3
180009085:     	int3
180009086:     	nopw	(%rax,%rax)
180009090:     	jmpq	*0x129a(%rip)           # 0x18000a330
180009096:     	pushq	%rbp
180009098:     	subq	$0x20, %rsp
18000909c:     	movq	%rdx, %rbp
18000909f:     	movb	0x40(%rbp), %cl
1800090a2:     	addq	$0x20, %rsp
1800090a6:     	popq	%rbp
1800090a7:     	jmp	0x180008c6c <numba_list_iter_next+0xaec>
1800090ac:     	int3
1800090ad:     	pushq	%rbp
1800090af:     	subq	$0x20, %rsp
1800090b3:     	movq	%rdx, %rbp
1800090b6:     	movb	0x20(%rbp), %cl
1800090b9:     	callq	0x180008c6c <numba_list_iter_next+0xaec>
1800090be:     	nop
1800090bf:     	addq	$0x20, %rsp
1800090c3:     	popq	%rbp
1800090c4:     	retq
1800090c5:     	int3
1800090c6:     	pushq	%rbp
1800090c8:     	subq	$0x20, %rsp
1800090cc:     	movq	%rdx, %rbp
1800090cf:     	addq	$0x20, %rsp
1800090d3:     	popq	%rbp
1800090d4:     	jmp	0x180008af8 <numba_list_iter_next+0x978>
1800090d9:     	int3
1800090da:     	pushq	%rbp
1800090dc:     	subq	$0x30, %rsp
1800090e0:     	movq	%rdx, %rbp
1800090e3:     	movq	(%rcx), %rax
1800090e6:     	movl	(%rax), %edx
1800090e8:     	movq	%rcx, 0x28(%rsp)
1800090ed:     	movl	%edx, 0x20(%rsp)
1800090f1:     	leaq	-0xbc8(%rip), %r9       # 0x180008530 <numba_list_iter_next+0x3b0>
1800090f8:     	movq	0x70(%rbp), %r8
1800090fc:     	movl	0x68(%rbp), %edx
1800090ff:     	movq	0x60(%rbp), %rcx
180009103:     	callq	0x180008a68 <numba_list_iter_next+0x8e8>
180009108:     	nop
180009109:     	addq	$0x30, %rsp
18000910d:     	popq	%rbp
18000910e:     	retq
18000910f:     	int3
180009110:     	pushq	%rbp
180009112:     	movq	%rdx, %rbp
180009115:     	movq	(%rcx), %rax
180009118:     	xorl	%ecx, %ecx
18000911a:     	cmpl	$0xc0000005, (%rax)     # imm = 0xC0000005
180009120:     	sete	%cl
180009123:     	movl	%ecx, %eax
180009125:     	popq	%rbp
180009126:     	retq
180009127:     	int3
