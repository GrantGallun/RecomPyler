# barnes-final adapter: [0x180001090, 0x1800011e0)
# Source/call-target-bound static range; padding included; never cycles.
180001090:     	pushq	%r14
180001092:     	pushq	%rsi
180001093:     	pushq	%rdi
180001094:     	pushq	%rbx
180001095:     	subq	$0x78, %rsp
180001099:     	movq	%rcx, %rsi
18000109c:     	movq	0x108(%rsp), %rax
1800010a4:     	movq	0xf0(%rsp), %rcx
1800010ac:     	movq	0xd8(%rsp), %r10
1800010b4:     	movq	0xc0(%rsp), %r11
1800010bc:     	movq	0x100(%rsp), %rdi
1800010c4:     	movq	0xe8(%rsp), %rbx
1800010cc:     	movq	$0x0, 0x40(%rsp)
1800010d5:     	movq	0xd0(%rsp), %r14
1800010dd:     	xorq	%r9, %r14
1800010e0:     	xorq	$0x4, %rbx
1800010e4:     	orq	%r14, %rbx
1800010e7:     	xorq	$0x1, %rdi
1800010eb:     	xorq	$0x8, %r11
1800010ef:     	orq	%rdi, %r11
1800010f2:     	orq	%rbx, %r11
1800010f5:     	xorq	$0x8, %r10
1800010f9:     	xorq	$0x8, %rcx
1800010fd:     	orq	%r10, %rcx
180001100:     	orq	%r11, %rcx
180001103:     	xorq	$0x1, %rax
180001107:     	orq	%rcx, %rax
18000110a:     	jne	0x1800011b4 <.text+0x1b4>
180001110:     	movq	%rdx, %rdi
180001113:     	movq	0x130(%rsp), %rcx
18000111b:     	movq	0x128(%rsp), %rdx
180001123:     	movsd	0x120(%rsp), %xmm0
18000112c:     	movsd	0x118(%rsp), %xmm1
180001135:     	movq	0x110(%rsp), %rax
18000113d:     	movq	0xf8(%rsp), %r10
180001145:     	movq	0xe0(%rsp), %r11
18000114d:     	movq	0xc8(%rsp), %rbx
180001155:     	movq	%r8, 0x50(%rsp)
18000115a:     	movq	%rbx, 0x58(%rsp)
18000115f:     	movq	%r11, 0x60(%rsp)
180001164:     	movq	%r10, 0x68(%rsp)
180001169:     	movq	%r9, 0x70(%rsp)
18000116e:     	movq	$0x0, 0x48(%rsp)
180001177:     	movq	%rcx, 0x38(%rsp)
18000117c:     	movq	%rdx, 0x30(%rsp)
180001181:     	movsd	%xmm0, 0x28(%rsp)
180001187:     	movsd	%xmm1, 0x20(%rsp)
18000118d:     	leaq	0x48(%rsp), %rcx
180001192:     	leaq	0x40(%rsp), %rdx
180001197:     	leaq	0x50(%rsp), %r8
18000119c:     	movq	%rax, %r9
18000119f:     	callq	0x1800025f0 <PyInit_rcaotr_37bed947cdaa1333e55322a8+0x60>
1800011a4:     	testl	%eax, %eax
1800011a6:     	jne	0x1800011cd <.text+0x1cd>
1800011a8:     	movq	0x48(%rsp), %rax
1800011ad:     	movq	%rax, (%rsi)
1800011b0:     	xorl	%eax, %eax
1800011b2:     	jmp	0x1800011c3 <.text+0x1c3>
1800011b4:     	leaq	0x9395(%rip), %rax      # 0x18000a550
1800011bb:     	movq	%rax, (%rdx)
1800011be:     	movl	$0x1, %eax
1800011c3:     	addq	$0x78, %rsp
1800011c7:     	popq	%rbx
1800011c8:     	popq	%rdi
1800011c9:     	popq	%rsi
1800011ca:     	popq	%r14
1800011cc:     	retq
1800011cd:     	movq	0x40(%rsp), %rcx
1800011d2:     	movq	%rcx, (%rdi)
1800011d5:     	jmp	0x1800011c3 <.text+0x1c3>
1800011d7:     	nopw	(%rax,%rax)
