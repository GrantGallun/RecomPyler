"""Read-only bounded assembly counts; never import/execute a compiled artifact."""
from collections import Counter
import argparse
import hashlib
import json
from pathlib import Path
import re
import struct

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'inline-actual-artifacts'
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--ranges', type=Path, default=OUT/'ranges.json')
args = parser.parse_args()
RANGES = {case: {name: tuple(int(value, 0) for value in bounds)
                 for name, bounds in ranges.items()}
          for case, ranges in json.loads(args.ranges.read_text()).items()}


def parse(path):
    rows = []
    for line in path.read_text().splitlines():
        match = re.match(r'\s*([0-9a-f]+):\s+(\w+)\s*(.*)', line)
        if match:
            rows.append((int(match[1], 16), match[2], match[3], line))
    return rows


all_counts = {}
for case, ranges in RANGES.items():
    meta = json.loads((OUT / (case + '-provenance.json')).read_text())
    raw = Path(meta['artifact']).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == meta['artifact_sha256']

    def double(address):
        for section in meta['sections']:
            offset = address - int(meta['preferred_image_base'], 16) - section['rva']
            if 0 <= offset <= section['rawsize'] - 8:
                return struct.unpack_from('<d', raw, section['offset'] + offset)[0]

    all_counts[case] = {}
    rows = parse(OUT / (case + '.asm'))
    for label, (start, end) in ranges.items():
        selected = [r for r in rows if start <= r[0] < end]
        thresholds = []
        for r in selected:
            match = re.search(r'# (0x[0-9a-f]+)', r[2])
            if match and double(int(match[1], 16)) == float(2**53):
                thresholds.append(hex(r[0]))
        counts = {
            'begin': hex(start), 'end_exclusive': hex(end), 'span_bytes': end-start,
            'instruction_lines_including_padding': len(selected),
            'padding_instruction_lines': sum(r[1].startswith('nop') for r in selected),
            'stack_operand_lines': sum('%rsp' in r[2] for r in selected),
            'frame_reservations': [r[3].strip() for r in selected if r[1] == 'subq' and ', %rsp' in r[2]],
            'direct_calls': [r[3].strip() for r in selected if r[1] == 'callq'],
            'exact_2pow53_rip_references': thresholds,
            'mnemonic_counts': dict(Counter(r[1] for r in selected)),
        }
        all_counts[case][label] = counts
        (OUT / f'{case}-{label}.asm').write_text(
            f'# {case} {label}: [{start:#x}, {end:#x})\n'
            '# Source/call-target-bound static range; padding included; never cycles.\n'
            + '\n'.join(r[3] for r in selected) + '\n')
    print(case, {label: v['instruction_lines_including_padding'] for label, v in all_counts[case].items()})
(OUT / 'static-counts.json').write_text(json.dumps(all_counts, indent=2) + '\n')
