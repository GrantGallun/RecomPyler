# Independent static review of inline-helper SSA product rewrite

Verdict: no code blocker in the25-line product diff from578.
Reviewed heap.py SHA2567904ae104331ea666cdcf0b577900771d2b2530f9b3ad28670480ef9e78c40b4
in wave9-inline-context-fix. No tests/compiler/native execution by this reviewer.

The contexts map uses only the original exact _INLINED source prefix. Source
classification occurs before AST/decorator rewriting. Calls select context
shape using the original callee name before renaming it, so the caller's own
inline status cannot accidentally dictate the argument convention. Replacing
the first four original array arguments leaves semantic order unchanged.

Wide helpers receive ctx plus five raw scalar values and construct views without
unpack. Narrow bodies unpack once, so those same five names are defined before
every inline helper call. Inline→inline, inline→recursive, recursive→inline
and merged wrapper/dispatcher edges follow the same callee rule. Every body
still holds ctx for recursive forwarding. No descriptor construction moves
inside recursion and no pointer escapes.

Public guards are unchanged. Four pointer extractions and the int64 length
binding occur once after validation, in the previous evaluation order, before
the unchanged typed pack. The borrowed entry call uses that entry's actual
convention, covering the inline SCC wrapper case without undefined names.
The intrinsics, _plain, numeric/error/depth logic, source inline eligibility,
typed pointee schema and helpers outside the generated map are unchanged.
New generated text naturally participates in existing source/cache identity.
No alias/readonly/invariant metadata or effect/value cache is introduced.

The fixture correction is justified: an original even_walk entry can precede
the specialized SCC rather than be a member itself. Following actual markers
on the real graph preserves the right expectation. The added synthetic
_INLINED entry→merged-dispatcher control directly exercises the public wide
source path. A real explicit-parameter mutual pair exercising that native path
is useful complementary coverage; it should not change product eligibility.

Observed initial focus already passed the native helper width/raw-pointer
checks and AOT-style descriptor-load counter on this product; old578 had12
loads and correctly failed the <=5 assertion. The one reported failure was
the mistaken source-graph expectation, not an observed product failure.
Corrected focus, full-suite freeze and fresh actual selected assembly/timing
remain separate acceptance gates. Wider _plain JIT helper calls remain an
explicit cost to measure. Preserve the frozen578 regression archive.
