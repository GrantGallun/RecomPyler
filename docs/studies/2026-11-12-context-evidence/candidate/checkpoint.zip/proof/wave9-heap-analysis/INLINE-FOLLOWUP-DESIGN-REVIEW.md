# Independent review: heap SSA values in guaranteed inline helpers

Read wave9-inline-context-analysis/DESIGN.md and the drafted
tests/test_heap_inline_context.py before root's RED execution gate.
Verdict: clear for fail-first source/native validation. No tests/compiler/native
execution performed by this reviewer.

The exact original _INLINED decorator prefix is the correct eligibility test.
Nonrecursive is insufficient because large helpers and entries are not always
inline; merged SCC wrappers can be inline even when the entry is a wrapper.
Preserving the old marker and making routing depend on the CALLEE handles
inline→inline, inline→recursive, recursive→inline and merged wrapper→dispatcher.
Public raw-pointer/length initialization after the unchanged guards supplies
the inline-entry case without undefined locals or a second descriptor.

Every function still receives ctx for recursive forwarding. Only guaranteed
inline helpers additionally receive the five immutable pointer/length values
already held by the caller. This does not freeze arena/header/field/status
contents, assume F/I disjointness, or change iteration reloads. Addresses stay
stable through one synchronous attempt; growth ends it and a new adapter entry
reinitializes values. The typed descriptor's schema, lifetime and cache identity
remain as reviewed. There is no new custom type, registry or alias metadata.

The source graph tests cover the main hazards, including a large noninline
control, merged inline entry wrapper and raw values from the public adapter.
The native helper-interface assertion should fail on578's ctx-only helper;
the recursive interface must remain narrow. _plain does remove inline markers
for JIT/profile compilation, so wider calls there are a real performance
tradeoff, not a reason to broaden the inline predicate or alter _plain.

_inlined_entry executes the unmodified generated source, retaining AOT-style
inline hints. Its fixture calls a mutable helper eight times; the scanner
tracks ctx-derived GEP/bitcast addresses and counts loads from the descriptor,
not loads from pointers read out of it. That is appropriate for this bounded
fixture. It is not a general LLVM alias/dataflow verifier (phi/select/address
arithmetic are outside its model). Observe actual <=5 RED on578 before relying
on it; aggregate loads/optimizer spelling can otherwise make a count assertion
pass for the wrong reason. Outputs and mutated cell state are checked too.

Remaining gates: executed RED/GREEN, product diff review, focused SCC/default/
dtype/alias/growth/error/AOT/cache tests, frozen full suite, then fresh actual
selected assembly/timings. Preserve578's measured ray regression and archive.
Actual force should retain two outgoing words; new render/SCC must demonstrate
reduced descriptor reads and report frames/spills/code size even if runtime
does not recover. Profile/build and whole-process costs remain separate.
