"""Run only after the coordinator's explicit heavy CPU release."""
import argparse
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import subprocess
import sys
import time


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inventory(candidate):
    return {
        path.relative_to(candidate).as_posix(): digest(path)
        for folder in (candidate / "src", candidate / "tests")
        for path in sorted(folder.rglob("*"))
        if path.is_file() and "__pycache__" not in path.parts
        and (path.suffix in {".py", ".c", ".pyd"} or path.name == "LICENSE.numba")
    }


def save(path, data):
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--candidate", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--cpu-release", required=True)
    parser.add_argument("tests", nargs="+")
    args = parser.parse_args()
    candidate = args.candidate.resolve()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    validation = candidate / "build" / "wave9-validation"
    temporary = validation / "temp"
    temporary.mkdir(parents=True, exist_ok=True)
    env = dict(os.environ, PYTHONPATH=str(candidate / "src"),
               RECOMPYLER_CACHE=str(validation / "region-cache"),
               NUMBA_CACHE_DIR=str(validation / "numba-cache"),
               TMP=str(temporary), TEMP=str(temporary))
    command = [sys.executable, "-m", "pytest", "-q", *args.tests]
    before = inventory(candidate)
    save(output / "before-inputs.json", before)
    receipt = {
        "cpu_release": args.cpu_release,
        "command": command,
        "cwd": str(candidate),
        "parent_pid": os.getpid(),
        "runtime": {"executable": sys.executable, "executable_sha256": digest(Path(sys.executable)),
                    "version": sys.version,
                    "packages": {name: importlib.metadata.version(name)
                                 for name in ("numba", "llvmlite", "numpy", "pytest")}},
        "environment": {name: env[name] for name in
                        ("PYTHONPATH", "RECOMPYLER_CACHE", "NUMBA_CACHE_DIR", "TMP", "TEMP")},
        "runner_sha256": digest(Path(__file__)),
    }
    save(output / "receipt.json", receipt)
    print(json.dumps({"started": command, "output": str(output)}), flush=True)
    started = time.perf_counter()
    with (output / "stdout.log").open("wb") as stdout, (output / "stderr.log").open("wb") as stderr:
        process = subprocess.Popen(command, cwd=candidate, env=env, stdout=stdout, stderr=stderr)
        receipt["pytest_pid"] = process.pid
        save(output / "receipt.json", receipt)
        result = process.wait()
    after = inventory(candidate)
    save(output / "after-inputs.json", after)
    receipt.update(exit_code=result, elapsed_seconds=time.perf_counter() - started,
                   inputs_unchanged=before == after,
                   changed_inputs=sorted(key for key in before.keys() | after.keys()
                                         if before.get(key) != after.get(key)),
                   stdout_sha256=digest(output / "stdout.log"), stderr_sha256=digest(output / "stderr.log"))
    save(output / "receipt.json", receipt)
    print(json.dumps({key: receipt[key] for key in
                      ("exit_code", "elapsed_seconds", "inputs_unchanged", "changed_inputs")}), flush=True)
    print((output / "stdout.log").read_text(encoding="utf-8", errors="replace"))
    print((output / "stderr.log").read_text(encoding="utf-8", errors="replace"), file=sys.stderr)
    return result if result else (0 if before == after else 1)


if __name__ == "__main__":
    raise SystemExit(main())
