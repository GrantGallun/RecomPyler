"""Capture only frozen raw inputs and follow-up evidence; never import native tools."""
import hashlib
import json
from pathlib import Path
import subprocess
import time
import zipfile


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    started = time.perf_counter()
    analysis = Path(__file__).resolve().parent
    root = analysis.parent
    freeze = json.loads((analysis / "candidate-freeze.json").read_text(encoding="utf-8-sig"))
    candidate = Path(freeze["candidate"])
    assert freeze["commit"] == "0373788b7be436e5e43b0a6a6f3fd40b2871c3a3"
    assert freeze["input_count"] == 61 and "599 passed" in freeze["full_suite"]
    full = json.loads((analysis / "full-suite" / "receipt.json").read_text())
    assert full["exit_code"] == 0 and full["inputs_unchanged"]
    base_receipt_path = root / "wave9-recursive-analysis" / "checkpoint-receipt.json"
    base_receipt = json.loads(base_receipt_path.read_text())
    assert sha(Path(base_receipt["zip"]).read_bytes()) == base_receipt["sha256"]
    destination = analysis / "wave9-inline-candidate-checkpoint.zip"
    receipt_path = analysis / "checkpoint-receipt.json"
    assert not destination.exists() and not receipt_path.exists()
    files, origins = {}, {}

    def add(name, data, origin):
        assert name not in files
        files[name] = data
        origins[name] = {"origin": origin, "sha256": sha(data), "bytes": len(data)}

    for relative, expected in sorted(freeze["inputs"].items()):
        path = candidate / relative
        data = path.read_bytes()
        assert sha(data) == expected, relative
        add("candidate/" + relative, data, str(path))
    for path in sorted(analysis.rglob("*")):
        if (path.is_file() and path.name not in {destination.name, receipt_path.name}
                and not {"__pycache__", "build", "temp", "cache"}.intersection(path.relative_to(analysis).parts)
                and path.suffix not in {".pyc", ".zip"}):
            add("analysis/" + path.relative_to(analysis).as_posix(), path.read_bytes(), str(path))
    for folder, names in (
        ("wave9-heap-analysis", ("INLINE-FOLLOWUP-DESIGN-REVIEW.md", "INLINE-FOLLOWUP-PRODUCT-REVIEW.md")),
        ("wave9-independent-review", ("INLINE-CONTEXT-REVIEW.md", "inline-focused-verification.json")),
    ):
        for name in names:
            path = root / folder / name
            add("proof/" + folder + "/" + name, path.read_bytes(), str(path))
    for path in sorted(root.glob("wave9-root-inline*verification.json")):
        add("proof/root/" + path.name, path.read_bytes(), str(path))
    for path in (root / "WAVE9-PLAN.md", root / "wave9-recursive-analysis" / "run_native_validation.py",
                 base_receipt_path):
        add("proof/shared/" + path.name, path.read_bytes(), str(path))
    for name, command in (
        ("inline-context.patch", ["git", "diff", "--binary", freeze["base"], freeze["commit"], "--", "src", "tests"]),
        ("commit.txt", ["git", "show", "--no-patch", "--format=fuller", freeze["commit"]]),
    ):
        add("git/" + name, subprocess.check_output(command, cwd=candidate), command)
    manifest = {"commit": freeze["commit"], "base": freeze["base"], "candidate_input_count": 61,
                "base_checkpoint_sha256": base_receipt["sha256"],
                "notes": "Exact raw source/test/native bytes. No build/cache/temp or native performance outputs. Base578 checkpoint preserved independently.",
                "members": origins}
    add("manifest.json", (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode(), "generated manifest")
    with zipfile.ZipFile(destination, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name, data in sorted(files.items()):
            archive.writestr(name, data)
    with zipfile.ZipFile(destination) as archive:
        assert set(archive.namelist()) == set(files)
        for name, expected in origins.items():
            data = archive.read(name)
            assert len(data) == expected["bytes"] and sha(data) == expected["sha256"], name
        assert archive.testzip() is None
    for relative, expected in freeze["inputs"].items():
        assert sha((candidate / relative).read_bytes()) == expected, relative
    receipt = {"zip": str(destination), "sha256": sha(destination.read_bytes()),
               "bytes": destination.stat().st_size, "member_count": len(files), "candidate_input_count": 61,
               "commit": freeze["commit"], "base_checkpoint_preserved": True,
               "verified_all_members_without_extraction": True, "members": origins,
               "elapsed_seconds": time.perf_counter() - started}
    receipt_path.write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n")
    print(json.dumps({key: value for key, value in receipt.items() if key != "members"}, indent=2))


if __name__ == "__main__":
    main()
